// Values from the text inside a tag, as display-regex cards write them:
// <Tag>a|b|c</Tag>, or one item a line as `rows`. Each
// item also has its parts by place ({{1}}…), its line ({{text}}) and a mark
// named after its first part ({{#a}}). And swaps (`value=shown`).

import { type ComponentField, exampleValue } from "./fields";
import type { BodyFormat } from "./model";

/** A line's parts: split at the separator, the last part keeping any further ones (`count` 0: no limit). */
export function splitParts(line: string, sep: string, count: number): string[] {
  const parts = line.split(sep);
  if (count > 0 && parts.length > count) parts.splice(count - 1, parts.length, parts.slice(count - 1).join(sep));
  return parts.map((p) => p.trim());
}

/** A part as a value of its field's kind (text when it does not read as that kind). */
function typed(f: ComponentField | undefined, raw: string): unknown {
  return f && f.type !== "text" ? exampleValue({ ...f, example: raw }) : raw;
}

/** A mark for a line's first part: a short word with no spaces. */
const markOf = (part: string) => (part && part.length <= 40 && !/\s/.test(part) ? part : null);

function item(line: string, format: BodyFormat, fields: ComponentField[]): Record<string, unknown> {
  const parts = splitParts(line, format.sep, fields.length);
  const out: Record<string, unknown> = { text: line };
  parts.forEach((p, i) => (out[String(i + 1)] = p));
  fields.forEach((f, i) => (out[f.name] = typed(f, parts[i] ?? "")));
  const mark = markOf(parts[0] ?? "");
  if (mark && !(mark in out)) out[mark] = true;
  return out;
}

/** The text inside a tag as the component's values. */
export function bodyValues(body: string, format: BodyFormat, fields: ComponentField[]): Record<string, unknown> {
  // a written-out \n (as some cards' examples have it) is a line break too
  const text = body.replace(/\r\n?/g, "\n").replace(/\\n/g, "\n").trim();
  if (format.lines) return { rows: text.split("\n").map((l) => l.trim()).filter(Boolean).map((l) => item(l, format, fields)), text };
  return { ...item(text, format, fields), text };
}

/** What the AI writes inside the tag, from the example (or the values' examples). */
export function bodyExample(format: BodyFormat, fields: ComponentField[]): string {
  if (format.sample.trim()) return format.sample.trim();
  return fields.map((f) => f.example.replace(/\n/g, " ")).join(format.sep === ":" ? ": " : "|");
}

/** The pairs of a field's swaps. */
function swapsOf(f: ComponentField): Map<string, string> {
  const out = new Map<string, string>();
  for (const line of (f.swaps ?? "").split("\n")) {
    const at = line.indexOf("=");
    if (at > 0) out.set(line.slice(0, at).trim().toLowerCase(), line.slice(at + 1).trim());
  }
  return out;
}

/** The values with each field's swaps applied (also in the items of `rows`). */
export function applySwaps(values: Record<string, unknown>, fields: ComponentField[]): Record<string, unknown> {
  const swapping = fields.filter((f) => f.swaps?.trim());
  if (!swapping.length) return values;
  const tables = new Map(swapping.map((f) => [f.name, swapsOf(f)]));
  const swap = (o: Record<string, unknown>) => {
    const next = { ...o };
    for (const [name, table] of tables) {
      const v = next[name];
      if (typeof v === "string" || typeof v === "number") {
        const to = table.get(String(v).trim().toLowerCase());
        if (to !== undefined) next[name] = to;
      }
    }
    return next;
  };
  const out = swap(values);
  if (Array.isArray(out.rows)) out.rows = out.rows.map((r) => (r && typeof r === "object" ? swap(r as Record<string, unknown>) : r));
  return out;
}
