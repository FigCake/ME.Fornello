// Marinara's own features through its /api: agents (the trackers among them),
// image generation, voice and chat summaries.

import { api } from "../shared/api";
import { getMarinara } from "../shared/marinara-global";
import { refreshQueries } from "../shared/react-bridge";
import { t } from "../shared/i18n";
import { trackerWritten } from "../host/generation-hold";
import { chatDetail, forgetDetail } from "./chat-store";
import { parseObject } from "./parse";

const enc = encodeURIComponent;
const send = (path: string, init: RequestInit) => (getMarinara().fetch ?? fetch)(`/api${path}`, { credentials: "same-origin", cache: "no-store", ...init });

// ── agents ──

export interface AgentInfo {
  type: string;
  name: string;
  category: string;
}

/** The agents Marinara knows: built in (from its capability packages) and made by the person. */
export async function agentList(): Promise<AgentInfo[]> {
  const [built, configs] = await Promise.all([
    api<Record<string, unknown>[]>("/capability-packages/agents").catch(() => []),
    api<Record<string, unknown>[]>("/agents").catch(() => []),
  ]);
  const out = new Map<string, AgentInfo>();
  for (const a of built ?? []) if (!a.libraryHidden) out.set(String(a.id), { type: String(a.id), name: String(a.name ?? a.id), category: String(a.category ?? "") });
  for (const c of configs ?? []) {
    const type = String(c.type ?? "");
    if (type && !out.has(type)) out.set(type, { type, name: String(c.name ?? type), category: "custom" });
  }
  return [...out.values()];
}

/** The agents on in a chat, and which trackers it only runs by hand. */
export async function chatAgents(chatId: string): Promise<{ on: string[]; manual: string[] }> {
  const meta = parseObject((await chatDetail(chatId)).metadata);
  const on = meta.enableAgents ? (Array.isArray(meta.activeAgentIds) ? meta.activeAgentIds.map(String) : []) : [];
  const manualTypes = parseObject(meta.manualTrackerAgentTypes);
  const manual = on.filter((type) => meta.manualTrackers === true || manualTypes[type] === true);
  return { on, manual };
}

/** Runs agents again on the chat's latest reply, as Marinara's "Re-run"; their errors come back. */
export async function rerunAgents(chatId: string, types: string[]): Promise<string[]> {
  if (!types.length) return [];
  const res = await send("/generate/retry-agents", {
    method: "POST",
    headers: { "Content-Type": "application/json", "x-marinara-csrf": "1" },
    body: JSON.stringify({ chatId, agentTypes: types, streaming: false, debugMode: false }),
  });
  if (!res.ok || !res.body) {
    const body = parseObject(await res.text().catch(() => ""));
    throw new Error(String(body.error ?? `${res.status}`));
  }
  const errors: string[] = [];
  const reader = res.body.getReader();
  const decoder = new TextDecoder();
  let buffer = "";
  for (;;) {
    const { done, value } = await reader.read();
    if (done) break;
    buffer += decoder.decode(value, { stream: true });
    let cut: number;
    while ((cut = buffer.indexOf("\n\n")) >= 0) {
      const chunk = buffer.slice(0, cut);
      buffer = buffer.slice(cut + 2);
      for (const line of chunk.split("\n")) {
        if (!line.startsWith("data:")) continue;
        const event = parseObject(line.slice(5).trim());
        if (event.type === "agent_error" || event.type === "error") {
          const data = parseObject(event.data);
          errors.push(String(data.error ?? data.message ?? event.data ?? "error"));
        }
      }
    }
  }
  trackerWritten(chatId);
  refreshQueries([["chats", chatId], ["game-state"], ["agents"]]);
  return errors;
}

export async function agentMemory(type: string, chatId: string): Promise<Record<string, unknown>> {
  try {
    return parseObject((await api<{ memory?: unknown }>(`/agents/memory/${enc(type)}/${enc(chatId)}`)).memory);
  } catch (e) {
    // an agent never set up has no memory yet
    if ((e as { status?: number }).status === 404) return {};
    throw e;
  }
}

export async function patchAgentMemory(type: string, chatId: string, patch: Record<string, unknown>): Promise<Record<string, unknown>> {
  const res = await api<{ memory?: unknown }>(`/agents/memory/${enc(type)}/${enc(chatId)}`, { method: "PATCH", body: { patch } });
  refreshQueries([["agents"]]);
  return parseObject(res?.memory);
}

export async function clearAgentMemory(type: string, chatId: string): Promise<void> {
  await api(`/agents/memory/${enc(type)}/${enc(chatId)}`, { method: "DELETE" });
  refreshQueries([["agents"]]);
}

// ── images and voice ──

/** Makes a picture with the chat's image connection; it is kept in the chat's gallery. */
export async function generateImage(chatId: string, prompt: string, title?: string): Promise<{ url: string; id: string }> {
  const image = await api<{ id?: string; url?: string }>(`/gallery/${enc(chatId)}/generate-image`, { method: "POST", body: { prompt, ...(title ? { title } : {}) } });
  refreshQueries([["gallery"], ["chat-gallery"]]);
  return { url: String(image?.url ?? ""), id: String(image?.id ?? "") };
}

/** The text spoken with Marinara's voice settings, as audio. */
export async function speech(text: string, voice?: string): Promise<Blob> {
  const res = await send("/tts/speak", {
    method: "POST",
    headers: { "Content-Type": "application/json", "x-marinara-csrf": "1" },
    body: JSON.stringify({ text: text.slice(0, 4096), ...(voice ? { voice } : {}) }),
  });
  if (!res.ok) {
    const body = parseObject(await res.text().catch(() => ""));
    throw new Error(String(body.error ?? t(`Voice failed: ${res.status}`, `음성 실패: ${res.status}`)));
  }
  return res.blob();
}

// ── summaries ──

export interface SummaryEntry {
  id: string;
  title: string;
  text: string;
  on: boolean;
}

export async function summaryEntries(chatId: string): Promise<SummaryEntry[]> {
  const meta = parseObject((await chatDetail(chatId)).metadata);
  const list = Array.isArray(meta.summaryEntries) ? (meta.summaryEntries as Record<string, unknown>[]) : [];
  if (!list.length && typeof meta.summary === "string" && meta.summary.trim()) return [{ id: "summary", title: "", text: meta.summary, on: true }];
  return list.map((e) => ({ id: String(e.id), title: String(e.title ?? ""), text: String(e.content ?? ""), on: e.enabled !== false }));
}

/** Marinara writes a summary of the latest `last` messages (its summary settings) and adds it. */
export async function makeChatSummary(chatId: string, last?: number): Promise<string> {
  const res = await api<{ summary?: string }>(`/chats/${enc(chatId)}/generate-summary`, { method: "POST", body: last ? { contextSize: last } : {} });
  forgetDetail(chatId);
  refreshQueries([["chats", "detail", chatId]]);
  return String(res?.summary ?? "");
}

/** One change to the chat's summaries (Marinara's summary-entries operations). */
export async function editSummaries(chatId: string, change: Record<string, unknown>): Promise<void> {
  await api(`/chats/${enc(chatId)}/summary-entries`, { method: "PATCH", body: change });
  forgetDetail(chatId);
  refreshQueries([["chats", "detail", chatId]]);
}
