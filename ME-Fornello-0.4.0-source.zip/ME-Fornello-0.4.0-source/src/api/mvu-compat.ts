// Pages of cards made for MVU wait for it (waitGlobalInitialized("Mvu")) and read
// getAllVariables().stat_data. MVU doesn't run here: they get Pesto's values at their message.
// MVU's names and usage only, none of its code.

import { pairShape } from "../ejs/service";
import { onStoryChange, storyAccess } from "../state/access";
import { getAny } from "./commands/variables";
import { getPath } from "./var-ops";
import { messageAt, type PageSession } from "./session";

type Obj = Record<string, unknown>;

/** Each page's values, read when it waited for MVU (getAllVariables answers at once). */
const pages = new WeakMap<PageSession, Obj>();
/** Pages already listening for Pesto's changes. */
const watched = new WeakSet<PageSession>();

/** Pesto's values after the page's message (the last for a page outside the chat), shaped as the card's own data; null without Pesto. */
async function pestoValues(s: PageSession): Promise<Obj | null> {
  const access = storyAccess();
  if (!access || s.preview) return null;
  const chatId = s.here();
  if (!(await access.has(chatId))) return null;
  // the page's own message; a page outside the chat (null) reads after the last
  const own = s.ownNum();
  const id = own ? messageAt(await s.freshMessages(), own).id : null;
  const view = await access.at(chatId, id);
  if (!view) return null;
  const card = access.cardOf ? await access.cardOf(chatId).catch(() => null) : null;
  return (card?.pairs ? pairShape(view.values) : structuredClone(view.values)) as Obj;
}

/** What a page gets for waitGlobalInitialized("Mvu") when MVU itself isn't there: its reading calls, on Pesto's values. */
export async function mvuStandIn(s: PageSession): Promise<unknown> {
  const values = await pestoValues(s).catch(() => null);
  if (values) pages.set(s, values);
  // the values at its message changed: the page draws again
  if (!s.preview && !watched.has(s)) {
    watched.add(s);
    const chatId = s.here();
    s.onDispose(
      onStoryChange((id) => {
        if (id !== chatId || s.disposed) return;
        void pestoValues(s)
          .then((next) => {
            if (!next || s.disposed || JSON.stringify(next) === JSON.stringify(pages.get(s) ?? null)) return;
            pages.set(s, next);
            s.reload?.();
          })
          .catch(() => undefined);
      }),
    );
  }
  const data = () => ({ stat_data: structuredClone(pages.get(s) ?? {}), display_data: {}, delta_data: {} });
  const mvu = {
    getMvuData: () => data(),
    getMvuVariable: (from: unknown, path: unknown, options?: { default_value?: unknown }) => {
      const stat = (from as { stat_data?: unknown } | null)?.stat_data ?? from ?? data().stat_data;
      const found = typeof path === "string" ? getPath(stat, path.replace(/^stat_data\./, "")) : undefined;
      return found === undefined ? options?.default_value : found;
    },
  };
  if (!s.disposed) s.define("Mvu", mvu);
  return mvu;
}

/** getAllVariables(): the global, character, chat and the page's message variables merged (later ones win), with stat_data. */
export function allVariables(s: PageSession): Obj {
  const own = s.ownNum();
  // a kind that can't be read (no message yet, no character) adds nothing
  const read = (options: Obj) => {
    try {
      return getAny(s, options);
    } catch {
      return {};
    }
  };
  const out: Obj = {
    ...read({ type: "global" }),
    ...(s.cast[0] ? read({ type: "character" }) : {}),
    ...read({ type: "chat" }),
    ...(own ? read({ type: "message", message_id: own - 1 }) : {}),
  };
  const stat = pages.get(s);
  if (stat) out.stat_data = structuredClone(stat);
  return out;
}
