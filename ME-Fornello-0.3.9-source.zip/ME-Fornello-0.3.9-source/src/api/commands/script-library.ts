// Page commands for the script lists (the person's, the card's, the chat's),
// also under the names SillyTavern scripts use. A page in a message asks once before
// changing a list.

import { t } from "../../shared/i18n";
import { cmd } from "../command";
import { updateChatData } from "../chat-data";
import { characterData, saveCharacter } from "../library";
import type { PageSession } from "../session";
import { libraryStore } from "../../scripts/library-store";
import { type GlobalScript, type LibraryItem, cardTree, mapLibrary, normalizeLibrary, toScriptTrees, withCardTree } from "../../scripts/model";

export type ScriptScope = "global" | "char" | "chat";

/** A scope by Fornello's name or as { type: "character" }. */
function scopeOf(raw: unknown): ScriptScope | "preset" {
  const name = String((typeof raw === "string" ? raw : (raw as { type?: unknown } | undefined)?.type) ?? "global");
  if (name === "global" || name === "chat" || name === "preset") return name;
  if (name === "char" || name === "character") return "char";
  throw new Error(t(`Use "global", "char" or "chat"`, `"global", "char", "chat" 중 하나`));
}

function store() {
  const found = libraryStore();
  if (!found) throw new Error(t("Scripts are not ready.", "스크립트가 아직 준비되지 않음."));
  return found;
}

function chatCharacter(s: PageSession) {
  const c = s.cast[0];
  if (!c) throw new Error(t("No character in this chat.", "이 채팅에 캐릭터 없음."));
  return c;
}

function getScripts(s: PageSession, scope: unknown = "global"): LibraryItem[] {
  const which = scopeOf(scope);
  if (which === "preset") return [];
  if (which === "char") return s.cast[0] ? cardTree(s.cast[0].data) : [];
  return structuredClone(which === "chat" ? s.chatScripts : store().global());
}

/** The list becomes `items` (scripts and folders, in Fornello's shape or SillyTavern's). */
async function setScripts(s: PageSession, items: unknown, scope: unknown = "global"): Promise<boolean> {
  const which = scopeOf(scope);
  if (which === "preset") throw new Error(t("Not supported: preset scripts", "지원 안 함: 프리셋 스크립트"));
  const list = normalizeLibrary(Array.isArray(items) ? items : [items]);
  const where = which === "global" ? t("your scripts (every chat)", "내 스크립트(모든 채팅)") : which === "char" ? t(`the scripts of "${chatCharacter(s).name}"`, `"${chatCharacter(s).name}" 카드의 스크립트`) : t("this chat's scripts", "이 채팅의 스크립트");
  if (!s.allowOnce(`scripts:${which}`, t(`This page wants to change ${where}. Allow?`, `이 페이지가 ${where}를 고치려고 해요. 허락할까요?`))) return false;
  if (which === "global") await store().setGlobal(list);
  else if (which === "char") {
    const c = chatCharacter(s);
    const data = withCardTree(await characterData(c.id), list);
    await saveCharacter(c.id, data);
    c.data = data;
  } else {
    await updateChatData(s.here(), (d) => ({ ...d, scripts: list }));
    s.chatScripts = list;
  }
  if (which !== "global") store().refresh();
  return true;
}

/** The running script's own entry changed by `change`, wherever it is kept. */
async function changeOwn(s: PageSession, change: (g: GlobalScript) => GlobalScript): Promise<void> {
  const def = s.script?.def;
  if (!def) throw new Error(t("Scripts only.", "스크립트 전용."));
  const scope: ScriptScope = def.source === "card" ? "char" : def.source;
  const list = mapLibrary(getScripts(s, scope), (g) => (g.id === def.id ? change(g) : g));
  await setScripts(s, list, scope);
}

export function scriptLibraryCommands(s: PageSession) {
  const own = () => {
    if (!s.script) throw new Error(t("Scripts only.", "스크립트 전용."));
    return s.script.def;
  };
  return {
    // getScripts("global" | "char" | "chat") / setScripts([...], scope)
    getScripts: cmd((scope?: unknown) => getScripts(s, scope)),
    setScripts: cmd({ writes: true }, (items: unknown, scope?: unknown) => setScripts(s, items, scope)),
    // the SillyTavern names (type "global" | "character"; "preset" has none here)
    getScriptTrees: cmd((option?: unknown) => toScriptTrees(getScripts(s, option))),
    replaceScriptTrees: cmd({ writes: true }, (trees: unknown, option?: unknown) => setScripts(s, trees, option)),
    updateScriptTreesWith: cmd({ writes: true }, async (updater: (trees: Record<string, unknown>[]) => unknown, option?: unknown) => {
      const next = await updater(toScriptTrees(getScripts(s, option)));
      if (Array.isArray(next)) await setScripts(s, next, option);
      return toScriptTrees(getScripts(s, option));
    }),
    getAllEnabledScriptButtons: cmd(() => libraryStore()?.buttons() ?? {}),
    getScriptInfo: cmd(() => own().info),
    replaceScriptInfo: cmd({ writes: true }, async (info: unknown) => {
      own().info = String(info ?? "");
      await changeOwn(s, (g) => ({ ...g, info: String(info ?? "") }));
    }),
  };
}
