// Outside stylesheets (Google Fonts, Font Awesome…), which Marinara's CSP
// blocks: Fornello fetches them, puts the rules in a <style> and hands the
// fonts to the browser as FontFace objects. Fonts split by character range
// are fetched only for the characters on screen.

interface Face {
  family: string;
  url: string;
  descriptors: FontFaceDescriptors;
  /** Code point ranges this piece covers (none: all). */
  ranges: [number, number][];
}

interface Sheet {
  /** The stylesheet without its @font-face rules (url()s made absolute). */
  css: string;
  faces: Face[];
}

const sheets = new Map<string, Promise<Sheet>>();
const fontBytes = new Map<string, Promise<ArrayBuffer | null>>();

/** Fetched stylesheets and fonts are let go (Fornello turned off). */
export function forgetStylesheets(): void {
  sheets.clear();
  fontBytes.clear();
}

/** https stylesheets a page or component asks for: <link rel=stylesheet>, @import. */
export function stylesheetUrls(code: string): string[] {
  const urls = new Set<string>();
  for (const m of code.matchAll(/<link\b[^>]*>/gi)) {
    const tag = m[0];
    if (!/rel\s*=\s*["']?stylesheet/i.test(tag)) continue;
    // the markup may come serialized: &amp; (a Google Fonts URL with two families) is a plain &
    const href = /href\s*=\s*["']([^"']+)["']/i.exec(tag)?.[1]?.replace(/&amp;/gi, "&").replace(/&quot;/gi, '"').replace(/&#39;/g, "'");
    if (href && /^https:\/\//i.test(href)) urls.add(href);
  }
  for (const m of code.matchAll(/@import\s+(?:url\(\s*)?["']?(https:\/\/[^"')\s;]+)["']?\s*\)?/gi)) urls.add(m[1]);
  return [...urls];
}

/** @font-face rules in a stylesheet text, with url()s resolved against `base`. */
function fontFaces(text: string, base: string): Face[] {
  const out: Face[] = [];
  const unquote = (v: string) => v.trim().replace(/^["']|["']$/g, "");
  for (const m of text.matchAll(/@font-face\s*\{([^}]*)\}/gi)) {
    const body = m[1];
    const prop = (name: string) => new RegExp(`(?:^|;)\\s*${name}\\s*:\\s*([^;]+)`, "i").exec(body)?.[1]?.trim();
    const family = prop("font-family");
    const sources = [...(prop("src") ?? "").matchAll(/url\(\s*([^)]+?)\s*\)(?:\s*format\(\s*["']?([\w-]+)["']?\s*\))?/gi)].map((s) => ({ url: unquote(s[1]), format: (s[2] ?? "").toLowerCase() }));
    // prefer woff2, then woff, then whatever comes first
    const pick = sources.find((s) => s.format === "woff2") ?? sources.find((s) => s.format === "woff") ?? sources[0];
    if (!family || !pick) continue;
    let url: string;
    try {
      url = new URL(pick.url, base).href;
    } catch {
      continue;
    }
    const descriptors: FontFaceDescriptors = {};
    const weight = prop("font-weight");
    const style = prop("font-style");
    const range = prop("unicode-range");
    if (weight) descriptors.weight = weight;
    if (style) descriptors.style = style;
    if (range) descriptors.unicodeRange = range;
    descriptors.display = "swap";
    const ranges: [number, number][] = [];
    for (const r of (range ?? "").split(",")) {
      const t = r.trim().replace(/^u\+/i, "");
      if (!t) continue;
      if (t.includes("?")) ranges.push([parseInt(t.replace(/\?/g, "0"), 16), parseInt(t.replace(/\?/g, "f"), 16)]);
      else {
        const [a, b] = t.split("-");
        ranges.push([parseInt(a, 16), parseInt(b ?? a, 16)]);
      }
    }
    out.push({ family: unquote(family), url, descriptors, ranges });
  }
  return out;
}

async function loadSheet(url: string): Promise<Sheet> {
  const res = await fetch(url, { credentials: "omit", referrerPolicy: "no-referrer" });
  if (!res.ok) throw new Error(`HTTP ${res.status}`);
  const text = await res.text();
  const css = text
    .replace(/@font-face\s*\{[^}]*\}/gi, "")
    .replace(/url\(\s*([^)]+?)\s*\)/gi, (whole, u: string) => {
      const clean = u.trim().replace(/^["']|["']$/g, "");
      if (/^data:/i.test(clean)) return whole;
      try {
        return `url("${new URL(clean, url).href}")`;
      } catch {
        return whole;
      }
    });
  return { css, faces: fontFaces(text, url) };
}

function sheet(url: string): Promise<Sheet> {
  let found = sheets.get(url);
  if (!found) {
    found = loadSheet(url);
    found.catch(() => sheets.delete(url));
    sheets.set(url, found);
  }
  return found;
}

function bytes(url: string): Promise<ArrayBuffer | null> {
  let found = fontBytes.get(url);
  if (!found) {
    found = fetch(url, { credentials: "omit", referrerPolicy: "no-referrer" })
      .then((r) => (r.ok ? r.arrayBuffer() : null))
      .catch(() => null);
    fontBytes.set(url, found);
  }
  return found;
}

function codePoints(text: string): Set<number> {
  const out = new Set<number>();
  for (const ch of text) out.add(ch.codePointAt(0)!);
  return out;
}

const covers = (face: Face, points: Set<number>) => !face.ranges.length || [...points].some((p) => face.ranges.some(([a, b]) => p >= a && p <= b));

interface DocFonts {
  sheets: Set<string>;
  faces: Face[];
  added: Set<string>;
}

const perDoc = new WeakMap<Document, DocFonts>();
const rulesDone = new WeakMap<Node, Set<string>>();

/** Rules into `ruleTarget` (<head> or a component's shadow root), fonts into the document's font set; returns the URLs that failed. */
export async function applyStylesheets(urls: string[], doc: Document, ruleTarget: Node = doc.head, transform: (css: string) => string = (css) => css): Promise<string[]> {
  const failed: string[] = [];
  const fonts = perDoc.get(doc) ?? { sheets: new Set<string>(), faces: [], added: new Set<string>() };
  perDoc.set(doc, fonts);
  const done = rulesDone.get(ruleTarget) ?? new Set<string>();
  rulesDone.set(ruleTarget, done);
  await Promise.all(
    urls.map(async (url) => {
      try {
        const s = await sheet(url);
        if (!done.has(url)) {
          done.add(url);
          if (s.css.trim()) {
            const style = doc.createElement("style");
            style.dataset.fornelloSheet = url;
            style.textContent = transform(s.css);
            ruleTarget.appendChild(style);
          }
        }
        if (!fonts.sheets.has(url)) {
          fonts.sheets.add(url);
          fonts.faces.push(...s.faces);
        }
      } catch {
        failed.push(url);
      }
    }),
  );
  return failed;
}

/** @font-face rules a page writes itself (fonts from a CDN in its own <style>). */
export function addPageFonts(doc: Document, cssText: string, base: string): void {
  const faces = fontFaces(cssText, base).filter((f) => /^https:/i.test(f.url));
  if (!faces.length) return;
  const fonts = perDoc.get(doc) ?? { sheets: new Set<string>(), faces: [], added: new Set<string>() };
  perDoc.set(doc, fonts);
  const known = new Set(fonts.faces.map((f) => `${f.family}|${f.url}`));
  for (const f of faces) if (!known.has(`${f.family}|${f.url}`)) fonts.faces.push(f);
}

/** Fetches the font pieces the given text needs (and that are not there yet). */
export async function loadFontsFor(doc: Document, text: string): Promise<void> {
  const fonts = perDoc.get(doc);
  if (!fonts?.faces.length) return;
  const points = codePoints(text);
  const wanted = fonts.faces.filter((f) => !fonts.added.has(f.url) && covers(f, points));
  for (const f of wanted) fonts.added.add(f.url);
  const FontFaceCtor = (doc.defaultView as (Window & typeof globalThis) | null)?.FontFace ?? FontFace;
  let next = 0;
  await Promise.all(
    Array.from({ length: Math.min(6, wanted.length) }, async () => {
      while (next < wanted.length) {
        const f = wanted[next++];
        const data = await bytes(f.url);
        if (!data) continue;
        const face = new FontFaceCtor(f.family, data.slice(0), f.descriptors);
        doc.fonts.add(face);
        await face.load().catch(() => undefined);
      }
    }),
  );
}

/** Font faces given to a document by family (Marinara's own fonts), once each. */
const familiesAdded = new WeakMap<Document, Set<string>>();

/** Makes one of Marinara's font families usable in shadow roots (where @font-face does not reach) through the document's font set. */
export function addFamily(doc: Document, faces: { family: string; url: string; weight?: string; style?: string; unicodeRange?: string }[]): void {
  const added = familiesAdded.get(doc) ?? new Set<string>();
  familiesAdded.set(doc, added);
  const FontFaceCtor = (doc.defaultView as (Window & typeof globalThis) | null)?.FontFace ?? FontFace;
  for (const f of faces) {
    if (added.has(f.url)) continue;
    added.add(f.url);
    try {
      const descriptors: FontFaceDescriptors = { display: "swap" };
      if (f.weight) descriptors.weight = f.weight;
      if (f.style) descriptors.style = f.style;
      if (f.unicodeRange) descriptors.unicodeRange = f.unicodeRange;
      doc.fonts.add(new FontFaceCtor(f.family, `url("${new URL(f.url, location.href).href}")`, descriptors));
    } catch {
      // a face the browser does not take: the text keeps the theme's font
    }
  }
}
