// A card's templates that Marinara's macros can't say, run by Fornello in a Worker of their own
// (the same locks as Pesto's code: no network, no storage), each written into the Worker's
// script as a function (Marinara forbids eval). A template sees what SillyTavern's templates see
// most: getvar / setvar / incvar / decvar (the chat's variables, and `stat_data`: Pesto's
// values, as [value, note] pairs for an [InitVar] card), getwi (another entry, run too when it is a
// template), getchar, execute (a slash command), a small `_` (lodash's most used), `user` and `char`,
// and Fornello's page commands by name (generate, getChatMessages…), asked of the page and run there
// with their usual checks. One run gives every template's text and the variables it set.

import { lockSource } from "../state/code";
import { LockedWorker } from "../state/locked-worker";
import { codeProblem } from "../runtime/guard";
import { compileEjs } from "./template";

export interface TemplateData {
  /** what getvar reads: the chat's variables, and stat_data */
  scope: Record<string, unknown>;
  user: string;
  char: string;
  /** the card's fields, for getchar */
  card: Record<string, unknown>;
  /** entry name → template id, for getwi on a template */
  byName: Record<string, string>;
}

export interface TemplateResult {
  outputs: Record<string, string>;
  errors: Record<string, string>;
  /** variables setvar / incvar / decvar left changed */
  writes: Record<string, unknown>;
}

/** lodash's most used, small, for templates (`_.get`, `_.has`, `_.set`…). */
const LODASH = `
const __path = (p) => Array.isArray(p) ? p : String(p).replace(/\\[(\\w+)\\]/g, ".$1").split(".").filter((x) => x !== "");
const __isObj = (v) => !!v && typeof v === "object" && !Array.isArray(v);
const _ = {
  get(o, p, d) { let v = o; for (const k of __path(p)) { if (v === null || v === undefined) return d; v = v[k]; } return v === undefined ? d : v; },
  has(o, p) { let v = o; for (const k of __path(p)) { if (v === null || v === undefined || !Object.prototype.hasOwnProperty.call(Object(v), k)) return false; v = v[k]; } return true; },
  set(o, p, val) { const ks = __path(p); let v = o; ks.forEach((k, i) => { if (i === ks.length - 1) v[k] = val; else { if (v[k] === null || typeof v[k] !== "object") v[k] = /^\\d+$/.test(ks[i + 1]) ? [] : {}; v = v[k]; } }); return o; },
  cloneDeep(v) { return v === undefined ? v : JSON.parse(JSON.stringify(v)); },
  isEqual(a, b) { return JSON.stringify(a) === JSON.stringify(b); },
  isEmpty(v) { return v === null || v === undefined || (typeof v === "object" ? Object.keys(v).length === 0 : String(v).length === 0); },
  isNil(v) { return v === null || v === undefined; },
  isNumber(v) { return typeof v === "number"; },
  isString(v) { return typeof v === "string"; },
  isArray: Array.isArray,
  isObject(v) { return !!v && typeof v === "object"; },
  isPlainObject: __isObj,
  includes(c, v) { return Array.isArray(c) || typeof c === "string" ? c.includes(v) : __isObj(c) ? Object.values(c).includes(v) : false; },
  keys(o) { return o ? Object.keys(o) : []; },
  values(o) { return o ? Object.values(o) : []; },
  entries(o) { return o ? Object.entries(o) : []; },
  toPairs(o) { return o ? Object.entries(o) : []; },
  size(c) { return c ? (Array.isArray(c) || typeof c === "string" ? c.length : Object.keys(c).length) : 0; },
  sum(a) { return (a || []).reduce((s, x) => s + Number(x || 0), 0); },
  sumBy(a, f) { return (a || []).reduce((s, x) => s + Number((typeof f === "function" ? f(x) : x[f]) || 0), 0); },
  max(a) { return a && a.length ? Math.max(...a) : undefined; },
  min(a) { return a && a.length ? Math.min(...a) : undefined; },
  clamp(n, lo, hi) { return Math.min(Math.max(n, lo), hi); },
  round(n, p = 0) { const m = 10 ** p; return Math.round(n * m) / m; },
  floor: Math.floor, ceil: Math.ceil,
  toNumber(v) { return Number(v); },
  random(a = 0, b = 1, f) { if (b === undefined) { b = a; a = 0; } const r = a + Math.random() * (b - a); return f || !Number.isInteger(a) || !Number.isInteger(b) ? r : Math.floor(a + Math.random() * (b - a + 1)); },
  sample(a) { return a && a.length ? a[Math.floor(Math.random() * a.length)] : undefined; },
  shuffle(a) { const c = [...(a || [])]; for (let i = c.length - 1; i > 0; i--) { const j = Math.floor(Math.random() * (i + 1)); [c[i], c[j]] = [c[j], c[i]]; } return c; },
  range(a, b, s = 1) { if (b === undefined) { b = a; a = 0; } const out = []; for (let i = a; s > 0 ? i < b : i > b; i += s) out.push(i); return out; },
  uniq(a) { return [...new Set(a || [])]; },
  map(c, f) { return (Array.isArray(c) ? c : Object.values(c || {})).map(typeof f === "function" ? f : (x) => x[f]); },
  filter(c, f) { return (Array.isArray(c) ? c : Object.values(c || {})).filter(f); },
  find(c, f) { return (Array.isArray(c) ? c : Object.values(c || {})).find(f); },
  sortBy(c, f) { const k = typeof f === "function" ? f : (x) => x[f]; return [...(c || [])].sort((x, y) => (k(x) > k(y) ? 1 : k(x) < k(y) ? -1 : 0)); },
  merge(o, ...more) { for (const m of more) for (const [k, v] of Object.entries(m || {})) o[k] = __isObj(v) && __isObj(o[k]) ? _.merge(o[k], v) : v; return o; },
  capitalize(s) { s = String(s || ""); return s.charAt(0).toUpperCase() + s.slice(1).toLowerCase(); },
  trim(s) { return String(s || "").trim(); },
};`;

/** The Worker's script: the locks, lodash's few, the templates as functions, then the answering. */
export function templateSource(templates: { id: string; source: string }[], commands: string[]): string {
  const fns = templates.map((tpl) => `${JSON.stringify(tpl.id)}: ${templateFunction(tpl.source)}`).join(",\n");
  return `${lockSource()}
const __answer = self.postMessage.bind(self);
${LODASH}
const __s = (v) => (v === undefined || v === null ? "" : typeof v === "object" ? JSON.stringify(v) : String(v));
let __next = 0;
const __calls = new Map();
const __call = (name, args) => new Promise((resolve, reject) => { const callId = ++__next; __calls.set(callId, { resolve, reject }); __answer({ call: name, callId, args: JSON.parse(JSON.stringify(args === undefined ? [] : args)) }); });
const __commands = ${JSON.stringify(commands)};
const __templates = {
${fns}
};
self.onmessage = async (e) => {
  const d = e.data || {};
  if (d.callId) { const c = __calls.get(d.callId); if (!c) return; __calls.delete(d.callId); if (d.error) c.reject(new Error(d.error)); else c.resolve(d.result); return; }
  const { id, ids, data } = d;
  const writes = {};
  const getvar = (key, opts) => { const v = _.get(data.scope, key); return v === undefined ? (opts && opts.defaults) : _.cloneDeep(v); };
  const setvar = (key, value) => { if (String(key).split(".")[0] === "stat_data") throw new Error("stat_data is Pesto's: change it in a reply's block"); _.set(data.scope, key, value); writes[__path(key)[0]] = data.scope[__path(key)[0]]; return value; };
  const incvar = (key, n = 1) => setvar(key, Number(getvar(key) || 0) + Number(n));
  const decvar = (key, n = 1) => setvar(key, Number(getvar(key) || 0) - Number(n));
  let depth = 0;
  const run = async (tid) => {
    if (++depth > 8) throw new Error("templates call each other too deep");
    try { return await __templates[tid](h); } finally { depth--; }
  };
  const getwi = async (a, b) => { const name = b === undefined ? a : b; const tid = data.byName[name]; return tid && __templates[tid] ? run(tid) : __s(await __call("__entry", [b === undefined ? null : a, name])); };
  const h = { getvar, setvar, incvar, decvar, getwi, getWorldInfo: getwi, getchar: (k) => (k ? data.card[k] : data.card), execute: (cmd) => __call("triggerSlash", [cmd]), user: data.user, char: data.char, _ };
  for (const name of __commands) if (!(name in h)) h[name] = (...args) => __call(name, args);
  const outputs = {};
  const errors = {};
  for (const tid of ids) {
    try { outputs[tid] = __s(await run(tid)); } catch (err) { errors[tid] = String((err && err.message) || err); }
  }
  __answer({ id, outputs, errors, writes: JSON.parse(JSON.stringify(writes)) });
};`;
}

/** The function a template becomes, as written into the Worker's script. */
const templateFunction = (source: string) => `async function (__h) { with (__h) {\n${compileEjs(source)}\n} }`;

/** Why a template can't run (it doesn't read as code, or it loads a module), or null. */
export function templateProblem(source: string): string | null {
  try {
    return codeProblem(`(${templateFunction(source)})`);
  } catch (e) {
    return e instanceof Error ? e.message : String(e);
  }
}

/** Runs a card's templates in their locked Worker; one that can't run is left out (and said so), the others go on. */
export class TemplateRunner {
  private worker: LockedWorker;
  private problems: Record<string, string> = {};

  constructor(templates: { id: string; source: string }[], commands: string[]) {
    for (const tpl of templates) {
      const problem = templateProblem(tpl.source);
      if (problem) this.problems[tpl.id] = problem;
    }
    const good = templates.filter((tpl) => !this.problems[tpl.id]);
    this.worker = new LockedWorker(() => templateSource(good, commands));
  }

  /** Every template's text (ids: which to run, in order); `call` answers the page commands they ask for. */
  async run(ids: string[], data: TemplateData, call: (name: string, args: unknown[]) => Promise<unknown>, timeMs: number): Promise<TemplateResult> {
    const errors: Record<string, string> = {};
    for (const id of ids) if (this.problems[id]) errors[id] = this.problems[id];
    const runnable = ids.filter((id) => !this.problems[id]);
    if (!runnable.length) return { outputs: {}, errors, writes: {} };
    const a = await this.worker.request({ ids: runnable, data }, timeMs, call);
    if (!a.ok) return { outputs: {}, errors: { ...errors, ...Object.fromEntries(runnable.map((id) => [id, a.error])) }, writes: {} };
    return { outputs: (a.data.outputs ?? {}) as Record<string, string>, errors: { ...errors, ...((a.data.errors ?? {}) as Record<string, string>) }, writes: (a.data.writes ?? {}) as Record<string, unknown> };
  }

  dispose(): void {
    this.worker.dispose();
  }
}
