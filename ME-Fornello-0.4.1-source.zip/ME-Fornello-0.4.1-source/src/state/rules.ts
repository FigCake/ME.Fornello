// Pesto's rules: what happens when the AI names an event, and what changes with every reply.
// A card writes them as YAML in its `pesto:rules` entry:
//
//   events:
//     rest:
//       params: { hours: 8 }            # names the AI may give, with defaults (a list of names works too)
//       when: "!dead"                   # refused when this is false
//       note: sleep; heals 5 an hour     # what it means, for the AI
//       do:
//         - add: { hp: hours * 5 }
//         - if: hp > max_hp
//           then:
//             - set: { hp: max_hp }
//     buy:                              # just the steps: every name given is readable
//       - sub: { gold: price }
//       - push: { bag: item }
//   each_reply:
//     - add: { turn: 1 }
//   dice:                               # rolled before each reply; the AI is told them, rules read dice.check
//     check: 1d20
//     loot: roll('1d6') + luck          # or an expression
//   triggers:                           # text for the AI while a condition holds
//     night_note:
//       when: night
//       text: It is night; monsters roam.
//     hurt:
//       when: hp < 20
//       entry: Hurt                    # a lorebook entry of the card or chat (kept off), copied in
//
// Steps: set, add (a number, or an item to a list), sub (takes away), push, pull (an item out of a
// list), remove (paths), if/then/else, do (another event, `with:` its values). A step's values are
// expressions (`"'forest'"` for a word as it is); numbers, yes/no and lists are taken as they are.
// A path may hold an expression in braces: `trust.{who}`.

import { exprProblem } from "./expr";

export type Step =
  | { kind: "set" | "add" | "sub" | "push" | "pull"; path: string; value: unknown }
  | { kind: "remove"; path: string }
  | { kind: "if"; test: string; then: Step[]; else: Step[] }
  | { kind: "do"; event: string; with: Record<string, unknown> };

export interface EventRule {
  params: Record<string, unknown>;
  when?: string;
  steps: Step[];
  /** what the event means, for the AI */
  note?: string;
}

export interface Trigger {
  when: string;
  /** the text itself, or the name of a lorebook entry whose text is used */
  text?: string;
  entry?: string;
  /** where it goes: with the character definitions ("before" / "after" them), or `depth` messages from the end */
  position?: "before" | "after" | "depth";
  depth?: number;
}

export interface Rules {
  events: Record<string, EventRule>;
  eachReply: Step[];
  /** name → dice ("2d6+1") or an expression, rolled before each reply */
  dice: Record<string, string>;
  triggers: Record<string, Trigger>;
}

/** "2d6+1", "d20": dice as they are written (anything else in `dice:` is an expression). */
export const DICE = /^\s*\d*\s*d\s*\d+\s*(?:[+-]\s*\d+)?\s*$/i;

export interface RuleProblem {
  path: string;
  why: string;
}

const isPlain = (v: unknown): v is Record<string, unknown> => !!v && typeof v === "object" && !Array.isArray(v);
const VALUE_STEPS = ["set", "add", "sub", "push", "pull"] as const;

export function readRules(raw: unknown): { rules: Rules; problems: RuleProblem[] } {
  const problems: RuleProblem[] = [];
  const rules: Rules = { events: Object.create(null), eachReply: [], dice: Object.create(null), triggers: Object.create(null) };
  if (raw === null || raw === undefined) return { rules, problems };
  if (!isPlain(raw)) {
    problems.push({ path: "", why: "the rules must be a set of names (events, each_reply)" });
    return { rules, problems };
  }
  for (const [name, def] of Object.entries(isPlain(raw.events) ? raw.events : {})) {
    const at = `events.${name}`;
    if (Array.isArray(def)) rules.events[name] = { params: {}, steps: readSteps(def, at, problems) };
    else if (isPlain(def)) {
      const params: Record<string, unknown> = {};
      if (Array.isArray(def.params)) for (const p of def.params) params[String(p)] = null;
      else if (isPlain(def.params)) Object.assign(params, def.params);
      let when: string | undefined;
      if (def.when !== undefined && def.when !== null) {
        when = String(def.when);
        const problem = exprProblem(when);
        if (problem) {
          problems.push({ path: `${at}.when`, why: problem });
          when = undefined;
        }
      }
      rules.events[name] = { params, when, steps: readSteps(def.do ?? def.steps ?? [], `${at}.do`, problems), ...(typeof def.note === "string" ? { note: def.note } : {}) };
    } else problems.push({ path: at, why: "an event is a list of steps, or params / when / do" });
  }
  rules.eachReply = readSteps(raw.each_reply ?? raw.every_reply ?? [], "each_reply", problems);
  for (const [name, spec] of Object.entries(isPlain(raw.dice) ? raw.dice : {})) {
    const src = String(spec ?? "");
    if (!/^[\p{L}_$][\p{L}\p{N}_$]*$/u.test(name)) problems.push({ path: `dice.${name}`, why: "a die's name is one word" });
    else if (!DICE.test(src) && exprProblem(src)) problems.push({ path: `dice.${name}`, why: `"${src}" is neither dice like 2d6+1 nor an expression` });
    else rules.dice[name] = src;
  }
  for (const [name, t] of Object.entries(isPlain(raw.triggers) ? raw.triggers : {})) {
    const at = `triggers.${name}`;
    if (!isPlain(t) || t.when === undefined || t.when === null) {
      problems.push({ path: at, why: "a trigger has `when` and `text` or `entry`" });
      continue;
    }
    const when = String(t.when);
    const problem = exprProblem(when);
    if (problem) problems.push({ path: `${at}.when`, why: problem });
    else if (typeof t.text !== "string" && typeof t.entry !== "string") problems.push({ path: at, why: "a trigger needs `text` or `entry`" });
    else {
      const position = t.position === "before" || t.position === "after" || t.position === "depth" ? t.position : undefined;
      const depth = Number(t.depth);
      rules.triggers[name] = {
        when,
        ...(typeof t.text === "string" ? { text: t.text } : { entry: String(t.entry) }),
        ...(position ? { position } : {}),
        ...(Number.isFinite(depth) && t.depth !== null && t.depth !== undefined ? { depth: Math.max(0, Math.round(depth)) } : {}),
      };
    }
  }
  // an event naming one that isn't there
  const check = (steps: Step[], at: string) => {
    for (const s of steps) {
      if (s.kind === "do" && !rules.events[s.event]) problems.push({ path: at, why: `there is no event "${s.event}"` });
      if (s.kind === "if") {
        check(s.then, at);
        check(s.else, at);
      }
    }
  };
  for (const [name, e] of Object.entries(rules.events)) check(e.steps, `events.${name}`);
  check(rules.eachReply, "each_reply");
  return { rules, problems };
}

function checkValue(value: unknown, at: string, problems: RuleProblem[]) {
  if (typeof value !== "string") return;
  const problem = exprProblem(value);
  if (problem) problems.push({ path: at, why: problem });
}

function checkPath(path: string, at: string, problems: RuleProblem[]) {
  for (const m of path.matchAll(/\{([^}]*)\}/g)) checkValue(m[1], at, problems);
}

function readSteps(raw: unknown, at: string, problems: RuleProblem[]): Step[] {
  const list = Array.isArray(raw) ? raw : [raw];
  const steps: Step[] = [];
  list.forEach((item, i) => {
    const here = `${at}[${i}]`;
    if (!isPlain(item)) {
      problems.push({ path: here, why: "a step is `set: { name: value }` and the like" });
      return;
    }
    if ("if" in item) {
      const test = String(item.if);
      const problem = exprProblem(test);
      if (problem) problems.push({ path: `${here}.if`, why: problem });
      else steps.push({ kind: "if", test, then: readSteps(item.then ?? [], `${here}.then`, problems), else: readSteps(item.else ?? [], `${here}.else`, problems) });
      return;
    }
    if ("do" in item) {
      const event = String(item.do);
      const given = isPlain(item.with) ? item.with : {};
      for (const [k, v] of Object.entries(given)) checkValue(v, `${here}.with.${k}`, problems);
      steps.push({ kind: "do", event, with: given });
      return;
    }
    for (const [name, body] of Object.entries(item)) {
      const kind = name.toLowerCase();
      if (kind === "remove" || kind === "delete") {
        for (const path of Array.isArray(body) ? body : [body]) {
          checkPath(String(path), here, problems);
          steps.push({ kind: "remove", path: String(path) });
        }
      } else if ((VALUE_STEPS as readonly string[]).includes(kind) && isPlain(body)) {
        for (const [path, value] of Object.entries(body)) {
          checkPath(path, here, problems);
          checkValue(value, `${here}.${kind}.${path}`, problems);
          steps.push({ kind: kind as (typeof VALUE_STEPS)[number], path, value });
        }
      } else problems.push({ path: here, why: `"${name}" is not a step (${[...VALUE_STEPS, "remove", "if", "do"].join(", ")})` });
    }
  });
  return steps;
}
