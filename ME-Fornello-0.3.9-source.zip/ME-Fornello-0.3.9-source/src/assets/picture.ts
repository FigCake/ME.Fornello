// One asset picture in a chat message: a box of its own (shadow DOM), so a
// card's message CSS can't stretch or hide it. A click shows it at full size
// and another puts it back.

import { t } from "../shared/i18n";
import { standApart } from "../ui/stand-apart";

const STYLE = `
:host { margin: .4em 0; }
figure { margin: 0; display: flex; justify-content: center; }
img { display: block; max-width: min(100%, var(--w)); height: auto; border-radius: 8px; cursor: zoom-in; }
img.big { max-width: 100%; cursor: zoom-out; }
`;

export const PICTURE_CLASS = "fornello-asset";

/** A picture for a message; `name` is what the reply called it (its alt text and tooltip). */
export function assetPicture(url: string, name: string, width: number): HTMLElement {
  const host = document.createElement("div");
  host.className = PICTURE_CLASS;
  standApart(host);
  host.dataset.asset = name;
  const root = host.attachShadow({ mode: "open" });
  const style = document.createElement("style");
  style.textContent = STYLE;
  const img = document.createElement("img");
  img.src = url;
  img.alt = name;
  img.title = name;
  img.loading = "lazy";
  img.decoding = "async";
  img.draggable = false;
  img.style.setProperty("--w", `${width}px`);
  img.addEventListener("click", (e) => {
    // a click on the picture must not open Marinara's message editing
    e.stopPropagation();
    img.classList.toggle("big");
    img.title = img.classList.contains("big") ? t("Click to make it smaller", "눌러서 작게") : name;
  });
  img.addEventListener("error", () => {
    img.alt = t(`Picture not found: ${name}`, `그림을 찾지 못했어요: ${name}`);
    img.style.cursor = "default";
  });
  const figure = document.createElement("figure");
  figure.append(img);
  root.append(style, figure);
  return host;
}
