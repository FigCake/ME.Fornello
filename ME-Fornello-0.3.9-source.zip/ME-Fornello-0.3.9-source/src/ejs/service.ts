// SillyTavern cards' lorebook templates in Marinara. The person converts a card's templates once (the
// settings, for the open chat's cards): each lorebook entry holding one gets new content in place
// (its keys, place and other settings stay), its first content kept in Fornello's storage so it can
// be put back.
// - A template that is only conditions on variables becomes Marinara's own macros ({{#if}}), with
//   Pesto's values given to Marinara as "story_" variables (vars.ts).
// - Any other becomes `{{getvar::fx_ejs_<entry id>}}`: before each reply Fornello runs the template
//   (runner.ts, once the person allowed that card's templates) and puts its text in that variable.

import { characterLore, chatCharacters, listMessages, persona } from "../api/chat-store";
import { macroVariables, patchMacroVariables, readVariables, writeVariables } from "../api/chat-data";
import { patchLoreEntry } from "../api/marinara";
import { pageApi, type PageApi } from "../api/page-api";
import type { RawLoreEntry } from "../api/types";
import { onGenerationStart, type GenStart } from "../host/generation-hold";
import { sha256 } from "../hash";
import { getMarinara } from "../shared/marinara-global";
import { t } from "../shared/i18n";
import type { Settings } from "../settings";
import { storyAccess } from "../state/access";
import { messagesBefore } from "../state/story";
import { safeName, varName } from "../state/vars";
import { screenUi } from "../ui/page-ui";
import { showToast } from "../ui/toast";
import { TemplateRunner, type TemplateData } from "./runner";
import { hasEjs, toMacros } from "./template";

/** Fornello's storage key for the converted entries' first contents. */
const STASH = "ejs";
/** The variable a run template's text goes in (Marinara keeps 10 000 characters a variable: more go in _2, _3…). */
export const OUT_PREFIX = "fx_ejs_";
const CHUNK = 10_000;
const CHUNKS = 5;

export interface Converted {
  bookId: string;
  name: string;
  /** the entry's content before it was converted */
  original: string;
  mode: "macro" | "run";
}

/** One of a card's entries with a template, and what converting it does (or did). */
export interface TemplateEntry {
  id: string;
  bookId: string;
  name: string;
  mode: "macro" | "run";
  /** why Marinara's macros can't say it (mode "run") */
  why?: string;
  converted: boolean;
  /** a run template the person allowed (as it is now) */
  allowed?: boolean;
}

const outName = (id: string, part: number) => safeName(`${OUT_PREFIX}${id.replace(/\W/g, "_")}${part > 1 ? `_${part}` : ""}`);

/** What a run template's entry holds after converting: its text, from the variables Fornello fills. */
export const runPlaceholder = (id: string) => Array.from({ length: CHUNKS }, (_, i) => `{{getvar::${outName(id, i + 1)}}}`).join("");

/** How a converted condition names a variable: Pesto's by its "story_" name, a chat variable by its own (when Marinara can). */
const macroNames = {
  story: (path: string) => varName(path),
  chat: (name: string) => (/^[A-Za-z_]\w{0,63}$/.test(name) ? name : null),
};

/** Pesto's values as templates of [InitVar] cards read them: every value that isn't a group as [value, ""]. */
export function pairShape(v: unknown): unknown {
  if (v && typeof v === "object" && !Array.isArray(v)) return Object.fromEntries(Object.entries(v).map(([k, x]) => [k, pairShape(x)]));
  return [v, ""];
}

/** A text cut into the variables' pieces (the rest empty, so an older longer text doesn't stay). */
export function outChunks(id: string, text: string): Record<string, string | null> {
  const out: Record<string, string | null> = {};
  for (let i = 0; i < CHUNKS; i++) {
    const piece = text.slice(i * CHUNK, (i + 1) * CHUNK);
    out[outName(id, i + 1)] = piece || (i === 0 ? "" : null);
  }
  return out;
}

export class TemplateService {
  private runners = new Map<string, TemplateRunner>();
  /** The page commands' names, for the templates' Worker (the same every time). */
  private commandNames: string[] | null = null;
  private told = new Set<string>();
  private stops: (() => void)[] = [];

  constructor(private settings: Settings) {}

  start(): void {
    // a reply waits this long for the templates only (Fornello's other work before it keeps its usual wait)
    this.stops.push(onGenerationStart((gen) => this.beforeReply(gen), () => this.settings.current.templates.wait * 1000));
  }

  stop(): void {
    for (const stop of this.stops.splice(0)) stop();
    for (const r of this.runners.values()) r.dispose();
    this.runners.clear();
  }

  /** The stash as read once (only Fornello writes it): no read of the storage each reply. */
  private stashRead: Promise<Record<string, Converted>> | null = null;

  private stash(): Promise<Record<string, Converted>> {
    this.stashRead ??= getMarinara()
      .storage.get()
      .then((all) => {
        const raw = all[STASH];
        return raw && typeof raw === "object" && !Array.isArray(raw) ? (raw as Record<string, Converted>) : {};
      });
    this.stashRead.catch(() => (this.stashRead = null));
    return this.stashRead.then((s) => ({ ...s }));
  }

  private async saveStash(next: Record<string, Converted>): Promise<void> {
    await getMarinara().storage.patch({ [STASH]: next });
    this.stashRead = Promise.resolve({ ...next });
  }

  /** The open chat's cards' lorebook entries. */
  private async cardEntries(chatId: string): Promise<RawLoreEntry[]> {
    const cast = await chatCharacters(chatId);
    return (await Promise.all(cast.map((c) => characterLore(c.id).catch(() => [] as RawLoreEntry[])))).flat();
  }

  /** The chat's cards' templates, and what converting each does. */
  async scan(chatId: string): Promise<TemplateEntry[]> {
    const stash = await this.stash();
    const out: TemplateEntry[] = [];
    for (const e of await this.cardEntries(chatId)) {
      const done = stash[e.id];
      const source = done ? done.original : String(e.content ?? "");
      if (!done && !hasEjs(source)) continue;
      const macro = toMacros(source, macroNames);
      out.push({
        id: e.id,
        bookId: String(e.lorebookId ?? done?.bookId ?? ""),
        name: String(e.name ?? ""),
        mode: done?.mode ?? ("text" in macro ? "macro" : "run"),
        ...("why" in macro ? { why: macro.why } : {}),
        converted: !!done,
        ...(done?.mode === "run" ? { allowed: this.allowed(done.original) } : {}),
      });
    }
    return out;
  }

  /** Whether the person allowed this template (as it is now) to run: each template is answered on its own. */
  private allowed(source: string): boolean {
    return this.settings.current.templates.code[sha256(source)] === true;
  }

  /** Converts the chat's cards' templates (those to run only when `allowRun`); returns how many of each. */
  async convert(chatId: string, allowRun: boolean): Promise<{ macro: number; run: number }> {
    const stash = { ...(await this.stash()) };
    const entries = await this.cardEntries(chatId);
    let macro = 0;
    let run = 0;
    const runSources: string[] = [];
    for (const e of entries) {
      const done = stash[e.id];
      // converted before: a run template not allowed (or changed since) is allowed now
      if (done) {
        if (done.mode === "run" && allowRun && !this.allowed(done.original)) runSources.push(done.original);
        continue;
      }
      const source = String(e.content ?? "");
      if (!hasEjs(source)) continue;
      const bookId = String(e.lorebookId ?? "");
      if (!bookId) continue;
      const m = toMacros(source, macroNames);
      if ("text" in m) {
        await patchLoreEntry(bookId, e.id, { content: m.text });
        stash[e.id] = { bookId, name: String(e.name ?? ""), original: source, mode: "macro" };
        macro++;
      } else if (allowRun) {
        await patchLoreEntry(bookId, e.id, { content: runPlaceholder(e.id) });
        stash[e.id] = { bookId, name: String(e.name ?? ""), original: source, mode: "run" };
        runSources.push(source);
        run++;
      }
      // kept as it goes: a stopped conversion can still be put back
      await this.saveStash(stash);
    }
    if (runSources.length) {
      const code = { ...this.settings.current.templates.code, ...Object.fromEntries(runSources.map((src) => [sha256(src), true])) };
      await this.settings.set({ templates: { ...this.settings.current.templates, code } });
    }
    // the conditions read Pesto's values as "story_" variables
    if (macro && !this.settings.current.story.vars) await this.settings.set({ story: { ...this.settings.current.story, vars: true } });
    return { macro, run };
  }

  /** Puts the chat's cards' converted entries back as they were, and takes out what Fornello put in the chat's variables. */
  async restore(chatId: string): Promise<number> {
    const stash = { ...(await this.stash()) };
    let n = 0;
    for (const e of await this.cardEntries(chatId)) {
      const done = stash[e.id];
      if (!done) continue;
      await patchLoreEntry(done.bookId, e.id, { content: done.original });
      delete stash[e.id];
      await this.saveStash(stash);
      n++;
    }
    const vars = await macroVariables(chatId);
    const gone = Object.fromEntries(Object.keys(vars).filter((k) => k.startsWith(OUT_PREFIX)).map((k) => [k, null]));
    await patchMacroVariables(chatId, gone);
    return n;
  }

  /** The chat's run templates, in the order of the card's entries. */
  private runTemplates(stash: Record<string, Converted>, entries: RawLoreEntry[]): { id: string; source: string; name: string }[] {
    return entries.filter((e) => stash[e.id]?.mode === "run").map((e) => ({ id: e.id, source: stash[e.id].original, name: stash[e.id].name }));
  }

  /** Before a reply: runs the chat's templates, once allowed, and puts their text where their entries read it. */
  async beforeReply(gen: GenStart): Promise<void> {
    const chatId = gen.chatId;
    const stash = await this.stash();
    if (!Object.keys(stash).length) return;
    const entries = await this.cardEntries(chatId);
    const all = this.runTemplates(stash, entries);
    const templates = all.filter((x) => this.allowed(x.source));
    if (templates.length < all.length) {
      const not = all.filter((x) => !this.allowed(x.source)).map((x) => x.name);
      this.tell(`not:${not.join("|")}`, t(`Not allowed to run (changed since, or never allowed): ${not.join(", ")}. Press Convert in the settings to allow them.`, `실행이 허락되지 않은 템플릿(그 뒤 바뀌었거나 허락 안 함): ${not.join(", ")}. 설정에서 변환을 눌러 허락해 주세요.`));
    }
    if (!templates.length) return;
    const hash = sha256(templates.map((x) => `${x.id}\u0000${x.source}`).join("\u0001"));
    const data = await this.data(chatId, gen, templates);
    const report = (m: string) => showToast(t(`Template: ${m}`, `템플릿: ${m}`), "warning");
    // a page session reads much: opened only when a template asks for a page command (their names read once)
    let api: PageApi | null = null;
    const page = async () => (api ??= await pageApi({ messageId: null, report, ui: screenUi }));
    try {
      let commands = this.commandNames;
      if (!commands) {
        const globals = (await page()).globals;
        this.commandNames = commands = Object.keys(globals).filter((k) => typeof globals[k] === "function");
      }
      let runner = this.runners.get(hash);
      if (!runner) this.runners.set(hash, (runner = new TemplateRunner(templates, commands)));
      const call = async (name: string, args: unknown[]) => {
        if (name === "__entry") return this.entryText(entries, args[0], args[1]);
        const fn = (await page()).globals[name];
        if (typeof fn !== "function") throw new Error(t(`there is no page command "${name}"`, `"${name}"라는 페이지 명령이 없어요`));
        return (fn as (...a: unknown[]) => unknown)(...args);
      };
      // a little under the reply's wait, so the text is in before it goes on
      const result = await runner.run(
        templates.map((x) => x.id),
        data,
        call,
        Math.max(1000, this.settings.current.templates.wait * 1000 - 700),
      );
      const out: Record<string, string | null> = {};
      for (const tpl of templates) Object.assign(out, outChunks(tpl.id, result.outputs[tpl.id] ?? ""));
      await patchMacroVariables(chatId, out);
      if (Object.keys(result.writes).length) await writeVariables(result.writes, {}, chatId);
      const failed = Object.entries(result.errors);
      if (failed.length) {
        console.warn("[Fornello] templates:", result.errors);
        const first = templates.find((x) => x.id === failed[0][0]);
        this.tell(`${hash}:${failed.map(([id, why]) => `${id}${why}`).join("|")}`, t(`“${first?.name}” didn't run: ${failed[0][1]}${failed.length > 1 ? ` (and ${failed.length - 1} more, in the console)` : ""}`, `“${first?.name}” 실행 실패: ${failed[0][1]}${failed.length > 1 ? ` (외 ${failed.length - 1}개, 콘솔에 있어요)` : ""}`));
      }
    } finally {
      (api as PageApi | null)?.dispose();
    }
  }

  private tell(key: string, text: string): void {
    if (this.told.has(key)) return;
    this.told.add(key);
    showToast(text, "warning");
  }

  /** What the templates read: the chat's variables and Pesto's values (before this reply), names, the card. */
  private async data(chatId: string, gen: GenStart, templates: { id: string; name: string }[]): Promise<TemplateData> {
    const [vars, cast, me, messages] = await Promise.all([readVariables(chatId).catch(() => ({})), chatCharacters(chatId), persona(chatId), listMessages(chatId, { fresh: true })]);
    const before = messagesBefore(messages, gen);
    const story = storyAccess();
    const view = story ? await story.at(chatId, before.at(-1)?.id ?? null).catch(() => null) : null;
    const card = story?.cardOf ? await story.cardOf(chatId).catch(() => null) : null;
    const scope: Record<string, unknown> = { ...vars };
    if (view) scope.stat_data = card?.from === "initvar" ? pairShape(view.values) : view.values;
    const c = cast[0];
    return {
      scope,
      user: me.name,
      char: c?.name ?? "",
      card: c ? { name: c.name, description: c.description, personality: c.personality, scenario: c.scenario, first_mes: c.firstMessage } : {},
      byName: Object.fromEntries(templates.map((x) => [x.name, x.id])),
    };
  }

  /** Another entry's text for getwi: by its name (or comment), among the chat's cards' entries (the book's name isn't needed to find it). */
  private entryText(entries: RawLoreEntry[], _book: unknown, name: unknown): string {
    const want = String(name ?? "").trim();
    const found = entries.find((e) => String(e.name ?? "").trim() === want || String(e.comment ?? "").trim() === want);
    return String(found?.content ?? "");
  }
}
