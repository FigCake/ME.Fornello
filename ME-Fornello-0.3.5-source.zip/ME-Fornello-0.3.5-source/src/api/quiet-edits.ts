// Messages a page rewrote without a redraw (setMsg(n, text, { refresh: false })):
// while the message holds that text, its page keeps running.

const edits = new Map<string, string>();

export function markQuietEdit(messageId: string, text: string): void {
  edits.set(messageId, text);
}

export function clearQuietEdit(messageId: string): void {
  edits.delete(messageId);
}

/** The message holds exactly what a page quietly wrote into it. */
export function isQuietEdit(messageId: string, text: string): boolean {
  const quiet = edits.get(messageId);
  return quiet !== undefined && quiet === text;
}

export function clearQuietEdits(): void {
  edits.clear();
}
