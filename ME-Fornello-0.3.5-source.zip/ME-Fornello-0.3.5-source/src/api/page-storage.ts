// localStorage and sessionStorage for pages, shared per chat. localStorage is
// kept in this browser's IndexedDB; sessionStorage lasts until a reload.

const DB_NAME = "fornello";
const STORE = "pageStorage";

function openDb(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    const req = indexedDB.open(DB_NAME, 1);
    req.onupgradeneeded = () => {
      if (!req.result.objectStoreNames.contains(STORE)) req.result.createObjectStore(STORE);
    };
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });
}

let db: Promise<IDBDatabase> | null = null;
const database = () => (db ??= openDb());

async function read(key: string): Promise<Record<string, string>> {
  const d = await database();
  return new Promise((resolve, reject) => {
    const req = d.transaction(STORE, "readonly").objectStore(STORE).get(key);
    req.onsuccess = () => resolve((req.result as Record<string, string> | undefined) ?? {});
    req.onerror = () => reject(req.error);
  });
}

async function write(key: string, value: Record<string, string>): Promise<void> {
  const d = await database();
  await new Promise<void>((resolve, reject) => {
    const tx = d.transaction(STORE, "readwrite");
    tx.objectStore(STORE).put(value, key);
    tx.oncomplete = () => resolve();
    tx.onerror = () => reject(tx.error);
  });
}

/**
 * A Storage the page uses like the browser's, keys as properties included
 * (localStorage.score = "3", Object.keys(localStorage)); `onChange` runs after each change.
 */
export class PageStorage implements Storage {
  [name: string]: unknown;
  readonly #data: Map<string, string>;
  readonly #onChange: () => void;

  constructor(data: Map<string, string>, onChange: () => void = () => {}) {
    this.#data = data;
    this.#onChange = onChange;
    const own = (p: string | symbol): p is string => typeof p === "string" && !(p in this);
    return new Proxy(this, {
      get: (t, p) => {
        if (own(p)) return data.get(p);
        const v = Reflect.get(t, p, t);
        return typeof v === "function" ? v.bind(t) : v;
      },
      set: (t, p, v) => {
        if (own(p)) t.setItem(p, v);
        else Reflect.set(t, p, v, t);
        return true;
      },
      deleteProperty: (t, p) => {
        if (own(p)) t.removeItem(p);
        return true;
      },
      has: (t, p) => p in t || (typeof p === "string" && data.has(p)),
      ownKeys: () => [...data.keys()],
      getOwnPropertyDescriptor: (_t, p) => (typeof p === "string" && data.has(p) ? { value: data.get(p), writable: true, enumerable: true, configurable: true } : undefined),
    });
  }

  get length(): number {
    return this.#data.size;
  }

  clear(): void {
    this.#data.clear();
    this.#onChange();
  }

  getItem(key: string): string | null {
    return this.#data.get(String(key)) ?? null;
  }

  key(index: number): string | null {
    return [...this.#data.keys()][index] ?? null;
  }

  removeItem(key: string): void {
    if (this.#data.delete(String(key))) this.#onChange();
  }

  setItem(key: string, value: string): void {
    this.#data.set(String(key), String(value));
    this.#onChange();
  }
}

interface ChatStorage {
  local: PageStorage;
  session: PageStorage;
}

const byChat = new Map<string, Promise<ChatStorage>>();
/** Saves still waiting on their short delay; written at once when the tab goes away. */
const pending = new Map<string, () => void>();

/** Writes every change that is still waiting (the tab is closing, Fornello is turned off). */
function flushPageStorage(): void {
  for (const flush of [...pending.values()]) flush();
}

const onHidden = () => {
  if (document.visibilityState === "hidden") flushPageStorage();
};

/** Writes what waits when the tab goes away. The returned stop writes it at once and forgets the storages. */
export function startPageStorage(): () => void {
  window.addEventListener("pagehide", flushPageStorage);
  document.addEventListener("visibilitychange", onHidden);
  return () => {
    flushPageStorage();
    window.removeEventListener("pagehide", flushPageStorage);
    document.removeEventListener("visibilitychange", onHidden);
    byChat.clear();
  };
}

/** The chat's storages (no chat: storages that last only as long as the page). */
export function chatStorage(chatId: string | null): Promise<ChatStorage> {
  if (!chatId) return Promise.resolve({ local: new PageStorage(new Map()), session: new PageStorage(new Map()) });
  let found = byChat.get(chatId);
  if (!found) {
    found = (async () => {
      const key = `chat:${chatId}`;
      let readable = true;
      const stored = await read(key).catch((e) => {
        // what is saved could not be read: the page gets an empty storage, and it is not written over
        console.warn("[Fornello] page storage not read; changes stay until reload", e);
        readable = false;
        byChat.delete(chatId);
        return {} as Record<string, string>;
      });
      const data = new Map(Object.entries(stored));
      let timer: ReturnType<typeof setTimeout> | null = null;
      const flush = () => {
        if (timer) clearTimeout(timer);
        timer = null;
        pending.delete(key);
        void write(key, Object.fromEntries(data)).catch((e) => console.warn("[Fornello] page storage not saved", e));
      };
      const save = () => {
        if (!readable) return;
        if (timer) clearTimeout(timer);
        timer = setTimeout(flush, 300);
        pending.set(key, flush);
      };
      return { local: new PageStorage(data, save), session: new PageStorage(new Map()) };
    })();
    byChat.set(chatId, found);
  }
  return found;
}
