// A background script's own commands (its buttons), also under
// JS-Slash-Runner's names. Pages and components do not get them.

import { normalizeButtons, type ScriptButton } from "../../scripts/model";
import { type CommandTable, cmd } from "../command";
import type { ScriptContext } from "../session";
import type { PageSession } from "../session";
import { listenTo } from "./events";

/** The event a script button sends when pressed (eventOn(getButtonEvent("…"), fn)). */
export const buttonEvent = (scriptKey: string, name: string): string => `fornello_button:${scriptKey}:${name}`;

export function scriptCommands(s: PageSession): CommandTable {
  const script = s.script as ScriptContext | null;
  if (!script) return {};
  const set = (list: unknown) => script.setButtons(normalizeButtons(list));
  // JS-Slash-Runner's (scriptId, buttons) form works too
  const own = (a: unknown, b: unknown) => (typeof a === "string" && b !== undefined ? b : a);
  return {
    setButtons: cmd((list: unknown) => set(list)),
    onButton: cmd((name: unknown, fn: unknown) => listenTo(s, buttonEvent(script.def.key, String(name)), fn)),
    getScriptId: cmd(() => script.def.id),
    getScriptName: cmd(() => script.def.name),
    getScriptButtons: cmd((): ScriptButton[] => script.buttons().map((b) => ({ ...b }))),
    replaceScriptButtons: cmd((a: unknown, b?: unknown) => set(own(a, b))),
    appendInexistentScriptButtons: cmd((a: unknown, b?: unknown) => {
      const now = script.buttons();
      set([...now, ...normalizeButtons(own(a, b)).filter((x) => !now.some((y) => y.name === x.name))]);
    }),
    updateScriptButtonsWith: cmd(async (a: unknown, b?: unknown) => {
      const fn = own(a, b) as (list: ScriptButton[]) => unknown;
      const next = await fn(script.buttons().map((x) => ({ ...x })));
      set(next);
      return script.buttons();
    }),
    getButtonEvent: cmd((name: string) => buttonEvent(script.def.key, String(name))),
  };
}
