// How the rest of Fornello reads Pesto (components, the values window, page commands)
// without starting it: StoryState registers itself here while it runs.

import type { Definition, DefinitionProblem, Turn } from "./engine";

export interface StoryView {
  def: Definition;
  /** the values after the message, and the computed ones */
  values: Record<string, unknown>;
  derived: Record<string, unknown>;
  /** what the message changed and which changes were refused (undefined before any message) */
  turn?: Turn;
  /** the message's own changes made by the person */
  edits: { path: string; value: unknown }[];
  /** the block a helper model wrote for this reply, which had none ("": it found no change) */
  filled?: string;
}

export interface StoryAccess {
  /** Whether the chat has Pesto (it is on, and the chat's cards bring a schema). */
  has(chatId: string): Promise<boolean>;
  /** The values after a message (null: the last one); null when the chat has no Pesto. */
  at(chatId: string, messageId: string | null): Promise<StoryView | null>;
  /** Sets values at a message, as the person's own changes; null as a value takes that change back. */
  edit(chatId: string, messageId: string, changes: { path: string; value: unknown }[]): Promise<void>;
  /** The chat's card code (`pesto:code`) and the person's answer about it (undefined: not answered). */
  codeOf?(chatId: string): Promise<{ code: string; allowed: boolean | undefined; hash: string } | null>;
  /** Lets a card's code run, or not (null: ask again). */
  answerCode?(hash: string, allow: boolean | null): Promise<void>;
  /** A reply tried after a message (null: the last), not saved: what it would change and what would be refused. */
  tryReply?(chatId: string, messageId: string | null, text: string): Promise<Pick<StoryView, "values" | "derived"> & { turn: Turn } | null>;
  /** The number values over the last messages, by path, for a graph (`ids` and `nums` are those messages'). */
  history?(chatId: string): Promise<{ ids: string[]; nums: number[]; series: Record<string, (number | null)[]> } | null>;
  /** The card's entries: their problems, and for a card read from its own variable data, that data written as Fornello's entries. */
  cardOf?(chatId: string): Promise<{ problems: DefinitionProblem[]; from?: "initvar" | "tags"; schema?: string; start?: string } | null>;
}

let access: StoryAccess | null = null;
const listeners = new Set<(chatId: string) => void>();

export function setStoryAccess(a: StoryAccess | null): void {
  access = a;
}

export function storyAccess(): StoryAccess | null {
  return access;
}

/** Calls `fn` when a chat's values may have changed (a reply was counted, the person edited). */
export function onStoryChange(fn: (chatId: string) => void): () => void {
  listeners.add(fn);
  return () => listeners.delete(fn);
}

export function storyChanged(chatId: string): void {
  for (const fn of [...listeners]) {
    try {
      fn(chatId);
    } catch (e) {
      console.warn("[Fornello]", e);
    }
  }
}

/** Every path a component can take a value from: the values' (into groups and maps), then the computed ones. */
export function storyPaths(view: Pick<StoryView, "values" | "derived">): string[] {
  const out: string[] = [];
  const walk = (v: unknown, path: string) => {
    if (path) out.push(path);
    if (v && typeof v === "object" && !Array.isArray(v)) for (const [k, x] of Object.entries(v)) walk(x, path ? `${path}.${k}` : k);
  };
  walk(view.values, "");
  out.push(...Object.keys(view.derived));
  return out;
}
