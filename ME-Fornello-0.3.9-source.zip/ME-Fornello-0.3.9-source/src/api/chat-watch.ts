// Chat changes for onMsg / onSend / onSwipe / onEdit / onDelete (and the
// SillyTavern card pages' events). Marinara sends no such events, so each message list
// Fornello reads is compared with the last; it reads one itself only when no
// one else did.
//
//   msg     a new reply, or a new swipe of one (a regenerated reply)
//   send    a new message of the person's
//   swipe   another swipe is on screen (with msg too when it is a new one)
//   edit    a message's text changed
//   delete  a message is gone (the listener gets its id and the number it had)

import { findComposer, isGenerating } from "../shared/composer";
import { quickHash } from "../hash";
import { onScreenChange } from "../host/screen-watch";
import { currentChatId } from "../host/current-chat";
import { onGenerationComplete } from "../host/events";
import { listMessages, onMessagesRead } from "./chat-store";
import type { Message } from "./types";

type Listener = (message: Message) => void;
export type WatchKind = "msg" | "send" | "swipe" | "edit" | "delete";

interface Seen {
  num: number;
  text: string;
  swipe: number;
  swipes: number;
}

const seen = (m: Message): Seen => ({ num: m.num, text: m.text, swipe: m.swipe ?? 0, swipes: m.swipes ?? 1 });

class ChatWatch {
  private readonly listeners: Record<WatchKind, Set<Listener>> = { msg: new Set(), send: new Set(), swipe: new Set(), edit: new Set(), delete: new Set() };
  private known: Map<string, Seen> | null = null;
  private chatId: string | null = null;
  private stops: (() => void)[] = [];
  private timer: ReturnType<typeof setTimeout> | null = null;
  private readonly followUps = new Set<ReturnType<typeof setTimeout>>();
  private count = -1;
  /** What the messages on screen say, roughly (only while someone listens for swipes, edits or deletes). */
  private shown = "";

  on(kind: WatchKind, fn: Listener): () => void {
    this.listeners[kind].add(fn);
    this.start();
    return () => {
      this.listeners[kind].delete(fn);
      if (Object.values(this.listeners).every((l) => !l.size)) this.stop();
    };
  }

  private start(): void {
    if (this.stops.length) return;
    this.stops.push(
      onMessagesRead(this.compare),
      onScreenChange(() => {
        const elements = document.querySelectorAll<HTMLElement>("[data-message-id]");
        if (elements.length !== this.count) {
          this.count = elements.length;
          this.schedule(600);
        }
        // another swipe shown, or a message edited: the count stays, the text on screen changes
        if (this.listeners.swipe.size || this.listeners.edit.size) {
          // the latest messages are where swipes and edits happen; reading all of a long chat each time would cost too much
          let shown = `${elements.length};`;
          for (const el of [...elements].slice(-20)) shown += `${el.dataset.messageId}:${quickHash(el.textContent ?? "")};`;
          if (shown !== this.shown) {
            if (this.shown) this.schedule(600);
            this.shown = shown;
          }
        }
      }),
    );
    this.stops.push(onGenerationComplete(this.onComplete));
    this.schedule(0);
  }

  /** Fornello is turned off: stop watching, whoever still listens. */
  reset(): void {
    for (const l of Object.values(this.listeners)) l.clear();
    this.stop();
  }

  private stop(): void {
    for (const s of this.stops) s();
    this.stops = [];
    if (this.timer) clearTimeout(this.timer);
    this.timer = null;
    for (const t of this.followUps) clearTimeout(t);
    this.followUps.clear();
    this.known = null;
    this.count = -1;
    this.shown = "";
  }

  // the finished reply can reach the message list a moment after the event
  // (and the count on screen may not change): look again
  private readonly onComplete = () => {
    for (const ms of [600, 4000]) {
      const t = setTimeout(() => {
        this.followUps.delete(t);
        this.schedule(0);
      }, ms);
      this.followUps.add(t);
    }
  };

  private schedule(ms: number): void {
    if (this.timer) clearTimeout(this.timer);
    this.timer = setTimeout(() => void this.check(), ms);
  }

  /** A look at the list: a recent read (the chat pages') answers it without a request. */
  private async check(): Promise<void> {
    const chatId = currentChatId();
    if (!chatId) return;
    // a reply still being written is announced once it is finished
    if (isGenerating(findComposer()) && this.known) return this.schedule(800);
    await listMessages(chatId).catch(() => undefined);
  }

  private tell(kind: WatchKind, m: Message): void {
    for (const fn of [...this.listeners[kind]]) {
      try {
        fn({ ...m });
      } catch (e) {
        console.warn("[Fornello]", e);
      }
    }
  }

  private readonly compare = (chatId: string, list: Message[]) => {
    if (chatId !== currentChatId()) return;
    if (chatId !== this.chatId || !this.known) {
      this.chatId = chatId;
      this.known = new Map(list.map((m) => [m.id, seen(m)]));
      return;
    }
    // a reply still being written waits (it may be saved before it is done)
    if (isGenerating(findComposer())) return this.schedule(800);
    const known = this.known;
    const reply = (m: Message) => m.role === "char" || m.role === "narrator";
    for (const m of list) {
      const before = known.get(m.id);
      known.set(m.id, seen(m));
      if (!before) {
        const kind = m.role === "user" ? "send" : reply(m) ? "msg" : null;
        if (kind) this.tell(kind, m);
      } else if ((m.swipes ?? 1) > before.swipes) {
        // a new swipe: the reply was written again
        this.tell("swipe", m);
        if (reply(m)) this.tell("msg", m);
      } else if ((m.swipe ?? 0) !== before.swipe) this.tell("swipe", m);
      else if (m.text !== before.text) this.tell("edit", m);
    }
    const now = new Set(list.map((m) => m.id));
    for (const [id, before] of [...known]) {
      if (now.has(id)) continue;
      known.delete(id);
      this.tell("delete", { id, num: before.num, role: "system", name: "", text: before.text, hidden: false, characterId: null });
    }
  };
}

export const chatWatch = new ChatWatch();
