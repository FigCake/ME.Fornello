// Takes parts of a message's text off the screen by blanking text in place
// (nothing moved or removed), so Marinara can redraw the message as usual.

export interface Span {
  start: number;
  end: number;
}

/** Blanks the spans `find` picks out of the element's whole text. */
export function blankText(content: HTMLElement, find: (full: string) => Span[]): void {
  const nodes: Text[] = [];
  const walker = document.createTreeWalker(content, NodeFilter.SHOW_TEXT);
  for (let n = walker.nextNode(); n; n = walker.nextNode()) nodes.push(n as Text);
  const full = nodes.map((n) => n.nodeValue ?? "").join("");
  const spans = find(full);
  if (!spans.length) return;
  let offset = 0;
  for (const n of nodes) {
    const start = offset;
    const value = n.nodeValue ?? "";
    offset += value.length;
    let text = value;
    // from the last span back, so earlier positions stay right
    for (const t of [...spans].sort((a, b) => b.start - a.start)) {
      const a = Math.max(t.start, start) - start;
      const b = Math.min(t.end, offset) - start;
      if (a < b) text = text.slice(0, a) + text.slice(b);
    }
    if (text !== value) n.nodeValue = text;
  }
}

/** Where each piece of the source shows in the text on screen, ignoring white space (or what `skip` picks). */
export function findLoose(full: string, pieces: string[], skip: RegExp = /\s/): Span[] {
  const at: number[] = [];
  let packed = "";
  for (let i = 0; i < full.length; i++) {
    if (skip.test(full[i])) continue;
    at.push(i);
    packed += full[i];
  }
  const out: Span[] = [];
  let from = 0;
  for (const piece of pieces) {
    const needle = [...piece].filter((c) => !skip.test(c)).join("");
    if (!needle) continue;
    const i = packed.indexOf(needle, from);
    if (i < 0) continue;
    out.push({ start: at[i], end: at[i + needle.length - 1] + 1 });
    from = i + needle.length;
  }
  return out;
}
