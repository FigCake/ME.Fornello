// The page commands' UI (they import none): the browser's confirm box and Fornello's toasts.

import type { PageUi } from "../api/page-api";
import { showToast } from "./toast";

export const screenUi: PageUi = {
  confirm: (question) => window.confirm(question),
  toast: showToast,
};
