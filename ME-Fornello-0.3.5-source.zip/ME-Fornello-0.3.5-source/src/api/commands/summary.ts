// Page commands for the chat's summaries (Marinara's Summary panel).

import { t } from "../../shared/i18n";
import { cmd } from "../command";
import { editSummaries, makeChatSummary, summaryEntries, type SummaryEntry } from "../features";
import type { PageSession } from "../session";

const getSummary = (s: PageSession): Promise<SummaryEntry[]> => summaryEntries(s.here());

/** Marinara writes a summary (of the last `last` messages, else its setting) and adds it; its text comes back. */
async function makeSummary(s: PageSession, options: { last?: number } = {}): Promise<string> {
  const chatId = s.here();
  const before = new Set((await summaryEntries(chatId)).map((e) => e.id));
  const all = await makeChatSummary(chatId, Number(options.last) || undefined);
  // Marinara answers with every summary joined: the new one is the entry that was not there
  const made = (await summaryEntries(chatId)).filter((e) => !before.has(e.id));
  return made.length ? made.map((e) => e.text).join("\n\n") : all;
}

/** The chat's summaries become `items` ({ id?, title?, text, on? }): known ids changed, others added, the rest deleted. */
export async function setSummary(s: PageSession, items: unknown): Promise<number> {
  const chatId = s.here();
  const list = (Array.isArray(items) ? items : [items]) as Partial<SummaryEntry>[];
  const before = await summaryEntries(chatId);
  const ids: string[] = [];
  for (const item of list) {
    if (!item || typeof item !== "object" || !String(item.text ?? "").trim()) throw new Error(t("A summary needs text.", "요약에 text가 필요함."));
    const known = item.id ? before.find((e) => e.id === item.id) : undefined;
    const id = known?.id ?? `fornello-${Date.now().toString(36)}-${ids.length}`;
    await editSummaries(chatId, {
      operation: "replace",
      entry: { id, content: String(item.text), title: String(item.title ?? known?.title ?? ""), enabled: item.on !== false, ...(known ? {} : { kind: "rolling", origin: "manual", sourceMode: "last" }) },
    });
    ids.push(id);
  }
  const gone = before.filter((e) => !ids.includes(e.id) && e.id !== "summary").map((e) => e.id);
  if (gone.length) await editSummaries(chatId, { operation: "delete", entryIds: gone });
  if (ids.length > 1) await editSummaries(chatId, { operation: "reorder", entryIds: ids });
  return ids.length;
}

export function summaryCommands(s: PageSession) {
  return {
    getSummary: cmd(() => getSummary(s)),
    makeSummary: cmd({ writes: true, paid: true }, (options?: { last?: number }) => makeSummary(s, options)),
    setSummary: cmd({ writes: true }, (items: unknown) => setSummary(s, items)),
  };
}
