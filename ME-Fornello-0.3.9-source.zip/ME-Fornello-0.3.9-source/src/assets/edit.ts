// Changes to a card's asset list, as the asset window makes them. Each
// returns a new list; several assets may share a name (one is picked per
// message), so nothing here merges by name.

import type { Asset, AssetPlace } from "./model";

/** A file's name, extension and all: what a new asset is called (one name in two types stays two pictures). */
export function nameFromFile(fileName: string): string {
  return fileName.replace(/^.*[\\/]/, "").trim();
}

/** Words typed with commas between them ("웃, smile , 미소"). */
export function parseWords(text: string): string[] {
  return [...new Set(text.split(/[,，、\n]/).map((w) => w.trim()).filter(Boolean))].slice(0, 20);
}

const same = (a: Asset, place: AssetPlace, file: string) => a.place === place && a.file === file;

/**
 * Lists a file under a name (a file listed already keeps its place in the
 * list and takes the name). `hash`: the file's bytes, for a picture from a
 * card file (see alreadyListed).
 */
export function listFile(assets: Asset[], place: AssetPlace, file: string, name: string, hash?: string): Asset[] {
  const clean = name.trim();
  if (!clean) return assets;
  const extra = hash ? { hash } : {};
  if (assets.some((a) => same(a, place, file))) return assets.map((a) => (same(a, place, file) ? { ...a, name: clean, ...extra } : a));
  return [...assets, { name: clean, file, place, ...extra }];
}

/** Whether a picture of this name and these bytes is listed already (a card file imported again). */
export function alreadyListed(assets: Asset[], name: string, hash: string): boolean {
  return assets.some((a) => a.hash === hash && a.name === name.trim());
}

/** Changes one listed asset (an empty person or no words drop the field). */
export function editAsset(assets: Asset[], place: AssetPlace, file: string, change: { name?: string; person?: string; words?: string[] }): Asset[] {
  return assets.map((a) => {
    if (!same(a, place, file)) return a;
    const next: Asset = { ...a };
    if (change.name !== undefined && change.name.trim()) next.name = change.name.trim();
    if (change.person !== undefined) {
      if (change.person.trim()) next.person = change.person.trim();
      else delete next.person;
    }
    if (change.words !== undefined) {
      if (change.words.length) next.words = change.words;
      else delete next.words;
    }
    return next;
  });
}

/** Takes a file off the list (the file itself stays). */
export function unlistFile(assets: Asset[], place: AssetPlace, file: string): Asset[] {
  return assets.filter((a) => !same(a, place, file));
}

/**
 * Words for a sprite: a sprite needs no listing to be found by its
 * expression, so it is listed only while it has words.
 */
export function setSpriteWords(assets: Asset[], sprite: { name: string; file: string }, words: string[]): Asset[] {
  if (!words.length) return unlistFile(assets, "sprite", sprite.file);
  if (assets.some((a) => same(a, "sprite", sprite.file))) return editAsset(assets, "sprite", sprite.file, { words });
  return [...assets, { name: sprite.name, file: sprite.file, place: "sprite", words }];
}
