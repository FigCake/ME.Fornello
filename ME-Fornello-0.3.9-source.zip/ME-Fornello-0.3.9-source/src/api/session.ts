// One running page's (or component's) hold on its chat: what it read when it
// opened, the messages it added, its AI calls. Every command works through it.

import { t } from "../shared/i18n";
import type { ToastKind } from "../ui/toast";
import { currentChatId, requireChat } from "../host/current-chat";
import { readChatData, readVariables } from "./chat-data";
import { chatCharacters, chatDetail, listMessages, onMessagesRead, pageSnapshot, persona } from "./chat-store";
import { abortRun, cardBookName } from "./marinara";
import { type CharacterName, type PersonaRow, bookList, characterNames, chatBookIds, personaList, presetList } from "./library";
import { type RegexScript, regexScripts } from "../regex";
import { type PageStorage, chatStorage } from "./page-storage";
import { type SharedChat, privateChat, sharedChat } from "./shared-vars";
import type { CharacterInfo, LoreBook, Message, PersonaInfo } from "./types";
import type { LibraryItem, ScriptButton, ScriptDef } from "../scripts/model";

/** How a page asks the person something and leaves a note (the screen's own in Fornello, stand-ins in tests). */
export interface PageUi {
  confirm(question: string): boolean;
  toast(text: string, kind?: ToastKind): void;
}

/** A background script's own side (scripts/host.ts): who it is and its buttons. */
export interface ScriptContext {
  def: ScriptDef;
  buttons(): ScriptButton[];
  setButtons(list: ScriptButton[]): void;
}

export interface PageContext {
  /** Marinara id of the message the page sits in (chat pages and components). */
  messageId?: string | null;
  /** A preview: commands that change the chat only say what they would do. */
  preview?: boolean;
  report(message: string): void;
  ui: PageUi;
  /** Set for a background script (its own commands: getScriptId, buttons, its variables). */
  script?: ScriptContext;
  /** Starts the page (or script) again (reloadIframe). */
  reload?: () => void;
}

/** AI calls a page may make in a minute before the person is asked. */
const SPEND_LIMIT = 12;

// ── what a page needs before it starts ──
// some calls are answered without await, so this is loaded first;
// pages opening together share one load (pageSnapshot).

const NO_PERSONA: PersonaInfo = { id: null, name: "User", description: "" };

/** The library as a page saw it last (getWorldbookNames, getPersona and the like answer at once). */
export interface World {
  books: LoreBook[];
  /** Books the person added to this chat. */
  chatBooks: string[];
  chars: CharacterName[];
  personas: PersonaRow[];
  regex: RegexScript[];
  /** The chat's prompt preset, and every preset. */
  presetId: string | null;
  presets: { id: string; name: string }[];
}

async function loadWorld(chatId: string | null): Promise<World> {
  const [books, chatBooks, chars, personas, regex, presetId, presets] = await Promise.all([
    bookList().catch(() => [] as LoreBook[]),
    chatId ? chatBookIds(chatId).catch(() => [] as string[]) : Promise.resolve([] as string[]),
    characterNames().catch(() => [] as CharacterName[]),
    personaList().catch(() => [] as PersonaRow[]),
    regexScripts().catch(() => [] as RegexScript[]),
    chatId ? chatDetail(chatId).then((d) => d.promptPresetId ?? null).catch(() => null) : Promise.resolve(null),
    presetList().catch(() => [] as { id: string; name: string }[]),
  ]);
  return { books, chatBooks, chars, personas, regex, presetId, presets };
}

function loadChat(chatId: string | null) {
  return Promise.all([
    chatId ? readVariables(chatId).catch(() => ({}) as Record<string, unknown>) : Promise.resolve({} as Record<string, unknown>),
    chatId ? listMessages(chatId).catch(() => [] as Message[]) : Promise.resolve([] as Message[]),
    loadWorld(chatId),
    chatId ? persona(chatId).catch(() => NO_PERSONA) : Promise.resolve(NO_PERSONA),
    chatId ? chatCharacters(chatId).catch(() => [] as CharacterInfo[]) : Promise.resolve([] as CharacterInfo[]),
    chatStorage(chatId),
    chatId ? readChatData(chatId).catch(() => null) : Promise.resolve(null),
  ]);
}

/** The message a number names in `list` (from 1; negative counts from the end, -1 = the last). */
export function messageAt(list: Message[], num: unknown): Message {
  const n = Number(num);
  const m = Number.isInteger(n) ? (n < 0 ? list[list.length + n] : list.find((x) => x.num === n)) : undefined;
  if (!m) throw new Error(t(`No message #${String(num)}.`, `${String(num)}번 메시지 없음.`));
  return m;
}

export class PageSession {
  /** The page's own chat: its commands act there even if another chat is open by the time they finish. */
  readonly chatId: string | null;
  readonly messageId: string | null;
  readonly preview: boolean;
  readonly script: ScriptContext | null;
  readonly reload: (() => void) | null;
  /** Adds a name the page's scripts see (set by the runtime through PageApi.bindScope). */
  define: (name: string, value: unknown) => void = () => {};
  readonly ui: PageUi;
  /** The chat's variables and chat_metadata, shared with its other pages (a preview's are its own). */
  readonly vars: SharedChat;
  me: PersonaInfo;
  readonly cast: CharacterInfo[];
  readonly storages: { local: PageStorage; session: PageStorage };
  /** The chat's messages as last read. */
  messages: Message[];
  /** Lorebook names, a card's own book also by its SillyTavern name. */
  bookNames: string[];
  /** The chat's own scripts as the page started (getScripts("chat")). */
  chatScripts: LibraryItem[];
  /** Books, characters, personas and regex scripts (read again after the page changes them). */
  world: World;
  /** What the person let this page change outside its chat (asked once each). */
  private readonly allowed = new Set<string>();
  disposed = false;
  /** Messages the page put in itself: its own onMsg / onSend never hear of them (a handler answering its own message would loop). */
  readonly ownIds = new Set<string>();
  readonly ownSends: string[] = [];
  /** The page's AI calls still running, by id (genChat / genRaw): stopped with the page. */
  readonly runs = new Map<string, "raw" | "dryRun">();
  private readonly cleanups: (() => void)[] = [];
  /** When the page called the AI lately (genChat, sendMsg…): past SPEND_LIMIT a minute, the person is asked. */
  private readonly spent: number[] = [];
  private spendStopped = false;
  private readonly reportTo: (message: string) => void;

  constructor(ctx: PageContext, chatId: string | null, loaded: Awaited<ReturnType<typeof loadChat>>) {
    const [vars, messages, world, me, cast, storages, chatData] = loaded;
    const meta = chatData?.meta ?? {};
    this.chatScripts = chatData?.scripts ?? [];
    this.chatId = chatId;
    this.messageId = ctx.messageId ?? null;
    this.preview = ctx.preview === true;
    this.script = ctx.script ?? null;
    this.reload = ctx.reload ?? null;
    this.ui = ctx.ui;
    this.reportTo = ctx.report;
    // one set of variables for every page of the chat; a preview keeps its own copy
    this.vars = chatId && !this.preview ? sharedChat(chatId, vars, meta) : privateChat(vars, meta);
    this.me = me;
    this.cast = cast;
    this.storages = storages;
    this.messages = messages.map((m) => ({ ...m }));
    // whatever reads the chat's messages keeps this list current (getLastMessageId answers at once)
    if (chatId) this.onDispose(onMessagesRead((id, list) => {
      if (id === chatId) this.messages = list;
    }));
    this.world = world;
    this.bookNames = [];
    this.nameBooks();
  }

  private nameBooks(): void {
    // a card's own book also goes by the name it had in SillyTavern
    const books = this.world.books;
    this.bookNames = books.map((b) => b.name);
    for (const c of this.cast) {
      const st = cardBookName(c);
      if (st && !this.bookNames.includes(st) && books.some((b) => b.characterIds?.includes(c.id))) this.bookNames.push(st);
    }
  }

  /** Reads the library again after a change. */
  async freshWorld(): Promise<World> {
    this.world = await loadWorld(this.chatId);
    this.nameBooks();
    return this.world;
  }

  /** A change outside the page's chat: a page in a message asks once per `key`; scripts the person added do not ask. */
  allowOnce(key: string, question: string): boolean {
    if (this.script || this.preview || this.allowed.has(key)) return true;
    if (!this.ui.confirm(question)) return false;
    this.allowed.add(key);
    return true;
  }

  readonly report = (e: unknown): void => this.reportTo(e instanceof Error ? e.message : String(e));

  /** The page's own chat (or, for a page outside any chat, the open one). */
  here(): string {
    return this.chatId ?? requireChat();
  }

  /** The page's own chat is still the open one, and the page is still there. */
  readonly stillHere = (): boolean => !this.disposed && (!this.chatId || currentChatId() === this.chatId);

  /** The number of the page's message now (an earlier message may have been deleted since the page opened). */
  ownNum(): number | null {
    return this.messageId ? (this.messages.find((m) => m.id === this.messageId)?.num ?? null) : null;
  }

  async freshMessages(): Promise<Message[]> {
    return (this.messages = await listMessages(this.here(), { fresh: true }));
  }

  async byNum(num: number): Promise<Message> {
    return messageAt(await this.freshMessages(), num);
  }

  /** Counts an AI call; past SPEND_LIMIT a minute the person is asked, and a no stops the page's calls. */
  budget(name: string): void {
    const now = Date.now();
    while (this.spent.length && now - this.spent[0] > 60_000) this.spent.shift();
    if (this.spendStopped) throw new Error(t(`AI calls stopped: ${name}`, `AI 부르기 멈춤: ${name}`));
    if (this.spent.length >= SPEND_LIMIT) {
      if (!this.ui.confirm(t(`This page called the AI ${this.spent.length} times in a minute. Let it keep calling?\n\n(Cancel stops this page from calling it again.)`, `이 페이지가 1분 사이에 AI를 ${this.spent.length}번 불렀어요. 계속 부르게 할까요?\n\n(취소하면 이 페이지는 더 부르지 않아요.)`))) {
        this.spendStopped = true;
        throw new Error(t(`AI calls stopped: ${name}`, `AI 부르기 멈춤: ${name}`));
      }
      this.spent.length = 0;
    }
    this.spent.push(now);
  }

  /** Runs `fn` when the page goes away. */
  onDispose(fn: () => void): void {
    this.cleanups.push(fn);
  }

  dispose(): void {
    this.disposed = true;
    // a closed page's calls are of no use to anyone
    for (const [id, kind] of this.runs) void abortRun(id, kind, this.chatId);
    this.runs.clear();
    for (const fn of this.cleanups.splice(0)) fn();
  }
}

/** Reads what the page needs (shared with pages opening at the same moment) and opens its session. */
export async function openSession(ctx: PageContext): Promise<PageSession> {
  const chatId = currentChatId();
  return new PageSession(ctx, chatId, await pageSnapshot(chatId, () => loadChat(chatId)));
}
