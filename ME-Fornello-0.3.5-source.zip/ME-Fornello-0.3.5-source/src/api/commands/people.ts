// Page commands for characters and personas: read, change (asked once each),
// make, delete (always asked), import cards, and the chat's persona.

import { t } from "../../shared/i18n";
import { cmd } from "../command";
import { characterData, createCharacter, createPersona, deleteCharacter, deletePersona, importCharacter, saveCharacter, savePersona, setChatPersona, type PersonaRow } from "../library";
import { parseList } from "../parse";
import { ownFirst } from "./lore";
import type { PageSession } from "../session";
import { mergeInto } from "../var-ops";

// ── characters ──

/** Card fields under Fornello's names ↔ SillyTavern's card fields. */
const CARD_FIELDS: Record<string, string> = {
  name: "name",
  description: "description",
  personality: "personality",
  scenario: "scenario",
  firstMessage: "first_mes",
  greetings: "alternate_greetings",
  example: "mes_example",
  systemPrompt: "system_prompt",
  postHistory: "post_history_instructions",
  creatorNotes: "creator_notes",
  creator: "creator",
  version: "character_version",
  tags: "tags",
};

export interface CharItem {
  id: string;
  name: string;
  description: string;
  personality: string;
  scenario: string;
  firstMessage: string;
  greetings: string[];
  example: string;
  systemPrompt: string;
  postHistory: string;
  creatorNotes: string;
  creator: string;
  version: string;
  tags: string[];
  /** Lorebooks linked to the character. */
  books: string[];
  /** The whole card (SillyTavern's fields), extensions too. */
  data: Record<string, unknown>;
}

export function charItem(s: PageSession, id: string, data: Record<string, unknown>): CharItem {
  const text = (k: string) => String(data[k] ?? "");
  return {
    id,
    name: text("name"),
    description: text("description"),
    personality: text("personality"),
    scenario: text("scenario"),
    firstMessage: text("first_mes"),
    greetings: parseList(data.alternate_greetings),
    example: text("mes_example"),
    systemPrompt: text("system_prompt"),
    postHistory: text("post_history_instructions"),
    creatorNotes: text("creator_notes"),
    creator: text("creator"),
    version: text("character_version"),
    tags: parseList(data.tags),
    books: ownFirst(s.world.books.filter((b) => b.characterIds?.includes(id))).map((b) => b.name),
    data: structuredClone(data),
  };
}

/** Fields a page gave (Fornello's names, or SillyTavern's card fields in `data`) as card data. */
function cardPatch(fields: Record<string, unknown>): Record<string, unknown> {
  const out: Record<string, unknown> = fields.data && typeof fields.data === "object" ? structuredClone(fields.data as Record<string, unknown>) : {};
  for (const [ours, card] of Object.entries(CARD_FIELDS)) {
    if (fields[ours] === undefined) continue;
    out[card] = ours === "greetings" || ours === "tags" ? parseList(fields[ours]).map(String) : String(fields[ours] ?? "");
  }
  return out;
}

/** A character by name or id ("current" or nothing: the chat's first). */
export function findChar(s: PageSession, name?: unknown): { id: string; name: string } {
  if (name === undefined || name === null || name === "" || name === "current") {
    const c = s.cast[0];
    if (!c) throw new Error(t("No character in this chat.", "이 채팅에 캐릭터 없음."));
    return c;
  }
  const n = String(name).replace(/\.png$/i, "");
  const c = s.cast.find((x) => x.name === n || x.id === n) ?? s.world.chars.find((x) => x.name === n || x.id === n);
  if (!c) throw new Error(t(`No character: ${n}`, `캐릭터 없음: ${n}`));
  return c;
}

/** The chat's characters answer at once; others come from the library. */
export function getChar(s: PageSession, name?: unknown): CharItem | Promise<CharItem> {
  // a chat without characters: empty fields
  if ((name === undefined || name === null || name === "" || name === "current") && !s.cast[0]) return charItem(s, "", {});
  const found = findChar(s, name);
  const inChat = s.cast.find((c) => c.id === found.id);
  if (inChat) return charItem(s, inChat.id, inChat.data);
  return characterData(found.id).then((data) => charItem(s, found.id, data));
}

/** Changes a character, merged like setVars (`replace`: the card fields given replace the card's). */
export async function setChar(s: PageSession, name: unknown, fields: Record<string, unknown>, options: { replace?: boolean } = {}): Promise<boolean> {
  const found = findChar(s, name);
  if (!s.allowOnce(`char:${found.id}`, t(`This page wants to change character "${found.name}". Allow?`, `이 페이지가 캐릭터 "${found.name}"을(를) 고치려고 해요. 허락할까요?`))) return false;
  const before = await characterData(found.id);
  const patch = cardPatch(fields ?? {});
  const next = options.replace ? { ...before, ...patch } : mergeInto(structuredClone(before), patch);
  await saveCharacter(found.id, next);
  // the chat's own copy follows at once
  const inChat = s.cast.find((c) => c.id === found.id);
  if (inChat) Object.assign(inChat, { name: String(next.name ?? inChat.name), description: String(next.description ?? ""), personality: String(next.personality ?? ""), scenario: String(next.scenario ?? ""), firstMessage: String(next.first_mes ?? ""), data: next });
  await s.freshWorld();
  return true;
}

export async function addChar(s: PageSession, name: unknown, fields: Record<string, unknown> = {}): Promise<string> {
  const data = { ...cardPatch(fields ?? {}), name: String(name ?? "").trim() };
  if (!data.name) throw new Error(t("A name is needed.", "이름이 필요함."));
  const id = await createCharacter(data);
  await s.freshWorld();
  return id;
}

/** Deletes a character from the library (always asked). */
export async function delChar(s: PageSession, name: unknown): Promise<boolean> {
  const found = findChar(s, name);
  if (!s.ui.confirm(t(`This page wants to delete character "${found.name}". Delete?`, `이 페이지가 캐릭터 "${found.name}"을(를) 지우려고 해요. 지울까요?`))) return false;
  await deleteCharacter(found.id);
  await s.freshWorld();
  return true;
}

/** Imports a SillyTavern card: a PNG (Blob) or its JSON (object or text). The new character's name comes back. */
export async function importChar(s: PageSession, file: unknown, filename?: unknown): Promise<string> {
  const card = file instanceof Blob ? file : typeof file === "string" ? (JSON.parse(file) as Record<string, unknown>) : (file as Record<string, unknown>);
  if (!card || typeof card !== "object") throw new Error(t("Not a character card.", "캐릭터 카드가 아님."));
  const id = await importCharacter(card, String(filename ?? "card.png"));
  const world = await s.freshWorld();
  return world.chars.find((c) => c.id === id)?.name ?? "";
}

// ── personas ──

export interface UserItem {
  id: string | null;
  name: string;
  description: string;
  personality: string;
  scenario: string;
  backstory: string;
  appearance: string;
  tags: string[];
  /** Picture path (for <img src>). */
  avatar: string | null;
  books: string[];
}

const PERSONA_FIELDS = ["name", "description", "personality", "scenario", "backstory", "appearance", "tags"] as const;

function userItem(s: PageSession, p: PersonaRow): UserItem {
  return {
    id: p.id,
    name: p.name,
    description: p.description,
    personality: p.personality,
    scenario: p.scenario,
    backstory: p.backstory,
    appearance: p.appearance,
    tags: [...p.tags],
    avatar: p.avatarPath,
    books: s.world.books.filter((b) => b.personaIds?.includes(p.id)).map((b) => b.name),
  };
}

/** A persona by name or id ("current" or nothing: the chat's). */
export function findPersona(s: PageSession, name?: unknown): PersonaRow | null {
  const n = name === undefined || name === null || name === "" || name === "current" ? null : String(name);
  const id = n === null ? s.me.id : null;
  return s.world.personas.find((p) => (id ? p.id === id : p.name === n || p.id === n)) ?? null;
}

function getUser(s: PageSession, name?: unknown): UserItem {
  const p = findPersona(s, name);
  if (p) return userItem(s, p);
  if (name !== undefined && name !== null && name !== "" && name !== "current") throw new Error(t(`No persona: ${String(name)}`, `페르소나 없음: ${String(name)}`));
  // a chat without a persona speaks as "User"
  return { id: s.me.id, name: s.me.name, description: s.me.description, personality: "", scenario: "", backstory: "", appearance: "", tags: [], avatar: null, books: [] };
}

function personaPatch(fields: Record<string, unknown>): Record<string, unknown> {
  const out: Record<string, unknown> = {};
  for (const k of PERSONA_FIELDS) if (fields[k] !== undefined) out[k] = k === "tags" ? parseList(fields[k]) : String(fields[k] ?? "");
  return out;
}

function requirePersona(s: PageSession, name: unknown): PersonaRow {
  const p = findPersona(s, name);
  if (!p) throw new Error(t(`No persona: ${String(name ?? "current")}`, `페르소나 없음: ${String(name ?? "current")}`));
  return p;
}

export async function setUser(s: PageSession, name: unknown, fields: Record<string, unknown>): Promise<boolean> {
  const p = requirePersona(s, name);
  if (!s.allowOnce(`persona:${p.id}`, t(`This page wants to change persona "${p.name}". Allow?`, `이 페이지가 페르소나 "${p.name}"을(를) 고치려고 해요. 허락할까요?`))) return false;
  await savePersona(p.id, personaPatch(fields ?? {}));
  await s.freshWorld();
  return true;
}

export async function addUser(s: PageSession, name: unknown, fields: Record<string, unknown> = {}): Promise<string> {
  const data = { ...personaPatch(fields ?? {}), name: String(name ?? "").trim() };
  if (!data.name) throw new Error(t("A name is needed.", "이름이 필요함."));
  const id = await createPersona(data);
  await s.freshWorld();
  return id;
}

export async function delUser(s: PageSession, name: unknown): Promise<boolean> {
  const p = requirePersona(s, name);
  if (!s.ui.confirm(t(`This page wants to delete persona "${p.name}". Delete?`, `이 페이지가 페르소나 "${p.name}"을(를) 지우려고 해요. 지울까요?`))) return false;
  await deletePersona(p.id);
  await s.freshWorld();
  return true;
}

/** This chat speaks as another persona. */
async function useUser(s: PageSession, name: unknown): Promise<void> {
  const p = requirePersona(s, name);
  await setChatPersona(s.here(), p.id);
  s.me = { id: p.id, name: p.name, description: p.description };
}

export function peopleCommands(s: PageSession) {
  return {
    getChar: cmd((name?: unknown) => getChar(s, name)),
    getChars: cmd(() => s.world.chars.map((c) => c.name)),
    setChar: cmd({ writes: true }, (name: unknown, fields: Record<string, unknown>, options?: { replace?: boolean }) => setChar(s, name, fields, options)),
    addChar: cmd({ writes: true }, (name: unknown, fields?: Record<string, unknown>) => addChar(s, name, fields)),
    delChar: cmd({ writes: true }, (name: unknown) => delChar(s, name)),
    importChar: cmd({ writes: true }, (file: unknown, filename?: unknown) => importChar(s, file, filename)),
    getUser: cmd((name?: unknown) => getUser(s, name)),
    getUsers: cmd(() => s.world.personas.map((p) => p.name)),
    setUser: cmd({ writes: true }, (name: unknown, fields: Record<string, unknown>) => setUser(s, name, fields)),
    addUser: cmd({ writes: true }, (name: unknown, fields?: Record<string, unknown>) => addUser(s, name, fields)),
    delUser: cmd({ writes: true }, (name: unknown) => delUser(s, name)),
    useUser: cmd({ writes: true }, (name: unknown) => useUser(s, name)),
  };
}
