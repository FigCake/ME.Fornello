// The running scripts' buttons, where the person put them (a script's ⋮ menu): one 🔥 bubble in
// Dispensa's Dock, and the Status tab. A script's buttons go nowhere until it is put somewhere.

import { DISPENSA_READY, type DockGroup } from "../shared/dispensa-bridge";
import type { ScriptButtonView } from "../scripts/host";
import { placeOf, withPlace } from "../scripts/places";
import type { Settings } from "../settings";
import { t } from "../shared/i18n";

const DOCK_ID = "fornello";

export class ScriptButtons {
  private list: ScriptButtonView[] = [];
  private readonly onDispensa = () => this.toDock();
  /** The Status tab's buttons changed. */
  onChange: (() => void) | null = null;

  constructor(private readonly settings: Settings) {}

  start(): void {
    window.addEventListener(DISPENSA_READY, this.onDispensa);
  }

  stop(): void {
    window.removeEventListener(DISPENSA_READY, this.onDispensa);
    this.list = [];
    this.toDock();
  }

  set(list: ScriptButtonView[]): void {
    this.list = list;
    this.refresh();
  }

  /** Where buttons go changed (or what runs): the Dock and the Status tab again. */
  refresh(): void {
    this.toDock();
    this.onChange?.();
  }

  /** The buttons put on the Status tab. */
  onStatus(): ScriptButtonView[] {
    return this.list.filter((b) => placeOf(this.settings.current, b.key).status);
  }

  private toDock(): void {
    const dispensa = window.__dispensa;
    if (typeof dispensa?.setDockGroup !== "function") return;
    const shown = this.list.filter((b) => placeOf(this.settings.current, b.key).dock);
    const group: DockGroup | null = shown.length
      ? {
          name: t("Scripts (Fornello)", "스크립트 (Fornello)"),
          icon: "🔥",
          items: shown.map((b) => ({ label: b.label, group: b.script, title: t(`Script: ${b.script}`, `스크립트: ${b.script}`), run: b.press })),
          // off the Dock in Dispensa's settings: these scripts' "On the Dock" goes off
          remove: () => {
            let places = this.settings.current.scriptPlaces;
            for (const key of new Set(shown.map((b) => b.key))) places = withPlace({ ...this.settings.current, scriptPlaces: places }, key, { dock: false });
            // and the cards' scripts that went there before there was a choice
            void this.settings.set({ scriptPlaces: places, legacyDock: false });
          },
        }
      : null;
    try {
      dispensa.setDockGroup(DOCK_ID, group);
    } catch {
      // a Dispensa that is stopping
    }
  }
}
