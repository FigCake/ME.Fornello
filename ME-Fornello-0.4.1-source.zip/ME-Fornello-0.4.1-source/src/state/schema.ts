// Pesto's schema: what values a story keeps, of which kind, in which range, and who may
// change them. A card writes it as YAML in its `pesto:schema` entry:
//
//   fields:
//     hp: { type: number, min: 0, max: max_hp, default: 100 }
//     max_hp: { type: int, default: 100, write: rules }
//     mood: { type: enum, of: [calm, angry, sad] }
//     bag: { type: list, of: text, max_items: 10 }
//     trust: { type: map, of: { type: int, min: -100, max: 100 } }   # any names: trust.<name>
//     player:                                                        # a group of values
//       name: text
//       level: 1                                                     # a kind and default at once
//   derive:
//     dying: hp < max_hp * 0.2                                       # computed, never written
//
// Kinds: number, int, text (or string), bool, enum, list, map, any; a field without `type` is a group.
// Limits (min, max) are numbers or expressions; a value outside them is brought inside.
// `write`: who may change it, any of ai, rules, user (all by default; `readonly: true` is none,
// only the starting values). `hidden: true` keeps it from the AI; `show_when` and `note` are for
// what the AI is shown.

import { exprProblem } from "./expr";

export type Writer = "ai" | "rules" | "user";
export const WRITERS: Writer[] = ["ai", "rules", "user"];

export type Kind = "number" | "int" | "text" | "bool" | "enum" | "list" | "map" | "object" | "any";

export interface Field {
  kind: Kind;
  default?: unknown;
  min?: number | string;
  max?: number | string;
  /** enum: the allowed words */
  values?: string[];
  /** list and map: what each item is */
  item?: Field;
  /** object (a group): its fields */
  fields?: Record<string, Field>;
  maxItems?: number;
  /** who may change it; undefined: as the group around it says */
  write?: Writer[];
  hidden?: boolean;
  showWhen?: string;
  note?: string;
}

export interface Schema {
  root: Field;
  /** name → expression; computed from the values whenever they are read */
  derive: Record<string, string>;
}

export interface SchemaProblem {
  path: string;
  why: string;
}

const KINDS: Record<string, Kind> = {
  number: "number",
  float: "number",
  int: "int",
  integer: "int",
  text: "text",
  string: "text",
  str: "text",
  bool: "bool",
  boolean: "bool",
  enum: "enum",
  choice: "enum",
  list: "list",
  array: "list",
  map: "map",
  record: "map",
  object: "object",
  group: "object",
  any: "any",
};

const isPlain = (v: unknown): v is Record<string, unknown> => !!v && typeof v === "object" && !Array.isArray(v);
const NAME = /^[\p{L}_$][\p{L}\p{N}_$]*$/u;

/** Reads a schema as the YAML gave it; problems name what was left out and why. */
export function readSchema(raw: unknown): { schema: Schema; problems: SchemaProblem[] } {
  const problems: SchemaProblem[] = [];
  const top = isPlain(raw) ? raw : {};
  if (raw !== null && raw !== undefined && !isPlain(raw)) problems.push({ path: "", why: "the schema must be a set of names" });
  // `fields:` and `derive:` at the top, or the fields themselves
  const fieldsRaw = isPlain(top.fields) && typeof top.fields.type !== "string" ? top.fields : Object.fromEntries(Object.entries(top).filter(([k]) => k !== "derive"));
  const root: Field = { kind: "object", fields: {} };
  for (const [name, def] of Object.entries(fieldsRaw)) {
    const f = readField(def, name, problems);
    if (f) root.fields![name] = f;
  }
  const derive: Record<string, string> = {};
  if (isPlain(top.derive)) {
    for (const [name, expr] of Object.entries(top.derive)) {
      const src = typeof expr === "number" || typeof expr === "boolean" ? String(expr) : expr;
      if (!NAME.test(name)) problems.push({ path: `derive.${name}`, why: "a computed value's name is one word" });
      else if (root.fields![name]) problems.push({ path: `derive.${name}`, why: "a value of this name is in the fields" });
      else if (typeof src !== "string") problems.push({ path: `derive.${name}`, why: "needs an expression" });
      else {
        const problem = exprProblem(src);
        if (problem) problems.push({ path: `derive.${name}`, why: problem });
        else derive[name] = src;
      }
    }
  }
  return { schema: { root, derive }, problems };
}

function readWriters(v: unknown, path: string, problems: SchemaProblem[]): Writer[] | undefined {
  if (v === undefined || v === null) return undefined;
  const list = (Array.isArray(v) ? v : String(v).split(/[\s,]+/)).map((x) => String(x).trim().toLowerCase()).filter(Boolean);
  if (list.includes("all")) return [...WRITERS];
  if (list.includes("none")) return [];
  const out = list.filter((w): w is Writer => (WRITERS as string[]).includes(w));
  if (out.length !== list.length) problems.push({ path, why: `write: one or more of ${WRITERS.join(", ")}` });
  return out;
}

function readBound(v: unknown, path: string, problems: SchemaProblem[]): number | string | undefined {
  if (v === undefined || v === null) return undefined;
  if (typeof v === "number") return v;
  const problem = exprProblem(String(v));
  if (problem) {
    problems.push({ path, why: problem });
    return undefined;
  }
  return String(v);
}

function readField(raw: unknown, path: string, problems: SchemaProblem[]): Field | undefined {
  // shorthands: `name: text` (a kind), `level: 1` (a kind and its default), `bag: []`
  if (typeof raw === "string" && KINDS[raw.toLowerCase()]) return { kind: KINDS[raw.toLowerCase()] };
  if (typeof raw === "number") return { kind: Number.isInteger(raw) ? "int" : "number", default: raw };
  if (typeof raw === "boolean") return { kind: "bool", default: raw };
  if (typeof raw === "string") return { kind: "text", default: raw };
  if (Array.isArray(raw)) return { kind: "list", default: raw };
  if (!isPlain(raw)) {
    problems.push({ path, why: "a field needs a kind" });
    return undefined;
  }
  const typeName = typeof raw.type === "string" ? raw.type.toLowerCase() : undefined;
  if (typeName === undefined) {
    // a group: every name in it is a field
    const fields: Record<string, Field> = {};
    for (const [name, def] of Object.entries(raw)) {
      const f = readField(def, `${path}.${name}`, problems);
      if (f) fields[name] = f;
    }
    return { kind: "object", fields };
  }
  const kind = KINDS[typeName];
  if (!kind) {
    problems.push({ path, why: `"${raw.type}" is not a kind (${Object.keys(KINDS).join(", ")})` });
    return undefined;
  }
  const field: Field = { kind };
  if (kind === "enum") {
    const values = Array.isArray(raw.of) ? raw.of : Array.isArray(raw.values) ? raw.values : [];
    field.values = values.map(String);
    if (!field.values.length) problems.push({ path, why: "an enum lists its words in `of`" });
  }
  if (kind === "list" || kind === "map") {
    const item = raw.of ?? raw.item ?? raw.items;
    if (item !== undefined) field.item = readField(item, `${path}[]`, problems);
    if (typeof raw.max_items === "number" && raw.max_items >= 0) field.maxItems = Math.floor(raw.max_items);
  }
  if (kind === "object") {
    field.fields = {};
    for (const [name, def] of Object.entries(isPlain(raw.fields) ? raw.fields : {})) {
      const f = readField(def, `${path}.${name}`, problems);
      if (f) field.fields[name] = f;
    }
  }
  if (kind === "number" || kind === "int") {
    field.min = readBound(raw.min, `${path}.min`, problems);
    field.max = readBound(raw.max, `${path}.max`, problems);
  }
  if ("default" in raw) field.default = raw.default;
  const write = raw.readonly === true ? [] : readWriters(raw.write, `${path}.write`, problems);
  if (write) field.write = write;
  if (raw.hidden === true) field.hidden = true;
  if (raw.show_when !== undefined && raw.show_when !== null) {
    const src = String(raw.show_when);
    const problem = exprProblem(src);
    if (problem) problems.push({ path: `${path}.show_when`, why: problem });
    else field.showWhen = src;
  }
  if (typeof raw.note === "string") field.note = raw.note;
  return field;
}

/** The field a path points at (through groups, list items and map entries), with who may write it. */
export function fieldAt(root: Field, parts: string[]): { field: Field; write: Writer[] } | undefined {
  let field = root;
  let write = root.write ?? [...WRITERS];
  for (const part of parts) {
    let next: Field | undefined;
    if (field.kind === "object") next = Object.hasOwn(field.fields ?? {}, part) ? field.fields![part] : undefined;
    else if (field.kind === "list") next = /^(?:\d+|-)$/.test(part) ? (field.item ?? { kind: "any" }) : undefined;
    else if (field.kind === "map") next = part === "__proto__" ? undefined : (field.item ?? { kind: "any" });
    else if (field.kind === "any") next = field;
    if (!next) return undefined;
    field = next;
    if (field.write) write = field.write;
  }
  return { field, write };
}

/** A field's starting value: its default, or the kind's empty value (an enum's first word, a number's min). */
export function emptyValue(field: Field): unknown {
  if (field.kind === "object") {
    const out: Record<string, unknown> = {};
    for (const [name, f] of Object.entries(field.fields ?? {})) out[name] = emptyValue(f);
    if (isPlain(field.default)) Object.assign(out, structuredClone(field.default));
    return out;
  }
  if (field.default !== undefined) return field.default !== null && typeof field.default === "object" ? structuredClone(field.default) : field.default;
  switch (field.kind) {
    case "number":
    case "int":
      return typeof field.min === "number" && field.min > 0 ? field.min : 0;
    case "text":
      return "";
    case "bool":
      return false;
    case "enum":
      return field.values?.[0] ?? "";
    case "list":
      return [];
    case "map":
      return {};
    default:
      return null;
  }
}
