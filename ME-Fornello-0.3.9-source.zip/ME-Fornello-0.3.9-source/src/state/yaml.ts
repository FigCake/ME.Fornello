// A small YAML reader for Pesto's card entries (schema, starting values, rules). It reads
// what those entries need: nested mappings and lists by indentation, `- ` items (also with a
// mapping on the same line), quoted and plain scalars, `[...]` and `{...}` (over several lines,
// trailing commas allowed), `#` comments, and `|` / `>` text blocks. JSON is YAML too, and is read
// as it is. Anchors, tags and several documents are not part of it.
//
// Two leniencies for rule expressions: a value after `key:` is the rest of the line (so
// `when: a ? b : c` works), and a plain value inside [...] or {...} keeps what is between
// brackets inside it (so `{ hp: min(hp + 10, max_hp) }` and `{ trust.{who}: 3 }` read as meant).

export class YamlError extends Error {
  constructor(
    message: string,
    readonly line: number,
  ) {
    super(`line ${line}: ${message}`);
  }
}

interface Line {
  indent: number;
  text: string; // without the indentation; comments still in
  no: number; // 1-based
}

/** Reads YAML (or JSON) text into plain values. Throws YamlError. */
export function readYaml(source: string): unknown {
  const trimmed = source.trim();
  if (!trimmed) return null;
  if (/^[[{"]/.test(trimmed)) {
    try {
      return JSON.parse(trimmed);
    } catch {
      // not strict JSON: read it as YAML below (trailing commas, comments, plain words)
    }
  }
  const lines: Line[] = source.split(/\r?\n/).map((raw, i) => {
    const expanded = raw.replace(/^[ \t]+/, (lead) => lead.replace(/\t/g, "  "));
    const text = expanded.trimStart();
    return { indent: expanded.length - text.length, text: text.trimEnd(), no: i + 1 };
  });
  const reader = new BlockReader(lines);
  const value = reader.block(0);
  reader.skip();
  if (reader.at < lines.length) throw new YamlError("unexpected text", lines[reader.at].no);
  return value;
}

/** A quote opens quoted text only at the start of a value, not inside a word (it's, can't). */
const opensQuote = (text: string, i: number) => i === 0 || /[\s[{(,:]/.test(text[i - 1]);

/** The text before a `#` comment (a `#` at the start or after a space, outside quotes). */
function stripComment(text: string): string {
  let quote = "";
  for (let i = 0; i < text.length; i++) {
    const c = text[i];
    if (quote) {
      if (c === "\\" && quote === '"') i++;
      else if (c === quote) quote = "";
    } else if (c === '"' || c === "'") {
      if (opensQuote(text, i)) quote = c;
    } else if (c === "#" && (i === 0 || /\s/.test(text[i - 1]))) return text.slice(0, i).trimEnd();
  }
  return text;
}

const KEY = /^("(?:[^"\\]|\\.)*"|'(?:[^']|'')*'|[^\s#'"{[\-?:][^#]*?|-[^\s#][^#]*?)\s*:(?:\s+|$)/;
/** `name: value` at the start of a line; a line without a colon isn't tried (KEY is slow on long lines of spaces). */
const keyOf = (text: string) => (text.includes(":") ? KEY.exec(text) : null);
const isSkippable = (l: Line) => {
  const t = stripComment(l.text);
  return t === "" || t === "---" || t === "...";
};

class BlockReader {
  at = 0;
  constructor(private lines: Line[]) {}

  /** Moves past blank and comment lines. */
  skip() {
    while (this.at < this.lines.length && isSkippable(this.lines[this.at])) this.at++;
  }

  /** The value whose lines are indented at least `min`. */
  block(min: number): unknown {
    this.skip();
    const line = this.lines[this.at];
    if (!line || line.indent < min) return null;
    const text = stripComment(line.text);
    if (text === "-" || text.startsWith("- ")) return this.sequence(line.indent);
    if (keyOf(text)) return this.mapping(line.indent);
    this.at++;
    if (text.startsWith("[") || text.startsWith("{")) return this.flow(text, line);
    return scalar(text, line.no);
  }

  private sequence(indent: number): unknown[] {
    const out: unknown[] = [];
    for (;;) {
      this.skip();
      const line = this.lines[this.at];
      if (!line || line.indent !== indent) break;
      const text = stripComment(line.text);
      if (!(text === "-" || text.startsWith("- "))) break;
      const rest = text === "-" ? "" : text.slice(2).trimStart();
      if (rest === "") {
        this.at++;
        out.push(this.block(indent + 1));
      } else {
        // "- key: v" or "- - x": the rest of the line starts a block at its own column
        const column = indent + (line.text.length - line.text.slice(1).trimStart().length);
        this.lines[this.at] = { indent: column, text: line.text.slice(column - indent), no: line.no };
        out.push(this.block(column));
      }
    }
    return out;
  }

  private mapping(indent: number): Record<string, unknown> {
    const out: Record<string, unknown> = {};
    for (;;) {
      this.skip();
      const line = this.lines[this.at];
      if (!line || line.indent !== indent) break;
      const text = stripComment(line.text);
      const m = keyOf(text);
      if (!m) {
        if (line.indent === indent && (text === "-" || text.startsWith("- "))) break;
        throw new YamlError("expected `name: value`", line.no);
      }
      const key = String(scalar(m[1].trim(), line.no) ?? "");
      if (key === "__proto__") throw new YamlError("`__proto__` can't be a name", line.no);
      const rest = text.slice(m[0].length).trim();
      this.at++;
      if (rest === "") {
        // the value is on the next lines, deeper (or a list at the same indentation, as YAML allows)
        this.skip();
        const next = this.lines[this.at];
        const nextText = next ? stripComment(next.text) : "";
        if (next && next.indent === indent && (nextText === "-" || nextText.startsWith("- "))) out[key] = this.sequence(indent);
        else out[key] = this.block(indent + 1);
      } else if (/^[|>][-+]?$/.test(rest)) out[key] = this.textBlock(indent, rest);
      else if (rest.startsWith("[") || rest.startsWith("{")) out[key] = this.flow(rest, line);
      else out[key] = scalar(rest, line.no);
    }
    return out;
  }

  /** `|` keeps line breaks, `>` joins lines with spaces; `-` drops the last line break, `+` keeps all. */
  private textBlock(indent: number, mark: string): string {
    const rows: string[] = [];
    let inner = -1;
    while (this.at < this.lines.length) {
      const line = this.lines[this.at];
      if (line.text === "") {
        rows.push("");
        this.at++;
        continue;
      }
      if (line.indent <= indent) break;
      if (inner < 0) inner = line.indent;
      if (line.indent < inner) break;
      rows.push(" ".repeat(line.indent - inner) + line.text);
      this.at++;
    }
    const trailing = rows.length - (rows.findLastIndex((r) => r !== "") + 1);
    const body = rows.slice(0, rows.length - trailing);
    let text = mark[0] === "|" ? body.join("\n") : body.reduce((acc, r, i) => (i === 0 ? r : acc + (r === "" || body[i - 1] === "" ? "\n" : " ") + r), "");
    if (mark[1] === "+") text += "\n".repeat(trailing + 1);
    else if (mark[1] !== "-" && text !== "") text += "\n";
    return text;
  }

  /** A [...] or {...} value, taking more lines until its brackets close. */
  private flow(first: string, line: Line): unknown {
    let text = first;
    while (!closed(text)) {
      if (this.at >= this.lines.length) throw new YamlError("a [ or { is not closed", line.no);
      text += "\n" + stripComment(this.lines[this.at++].text);
    }
    const reader = new FlowReader(text, line.no);
    const value = reader.value(false);
    reader.space();
    if (reader.pos < text.length) throw new YamlError("unexpected text after the closing bracket", line.no);
    return value;
  }
}

/** Whether the brackets in `text` are all closed (quotes respected). */
function closed(text: string): boolean {
  let depth = 0;
  let quote = "";
  for (let i = 0; i < text.length; i++) {
    const c = text[i];
    if (quote) {
      if (c === "\\" && quote === '"') i++;
      else if (c === quote) quote = "";
    } else if ((c === '"' || c === "'") && opensQuote(text, i)) quote = c;
    else if (c === "[" || c === "{") depth++;
    else if (c === "]" || c === "}") depth--;
  }
  return depth <= 0;
}

class FlowReader {
  pos = 0;
  constructor(
    private text: string,
    private line: number,
  ) {}

  private fail(message: string): never {
    throw new YamlError(message, this.line + (this.text.slice(0, this.pos).match(/\n/g)?.length ?? 0));
  }

  space() {
    while (this.pos < this.text.length && /\s/.test(this.text[this.pos])) this.pos++;
  }

  value(asKey: boolean): unknown {
    this.space();
    const c = this.text[this.pos];
    if (c === "[") return this.list();
    if (c === "{") return this.map();
    if (c === '"' || c === "'") return this.quoted();
    return this.plain(asKey);
  }

  private list(): unknown[] {
    const out: unknown[] = [];
    this.pos++;
    for (;;) {
      this.space();
      if (this.text[this.pos] === "]") break;
      out.push(this.value(false));
      this.space();
      if (this.text[this.pos] === ",") this.pos++;
      else if (this.text[this.pos] !== "]") this.fail("expected , or ]");
    }
    this.pos++;
    return out;
  }

  private map(): Record<string, unknown> {
    const out: Record<string, unknown> = {};
    this.pos++;
    for (;;) {
      this.space();
      if (this.text[this.pos] === "}") break;
      const key = String(this.value(true) ?? "");
      if (key === "__proto__") this.fail("`__proto__` can't be a name");
      this.space();
      if (this.text[this.pos] === ":") {
        this.pos++;
        out[key] = this.value(false);
      } else out[key] = null;
      this.space();
      if (this.text[this.pos] === ",") this.pos++;
      else if (this.text[this.pos] !== "}") this.fail("expected , or }");
    }
    this.pos++;
    return out;
  }

  private quoted(): string {
    const quote = this.text[this.pos];
    const start = this.pos;
    this.pos++;
    while (this.pos < this.text.length) {
      const c = this.text[this.pos];
      if (quote === '"' && c === "\\") this.pos += 2;
      else if (c === quote) {
        if (quote === "'" && this.text[this.pos + 1] === "'") this.pos += 2;
        else break;
      } else this.pos++;
    }
    if (this.pos >= this.text.length) this.fail("a quote is not closed");
    this.pos++;
    return unquote(this.text.slice(start, this.pos), this.line) as string;
  }

  /** A plain value up to , ] } (or `: ` for a name), keeping what is between brackets inside it (`min(a, b)`, `trust.{who}`). */
  private plain(asKey: boolean): unknown {
    const start = this.pos;
    let depth = 0;
    let quote = "";
    for (; this.pos < this.text.length; this.pos++) {
      const c = this.text[this.pos];
      if (quote) {
        if (c === "\\" && quote === '"') this.pos++;
        else if (c === quote) quote = "";
        continue;
      }
      if ((c === '"' || c === "'") && opensQuote(this.text, this.pos)) quote = c;
      else if (c === "(" || c === "[" || c === "{") depth++;
      else if (depth > 0 && (c === ")" || c === "]" || c === "}")) depth--;
      else if (depth <= 0 && (c === "," || c === "]" || c === "}")) break;
      else if (depth <= 0 && asKey && c === ":" && /[\s,}\]]|^$/.test(this.text[this.pos + 1] ?? "")) break;
    }
    const raw = this.text.slice(start, this.pos).trim();
    if (raw === "" && !asKey) this.fail("a value is missing");
    return scalar(raw, this.line);
  }
}

function unquote(text: string, line: number): unknown {
  if (text.startsWith('"')) {
    try {
      return JSON.parse(text.replace(/\n\s*/g, " ").replace(/\\'/g, "'"));
    } catch {
      throw new YamlError("a quoted text has a bad escape", line);
    }
  }
  return text.slice(1, -1).replace(/''/g, "'").replace(/\n\s*/g, " ");
}

/** A plain or quoted scalar: null, true/false, a number, or text. */
function scalar(text: string, line: number): unknown {
  if (/^"(?:[^"\\]|\\.)*"$/.test(text) || /^'(?:[^']|'')*'$/.test(text)) return unquote(text, line);
  if (/^(?:~|null|Null|NULL)$/.test(text) || text === "") return null;
  if (/^(?:true|True|TRUE)$/.test(text)) return true;
  if (/^(?:false|False|FALSE)$/.test(text)) return false;
  if (/^[-+]?(?:\d[\d_]*(?:\.\d*)?|\.\d+)(?:[eE][-+]?\d+)?$/.test(text)) return Number(text.replace(/_/g, ""));
  if (/^[&*]\S/.test(text)) throw new YamlError("anchors (&, *) are not supported", line);
  return text;
}
