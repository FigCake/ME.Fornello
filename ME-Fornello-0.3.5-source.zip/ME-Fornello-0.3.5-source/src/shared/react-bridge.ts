// Same file in Dispensa and Fornello (src/shared/): after a change, run
// `npm run shared -- sync <path to the other repository>`.

// Marinara caches chat messages with React Query and has no public refresh
// hook, so after writing through the API we find the QueryClient on the
// React tree and invalidate the chat's queries. If the lookup ever fails,
// the write still happened; the chat just shows it on the next refresh.

interface QueryClientLike {
  invalidateQueries(filters: { queryKey: unknown[] }): Promise<void> | void;
}

let cached: QueryClientLike | null = null;

function isQueryClient(v: unknown): v is QueryClientLike {
  return !!v && typeof v === "object" && typeof (v as QueryClientLike).invalidateQueries === "function" && typeof (v as { getQueryCache?: unknown }).getQueryCache === "function";
}

/** Climbs from an element React drew up through its parents to the QueryClientProvider. */
function findQueryClient(): QueryClientLike | null {
  if (cached) return cached;
  const node = document.querySelector("#root *");
  const fiberKey = node && Object.keys(node).find((k) => k.startsWith("__reactFiber$"));
  type Fiber = { return?: Fiber | null; memoizedProps?: { client?: unknown } };
  for (let fiber = fiberKey ? (node as unknown as Record<string, Fiber>)[fiberKey] : null; fiber; fiber = fiber.return ?? null) {
    const client = fiber.memoizedProps?.client;
    if (isQueryClient(client)) return (cached = client);
  }
  return null;
}

export function refreshChatQueries(chatId: string): boolean {
  const client = findQueryClient();
  if (!client) return false;
  void client.invalidateQueries({ queryKey: ["chats", "messages", chatId] });
  void client.invalidateQueries({ queryKey: ["chats", chatId] });
  return true;
}

/**
 * Switch Marinara to another chat. The sidebar row is a button with
 * data-chat-id; clicking it is what the user would do. When the row is not
 * on screen (sidebar closed, other tab), fall back to a reload with the chat
 * remembered as active.
 */
export async function openChat(chatId: string): Promise<void> {
  const client = findQueryClient();
  if (client) await client.invalidateQueries({ queryKey: ["chats", "list"] });
  const selector = `[role="button"][data-chat-id="${CSS.escape(chatId)}"]`;
  for (let i = 0; i < 20; i++) {
    const row = document.querySelector<HTMLElement>(selector);
    if (row) {
      row.click();
      return;
    }
    await new Promise((r) => setTimeout(r, 100));
  }
  localStorage.setItem("marinara-active-chat-id", chatId);
  location.reload();
}

/** Invalidate a few React Query keys (best effort). */
export function refreshQueries(keys: unknown[][]): boolean {
  const client = findQueryClient();
  if (!client) return false;
  for (const queryKey of keys) void client.invalidateQueries({ queryKey });
  return true;
}
