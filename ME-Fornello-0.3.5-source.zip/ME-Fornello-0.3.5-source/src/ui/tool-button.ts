// The small round buttons in the corner of a page or component.

/** An icon button; `label` is its tooltip and what screen readers say. */
export function toolButton(svg: string, label: string, onClick: () => void): HTMLButtonElement {
  const b = document.createElement("button");
  b.type = "button";
  b.title = label;
  b.setAttribute("aria-label", label);
  b.innerHTML = svg;
  b.addEventListener("click", onClick);
  return b;
}
