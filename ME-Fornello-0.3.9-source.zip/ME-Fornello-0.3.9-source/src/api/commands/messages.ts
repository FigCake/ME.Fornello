// Page commands for the chat's messages and its input.

import { findComposer, isGenerating, setComposerText, submitThroughComposer, waitUntil } from "../../shared/composer";
import { t } from "../../shared/i18n";
import { type WatchKind, chatWatch } from "../chat-watch";
import { stopRun } from "./generate";
import { cmd } from "../command";
import { requestRegenerate } from "../../host/events";
import { addMessage, deleteMessages, editMessage } from "../marinara";
import { MESSAGE_DATA } from "../chat-store";
import { injectFor } from "./replies";
import { mergeInto } from "../var-ops";
import { clearQuietEdit, markQuietEdit } from "../quiet-edits";
import { messageAt, type PageSession } from "../session";
import type { Message } from "../types";

// One send or regenerate at a time, for every page: a double click sends once.
let sending = false;

export async function untilReplyDone(): Promise<void> {
  // a reply that is about to start shows the stop button first
  await waitUntil(() => isGenerating(findComposer()), 2500, 100);
  await waitUntil(() => !isGenerating(findComposer()), 10 * 60_000, 300);
}

/** Fornello is turned off: a send cut short must not block the next. */
export function resetSending(): void {
  sending = false;
}

/** Runs `fn` unless another send is still going (then answers false). */
export async function whileSending<T>(fn: () => Promise<T>): Promise<T | false> {
  if (sending) return false;
  sending = true;
  try {
    return await fn();
  } finally {
    sending = false;
  }
}

export async function sendMsg(s: PageSession, text: unknown, confirm = false): Promise<boolean> {
  const line = String(text ?? "").trim();
  if (!line) return false;
  if (confirm && !s.ui.confirm(t(`Send this?\n\n${line}`, `이 글을 보낼까요?\n\n${line}`))) return false;
  const done = await whileSending(async () => {
    s.ownSends.push(line);
    if (s.ownSends.length > 5) s.ownSends.shift();
    await submitThroughComposer(line, s.stillHere);
    await untilReplyDone();
    return true;
  });
  if (done === false) s.ui.toast(t("The last send is still in progress.", "앞서 보낸 것이 아직 처리 중이에요."), "warning");
  return done;
}

export async function sendRegen(s: PageSession, hint?: unknown, confirm = false): Promise<boolean> {
  if (confirm && !s.ui.confirm(t("Have the last reply written again?", "마지막 답변을 새로 쓰게 할까요?"))) return false;
  const id = s.here();
  const guide = String(hint ?? "").trim();
  const done = await whileSending(async () => {
    // text for the AI is English whatever the screen language; in this reply's prompt only
    if (guide) await injectFor(s, `[Guidance for this reply: ${guide}]`, { depth: 0, once: true });
    requestRegenerate(id);
    await untilReplyDone();
    return true;
  });
  if (done === false) s.ui.toast(t("The last send is still in progress.", "앞서 보낸 것이 아직 처리 중이에요."), "warning");
  return done;
}

export async function setMsg(s: PageSession, num: unknown, text: unknown, options: { refresh?: boolean } = {}): Promise<boolean> {
  const m = await s.byNum(Number(num));
  const refresh = options.refresh !== false;
  const value = String(text ?? "");
  if (refresh) clearQuietEdit(m.id);
  else markQuietEdit(m.id, value);
  await editMessage(m.id, value, { refresh }, s.here());
  m.text = value;
  return true;
}

export interface AddMsgOptions {
  /** Which character writes it (a "char" message), by name. */
  name?: string;
  /** Hidden from the AI. */
  hidden?: boolean;
  /** Data kept with it (getMsgData). */
  data?: Record<string, unknown>;
  /** Put in before this message number instead of at the end. */
  before?: number;
}

/** Adds a message without a reply; its number comes back. */
export async function addMsg(s: PageSession, text: unknown, role: unknown = "char", options: AddMsgOptions = {}): Promise<number> {
  const extra: Record<string, unknown> = {};
  if (options.hidden) extra.hiddenFromAI = true;
  if (options.data) extra[MESSAGE_DATA] = mergeInto({}, options.data);
  let characterId: string | null | undefined;
  if (options.name !== undefined) {
    const found = s.cast.find((c) => c.name === String(options.name));
    if (!found) throw new Error(t(`No character: ${String(options.name)}`, `캐릭터 없음: ${String(options.name)}`));
    characterId = found.id;
  }
  // Marinara orders a chat by when each message was written: one written "between" two lands between them
  let createdAt: string | undefined;
  if (options.before !== undefined && options.before !== null) {
    const list = await s.freshMessages();
    const next = messageAt(list, options.before);
    const prev = list[list.indexOf(next) - 1];
    const end = Date.parse(next.at ?? "");
    const start = prev ? Date.parse(prev.at ?? "") : end - 2000;
    if (!Number.isFinite(end) || !Number.isFinite(start)) throw new Error(t("Cannot place it there.", "그 자리에 넣을 수 없음."));
    createdAt = new Date(Math.floor((start + end) / 2)).toISOString();
  }
  const id = await addMessage(String(text ?? ""), String(role), s.here(), { characterId, extra: Object.keys(extra).length ? extra : undefined, createdAt });
  if (id) s.ownIds.add(id);
  const list = await s.freshMessages();
  return list.find((m) => m.id === id)?.num ?? list.length;
}

/** Deletes messages by number, after asking. */
export async function delMsg(s: PageSession, nums: unknown): Promise<number> {
  const list = await s.freshMessages();
  const ids = [...new Set((Array.isArray(nums) ? nums : [nums]).map((n) => messageAt(list, n).id))];
  if (!ids.length) return 0;
  if (!s.ui.confirm(t(`Delete ${ids.length} message(s)?`, `메시지 ${ids.length}개를 지울까요?`))) return 0;
  return deleteMessages(ids, s.here());
}

export function stopGen(): boolean {
  const composer = findComposer();
  if (!composer || !isGenerating(composer)) return false;
  composer.sendButton?.click();
  return true;
}

export function setInput(text: unknown): boolean {
  const composer = findComposer();
  if (!composer) return false;
  setComposerText(composer.textarea, String(text ?? ""));
  composer.textarea.focus();
  return true;
}

/** Calls `fn` for each new reply ("msg") or message the person sends ("send"), except the page's own. */
export function listen(s: PageSession, kind: WatchKind, fn: unknown): () => void {
  if (typeof fn !== "function") return () => {};
  const stop = chatWatch.on(kind, (m) => {
    // a page never hears of the messages it put in itself (a handler answering its own message would loop)
    if ((kind === "msg" || kind === "send") && s.ownIds.delete(m.id)) return;
    const sent = kind === "send" ? s.ownSends.indexOf(m.text.trim()) : -1;
    if (sent >= 0) {
      s.ownSends.splice(sent, 1);
      return;
    }
    try {
      void Promise.resolve((fn as (m: Message) => unknown)(pageCopy(m))).catch(s.report);
    } catch (e) {
      s.report(e);
    }
  });
  s.onDispose(stop);
  return stop;
}

/** A message as a page gets it: its own copy, so what the page changes never reaches the shared cache. */
function pageCopy(m: Message): Message {
  return { ...m, data: structuredClone(m.data ?? {}), ...(m.expressions ? { expressions: structuredClone(m.expressions) } : {}), ...(m.story ? { story: structuredClone(m.story) } : {}) };
}

export function messageCommands(s: PageSession) {
  return {
    sendMsg: cmd({ writes: true, paid: true }, (text: unknown, confirm = false) => sendMsg(s, text, confirm)),
    sendRegen: cmd({ writes: true, paid: true }, (hint?: unknown, confirm = false) => sendRegen(s, hint, confirm)),
    // getMsgs({ role: "char", hidden: false }): only those
    getMsgs: cmd(async (options: { role?: string; hidden?: boolean } = {}) =>
      (await s.freshMessages())
        .filter((m) => (options.role === undefined || m.role === options.role) && (options.hidden === undefined || m.hidden === options.hidden))
        .map(pageCopy),
    ),
    getLastMsg: cmd(async (role: unknown = "char") => {
      const want = String(role) === "assistant" ? "char" : String(role);
      const list = await s.freshMessages();
      return [...list].reverse().find((m) => m.role === want)?.text ?? "";
    }),
    getMsgId: cmd(() => s.ownNum()),
    setMsg: cmd({ writes: true }, (num: unknown, text: unknown, options?: { refresh?: boolean }) => setMsg(s, num, text, options)),
    addMsg: cmd({ writes: true }, (text: unknown, role?: unknown, options?: AddMsgOptions) => addMsg(s, text, role, options)),
    delMsg: cmd({ writes: true }, (nums: unknown) => delMsg(s, nums)),
    // stopGen(): the reply being written; stopGen(id): one of the page's own AI calls
    stopGen: cmd((id?: unknown) => (id === undefined || id === null ? stopGen() : stopRun(s, String(id)))),
    getInput: cmd(() => findComposer()?.textarea.value ?? ""),
    setInput: cmd(setInput),
  };
}

export function listenCommands(s: PageSession) {
  return {
    onMsg: cmd((fn: unknown) => listen(s, "msg", fn)),
    onSend: cmd((fn: unknown) => listen(s, "send", fn)),
    onSwipe: cmd((fn: unknown) => listen(s, "swipe", fn)),
    onEdit: cmd((fn: unknown) => listen(s, "edit", fn)),
    onDelete: cmd((fn: unknown) => listen(s, "delete", fn)),
  };
}
