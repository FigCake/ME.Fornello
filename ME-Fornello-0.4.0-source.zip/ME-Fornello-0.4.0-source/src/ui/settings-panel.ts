// Fornello's settings window; component-editor.ts and component-sets.ts draw into it.

import { trackerState } from "../api/marinara";
import { readChatData, updateChatData } from "../api/chat-data";
import { currentChatId } from "../host/current-chat";
import { type CardComponents, chatCardComponents } from "../components/cards";
import type { TrackerState } from "../shared/tracker";
import { THEME_CSS } from "../components/look";
import { serverFonts } from "../api/library";
import { AUTO_RUN_MAX, type FornelloSettings, RUN_MODES, type RunMode, type Settings } from "../settings";
import { t } from "../shared/i18n";
import { type ComponentDef, type ComponentKind, isTagName, ownFields } from "../components/model";
import { newComponentFrom } from "../components/files";
import { componentName } from "../components/source";
import { fieldsFromCode } from "../components/fields";
import { FORM_CSS, helpTip, section, setting, toggle } from "../shared/form";
import { CONTROLS, THEME_TOKENS } from "../shared/theme";
import { showToast } from "./toast";
import { BACKDROP_CSS, el } from "./dom";
import { ComponentEditor } from "./component-editor";
import { ComponentSets } from "./component-sets";
import { type GoToTab, TABS_CSS, tabHeader } from "./window-tabs";
import { ICON_EXPORT, ICON_IMPORT, ICON_PLUS } from "./icons";
import { storyAccess, storyPaths } from "../state/access";

const STYLE = `
${THEME_TOKENS}
${THEME_CSS}
:host { position: fixed; inset: 0; z-index: 2147482700; }
* { box-sizing: border-box; }
${CONTROLS}
${FORM_CSS}
${BACKDROP_CSS}
.win { width: min(640px, 100%); max-height: min(860px, 100%); transition: width .2s ease; display: flex; flex-direction: column; overflow: hidden;
  font: 13px/1.45 var(--d-font); color: var(--d-text); background: var(--d-panel-solid); border: 1px solid var(--d-line); border-radius: var(--d-radius); box-shadow: var(--d-shadow); }
.win.wide { width: min(980px, 100%); }
header { display: flex; align-items: center; gap: 8px; padding: 10px 14px; border-bottom: 1px solid var(--d-divider); }
header h2 { margin: 0; font-size: 15px; color: var(--d-title); flex: 1; min-width: 0; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
header > :not(h2) { flex: none; }
/* on a narrow screen a heading's buttons go under it; a Korean word is not cut in two */
.sec-h { flex-wrap: wrap; row-gap: 4px; }
.sec-h h3 { word-break: keep-all; }
header select.lang { width: auto; flex: none; padding: 4px 6px; font-size: 12px; }
main { overflow: auto; padding: 12px 16px 18px; display: flex; flex-direction: column; }
.row { display: flex; gap: 8px; align-items: center; flex-wrap: wrap; }
.note { color: var(--d-muted); font-size: 12px; }
.list { display: flex; flex-direction: column; gap: 4px; }
.item { display: flex; align-items: center; gap: 8px; padding: 6px 8px; border: 1px solid var(--d-line); border-radius: var(--d-radius-sm); }
.item.sel { border-color: var(--d-btn-border-active); background: var(--d-hl-bg); }
.item .name { font-weight: 700; flex: 1; cursor: pointer; }
.badge { font-size: 11px; padding: 2px 7px; border-radius: 999px; border: 1px solid var(--d-line); color: var(--d-muted); }
.editor { display: grid; grid-template-columns: minmax(0, 1fr) minmax(0, 1fr); gap: 12px; margin-top: 10px; }
@media (max-width: 760px) { .editor { grid-template-columns: 1fr; } }
.col { display: flex; flex-direction: column; gap: 8px; min-width: 0; }
label.f, .f { display: flex; flex-direction: column; gap: 4px; font-size: 12px; color: var(--d-muted); }
.field-h { display: flex; align-items: center; gap: 6px; font-size: 12px; color: var(--d-muted); }
textarea.code { font: 12px/1.45 var(--d-mono); min-height: 260px; resize: vertical; white-space: pre; }
textarea.small { min-height: 74px; resize: vertical; font: 12px/1.45 var(--d-mono); }
.editor-wrap { margin-top: 10px; }
.ftable { display: flex; flex-direction: column; gap: 6px; }
.frow { display: flex; flex-direction: column; gap: 4px; padding: 6px; border: 1px solid var(--d-line); border-radius: var(--d-radius-sm); }
.frow .row { flex-wrap: nowrap; }
.frow input.fname { flex: 1; min-width: 0; font: 12px var(--d-mono); }
.frow select { width: auto; flex: none; }
textarea.inst { min-height: 44px; resize: vertical; font-size: 12px; }
button.mini { padding: 2px 8px; font-size: 12px; }
.preview { border: 1px dashed var(--d-line); border-radius: var(--d-radius-sm); padding: 8px; min-height: 80px; overflow: auto; max-height: 520px; background: var(--d-field); }
.err { color: var(--d-danger); white-space: pre-wrap; font-size: 12px; }
.ok { color: #3fb97a; font-size: 12px; }
input.num { width: 76px !important; min-width: 0 !important; }
${TABS_CSS}
/* the components tab: the list on the left, the open one's editor on the right */
main.two { display: grid; grid-template-columns: minmax(300px, 380px) minmax(0, 1fr); gap: 0; padding: 0; overflow: hidden; flex: 1; min-height: 0; }
main.two > .lpane, main.two > .rpane { overflow: auto; padding: 12px 16px 18px; min-height: 0; }
main.two > .rpane { border-left: 1px solid var(--d-divider); }
.rpane .editor { grid-template-columns: 1fr; }
.rpane .editor-wrap { margin-top: 0; }
.sec-h button.icon { display: inline-flex; align-items: center; padding: 4px 6px; }
@media (max-width: 720px) { main.two { grid-template-columns: 1fr; overflow: auto; } main.two > .lpane, main.two > .rpane { overflow: visible; } main.two > .rpane { border-left: none; border-top: 1px solid var(--d-divider); } }
/* ⚙: pages and component display, under the header; the whole window on a phone */
header { position: relative; }
.gear-pop { position: absolute; right: 12px; top: calc(100% + 4px); z-index: 5; width: min(440px, calc(100% - 24px)); max-height: 70vh; overflow: auto; padding: 10px 14px 14px; border: 1px solid var(--d-line); border-radius: var(--d-radius); background: var(--d-panel-solid); box-shadow: var(--d-shadow); display: flex; flex-direction: column; gap: 8px; }
.gear-pop .pop-h { display: flex; align-items: center; justify-content: space-between; }
@media (max-width: 600px) { .gear-pop { position: fixed; inset: 0; width: auto; max-height: none; border: none; border-radius: 0; } }
`;

/** A toggle that can't be changed while `off` (Pesto itself off). */
export class SettingsPanel {
  private element: HTMLElement | null = null;
  private root: ShadowRoot | null = null;
  private selected: string | null = null;
  private draft: ComponentDef | null = null;
  private tracker: TrackerState | null = null;
  /** The open chat's Pesto paths, for the component editor (empty when it has none). */
  private storyPaths: string[] = [];
  /** Components the cards of the open chat bring. */
  private cards: CardComponents[] = [];
  /** The window slides in once, when it opens (not on every redraw). */
  private entering = false;
  /** Marinara's own font families, for the editor's font choice; null while not read. */
  private fonts: string[] | null = null;
  /** What the open chat chose for its components (by id); null while not read. */
  private chatChoice: Record<string, boolean> | null = null;
  /** The open chat's components changed (ComponentHost draws again). */
  onChatComponents: (() => void) | null = null;
  /** The tabs of Fornello's window (main.ts sets it). */
  tabs: GoToTab | null = null;
  /** ⚙ is open: pages and component display. */
  private gearOpen = false;
  /** Where focus goes back to when the window closes. */
  private returnFocus: HTMLElement | null = null;
  /** A press is going on in the window: a redraw waits for its click (the button pressed must still be there). */
  private pressing = false;
  private redrawAfterPress = false;
  private redrawTimer: ReturnType<typeof setTimeout> | null = null;
  private readonly editor: ComponentEditor;
  private readonly sets: ComponentSets;

  constructor(private readonly settings: Settings) {
    const closeEditor = () => {
      this.select(null);
      this.render();
    };
    this.editor = new ComponentEditor({
      settings,
      render: () => this.render(),
      renderSoon: () => this.renderSoon(),
      fonts: () => this.fonts,
      tracker: () => this.tracker,
      storyPaths: () => this.storyPaths,
      saveComponent: (d) => this.saveComponent(d, true),
      removeComponent: (d) => this.removeComponent(d),
      exportFile: (defs, name) => this.sets.exportFile(defs, name),
      closeEditor,
    });
    this.sets = new ComponentSets({
      settings,
      render: () => this.render(),
      save: (patch) => this.save(patch),
      newComponent: (code, kind, fileName) => this.newComponent(code, kind, fileName),
      closeEditor: () => this.select(null),
    });
  }

  open(componentId?: string): void {
    if (componentId) this.select(componentId);
    if (!this.element) {
      this.element = document.createElement("div");
      this.element.id = "fornello-settings";
      this.root = this.element.attachShadow({ mode: "open" });
      this.root.addEventListener("keydown", (e) => this.trapTab(e as KeyboardEvent));
      this.root.addEventListener("pointerdown", () => (this.pressing = true), true);
      document.addEventListener("pointerup", this.onRelease, true);
      document.addEventListener("pointercancel", this.onRelease, true);
      // where focus goes back to when it closes
      this.returnFocus = document.activeElement instanceof HTMLElement ? document.activeElement : null;
      document.addEventListener("keydown", this.onKey, true);
      document.body.append(this.element);
      this.entering = true;
    }
    const chatId = currentChatId();
    if (chatId) void trackerState(undefined, chatId).then((t) => (this.tracker = t)).catch(() => undefined);
    this.storyPaths = [];
    if (chatId)
      void storyAccess()
        ?.at(chatId, null)
        .then((v) => (this.storyPaths = v ? storyPaths(v) : []))
        .catch(() => undefined);
    this.cards = [];
    this.chatChoice = null;
    if (!this.fonts)
      void serverFonts()
        .then((list) => {
          this.fonts = [...new Set(list.map((f) => f.family))];
          if (this.root && this.draft) this.render();
        })
        .catch(() => (this.fonts = []));
    if (chatId)
      void readChatData(chatId)
        .then((d) => {
          this.chatChoice = d.components;
          if (this.root) this.render();
        })
        .catch(() => undefined);
    if (chatId)
      void chatCardComponents(chatId)
        .then((cards) => {
          this.cards = cards;
          if (this.root && cards.length) this.render();
        })
        .catch(() => undefined);
    this.render();
  }

  close(): void {
    this.editor.stopPreview();
    document.removeEventListener("keydown", this.onKey, true);
    document.removeEventListener("pointerup", this.onRelease, true);
    document.removeEventListener("pointercancel", this.onRelease, true);
    if (this.redrawTimer) clearTimeout(this.redrawTimer);
    this.redrawTimer = null;
    this.pressing = this.redrawAfterPress = false;
    const wasOpen = !!this.element;
    this.element?.remove();
    this.element = null;
    this.root = null;
    if (wasOpen && this.returnFocus?.isConnected) this.returnFocus.focus();
    this.returnFocus = null;
  }

  /** Redraws when open (the screen language changed). */
  refresh(): void {
    if (this.root) this.render();
  }

  private readonly onRelease = () => {
    this.pressing = false;
    if (!this.redrawAfterPress) return;
    this.redrawAfterPress = false;
    // after the click that goes with this release
    this.renderSoon();
  };

  /** Redraws once a press's click and a focus move have landed (else the next field or the pressed button would be gone). */
  private renderSoon(): void {
    if (this.pressing) {
      this.redrawAfterPress = true;
      return;
    }
    if (this.redrawTimer) clearTimeout(this.redrawTimer);
    this.redrawTimer = setTimeout(() => {
      this.redrawTimer = null;
      if (this.root) this.render();
    }, 0);
  }

  /** Escape closes it wherever focus is. */
  private readonly onKey = (e: KeyboardEvent) => {
    if (e.key !== "Escape" || !this.element) return;
    e.stopPropagation();
    // ⚙ closes before the window
    if (this.gearOpen) {
      this.gearOpen = false;
      this.render();
      return;
    }
    this.close();
  };

  /** Opens ⚙ (pages and component display) over the components. */
  openGear(): void {
    this.gearOpen = true;
    this.render();
  }

  /** Tab stays inside the window (Marinara behind the backdrop is out of reach). */
  private trapTab(e: KeyboardEvent): void {
    if (e.key !== "Tab" || !this.root) return;
    const items = [...this.root.querySelectorAll<HTMLElement>("button, input, select, textarea, [tabindex]:not([tabindex='-1'])")].filter((x) => !x.hasAttribute("disabled") && x.offsetParent !== null);
    if (!items.length) return;
    const first = items[0];
    const last = items[items.length - 1];
    const at = this.root.activeElement;
    if (e.shiftKey && (at === first || !at)) {
      e.preventDefault();
      last.focus();
    } else if (!e.shiftKey && at === last) {
      e.preventDefault();
      first.focus();
    }
  }

  private select(id: string | null): void {
    this.editor.reset();
    this.selected = id;
    const found = this.settings.current.components.find((w) => w.id === id);
    this.draft = found ? structuredClone(found) : null;
  }

  private render(): void {
    if (!this.root) return;
    const s = this.settings.current;
    const style = document.createElement("style");
    style.textContent = STYLE;
    const go: GoToTab = this.tabs ?? (() => undefined);
    const head = el(
      "header",
      {},
      ...tabHeader("components", go, { open: this.gearOpen, toggle: () => ((this.gearOpen = !this.gearOpen), this.render()) }),
      el("button", { className: "ghost", title: t("Close", "닫기"), "aria-label": t("Close", "닫기"), onclick: () => this.close() }, "✕"),
    );
    const mode = el(
      "select",
      { "aria-label": t("Run scripts", "스크립트 실행"), "data-key": "mode", onchange: (e: Event) => void this.changeMode((e.target as HTMLSelectElement).value as RunMode) },
      ...Object.entries(RUN_MODES).map(([v, label]) => el("option", { value: v, selected: v === s.mode }, label)),
    );
    const pages = section(
      t("Pages", "페이지"),
      undefined,
      [],
      setting(
        t("Run scripts", "스크립트 실행"),
        mode,
        t(
          "· Run at once: pages of recent messages run when on screen\n· Click to run: on ▶ Run only (safer for unknown cards)\n· Off: pages only show; components and scripts are off",
          "· 바로 실행: 최근 메시지의 페이지가 화면에 보이면 실행\n· 눌러서 실행: ▶ 실행을 눌러야 실행(모르는 카드엔 이쪽이 안전)\n· 끄기: 페이지는 모양만, 컴포넌트·스크립트는 꺼짐",
        ),
      ),
      s.mode === "always"
        ? setting(
            t("Recent messages to auto-run", "자동 실행할 최근 메시지"),
            el("input", {
              type: "number",
              min: "0",
              max: String(AUTO_RUN_MAX),
              value: String(s.autoRun),
              "aria-label": t("Number of recent messages whose pages auto-run", "페이지를 자동 실행할 최근 메시지 수"),
              onchange: (e: Event) => {
                const input = e.target as HTMLInputElement;
                const autoRun = Math.max(0, Math.min(AUTO_RUN_MAX, Math.round(Number(input.value)) || 0));
                input.value = String(autoRun);
                void this.save({ autoRun });
              },
            }),
            t(
              "How many recent messages have their pages run by themselves (every page in them). More can slow down opening a chat",
              "페이지가 저절로 실행될 최근 메시지 수(그 안의 페이지는 모두). 많으면 채팅 열기가 느려질 수 있음",
            ),
          )
        : null,
    );
    const list = el("div", { className: "list" });
    for (const w of s.components) {
      list.append(
        el(
          "div",
          { className: `item${w.id === this.selected ? " sel" : ""}` },
          toggle(w.enabled, (v) => void this.saveComponent({ ...w, enabled: v }, false), t(`Turn on ${w.name}`, `${w.name} 켜기`)),
          el("span", { className: "name", role: "button", tabIndex: 0, "aria-expanded": String(w.id === this.selected), onclick: () => (this.select(this.selected === w.id ? null : w.id), this.render()), onkeydown: (e: KeyboardEvent) => {
            if (e.key !== "Enter" && e.key !== " ") return;
            e.preventDefault();
            this.select(this.selected === w.id ? null : w.id);
            this.render();
          } }, w.name),
          el("span", { className: "badge" }, w.kind === "html" ? "HTML" : "JSX"),
          el("span", { className: "badge" }, w.source === "tag" ? t("Tag in reply", "답변 속 태그") : w.source === "body" ? t("Text in tag", "본문") : t("Tracker", "트래커")),
        ),
      );
    }
    const cardList = el("div", { className: "list" });
    for (const card of this.cards) {
      const allowed = s.trustedCards[card.characterId] === card.hash;
      cardList.append(
        el(
          "div",
          { className: "item" },
          el("span", { className: "name", style: "cursor:default" }, card.defs.map((d) => d.name).join(", ")),
          el("span", { className: "badge" }, t(`Card: ${card.characterName}`, `카드: ${card.characterName}`)),
          el(
            "button",
            { onclick: () => void this.trustCard(card, !allowed) },
            allowed ? t("Stop allowing", "허락 취소") : t("Allow", "허락"),
          ),
        ),
      );
    }
    const recent = el("input", {
      type: "number",
      className: "num",
      min: "0",
      max: "50",
      value: String(s.display.recent),
      "aria-label": t("Replies to keep open", "펼쳐 둘 답변 수"),
      onchange: (e: Event) => {
        const input = e.target as HTMLInputElement;
        const recent = Math.max(0, Math.min(50, Math.round(Number(input.value)) || 0));
        // what is kept is what shows
        input.value = String(recent);
        void this.save({ display: { ...s.display, recent } });
      },
    });
    const older = el(
      "select",
      { "aria-label": t("Components of older replies", "더 오래된 답변의 컴포넌트"), onchange: (e: Event) => void this.save({ display: { ...s.display, older: (e.target as HTMLSelectElement).value as "collapsed" | "hidden" } }) },
      el("option", { value: "collapsed", selected: s.display.older === "collapsed" }, t("Collapse", "접어 두기")),
      el("option", { value: "hidden", selected: s.display.older === "hidden" }, t("Hide", "숨기기")),
    );
    const components = section(
      t("Components", "컴포넌트"),
      t("Small screens drawn in replies, from JSX or an HTML template", "답변 속에 그리는 작은 화면(JSX·HTML 템플릿)"),
      [
        el("button", { className: "icon", innerHTML: ICON_PLUS, title: t("New component", "새 컴포넌트"), "aria-label": t("New component", "새 컴포넌트"), onclick: () => this.newComponent("") }),
        el("button", { className: "icon", innerHTML: ICON_IMPORT, title: t("Import a components file, .jsx, .html or character card", "컴포넌트 파일·.jsx·.html·캐릭터 카드 불러오기"), "aria-label": t("Import", "불러오기"), onclick: () => this.sets.importFile() }),
        s.components.length ? el("button", { className: "icon", innerHTML: ICON_EXPORT, title: t("Save all components to one file", "컴포넌트 전부를 파일 하나로 저장"), "aria-label": t("Export", "내보내기"), onclick: () => this.sets.exportFile(s.components, t("Fornello components", "Fornello 컴포넌트")) }) : null,
      ],
      s.components.length ? list : el("div", { className: "note", style: "padding:6px 0" }, t("No components yet.", "아직 컴포넌트가 없어요.")),
      this.sets.setsBlock(),
      this.cards.length
        ? el(
            "div",
            { className: "field-h", style: "margin-top:10px" },
            t("From this chat's cards", "이 채팅의 카드에 든 컴포넌트"),
            helpTip(
              t(
                "Components in the card's lorebook (entries named fornello:Name). They draw once allowed; your own of the same name wins",
                "카드 로어북의 fornello:이름 항목. 허락하면 그려짐. 같은 이름이면 내 컴포넌트 우선",
              ),
              t("Card components", "카드 컴포넌트"),
            ),
          )
        : null,
      this.cards.length ? cardList : null,
      this.chatComponents(),
    );
    components.dataset.section = "components";
    const display = section(
      t("Component display", "컴포넌트 표시"),
      undefined,
      [],
      setting(
        t("Replies to keep open", "펼쳐 둘 답변 수"),
        recent,
        t("How many recent replies show components open", "컴포넌트를 펼쳐 둘 최근 답변 수"),
      ),
      setting(t("Components of older replies", "더 오래된 답변의 컴포넌트"), older, t("Collapse: one line, opens on a click", "접어 두기: 한 줄, 누르면 펼침")),
    );
    const gear = this.gearOpen
      ? el(
          "div",
          { className: "gear-pop", role: "dialog", "aria-label": t("Fornello settings", "Fornello 설정") },
          el("div", { className: "pop-h" }, el("strong", {}, t("Fornello settings", "Fornello 설정")), el("button", { className: "ghost", "aria-label": t("Close settings", "설정 닫기"), onclick: () => ((this.gearOpen = false), this.render()) }, "✕")),
          pages,
          display,
          section(
            t("Character import", "캐릭터 가져오기"),
            undefined,
            [],
            setting(
              t("Pictures too", "그림까지"),
              toggle(s.marinaraImport, (v) => void this.save({ marinaraImport: v }), t("Pictures too", "그림까지"), "marinara-import"),
              t("A .charx, JPEG card or card .zip picked in Marinara's character import comes in with its pictures, lorebook and QR sets", "마리나라 캐릭터 가져오기에서 고른 .charx·JPEG 카드·카드 .zip을 그림·로어북·QR 세트까지 가져와요"),
            ),
          ),
        )
      : null;
    head.append(...(gear ? [gear] : []));
    const win = el("div", { className: `win tabbed${this.entering ? " d-enter" : ""}`, role: "dialog", "aria-modal": "true", "aria-label": t("Fornello settings", "Fornello 설정"), tabIndex: -1 }, head, el("main", { className: "two" }, el("div", { className: "lpane" }, components), el("div", { className: "rpane" }, this.sets.importing ? this.sets.importer(this.sets.importing) : this.draft ? this.editor.draw(this.draft) : el("div", { className: "note" }, t("Pick a component to edit it, or make a new one.", "고칠 컴포넌트를 고르거나 새로 만드세요.")))));
    const back = el("div", { className: `back${this.entering ? " d-fade" : ""}` }, win);
    // focus moves into the window when it opens, and stays in it through redraws
    const focused = this.root.activeElement as HTMLElement | null;
    const keyOf = (x: HTMLElement) => x.getAttribute("data-key") || x.getAttribute("aria-label") || x.title || x.textContent || "";
    const focusKey = focused ? keyOf(focused) : null;
    const takeFocus = this.entering || !!focused;
    this.entering = false;
    back.addEventListener("mousedown", (e) => {
      if (e.target === back) this.close();
    });
    // keep the scroll positions through redraws
    const scrolls = [".lpane", ".rpane"].map((q) => this.root!.querySelector(q)?.scrollTop ?? 0);
    this.root.replaceChildren(style, back);
    [".lpane", ".rpane"].forEach((q, i) => {
      const pane = this.root!.querySelector(q);
      if (pane) pane.scrollTop = scrolls[i];
    });
    if (takeFocus) {
      // the same control again when it is still there, else the window
      const same = focusKey ? [...win.querySelectorAll<HTMLElement>("button, input, select, textarea, [tabindex]")].find((x) => keyOf(x) === focusKey) : undefined;
      (same ?? win).focus({ preventScroll: true });
    }
  }

  private newComponent(code: string, kind: ComponentKind = "jsx", fileName = ""): void {
    // code from a file is looked at before it runs: its preview waits for ▶
    this.editor.reset(!!fileName);
    this.draft = newComponentFrom(code, kind === "html", fileName);
    this.selected = this.draft.id;
    this.render();
  }


















  /** The fields that go with a mode ("바로 실행" has its page count) follow it. */
  private async changeMode(mode: RunMode): Promise<void> {
    if (!(await this.save({ mode }))) return;
    this.render();
    this.root?.querySelector<HTMLSelectElement>('select[data-key="mode"]')?.focus();
  }

  /** Saves a change; a failure (settings not read, storage full) shows up as a note. */
  private async save(patch: Partial<FornelloSettings>): Promise<boolean> {
    try {
      await this.settings.set(patch);
      return true;
    } catch (e) {
      showToast(t(`Could not save settings: ${e instanceof Error ? e.message : String(e)}`, `설정 저장 실패: ${e instanceof Error ? e.message : String(e)}`), "error");
      return false;
    }
  }

  private async saveComponent(d: ComponentDef, notify: boolean): Promise<void> {
    const html = d.kind === "html";
    const name = html ? (isTagName(d.name) ? d.name : null) : componentName(d.code);
    if (!name || !d.code.trim()) {
      showToast(html ? t("Name: English letters, a capital first. Not saved.", "이름: 영문, 대문자로 시작. 저장 안 함.") : t("No component found. Not saved.", "컴포넌트 없음. 저장 안 함."), "warning");
      return;
    }
    const clash = this.settings.current.components.find((w) => w.name === name && w.id !== d.id);
    if (clash) {
      showToast(html ? t(`A "${name}" component already exists. Rename it.`, `"${name}" 컴포넌트가 이미 있어요. 이름을 바꿔 주세요.`) : t(`A "${name}" component already exists. Rename it (the function name).`, `"${name}" 컴포넌트가 이미 있어요. 이름(함수 이름)을 바꿔 주세요.`), "warning");
      return;
    }
    const next = { ...d, name, fields: ownFields(d.kind, d.source === "body", d.body) ? d.fields : fieldsFromCode(d.code, name, d.fields) };
    const list = [...this.settings.current.components];
    const i = list.findIndex((w) => w.id === d.id);
    if (i >= 0) list[i] = next;
    else list.push(next);
    if (!(await this.save({ components: list }))) return;
    if (this.selected === d.id) this.draft = structuredClone(next);
    if (notify) showToast(t(`Saved the "${name}" component.`, `"${name}" 컴포넌트를 저장했어요.`), "success");
    this.render();
  }

  private async removeComponent(d: ComponentDef): Promise<void> {
    if (!window.confirm(t(`Delete the "${d.name}" component?`, `"${d.name}" 컴포넌트를 지울까요?`))) return;
    if (!(await this.save({ components: this.settings.current.components.filter((w) => w.id !== d.id), componentSets: this.settings.current.componentSets.map((x) => ({ ...x, componentIds: x.componentIds.filter((id) => id !== d.id) })) }))) return;
    this.select(null);
    this.render();
  }

  /** The open chat's switches: which components it shows (its own choice, else each component's "new chats" one). */
  private chatComponents(): HTMLElement | null {
    const chatId = currentChatId();
    const choice = this.chatChoice;
    const defs = [...this.settings.current.components.filter((w) => w.enabled), ...this.cards.flatMap((c) => c.defs).filter((d) => !this.settings.current.components.some((w) => w.name === d.name))];
    if (!chatId || !choice || !defs.length) return null;
    const list = el("div", { className: "list" });
    // a set is on when all its components are; its switch turns them all
    for (const set of this.settings.current.componentSets) {
      const members = defs.filter((d) => set.componentIds.includes(d.id));
      if (!members.length) continue;
      const on = members.every((d) => choice[d.id] ?? d.everyChat);
      list.append(
        el(
          "div",
          { className: "item" },
          toggle(on, (v) => void this.chooseForChat(chatId, members, v), t(`Set ${set.name} in this chat`, `이 채팅에서 ${set.name} 묶음`)),
          el("span", { className: "name", style: "cursor:default" }, set.name),
          el("span", { className: "badge" }, t(`Set · ${members.length}`, `묶음 · ${members.length}개`)),
        ),
      );
    }
    for (const d of defs) {
      const on = choice[d.id] ?? d.everyChat;
      list.append(
        el(
          "div",
          { className: "item" },
          toggle(on, (v) => void this.chooseForChat(chatId, [d], v), t(`${d.label || d.name} in this chat`, `이 채팅에서 ${d.label || d.name}`)),
          el("span", { className: "name", style: "cursor:default" }, d.label || d.name),
          d.id in choice ? el("span", { className: "badge" }, t("This chat's choice", "이 채팅에서 고름")) : el("span", { className: "badge" }, d.everyChat ? t("On in new chats", "새 채팅에서 켜짐") : t("Off in new chats", "새 채팅에서 꺼짐")),
        ),
      );
    }
    return el(
      "div",
      {},
      el(
        "div",
        { className: "field-h", style: "margin-top:10px" },
        t("In this chat", "이 채팅에서 쓸 컴포넌트"),
        helpTip(
          t("Which components this chat shows. Unset: each one's \"New chats\"", "이 채팅에 보일 컴포넌트. 안 고르면 각자의 \"새 채팅에서\"를 따름"),
          t("In this chat", "이 채팅에서 쓸 컴포넌트"),
        ),
      ),
      list,
    );
  }

  private async chooseForChat(chatId: string, defs: ComponentDef[], on: boolean): Promise<void> {
    const chosen = Object.fromEntries(defs.map((d) => [d.id, on]));
    try {
      await updateChatData(chatId, (data) => ({ ...data, components: { ...data.components, ...chosen } }));
      this.chatChoice = { ...(this.chatChoice ?? {}), ...chosen };
      this.onChatComponents?.();
      this.render();
    } catch (e) {
      showToast(t(`Could not save this chat's choice: ${e instanceof Error ? e.message : String(e)}`, `이 채팅의 선택을 저장하지 못했어요: ${e instanceof Error ? e.message : String(e)}`), "error");
    }
  }

  /** Allows a card's components as they are now, or stops allowing them. */
  private async trustCard(card: CardComponents, allow: boolean): Promise<void> {
    const trustedCards = { ...this.settings.current.trustedCards };
    if (allow) trustedCards[card.characterId] = card.hash;
    else delete trustedCards[card.characterId];
    if (await this.save({ trustedCards })) this.render();
  }



}
