// While picture tags are on, one Marinara regex script (display only, AI replies) shows {{raw::name}} as
// an address the browser doesn't fetch (tags.ts SHOWN_PREFIX): the copy of a page Marinara draws then
// asks the server for nothing, and Fornello fills the name in where it draws the page. What the AI
// reads and what the chat keeps stay as written.

import { api } from "../shared/api";
import { forgetRegexScripts, regexScripts } from "../regex";
import { SHOWN_PREFIX } from "./tags";

export const PICTURE_REGEX = "Fornello: picture names";
const FIND = "\\{\\{(?:raw|path)::([^{}\\n]+)\\}\\}";
const REPLACE = `${SHOWN_PREFIX}$1`;

let made: Promise<void> | null = null;

/** Makes the script once a session (one the person turned off stays off). */
export function ensurePictureRegex(): Promise<void> {
  made ??= (async () => {
    const mine = (await regexScripts()).find((s) => s.name === PICTURE_REGEX);
    if (mine) return;
    await api("/regex-scripts", { method: "POST", body: { name: PICTURE_REGEX, enabled: true, findRegex: FIND, replaceString: REPLACE, placement: ["ai_output"], flags: "g", applyMode: "display" } });
    forgetRegexScripts();
  })().catch((e) => {
    made = null;
    throw e;
  });
  return made;
}

/** Takes the script away (picture tags turned off). */
export async function removePictureRegex(): Promise<void> {
  made = null;
  forgetRegexScripts();
  for (const s of (await regexScripts()).filter((x) => x.name === PICTURE_REGEX)) await api(`/regex-scripts/${encodeURIComponent(s.id)}`, { method: "DELETE" });
  forgetRegexScripts();
}

/** Forgets that it was made (Fornello stopped). */
export function forgetPictureRegex(): void {
  made = null;
}
