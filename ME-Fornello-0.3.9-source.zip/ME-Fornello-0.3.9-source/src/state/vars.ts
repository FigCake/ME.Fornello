// Pesto's values as Marinara chat variables, so a card's prompts can read them with
// Marinara's own macros: `{{getvar::story_hp}}`, `{{#if var:story_hp < 10}}…{{/if}}`. Every name
// starts with "story_", the path's dots as "_" (the names Fornello wrote are kept in the chat's
// data: only those it changes or takes out, never a card's own "story_…")
// (`story_hero_level`); a path Marinara can't take as a name (it takes English letters, digits and
// "_", up to 64, never 21 of them, which name characters) gets one made from it, "story_v_" and a
// short hash.
// Groups and lists are given as JSON too, at their own path. Written before each reply, with the
// values that reply starts from.

import { quickHash } from "../hash";
import { derived, type Definition } from "./engine";

type Obj = Record<string, unknown>;

export const VAR_PREFIX = "story_";
/** Marinara keeps a chat's variables up to 500 in all, 10 000 characters each. */
const MAX_VARS = 300;
const MAX_TEXT = 10_000;

const isPlain = (v: unknown): v is Obj => !!v && typeof v === "object" && !Array.isArray(v);

/** The variable name for a value's path. */
export function varName(path: string): string {
  const plain = `${VAR_PREFIX}${path.replace(/\./g, "_")}`;
  return /^[A-Za-z_]\w{0,63}$/.test(plain) ? safeName(plain) : hashedName(path);
}

/** A name made from the path: "story_v_" and a short hash. */
const hashedName = (path: string) => safeName(`${VAR_PREFIX}v_${quickHash(path).replace(/[^A-Za-z0-9]/g, "").slice(-8)}`);

/** Marinara keeps names of exactly 21 letters for characters: one more "_" then. */
export const safeName = (name: string) => (name.length === 21 ? `${name}_` : name);

const asText = (v: unknown) => {
  const text = typeof v === "string" ? v : v === null || v === undefined ? "" : typeof v === "object" ? JSON.stringify(v) : String(v);
  return text.length > MAX_TEXT ? text.slice(0, MAX_TEXT) : text;
};

/** Every path of the values (and the computed ones) with its variable's name and text. */
export function storyVars(def: Definition, values: Obj): Record<string, string> {
  const out: Record<string, string> = {};
  let count = 0;
  const walk = (v: unknown, path: string) => {
    if (count >= MAX_VARS) return;
    if (path) {
      // two paths with one name (hero.level, hero_level): the second gets its made name
      let name = varName(path);
      if (Object.hasOwn(out, name)) name = hashedName(path);
      out[name] = asText(v);
      count++;
    }
    if (isPlain(v)) for (const [k, x] of Object.entries(v)) walk(x, path ? `${path}.${k}` : k);
  };
  walk(values, "");
  for (const [k, v] of Object.entries(derived(def, values))) walk(v, k);
  return out;
}

/** What to send Marinara: the names that changed, and the old names Fornello wrote (`owned`) to take out (null). */
export function varChanges(had: Record<string, unknown>, now: Record<string, string>, owned: ReadonlySet<string>): Record<string, string | null> {
  const out: Record<string, string | null> = {};
  for (const [k, v] of Object.entries(now)) if (had[k] !== v) out[k] = v;
  for (const k of owned) if (Object.hasOwn(had, k) && !Object.hasOwn(now, k)) out[k] = null;
  return out;
}
