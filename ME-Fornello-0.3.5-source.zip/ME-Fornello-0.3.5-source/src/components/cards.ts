// Components a character card brings:
//   - entries of its own lorebook named "fornello:<Name>", the JSX code as
//     content (kept off, so the AI never reads it), and
//   - data.extensions.fornello.components ([{ name, code }]).
// They run once the person allows the card, asked again when they change.

import { characterLore, chatCharacters } from "../api/chat-store";
import type { CharacterInfo, RawLoreEntry } from "../api/types";
import { sha256 } from "../hash";
import { type ComponentDef, normalizeComponent } from "./model";

/** The name a lorebook entry carries when its content is a component. */
const ENTRY_PREFIX = "fornello:";

export interface CardComponents {
  characterId: string;
  characterName: string;
  /** SHA-256 of the components (asked again when it changes). */
  hash: string;
  defs: ComponentDef[];
}

/** A card's components, from its lorebook entries and its own data (the first of a name wins). */
export function componentsOf(character: Pick<CharacterInfo, "id" | "name" | "data">, entries: Pick<RawLoreEntry, "name" | "content">[]): CardComponents | null {
  const found: { name: string; code: string }[] = [];
  for (const e of entries) {
    const label = String(e.name ?? "").trim();
    if (!label.toLowerCase().startsWith(ENTRY_PREFIX)) continue;
    found.push({ name: label.slice(ENTRY_PREFIX.length).trim(), code: String(e.content ?? "") });
  }
  const own = (character.data.extensions as { fornello?: { components?: unknown } } | undefined)?.fornello?.components;
  if (Array.isArray(own)) for (const c of own) if (c && typeof c === "object") found.push({ name: String((c as { name?: unknown }).name ?? ""), code: String((c as { code?: unknown }).code ?? "") });
  const defs: ComponentDef[] = [];
  for (const { name, code } of found) {
    if (defs.some((d) => d.name === name)) continue;
    const def = normalizeComponent({ id: `card:${character.id}:${name}`, name, code, source: "tag" });
    if (def) defs.push({ ...def, card: { characterId: character.id, characterName: character.name } });
  }
  if (!defs.length) return null;
  return { characterId: character.id, characterName: character.name, hash: sha256(defs.map((d) => `${d.name}\n${d.code}`).join("\n\n")), defs };
}

/** The components the cards of a chat's characters bring. */
export async function chatCardComponents(chatId: string): Promise<CardComponents[]> {
  const characters = await chatCharacters(chatId);
  const found = await Promise.all(characters.map(async (c) => componentsOf(c, await characterLore(c.id).catch(() => []))));
  return found.filter((f): f is CardComponents => !!f);
}
