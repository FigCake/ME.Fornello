// Instructions for the tracker AI, kept as an `instruction` on Marinara's
// custom tracker fields (Marinara keeps it and its Custom Tracker agent reads
// it). A tracker write may drop them, so the chat remembers which fields it
// was given and puts back what went missing. Values, locked fields and
// instructions the person wrote are left alone.

import { readChatData, updateChatData } from "../api/chat-data";
import { patchTracker, trackerState } from "../api/marinara";
import type { TrackerState } from "../shared/tracker";
import type { ComponentDef } from "./model";

type CustomField = NonNullable<NonNullable<TrackerState["playerStats"]>["customTrackerFields"]>[number];

/** The custom tracker field a tracker-mode value reads (custom.<name>, or its own name when not mapped); none for other paths. */
export function customFieldOf(def: ComponentDef, value: string): string | null {
  const path = def.map[value];
  if (!path) return value;
  const m = /^custom\.(.+)$/.exec(path);
  return m ? m[1] : null;
}

/** A tracker-mode component's instructions, by custom field name. */
export function instructionsOf(def: ComponentDef): Record<string, string> {
  const out: Record<string, string> = {};
  for (const f of def.fields) {
    const field = customFieldOf(def, f.name);
    if (field && f.instruction.trim()) out[field] = f.instruction.trim();
  }
  return out;
}

/** The fields with the instructions put in where none is (`replace`: over others too), and with `add` missing fields added empty. */
export function withInstructions(fields: CustomField[], wanted: Record<string, string>, add = false, replace = add): { fields: CustomField[]; changed: boolean; added: number; set: number } {
  let added = 0;
  let set = 0;
  const same = (a: string, b: string) => a.trim().toLowerCase() === b.trim().toLowerCase();
  const next = fields.map((f) => {
    const name = Object.keys(wanted).find((n) => same(n, f.name));
    if (!name || f.locked || f.instruction === wanted[name]) return f;
    // one the person (or another tool) wrote differently stays, unless the person asked to put them in
    if (!replace && f.instruction?.trim()) return f;
    set++;
    return { ...f, instruction: wanted[name] };
  });
  if (add) {
    for (const [name, instruction] of Object.entries(wanted)) {
      if (next.some((f) => same(f.name, name))) continue;
      next.push({ name, value: "", instruction });
      added++;
    }
  }
  return { fields: next, changed: added + set > 0, added, set };
}

/** The fields without the instructions of `names` (only where they still read as `wanted` said, when given). */
function withoutInstructions(fields: CustomField[], names: string[], wanted?: Record<string, string>): { fields: CustomField[]; removed: number } {
  let removed = 0;
  const same = (a: string, b: string) => a.trim().toLowerCase() === b.trim().toLowerCase();
  const next = fields.map((f) => {
    const name = names.find((n) => same(n, f.name));
    if (!name || f.locked || f.instruction === undefined) return f;
    if (wanted && wanted[name] !== undefined && f.instruction !== wanted[name]) return f;
    removed++;
    const rest = { ...f };
    delete rest.instruction;
    return rest;
  });
  return { fields: next, removed };
}

/** Rewrites the tracker's custom fields with `change` (null: no write); `byHand` marks it as the person's edit. */
async function rewrite(chatId: string, change: (fields: CustomField[]) => CustomField[] | null, byHand: boolean): Promise<void> {
  const state = (await trackerState(undefined, chatId)) ?? {};
  const fields = change(state.playerStats?.customTrackerFields ?? []);
  if (!fields) return;
  state.playerStats = { ...(state.playerStats ?? {}), customTrackerFields: fields };
  await patchTracker(state, ["playerStats"], chatId, byHand && !state.messageId);
}

/** The custom fields a component's values read, whether they have an instruction or not. */
function fieldsOf(def: ComponentDef): string[] {
  return def.fields.map((f) => customFieldOf(def, f.name)).filter((f): f is string => !!f);
}

/** Puts a component's instructions in the chat's tracker (adding the fields it lacks) and keeps them for the chat. */
export async function instructionsToChat(chatId: string, def: ComponentDef): Promise<{ added: number; set: number }> {
  const wanted = instructionsOf(def);
  // the component's own entries are replaced: a value whose instruction was cleared loses it
  const own = fieldsOf(def);
  await updateChatData(chatId, (d) => ({ ...d, instructions: { ...Object.fromEntries(Object.entries(d.instructions).filter(([k]) => !own.includes(k))), ...wanted } }));
  const cleared = own.filter((f) => !(f in wanted));
  let result = { added: 0, set: 0 };
  await rewrite(
    chatId,
    (fields) => {
      const r = withInstructions(withoutInstructions(fields, cleared).fields, wanted, true);
      result = { added: r.added, set: r.set };
      return r.changed || cleared.length ? r.fields : null;
    },
    true,
  );
  return result;
}

/** Takes a component's instructions out of the chat's tracker and out of what the chat keeps. */
export async function instructionsFromChat(chatId: string, def: ComponentDef): Promise<number> {
  const own = fieldsOf(def);
  const { instructions } = await readChatData(chatId);
  await updateChatData(chatId, (d) => ({ ...d, instructions: Object.fromEntries(Object.entries(d.instructions).filter(([k]) => !own.includes(k))) }));
  let removed = 0;
  await rewrite(
    chatId,
    (fields) => {
      // an instruction the person wrote differently in the tracker is theirs: it stays
      const r = withoutInstructions(fields, own, instructions);
      removed = r.removed;
      return r.removed ? r.fields : null;
    },
    true,
  );
  return removed;
}

/** The instructions to keep in the tracker: those the chat was given, from components still on in it, as they are now. */
export function keptInstructions(kept: Record<string, string>, shown: ComponentDef[]): Record<string, string> {
  const out: Record<string, string> = {};
  for (const def of shown) {
    if (def.source !== "tracker") continue;
    for (const [field, text] of Object.entries(instructionsOf(def))) if (field in kept) out[field] = text;
  }
  return out;
}

const busy = new Set<string>();
const again = new Set<string>();

/** Puts back instructions a tracker write dropped (not as the person's edit); one at a time per chat. */
export async function refillInstructions(chatId: string, shown: ComponentDef[]): Promise<void> {
  if (busy.has(chatId)) {
    again.add(chatId);
    return;
  }
  busy.add(chatId);
  try {
    do {
      again.delete(chatId);
      const wanted = keptInstructions((await readChatData(chatId)).instructions, shown);
      if (!Object.keys(wanted).length) break;
      await rewrite(
        chatId,
        (fields) => {
          const r = withInstructions(fields, wanted);
          return r.changed ? r.fields : null;
        },
        false,
      );
    } while (again.has(chatId));
  } finally {
    busy.delete(chatId);
    again.delete(chatId);
  }
}
