// Marinara through its /api: AI calls and writes to messages, lorebooks and
// the tracker. Shared reads are in chat-store.ts, variables in chat-data.ts.
// Every function takes the chat it acts on.

import { api } from "../shared/api";
import { getMarinara } from "../shared/marinara-global";
import { refreshChatQueries, refreshQueries } from "../shared/react-bridge";
import { OWN_READ } from "../host/generation-hold";
import type { TrackerState } from "../shared/tracker";
import { t } from "../shared/i18n";
import { MESSAGE_DATA, alwaysOnLore, chatCharacters, chatDetail, forgetChat, forgetLore, listMessages, persona } from "./chat-store";
import { parseList, parseObject } from "./parse";
import type { CharacterInfo, LoreBook, LoreNote, Message, PersonaInfo, RawLoreEntry } from "./types";

const enc = encodeURIComponent;

const noChat = () => new Error(t("No chat is open.", "열려 있는 채팅이 없어요."));

/** After a write through the API: let Marinara show it. */
function refreshChat(chatId: string): void {
  refreshChatQueries(chatId);
}

// ── AI calls ──

async function rawConnectionId(chatId: string | null): Promise<string> {
  const chat = chatId ? await chatDetail(chatId).catch(() => null) : null;
  if (chat?.connectionId && chat.connectionId !== "random") return chat.connectionId;
  const list = await api<{ id: string; isDefault?: boolean }[]>("/connections");
  const pick = list.find((c) => c.isDefault) ?? list[0];
  if (!pick) throw new Error(t("No AI connection.", "AI 연결(Connection)이 없어요."));
  return pick.id;
}

type AiMessage = { role: "system" | "user" | "assistant"; content: string };

/**
 * A light context instead of Marinara's whole prompt: the cards, the persona,
 * always-on lorebook entries and the last `history` messages, then the request.
 * Cheaper for pages that call the AI often.
 */
export function lightContext(cast: CharacterInfo[], me: PersonaInfo, messages: Message[], prompt: string, history: number, lore: LoreNote[] = []): AiMessage[] {
  const card = (c: CharacterInfo) =>
    [`# ${c.name}`, c.description && `Description: ${c.description}`, c.personality && `Personality: ${c.personality}`, c.scenario && `Scenario: ${c.scenario}`].filter(Boolean).join("\n");
  const system = [
    "You are writing for the characters of an ongoing roleplay. Stay true to their cards.",
    ...cast.map(card),
    `# ${me.name} (the user)${me.description ? `\n${me.description}` : ""}`,
    lore.length ? `# World info\n${lore.map((l) => l.content).join("\n\n")}` : "",
  ]
    .filter(Boolean)
    .join("\n\n");
  // page code is long and says nothing to the story
  const prose = (text: string) => text.replace(/```[ \t]*html?\b[\s\S]*?(?:```|$)/gi, "[HTML page]").trim();
  const recent = history > 0 ? messages.filter((m) => !m.hidden && m.role !== "system" && prose(m.text)).slice(-history) : [];
  return [
    { role: "system", content: system },
    ...recent.map((m): AiMessage => ({ role: m.role === "user" ? "user" : "assistant", content: cast.length > 1 || m.role === "narrator" ? `${m.name}: ${prose(m.text)}` : prose(m.text) })),
    { role: "user", content: prompt },
  ];
}

export type AiInputMessage = AiMessage & { images?: string[] };

export interface GenerateOptions {
  /** The prompt alone (or the messages given), nothing of the chat. */
  raw?: boolean;
  /** A saved connection, by name or id (Marinara's own: its keys never leave the server). */
  connection?: string;
  /** A saved connection's id, used as it is (no lookup: a connection that is gone fails at Marinara). */
  connectionId?: string;
  chatId: string | null;
  /** Only the cards, the persona, always-on entries and the last `history` messages (see lightContext). */
  history?: number;
  /** Chat prompt: a note the AI takes into account for this reply ("Take the following into special consideration…"). */
  guide?: string;
  /** Chat prompt: another prompt preset, by name or id. */
  preset?: string;
  /** Raw: images with the request (data URLs or links). */
  images?: string[];
  /** Raw: temperature, maxTokens, topP, topK, minP, frequencyPenalty, presencePenalty, reasoningEffort. */
  parameters?: Record<string, unknown>;
  /** Called as the reply comes in: the text so far and the newest piece. */
  onToken?: (text: string, piece: string) => void;
  /** The run's id, for stopping it (abortRun). */
  runId?: string;
}

/** The saved connections, by id and name (for the person to pick one; their keys stay on the server). */
export async function listConnections(): Promise<{ id: string; name: string }[]> {
  const list = await api<{ id: string; name?: string }[]>("/connections");
  return list.map((c) => ({ id: c.id, name: String(c.name ?? c.id) }));
}

/** A saved connection's id, from its name or id. */
async function connectionIdFor(nameOrId: string): Promise<string> {
  const list = await api<{ id: string; name?: string }[]>("/connections");
  const want = nameOrId.trim().toLowerCase();
  const found = list.find((c) => c.id === nameOrId) ?? list.find((c) => String(c.name ?? "").trim().toLowerCase() === want);
  if (!found) throw new Error(t(`No connection: ${nameOrId}`, `연결 없음: ${nameOrId}`));
  return found.id;
}

/** A prompt preset's id, from its name or id. */
async function presetIdFor(nameOrId: string): Promise<string> {
  const list = await api<{ id: string; name?: string }[]>("/prompts");
  const found = list.find((p) => p.id === nameOrId) ?? list.find((p) => p.name === nameOrId);
  if (!found) throw new Error(t(`No preset: ${nameOrId}`, `프리셋 없음: ${nameOrId}`));
  return found.id;
}

/** Posts to a generation route that answers as a stream: each piece goes to onToken; the whole reply comes back. */
async function streamGeneration(path: string, body: Record<string, unknown>, onToken: (text: string, piece: string) => void): Promise<string> {
  const res = await (getMarinara().fetch ?? fetch)(`/api${path}`, {
    method: "POST",
    headers: { "Content-Type": "application/json", Accept: "text/event-stream", "x-marinara-csrf": "1" },
    body: JSON.stringify({ ...body, streaming: true }),
    credentials: "same-origin",
    cache: "no-store",
  });
  if (!res.ok || !res.body) {
    const data = await res.json().catch(() => null);
    throw new Error((data as { error?: string } | null)?.error || `${res.status} ${res.statusText}`);
  }
  const reader = res.body.getReader();
  const decoder = new TextDecoder();
  let text = "";
  let buffer = "";
  let result: string | null = null;
  for (;;) {
    const { done, value } = await reader.read();
    if (done) break;
    buffer += decoder.decode(value, { stream: true });
    let cut: number;
    while ((cut = buffer.indexOf("\n\n")) >= 0) {
      const frame = buffer.slice(0, cut);
      buffer = buffer.slice(cut + 2);
      const line = frame.split("\n").find((l) => l.startsWith("data:"));
      if (!line) continue;
      let event: { type?: string; data?: unknown };
      try {
        event = JSON.parse(line.slice(5).trim());
      } catch {
        continue;
      }
      if (event.type === "token" && typeof event.data === "string") {
        text += event.data;
        onToken(text, event.data);
      } else if (event.type === "result") result = String((event.data as { content?: unknown } | null)?.content ?? text);
      else if (event.type === "error") throw new Error(String(event.data || "Generation failed"));
      else if (event.type === "aborted") return result ?? text;
    }
  }
  return result ?? text;
}

/** An AI reply, not saved to the chat: with the chat's whole context, a light one (`history`), or the prompt alone (`raw`). */
export async function generate(input: string | AiInputMessage[], options: GenerateOptions): Promise<string> {
  const given = Array.isArray(input) ? input : null;
  const prompt = given ? "" : String(input ?? "");
  if (given ? !given.length : !prompt.trim()) throw new Error(t("Empty request.", "요청이 비어 있음."));
  const light = !options.raw && !given && options.history !== undefined && Number.isFinite(Number(options.history));
  const connectionId = options.connectionId ?? (options.connection ? await connectionIdFor(options.connection) : undefined);
  const runId = options.runId;
  if (options.raw || light || given) {
    const chatId = options.chatId;
    let messages: AiInputMessage[] = given ?? [{ role: "user", content: prompt, ...(options.images?.length ? { images: options.images } : {}) }];
    if (light) {
      if (!chatId) throw noChat();
      const id = chatId;
      const history = Math.max(0, Math.min(100, Math.floor(Number(options.history))));
      const [cast, me, list, lore] = await Promise.all([
        chatCharacters(id).catch(() => []),
        persona(id),
        history ? listMessages(id) : Promise.resolve([]),
        alwaysOnLore(id).catch(() => []),
      ]);
      messages = lightContext(cast, me, list, prompt, history, lore);
    }
    const body = { connectionId: connectionId ?? (await rawConnectionId(chatId)), messages, ...(options.parameters ? { parameters: options.parameters } : {}), ...(runId ? { runId } : {}) };
    if (options.onToken) return streamGeneration("/generate/raw", body, options.onToken);
    const res = await api<{ content?: string }>("/generate/raw", { method: "POST", body: { ...body, streaming: false } });
    return res.content ?? "";
  }
  if (!options.chatId) throw noChat();
  // lorebooks, trackers and summary are opt-in, as in Marinara's prompt preview
  const body = {
    chatId: options.chatId,
    userMessage: prompt,
    connectionId,
    presetId: options.preset ? await presetIdFor(options.preset) : undefined,
    generationGuide: options.guide || undefined,
    injectLorebook: true,
    injectTrackers: true,
    injectChatSummary: true,
    ...(runId ? { runId } : {}),
  };
  if (options.onToken) return streamGeneration("/generate/dryRun", body, options.onToken);
  const res = await api<{ content?: string }>("/generate/dryRun", { method: "POST", body: { ...body, streaming: false } });
  return res.content ?? "";
}

/** Stops one run that generate started (by its runId). */
export async function abortRun(runId: string, kind: "raw" | "dryRun", chatId?: string | null): Promise<boolean> {
  const res = await api<{ aborted?: boolean }>(kind === "raw" ? "/generate/raw/abort" : "/generate/dryRun/abort", { method: "POST", body: { runId, ...(chatId ? { chatId } : {}) } }).catch(() => null);
  return res?.aborted === true;
}

export async function editMessage(messageId: string, text: string, { refresh = true } = {}, chatId: string): Promise<void> {
  await api(`/chats/${enc(chatId)}/messages/${enc(messageId)}`, { method: "PATCH", body: { content: text } });
  forgetChat(chatId);
  if (refresh) refreshChat(chatId);
}

const MARINARA_ROLE: Record<string, string> = { user: "user", char: "assistant", assistant: "assistant", narrator: "narrator", system: "narrator" };

export async function addMessage(text: string, role: string, chatId: string, more: { characterId?: string | null; extra?: Record<string, unknown>; createdAt?: string } = {}): Promise<string | null> {
  const marinaraRole = MARINARA_ROLE[role] ?? "assistant";
  const characterId = marinaraRole === "assistant" ? (more.characterId ?? parseList((await chatDetail(chatId)).characterIds)[0] ?? null) : null;
  const body = { role: marinaraRole, content: text, characterId, ...(more.extra ? { extra: more.extra } : {}), ...(more.createdAt ? { createdAt: more.createdAt } : {}) };
  const created = await api<{ id?: string }>(`/chats/${enc(chatId)}/messages`, { method: "POST", body });
  forgetChat(chatId);
  refreshChat(chatId);
  return created?.id ?? null;
}

/** Merges keys into a message's `extra` (its swipe on screen, or swipe `swipe`). */
export async function patchMessageExtra(chatId: string, messageId: string, extra: Record<string, unknown>, swipe?: number): Promise<void> {
  const query = swipe === undefined ? "" : `?swipeIndex=${swipe}`;
  await api(`/chats/${enc(chatId)}/messages/${enc(messageId)}/extra${query}`, { method: "PATCH", body: extra });
  forgetChat(chatId);
}

/** Hides messages from the AI, or shows them again (Marinara's "Hide from AI"). */
export async function setMessagesHidden(chatId: string, messageIds: string[], hidden: boolean): Promise<void> {
  if (!messageIds.length) return;
  await api(`/chats/${enc(chatId)}/messages/bulk-hidden`, { method: "PATCH", body: { messageIds, hidden } });
  forgetChat(chatId);
  refreshChat(chatId);
}

export interface Swipe {
  index: number;
  text: string;
  data: Record<string, unknown>;
}

export async function listSwipes(chatId: string, messageId: string): Promise<Swipe[]> {
  const list = await api<{ index: number; content?: string; extra?: unknown }[]>(`/chats/${enc(chatId)}/messages/${enc(messageId)}/swipes`);
  return (list ?? []).map((w) => ({ index: Number(w.index), text: String(w.content ?? ""), data: parseObject(parseObject(w.extra)[MESSAGE_DATA]) }));
}

export async function setActiveSwipe(chatId: string, messageId: string, index: number): Promise<void> {
  await api(`/chats/${enc(chatId)}/messages/${enc(messageId)}/active-swipe`, { method: "PUT", body: { index } });
  forgetChat(chatId);
  refreshChat(chatId);
}

/** Adds a swipe (shown at once unless `silent`); its index comes back. */
export async function addSwipe(chatId: string, messageId: string, text: string, silent: boolean): Promise<number> {
  const res = await api<{ index?: number }>(`/chats/${enc(chatId)}/messages/${enc(messageId)}/swipes`, { method: "POST", body: { content: text, silent } });
  forgetChat(chatId);
  refreshChat(chatId);
  return Number(res?.index ?? -1);
}

export async function deleteSwipe(chatId: string, messageId: string, index: number): Promise<void> {
  await api(`/chats/${enc(chatId)}/messages/${enc(messageId)}/swipes/${index}`, { method: "DELETE" });
  forgetChat(chatId);
  refreshChat(chatId);
}

/** A new chat with the messages up to `messageId` (Marinara's "Branch from here"); its id comes back. */
export async function branchChat(chatId: string, messageId: string): Promise<string> {
  const created = await api<{ id: string }>(`/chats/${enc(chatId)}/branch`, { method: "POST", body: { upToMessageId: messageId } });
  refreshQueries([["chats"]]);
  return created.id;
}

export async function deleteMessages(messageIds: string[], chatId: string): Promise<number> {
  if (!messageIds.length) return 0;
  await api(`/chats/${enc(chatId)}/messages/bulk-delete`, { method: "POST", body: { messageIds } });
  forgetChat(chatId);
  refreshChat(chatId);
  return messageIds.length;
}

// ── lorebooks ──

export async function loreBooks(): Promise<LoreBook[]> {
  const res = await api<unknown>("/lorebooks");
  const list = (Array.isArray(res) ? res : ((res as { items?: unknown[] }).items ?? [])) as LoreBook[];
  return list.map((b) => ({ id: b.id, name: b.name, characterIds: parseList(b.characterIds) }));
}

const sameName = (a: string, b: string) => a.normalize("NFC") === b.normalize("NFC");

/** The SillyTavern name of a card's own book (Marinara renames it on import). */
export const cardBookName = (c: CharacterInfo): string => {
  const world = (c.data.extensions as { world?: unknown } | undefined)?.world;
  return typeof world === "string" ? world : "";
};

/** A lorebook by id or name; a card's SillyTavern book name finds the book Marinara made of that card in `chatId`. */
export async function findLoreBook(nameOrId: string, chatId: string | null): Promise<LoreBook | null> {
  const books = await loreBooks();
  const found = books.find((b) => b.id === nameOrId) ?? books.find((b) => sameName(b.name, nameOrId));
  if (found) return found;
  if (!chatId) return null;
  for (const c of await chatCharacters(chatId).catch(() => [])) {
    if (!cardBookName(c) || !sameName(cardBookName(c), nameOrId)) continue;
    const own = books.find((b) => b.characterIds?.includes(c.id));
    if (own) return own;
  }
  return null;
}

export async function createLoreBook(name: string): Promise<LoreBook> {
  const book = await api<LoreBook>("/lorebooks", { method: "POST", body: { name } });
  forgetLore();
  refreshQueries([["lorebooks"]]);
  return { id: book.id, name: book.name };
}

/** The chat's own lorebook if it has one (none is made). */
export async function chatLoreBookIfAny(chatId: string): Promise<LoreBook | null> {
  const res = await api<unknown>(`/lorebooks?chatId=${enc(chatId)}`);
  const own = (Array.isArray(res) ? res : ((res as { items?: unknown[] }).items ?? [])) as LoreBook[];
  return own[0] ? { id: own[0].id, name: own[0].name } : null;
}

/** The chat's own lorebook (made on first use): what is in it reaches only this chat. */
export async function chatLoreBook(chatId: string): Promise<LoreBook> {
  const res = await api<unknown>(`/lorebooks?chatId=${enc(chatId)}`);
  const own = (Array.isArray(res) ? res : ((res as { items?: unknown[] }).items ?? [])) as LoreBook[];
  if (own[0]) return { id: own[0].id, name: own[0].name };
  const name = `Chat Book ${(await chatDetail(chatId)).name ?? chatId}`.slice(0, 200);
  const book = await api<LoreBook>("/lorebooks", { method: "POST", body: { name, chatId } });
  forgetLore();
  refreshQueries([["lorebooks"]]);
  return { id: book.id, name: book.name };
}

export async function loreEntries(bookId: string): Promise<RawLoreEntry[]> {
  return api<RawLoreEntry[]>(`/lorebooks/${enc(bookId)}/entries`);
}

export async function createLoreEntry(bookId: string, data: Record<string, unknown>): Promise<RawLoreEntry> {
  // what genChat sends as always-on entries is read again
  forgetLore();
  return api<RawLoreEntry>(`/lorebooks/${enc(bookId)}/entries`, { method: "POST", body: { name: "New entry", ...data } });
}

export async function patchLoreEntry(bookId: string, entryId: string, patch: Record<string, unknown>): Promise<void> {
  forgetLore();
  await api(`/lorebooks/${enc(bookId)}/entries/${enc(entryId)}`, { method: "PATCH", body: patch });
}

export async function deleteLoreEntries(bookId: string, entryIds: string[]): Promise<number> {
  if (!entryIds.length) return 0;
  forgetLore();
  const res = await api<{ deleted?: number }>(`/lorebooks/${enc(bookId)}/entries/bulk-delete`, { method: "POST", body: { entryIds } });
  return res?.deleted ?? entryIds.length;
}

// ── tracker ──

const TRACKER_JSON_FIELDS = ["presentCharacters", "playerStats", "personaStats", "worldCustomFields", "recentEvents", "manualOverrides", "fieldLocks"];

function readTrackerState(raw: Record<string, unknown> | null): TrackerState | null {
  if (!raw) return null;
  for (const k of TRACKER_JSON_FIELDS) {
    if (typeof raw[k] === "string") raw[k] = parseObject(raw[k]);
  }
  return raw as TrackerState;
}

/** The tracker now, or as it was at one message. */
export async function trackerState(messageId: string | undefined, chatId: string): Promise<TrackerState | null> {
  const path = messageId ? `/chats/${enc(chatId)}/messages/${enc(messageId)}/game-state` : `/chats/${enc(chatId)}/game-state`;
  return readTrackerState(await api<Record<string, unknown> | null>(path).catch(() => null));
}

/** The tracker as trackerState reads it, by a read that is never held (generation-hold.ts): Fornello's own, while it writes it. */
export async function ownTrackerState(messageId: string | undefined, chatId: string): Promise<TrackerState | null> {
  const path = messageId ? `/chats/${enc(chatId)}/messages/${enc(messageId)}/game-state` : `/chats/${enc(chatId)}/game-state`;
  const res = await (getMarinara().fetch ?? fetch)(`/api${path}`, { headers: { Accept: "application/json", [OWN_READ]: "1" }, credentials: "same-origin", cache: "no-store" }).catch(() => null);
  if (!res?.ok) return null;
  return readTrackerState((await res.json().catch(() => null)) as Record<string, unknown> | null);
}

/** Writes tracker fields; `manual` marks it as the person's own edit, which Marinara keeps over a regenerated reply. */
export async function patchTracker(state: TrackerState, fields: string[], chatId: string, manual = true): Promise<void> {
  const body: Record<string, unknown> = { manual };
  for (const f of new Set(fields)) body[f] = state[f];
  if (state.messageId) {
    body.messageId = state.messageId;
    body.swipeIndex = state.swipeIndex ?? 0;
  }
  await api(`/chats/${enc(chatId)}/game-state`, { method: "PATCH", body });
  refreshQueries([["chats", chatId], ["game-state"]]);
}
