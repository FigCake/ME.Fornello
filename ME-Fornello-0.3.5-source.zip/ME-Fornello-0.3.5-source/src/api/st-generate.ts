// JS-Slash-Runner's generate / generateRaw / injectPrompts on Fornello's own
// commands; options Marinara cannot do (tools, JSON schema, a custom API) are errors.

import { t } from "../shared/i18n";
import { alwaysOnLore } from "./chat-store";
import { emitEvent } from "./event-bus";
import { genChat, genRaw } from "./commands/generate";
import { type BeforeGen, beforeGen, injectFor } from "./commands/replies";
import { uninject } from "./injections";
import type { AiInputMessage } from "./marinara";
import type { PageSession } from "./session";

/** Their names (the values are Fornello's own: pages only ever use the names). */
export const IFRAME_EVENTS = Object.freeze({
  GENERATION_STARTED: "fornello_generation_started",
  STREAM_TOKEN_RECEIVED_FULLY: "fornello_stream_token_received_fully",
  STREAM_TOKEN_RECEIVED_INCREMENTALLY: "fornello_stream_token_received_incrementally",
  GENERATION_ENDED: "fornello_generation_ended",
});

/** SillyTavern's name for each kind of reply (GENERATION_STARTED's first value). */
export const ST_GEN_TYPE: Record<BeforeGen["kind"], string> = { send: "normal", regenerate: "regenerate", continue: "continue", impersonate: "impersonate" };

type Obj = Record<string, unknown>;

const PLACEHOLDERS = ["world_info_before", "persona_description", "char_description", "char_personality", "scenario", "world_info_after", "dialogue_examples", "chat_history", "user_input"] as const;
type Placeholder = (typeof PLACEHOLDERS)[number];

const notSupported = (what: string) => new Error(t(`Not supported: ${what}`, `지원 안 함: ${what}`));

const userInput = (config: Obj) => String(config.user_input ?? "");

/** Options Marinara has no way to do: an error, not a reply made without them. */
function refuseMissing(config: Obj, also: string[] = []): void {
  for (const key of ["tools", "tool_choice", "json_schema", ...also]) if (config[key] !== undefined) throw notSupported(key);
  const api = config.custom_api as Obj | undefined;
  if (api && Object.keys(api).length) throw new Error(t('Use { connection: "name" } with genChat / genRaw.', 'genChat / genRaw의 { connection: "이름" }을 쓰세요.'));
}

function images(image: unknown): string[] | undefined {
  if (image === undefined || image === null) return undefined;
  const list = Array.isArray(image) ? image : [image];
  return list.map((i) => (typeof i === "string" ? i : String((i as { url?: unknown })?.url ?? ""))).filter(Boolean);
}

/** Streaming as JS-Slash-Runner reports it: the whole text so far, and the newest piece, with the run's id. */
function streamEvents(id: string, report: (e: unknown) => void) {
  return (text: string, piece: string) => {
    void emitEvent(IFRAME_EVENTS.STREAM_TOKEN_RECEIVED_FULLY, [text, id], report);
    void emitEvent(IFRAME_EVENTS.STREAM_TOKEN_RECEIVED_INCREMENTALLY, [piece, id], report);
  };
}

async function asStGeneration(s: PageSession, config: Obj, run: (id: string, onToken?: (text: string, piece: string) => void) => Promise<string>): Promise<unknown> {
  const id = String(config.generation_id ?? `gen-${Date.now().toString(36)}`);
  await emitEvent(IFRAME_EVENTS.GENERATION_STARTED, [id], s.report);
  const text = await run(id, config.should_stream ? streamEvents(id, s.report) : undefined);
  await emitEvent(IFRAME_EVENTS.GENERATION_ENDED, [text, id], s.report);
  return config.should_return_reasoning ? { content: text } : text;
}

/** generate(config): the chat's own prompt, with the person's input. */
export async function stGenerate(s: PageSession, config: unknown): Promise<unknown> {
  const c: Obj = typeof config === "string" ? { user_input: config } : ((config ?? {}) as Obj);
  refuseMissing(c, ["overrides", "max_chat_history", "image"]);
  const injected = await placeInjects(s, c.injects);
  try {
    const preset = c.preset_name === undefined || c.preset_name === "in_use" ? undefined : String(c.preset_name);
    return await asStGeneration(s, c, (id, onToken) => genChat(s, userInput(c), { id, onToken, preset }));
  } finally {
    if (injected.length) await uninject(s.here(), injected);
  }
}

async function placeInjects(s: PageSession, injects: unknown): Promise<string[]> {
  if (!Array.isArray(injects)) return [];
  const ids: string[] = [];
  for (const inj of injects as Obj[]) {
    if (inj.position === "none") throw notSupported('position "none"');
    const placed = await injectFor(s, inj.content, { depth: Number(inj.depth ?? 0), role: (inj.role as "system") ?? "system", once: true });
    ids.push(placed.id);
  }
  return ids;
}

/** generateRaw(config): the prompt in the order given (ordered_prompts), filled from the cards, the persona, the world info and the chat. */
export async function stGenerateRaw(s: PageSession, config: unknown): Promise<unknown> {
  const c: Obj = typeof config === "string" ? { user_input: config } : ((config ?? {}) as Obj);
  refuseMissing(c);
  const messages = await orderedPrompt(s, c);
  return asStGeneration(s, c, (id, onToken) => genRaw(s, messages, { id, onToken }));
}

async function orderedPrompt(s: PageSession, c: Obj): Promise<AiInputMessage[]> {
  const card = s.cast[0];
  const data = (card?.data ?? {}) as Obj;
  const overrides = (c.overrides ?? {}) as Obj;
  const chatId = s.chatId;
  const lore = chatId ? await alwaysOnLore(chatId).catch(() => []) : [];
  const text: Partial<Record<Placeholder, string>> = {
    world_info_before: lore.map((l) => l.content).join("\n\n"),
    persona_description: s.me.description,
    char_description: card?.description ?? "",
    char_personality: card?.personality ?? "",
    scenario: card?.scenario ?? "",
    world_info_after: "",
    dialogue_examples: String(data.mes_example ?? ""),
  };
  for (const key of Object.keys(text) as Placeholder[]) if (typeof overrides[key] === "string") text[key] = overrides[key] as string;
  // the chat, as SillyTavern counts it; the overrides may give it instead
  const historyOverride = (overrides.chat_history as { prompts?: Obj[] } | undefined)?.prompts;
  const max = c.max_chat_history === undefined || c.max_chat_history === "all" ? Infinity : Math.max(0, Number(c.max_chat_history) || 0);
  const history: AiInputMessage[] = Array.isArray(historyOverride)
    ? historyOverride.map(rolePrompt)
    : (await s.freshMessages())
        .filter((m) => !m.hidden && m.role !== "system")
        .slice(max === Infinity ? 0 : -max || Number.MAX_SAFE_INTEGER)
        .map((m): AiInputMessage => ({ role: m.role === "user" ? "user" : "assistant", content: m.text }));
  const order = Array.isArray(c.ordered_prompts) ? (c.ordered_prompts as unknown[]) : [...PLACEHOLDERS];
  const out: AiInputMessage[] = [];
  let historyEnd = -1;
  let inputPlaced = false;
  for (const item of order) {
    if (typeof item === "string") {
      if (item === "chat_history") {
        out.push(...history);
        historyEnd = out.length;
      } else if (item === "user_input") {
        if (userInput(c)) out.push({ role: "user", content: userInput(c), ...(images(c.image) ? { images: images(c.image) } : {}) });
        inputPlaced = true;
      } else if ((PLACEHOLDERS as readonly string[]).includes(item)) {
        const value = text[item as Placeholder];
        if (value) out.push({ role: "system", content: value });
      }
    } else if (item && typeof item === "object") out.push(rolePrompt(item as Obj));
  }
  // not placed: after the chat when there is one, otherwise at the end (as JS-Slash-Runner does)
  if (!inputPlaced && userInput(c)) {
    const input: AiInputMessage = { role: "user", content: userInput(c), ...(images(c.image) ? { images: images(c.image) } : {}) };
    if (historyEnd >= 0) {
      out.splice(historyEnd, 0, input);
      historyEnd++;
    } else out.push(input);
  }
  // injections in the chat, counted from its end
  if (Array.isArray(c.injects)) {
    const at = historyEnd >= 0 ? historyEnd : out.length;
    for (const inj of c.injects as Obj[]) {
      if (inj.position === "none") throw notSupported('position "none"');
      const depth = Math.max(0, Number(inj.depth ?? 0) || 0);
      out.splice(Math.max(0, at - depth), 0, { role: (inj.role as AiInputMessage["role"]) ?? "system", content: String(inj.content ?? "") });
    }
  }
  return out;
}

function rolePrompt(p: Obj): AiInputMessage {
  const role = p.role === "user" || p.role === "assistant" ? p.role : "system";
  const pics = images(p.image);
  return { role, content: String(p.content ?? ""), ...(pics ? { images: pics } : {}) };
}

/** injectPrompts(prompts, { once }): with a filter, a prompt goes in only for the replies the filter allows. */
export async function stInjectPrompts(s: PageSession, prompts: unknown, options: { once?: boolean } = {}): Promise<{ uninject: () => Promise<void> }> {
  const chatId = s.here();
  const ids: string[] = [];
  const stops: (() => void)[] = [];
  for (const p of (Array.isArray(prompts) ? prompts : []) as Obj[]) {
    if (p.position === "none") throw notSupported('position "none"');
    const id = String(p.id ?? `${Date.now().toString(36)}-${ids.length}`);
    const opts = { id, depth: Number(p.depth ?? 0), role: (p.role as "system") ?? "system" };
    if (typeof p.filter === "function") {
      // decided before each reply
      let used = false;
      stops.push(
        beforeGen(s, p.filter, async (filter, gen) => {
          if (options.once && used) return;
          if (await filter()) {
            used = true;
            await gen.inject(p.content, opts);
          }
        }),
      );
    } else await injectFor(s, p.content, { ...opts, once: options.once });
    ids.push(id);
  }
  return {
    uninject: async () => {
      for (const stop of stops) stop();
      await uninject(chatId, ids);
    },
  };
}
