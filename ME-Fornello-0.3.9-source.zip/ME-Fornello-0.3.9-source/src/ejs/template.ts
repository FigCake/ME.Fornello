// Templates in a SillyTavern card's lorebook entries (`<% if (…) { %> … <% } %>`, `<%= … %>`),
// read here from the format alone. A template whose code is only conditions on variables and
// printed variables is written as Marinara's own macros (`{{#if var:story_hp >= 20}}`,
// `{{getvar::story_hp}}`): Marinara then works it out itself. Any other template (loops, functions,
// setvar, page commands…) is run by Fornello before each reply (runner.ts).

export type Segment = { kind: "text" | "code" | "out"; text: string };

/** Whether a text holds template tags. */
export const hasEjs = (text: string) => /<%[^%]/.test(text);

/**
 * The template's pieces: text, code (`<% %>`), and what is printed (`<%= %>`, `<%- %>`). Comments
 * (`<%# %>`) go; `<%%` is a literal "<%"; `-%>` takes the line break after it, `<%_` / `_%>` the spaces
 * and tabs around.
 */
export function parseEjs(source: string): Segment[] {
  const out: Segment[] = [];
  let text = "";
  let i = 0;
  const pushText = () => {
    if (text) out.push({ kind: "text", text });
    text = "";
  };
  while (i < source.length) {
    const at = source.indexOf("<%", i);
    if (at < 0) {
      text += source.slice(i);
      break;
    }
    text += source.slice(i, at);
    if (source[at + 2] === "%") {
      text += "<%";
      i = at + 3;
      continue;
    }
    const mark = source[at + 2];
    if (mark === "_") text = text.replace(/[ \t]+$/, "");
    const end = source.indexOf("%>", at + 2);
    if (end < 0) throw new Error("a <% is not closed with %>");
    let body = source.slice(at + 2, end);
    const trimNext = body.endsWith("-") ? "line" : body.endsWith("_") ? "space" : "";
    if (trimNext) body = body.slice(0, -1);
    i = end + 2;
    if (trimNext === "line" && source[i] === "\n") i++;
    else if (trimNext === "line" && source.startsWith("\r\n", i)) i += 2;
    else if (trimNext === "space") while (source[i] === " " || source[i] === "\t") i++;
    pushText();
    if (mark === "#") continue;
    if (mark === "=" || mark === "-") out.push({ kind: "out", text: body.slice(1).trim() });
    else out.push({ kind: "code", text: (mark === "_" ? body.slice(1) : body).trim() });
  }
  pushText();
  return out;
}

/** The template as the body of an async function that returns its text (run in a Worker, never with eval). */
export function compileEjs(source: string): string {
  const lines = ["let __o = '';", "const print = (...a) => { __o += a.map(__s).join(''); };"];
  for (const s of parseEjs(source)) {
    if (s.kind === "text") lines.push(`__o += ${JSON.stringify(s.text)};`);
    else if (s.kind === "out") lines.push(`__o += __s(await (${s.text}));`);
    else lines.push(s.text);
  }
  lines.push("return __o;");
  return lines.join("\n");
}

// ── written as Marinara's macros ──

/** How a variable a template reads is named in Marinara: a Pesto value's path, or a chat variable. */
export interface MacroNames {
  /** `getvar("stat_data").a.b` → the path "a.b" */
  story(path: string): string;
  /** `getvar("mood")` → the chat variable "mood" (null: Marinara can't name it) */
  chat(name: string): string | null;
}

class NotMacro extends Error {}

/** A JS expression read as far as Marinara's `{{#if}}` can follow it, or NotMacro. */
class CondReader {
  private at = 0;
  constructor(
    private src: string,
    private names: MacroNames,
  ) {}

  private ws() {
    while (/\s/.test(this.src[this.at] ?? "")) this.at++;
  }

  private eat(s: string): boolean {
    this.ws();
    if (this.src.startsWith(s, this.at)) {
      this.at += s.length;
      return true;
    }
    return false;
  }

  read(): string {
    const out = this.or();
    this.ws();
    if (this.at < this.src.length) throw new NotMacro(`can't read "${this.src.slice(this.at)}"`);
    return out;
  }

  private or(): string {
    let left = this.and();
    while (this.eat("||")) left = `${left} || ${this.and()}`;
    return left;
  }

  private and(): string {
    let left = this.compare();
    while (this.eat("&&")) left = `${left} && ${this.compare()}`;
    return left;
  }

  private compare(): string {
    const left = this.term();
    for (const [js, mac] of [["===", "=="], ["!==", "!="], ["==", "=="], ["!=", "!="], [">=", ">="], ["<=", "<="], [">", ">"], ["<", "<"]] as const) {
      if (this.eat(js)) return `${left.text} ${mac} ${this.term().text}`;
    }
    // a bare value: true when it is filled in (as Marinara reads it)
    return left.text;
  }

  /** One operand: a variable, a quoted text, a number, a group in parentheses, or `_.has(...)` (always true here). */
  private term(): { text: string; always?: boolean } {
    this.ws();
    if (this.eat("(")) {
      const inner = this.or();
      if (!this.eat(")")) throw new NotMacro("a ( is not closed");
      return { text: `(${inner})` };
    }
    const num = /^-?\d+(?:\.\d+)?/.exec(this.src.slice(this.at));
    if (num) {
      this.at += num[0].length;
      return { text: num[0] };
    }
    const str = /^("(?:[^"\\]|\\.)*"|'(?:[^'\\]|\\.)*')/.exec(this.src.slice(this.at));
    if (str) {
      this.at += str[0].length;
      return { text: JSON.stringify(str[0].slice(1, -1).replace(/\\(.)/g, "$1")) };
    }
    if (/^true\b/.test(this.src.slice(this.at))) {
      this.at += 4;
      return { text: '"true"' };
    }
    if (/^false\b/.test(this.src.slice(this.at))) {
      this.at += 5;
      return { text: '"false"' };
    }
    const path = this.variable();
    if (path) return path;
    throw new NotMacro(`can't read "${this.src.slice(this.at, this.at + 30)}"`);
  }

  /** `getvar("stat_data").a["b"][0]`, `getvar("stat_data.a.b")`, `_.get(getvar("stat_data"), "a.b")`, `getvar("mood")`, `_.has(…)`. */
  private variable(): { text: string; always?: boolean } | null {
    const rest = this.src.slice(this.at);
    const has = /^_\.has\s*\(/.exec(rest);
    if (has) {
      // a template may ask whether the data was set up yet: with Pesto it always is
      const end = closing(this.src, this.at + has[0].length);
      if (end < 0) throw new NotMacro("_.has( is not closed");
      this.at = end + 1;
      return { text: '"true"', always: true };
    }
    const get = /^_\.get\s*\(\s*getvar\s*\(\s*(["'])stat_data\1\s*\)\s*,\s*(["'])([^"']*)\2\s*(?:,[^)]*)?\)/.exec(rest);
    if (get) {
      this.at += get[0].length;
      return { text: `var:${this.names.story(cleanPath(get[3]))}` };
    }
    const call = /^getvar\s*\(\s*(["'])([^"']+)\1\s*(?:,[^)]*)?\)/.exec(rest);
    if (!call) return null;
    this.at += call[0].length;
    let path = call[2];
    // what follows: .name, ["name"], [0]
    for (;;) {
      const m = /^\s*(?:\.([\p{L}\p{N}_$]+)|\[\s*(["'])([^"']*)\2\s*\]|\[\s*(\d+)\s*\])/u.exec(this.src.slice(this.at));
      if (!m) break;
      this.at += m[0].length;
      path += m[1] !== undefined ? `.${m[1]}` : m[3] !== undefined ? `.${m[3]}` : `[${m[4]}]`;
    }
    const clean = cleanPath(path);
    if (clean === "stat_data" || clean.startsWith("stat_data.")) return { text: `var:${this.names.story(clean.replace(/^stat_data\.?/, ""))}` };
    if (/[.[]/.test(clean)) throw new NotMacro(`a path into a chat variable: ${clean}`);
    const name = this.names.chat(clean);
    if (!name) throw new NotMacro(`Marinara can't name the variable "${clean}"`);
    return { text: `var:${name}` };
  }
}

/** "a.b[0]" → "a.b": a value kept with its note as [value, note] is named with `[0]` at the end. */
const cleanPath = (p: string) => p.replace(/\[(\d+)\]/g, ".$1").replace(/\.0$/, "").replace(/^\.+/, "");

/** Where the parenthesis opened before `from` closes (strings skipped), or -1. */
function closing(src: string, from: number): number {
  let depth = 1;
  let quote = "";
  for (let i = from; i < src.length; i++) {
    const c = src[i];
    if (quote) {
      if (c === "\\") i++;
      else if (c === quote) quote = "";
    } else if (c === '"' || c === "'" || c === "`") quote = c;
    else if (c === "(") depth++;
    else if (c === ")" && --depth === 0) return i;
  }
  return -1;
}

/** The template as Marinara's macros, or why it can't be (then Fornello runs it). */
export function toMacros(source: string, names: MacroNames): { text: string } | { why: string } {
  let segments: Segment[];
  try {
    segments = parseEjs(source);
  } catch (e) {
    return { why: e instanceof Error ? e.message : String(e) };
  }
  let out = "";
  let open = 0;
  try {
    for (const s of segments) {
      if (s.kind === "text") {
        if (/\{\{|\}\}/.test(s.text) && /\{\{\s*[#/]?(?:if|else)\b/.test(s.text)) throw new NotMacro("the text already has {{#if}} blocks");
        out += s.text;
        continue;
      }
      if (s.kind === "out") {
        const v = new CondReader(s.text, names).read();
        if (!/^var:\S+$/.test(v)) throw new NotMacro(`prints more than a variable: ${s.text}`);
        out += `{{getvar::${v.slice(4)}}}`;
        continue;
      }
      // code: `if (…) {`, `} else if (…) {`, `} else {`, `}`
      const code = s.text.replace(/;\s*$/, "").trim();
      let m: RegExpExecArray | null;
      if ((m = /^if\s*\(([\s\S]*)\)\s*\{$/.exec(code))) {
        out += `{{#if ${new CondReader(m[1], names).read()}}}`;
        open++;
      } else if ((m = /^\}\s*else\s+if\s*\(([\s\S]*)\)\s*\{$/.exec(code))) {
        if (!open) throw new NotMacro("an else if without its if");
        out += `{{else if ${new CondReader(m[1], names).read()}}}`;
      } else if (/^\}\s*else\s*\{$/.test(code)) {
        if (!open) throw new NotMacro("an else without its if");
        out += "{{else}}";
      } else if (code === "}") {
        if (!open) throw new NotMacro("a } without its if");
        out += "{{/if}}";
        open--;
      } else if (code === "") continue;
      else throw new NotMacro(`code: ${code.slice(0, 60)}`);
    }
  } catch (e) {
    if (e instanceof NotMacro) return { why: e.message };
    throw e;
  }
  if (open) return { why: "an if is not closed" };
  return { text: out };
}
