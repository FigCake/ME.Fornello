// JS-Slash-Runner's names for worldbooks, characters, personas and regex
// scripts, in SillyTavern's shapes, on Fornello's own commands. Those answered
// without await read what the page loaded at start (PageSession.world).

import { t } from "../shared/i18n";
import { cmd } from "./command";
import { bookFor, delBook, importLore, keyList, linkBook, ownFirst, removeLore, setLore } from "./commands/lore";
import { addChar, addUser, charItem, delChar, delUser, findChar, findPersona, getChar, importChar, setChar, setUser } from "./commands/people";
import { type RegexScope, applyRegex, setRegex } from "./commands/regex";
import { createLoreEntry, loreEntries } from "./marinara";
import { setChatBookIds } from "./library";
import { asText } from "./parse";
import type { PageSession } from "./session";
import type { RawLoreEntry } from "./types";
import type { RegexScript } from "../regex";

// ── lorebook entries in SillyTavern's shapes ──

// SillyTavern World Info position names (JS-Slash-Runner) ↔ Marinara's positions
const ST_POSITION: Record<string, number> = {
  before_character_definition: 0,
  after_character_definition: 1,
  before_example_messages: 1,
  after_example_messages: 1,
  before_author_note: 2,
  after_author_note: 2,
  at_depth: 2,
  at_depth_as_system: 2,
  at_depth_as_user: 2,
  at_depth_as_assistant: 2,
  before_char: 0,
  after_char: 1,
};

// how secondary keys count: SillyTavern's names ↔ Marinara's
const ST_LOGIC: Record<string, string> = { and: "and_any", or: "and_any", and_all: "and_all", not: "not_any", not_all: "not_all" };
const LOGIC_FROM_ST: Record<string, string> = { and_any: "and", and_all: "and_all", not_any: "not", not_all: "not_all" };

const numOrNull = (v: unknown): number | null => (v === null || v === undefined || v === "" || !Number.isFinite(Number(v)) ? null : Number(v));

/** An entry in JS-Slash-Runner's "Worldbook" shape (getWorldbook). */
export function stEntry(e: RawLoreEntry): Record<string, unknown> {
  const pos = Number(e.position ?? 0);
  return {
    uid: e.id,
    name: String(e.name ?? ""),
    enabled: e.enabled !== false,
    strategy: {
      type: e.constant ? "constant" : "selective",
      keys: Array.isArray(e.keys) ? e.keys : [],
      keys_secondary: { logic: ST_LOGIC[String(e.selectiveLogic ?? "and")] ?? "and_any", keys: Array.isArray(e.secondaryKeys) ? e.secondaryKeys : [] },
      scan_depth: e.scanDepth ?? "same_as_global",
    },
    position: { type: pos === 1 ? "after_character_definition" : pos === 2 ? "at_depth" : "before_character_definition", role: e.role ?? "system", depth: Number(e.depth ?? 4), order: Number(e.order ?? 100) },
    content: String(e.content ?? ""),
    probability: e.probability ?? 100,
    recursion: { prevent_incoming: e.excludeRecursion === true, prevent_outgoing: e.preventRecursion !== false, delay_until: e.delayUntilRecursion === true ? 1 : null },
    effect: { sticky: numOrNull(e.sticky), cooldown: numOrNull(e.cooldown), delay: numOrNull(e.delay) },
    extra: {},
  };
}

/** A "Worldbook" entry a page passed, as the fields Marinara takes (what it leaves out stays as it is). */
export function fromStEntry(input: Record<string, unknown>): Record<string, unknown> {
  const strategy = (input.strategy ?? {}) as { type?: string; keys?: unknown; keys_secondary?: { logic?: unknown; keys?: unknown }; scan_depth?: unknown };
  const position = (input.position ?? {}) as { type?: string; depth?: unknown; order?: unknown; role?: unknown };
  const out: Record<string, unknown> = {
    name: String(input.name ?? input.comment ?? "Entry").slice(0, 200) || "Entry",
    content: asText(input.content ?? ""),
    enabled: input.enabled !== false,
    constant: strategy.type === "constant",
    keys: keyList(strategy.keys ?? input.keys),
    position: ST_POSITION[String(position.type ?? "")] ?? 0,
  };
  if (input.uid !== undefined) out.id = String(input.uid);
  if (position.depth !== undefined) out.depth = Number(position.depth) || 0;
  if (position.order !== undefined) out.order = Number(position.order) || 0;
  if (["system", "user", "assistant"].includes(String(position.role))) out.role = String(position.role);
  const second = strategy.keys_secondary;
  if (second?.keys !== undefined) {
    out.secondaryKeys = keyList(second.keys);
    out.selective = (out.secondaryKeys as string[]).length > 0;
  }
  if (second?.logic !== undefined && LOGIC_FROM_ST[String(second.logic)]) out.selectiveLogic = LOGIC_FROM_ST[String(second.logic)];
  if (strategy.scan_depth !== undefined) out.scanDepth = strategy.scan_depth === "same_as_global" ? null : numOrNull(strategy.scan_depth);
  if (input.probability !== undefined) out.probability = numOrNull(input.probability);
  const recursion = input.recursion as { prevent_incoming?: unknown; prevent_outgoing?: unknown; delay_until?: unknown } | undefined;
  if (recursion) {
    if (recursion.prevent_incoming !== undefined) out.excludeRecursion = recursion.prevent_incoming === true;
    if (recursion.prevent_outgoing !== undefined) out.preventRecursion = recursion.prevent_outgoing === true;
    if (recursion.delay_until !== undefined) out.delayUntilRecursion = recursion.delay_until !== null && recursion.delay_until !== false;
  }
  const effect = input.effect as { sticky?: unknown; cooldown?: unknown; delay?: unknown } | undefined;
  if (effect) for (const k of ["sticky", "cooldown", "delay"] as const) if (effect[k] !== undefined) out[k] = numOrNull(effect[k]);
  return out;
}

/** An entry in JS-Slash-Runner's older "Lorebook" shape (getLorebookEntries). */
export function oldEntry(e: RawLoreEntry): Record<string, unknown> {
  const pos = Number(e.position ?? 0);
  const role = String(e.role ?? "system");
  return {
    uid: e.id,
    comment: String(e.name ?? ""),
    enabled: e.enabled !== false,
    type: e.constant ? "constant" : "selective",
    position: pos === 1 ? "after_character_definition" : pos === 2 ? `at_depth_as_${role}` : "before_character_definition",
    depth: Number(e.depth ?? 4),
    order: Number(e.order ?? 100),
    probability: e.probability ?? 100,
    keys: Array.isArray(e.keys) ? e.keys : [],
    filters: Array.isArray(e.secondaryKeys) ? e.secondaryKeys : [],
    content: String(e.content ?? ""),
  };
}

/** An older "Lorebook" entry a page passed, as the fields Marinara takes. */
export function fromOldEntry(input: Record<string, unknown>): Record<string, unknown> {
  const position = String(input.position ?? "");
  const out: Record<string, unknown> = {
    name: String(input.comment ?? input.name ?? "Entry").slice(0, 200) || "Entry",
    content: asText(input.content ?? ""),
    enabled: input.enabled !== false,
    constant: input.type === "constant" || input.constant === true,
    keys: keyList(input.keys ?? input.key),
    position: ST_POSITION[position] ?? 0,
  };
  const role = /^at_depth_as_(system|user|assistant)$/.exec(position)?.[1];
  if (role) out.role = role;
  if (input.depth !== undefined) out.depth = Number(input.depth) || 0;
  if (input.order !== undefined) out.order = Number(input.order) || 0;
  return out;
}

const NO_BOOK = (name: unknown) => new Error(t(`No lorebook: ${String(name)}`, `로어북 없음: ${String(name)}`));

async function existingBook(s: PageSession, name: unknown) {
  const book = await bookFor(s, String(name), false);
  if (!book) throw NO_BOOK(name);
  return book;
}

async function stWorldbook(s: PageSession, name: unknown): Promise<Record<string, unknown>[]> {
  return (await loreEntries((await existingBook(s, name)).id)).map(stEntry);
}

/** The book's entries become `entries` (same uid or name: changed; others deleted, asked as delLore). */
async function replaceBook(s: PageSession, name: unknown, entries: unknown): Promise<void> {
  await existingBook(s, name);
  const list = (Array.isArray(entries) ? entries : []) as Record<string, unknown>[];
  await setLore(s, name, list.map(fromStEntry), { replace: true });
}

/** A character's books in SillyTavern's shape: its own book (the first linked) and the rest. */
function charBooks(s: PageSession, name: unknown): { primary: string | null; additional: string[] } {
  const id = findChar(s, name).id;
  const names = ownFirst(s.world.books.filter((b) => b.characterIds?.includes(id))).map((b) => b.name);
  return { primary: names[0] ?? null, additional: names.slice(1) };
}

/** The chat's book: the one added to it last, or its own. */
function chatBookName(s: PageSession): string | null {
  const added = s.world.chatBooks.map((id) => s.world.books.find((b) => b.id === id)).filter(Boolean);
  const own = s.world.books.find((b) => s.chatId && b.chatId === s.chatId);
  return added.at(-1)?.name ?? own?.name ?? null;
}

function worldbookCommands(s: PageSession) {
  return {
    getWorldbookNames: cmd(() => [...s.bookNames]),
    getGlobalWorldbookNames: cmd(() => s.world.books.filter((b) => b.isGlobal).map((b) => b.name)),
    getCharWorldbookNames: cmd((name?: unknown) => charBooks(s, name)),
    getChatWorldbookName: cmd(() => chatBookName(s)),
    getOrCreateChatWorldbook: cmd({ writes: true }, async (_chat?: unknown, name?: unknown) => {
      const known = chatBookName(s);
      if (known) return known;
      // a new book of this chat's own, under the name given (or Marinara's)
      const book = name ? await bookFor(s, String(name), true) : await bookFor(s, "@chat", true);
      if (!book) throw NO_BOOK(name);
      if (name) await setChatBookIds(s.here(), [...s.world.chatBooks, book.id]);
      await s.freshWorld();
      return book.name;
    }),
    rebindGlobalWorldbooks: cmd({ writes: true }, async (names: unknown) => {
      const wanted = new Set((Array.isArray(names) ? names : []).map(String));
      for (const b of s.world.books) {
        const on = wanted.has(b.name);
        if (on !== (b.isGlobal === true)) await linkBook(s, b.id, "global", on);
      }
    }),
    rebindCharWorldbooks: cmd({ writes: true }, async (name: unknown, books: { primary?: unknown; additional?: unknown }) => {
      const c = findChar(s, name);
      const wanted = new Set([books?.primary, ...(Array.isArray(books?.additional) ? books.additional : [])].filter((x) => x !== null && x !== undefined && x !== "").map(String));
      for (const b of s.world.books) {
        const linked = b.characterIds?.includes(c.id) === true;
        const want = wanted.has(b.name);
        if (want !== linked) await linkBook(s, b.id, { char: c.id }, want);
      }
    }),
    rebindChatWorldbook: cmd({ writes: true }, async (_chat: unknown, name: unknown) => {
      await linkBook(s, String(name), "chat", true);
    }),
    getWorldbook: cmd((name: unknown) => stWorldbook(s, name)),
    replaceWorldbook: cmd({ writes: true }, (name: unknown, entries: unknown) => replaceBook(s, name, entries)),
    updateWorldbookWith: cmd({ writes: true }, async (name: unknown, updater: (entries: Record<string, unknown>[]) => unknown) => {
      await replaceBook(s, name, await updater(await stWorldbook(s, name)));
      return stWorldbook(s, name);
    }),
    createWorldbook: cmd({ writes: true }, async (name: unknown, entries?: unknown) => {
      if (await bookFor(s, String(name), false)) return false;
      await setLore(s, name, (Array.isArray(entries) ? entries : []).map(fromStEntry));
      await s.freshWorld();
      return true;
    }),
    createOrReplaceWorldbook: cmd({ writes: true }, async (name: unknown, entries?: unknown) => {
      const existed = !!(await bookFor(s, String(name), false));
      await setLore(s, name, (Array.isArray(entries) ? entries : []).map(fromStEntry), { replace: true });
      await s.freshWorld();
      return !existed;
    }),
    deleteWorldbook: cmd({ writes: true }, (name: unknown) => delBook(s, name)),
    importRawWorldbook: cmd({ writes: true }, async (filename: unknown, content: unknown) => {
      const name = await importLore(s, content, String(filename ?? "").replace(/\.json$/i, ""));
      return new Response(JSON.stringify({ name }), { status: 200 });
    }),
    createWorldbookEntries: cmd({ writes: true }, async (name: unknown, entries: Record<string, unknown>[]) => {
      const book = await existingBook(s, name);
      const created: RawLoreEntry[] = [];
      for (const e of entries ?? []) {
        const fields = fromStEntry(e);
        delete fields.id;
        created.push(await createLoreEntry(book.id, fields));
      }
      const all = await loreEntries(book.id);
      return { worldbook: all.map(stEntry), new_entries: created.map(stEntry) };
    }),
    deleteWorldbookEntries: cmd({ writes: true }, async (name: unknown, predicate: (entry: Record<string, unknown>) => unknown) => {
      const book = await bookFor(s, String(name), false);
      if (!book) return { worldbook: [], deleted_entries: [] };
      const all = await loreEntries(book.id);
      let doomed = all.filter((e) => predicate(stEntry(e)));
      if (!(await removeLore(s, String(name), book, doomed.map((e) => e.id)))) doomed = [];
      return { worldbook: all.filter((e) => !doomed.includes(e)).map(stEntry), deleted_entries: doomed.map(stEntry) };
    }),
    // the same, under JS-Slash-Runner's older "Lorebook" names
    getLorebooks: cmd(() => [...s.bookNames]),
    getLorebookEntries: cmd(async (name: unknown) => {
      const found = await bookFor(s, String(name), false);
      return found ? (await loreEntries(found.id)).map(oldEntry) : [];
    }),
    createLorebookEntry: cmd({ writes: true }, async (name: unknown, fields: Record<string, unknown>) => {
      const book = await bookFor(s, String(name), true);
      if (!book) throw NO_BOOK(name);
      return (await createLoreEntry(book.id, fromOldEntry(fields ?? {}))).id;
    }),
    createLorebookEntries: cmd({ writes: true }, async (name: unknown, list: Record<string, unknown>[]) => {
      const book = await bookFor(s, String(name), true);
      if (!book) throw NO_BOOK(name);
      const ids: string[] = [];
      for (const e of list ?? []) ids.push((await createLoreEntry(book.id, fromOldEntry(e))).id);
      return ids;
    }),
    deleteLorebookEntry: cmd({ writes: true }, async (name: unknown, uid: unknown) => {
      const book = await bookFor(s, String(name), false);
      if (!book) return false;
      return (await removeLore(s, String(name), book, [String(uid)])) > 0;
    }),
    deleteLorebookEntries: cmd({ writes: true }, async (name: unknown, uids: unknown[]) => {
      const book = await bookFor(s, String(name), false);
      if (!book) return false;
      return (await removeLore(s, String(name), book, (uids ?? []).map(String))) > 0;
    }),
  };
}

// ── characters ──

/** A character in JS-Slash-Runner's "Character" shape. */
function stCharacter(s: PageSession, id: string, data: Record<string, unknown>): Record<string, unknown> {
  const item = charItem(s, id, data);
  const extensions = (data.extensions && typeof data.extensions === "object" ? structuredClone(data.extensions) : {}) as Record<string, unknown>;
  const helper = (extensions.tavern_helper ?? {}) as Record<string, unknown>;
  return {
    name: item.name,
    version: item.version,
    creator: item.creator,
    creator_notes: item.creatorNotes,
    worldbook: item.books[0] ?? null,
    description: item.description,
    first_messages: [item.firstMessage, ...item.greetings],
    extensions: {
      ...extensions,
      regex_scripts: s.world.regex.filter((r) => id && r.targetCharacterIds.includes(id)).map(stRegex),
      tavern_helper: { scripts: Array.isArray(helper.scripts) ? helper.scripts : [], variables: helper.variables && typeof helper.variables === "object" ? helper.variables : {} },
    },
  };
}

/** A "Character" a page passed, as setChar's fields. */
function fromStCharacter(input: Record<string, unknown>): Record<string, unknown> {
  const data: Record<string, unknown> = {};
  const fields: Record<string, unknown> = { data };
  for (const [st, ours] of [
    ["name", "name"],
    ["description", "description"],
    ["creator", "creator"],
    ["creator_notes", "creatorNotes"],
    ["version", "version"],
  ] as const) {
    if (input[st] !== undefined) fields[ours] = input[st];
  }
  if (Array.isArray(input.first_messages)) {
    fields.firstMessage = String(input.first_messages[0] ?? "");
    fields.greetings = input.first_messages.slice(1).map(String);
  }
  if (input.extensions && typeof input.extensions === "object") {
    // regex scripts live in Marinara's regex list, not in the card
    const rest = { ...(input.extensions as Record<string, unknown>) };
    delete rest.regex_scripts;
    data.extensions = rest;
  }
  return fields;
}

async function stGetCharacter(s: PageSession, name: unknown): Promise<Record<string, unknown>> {
  const item = await getChar(s, name);
  return stCharacter(s, item.id, item.data);
}

async function stReplaceCharacter(s: PageSession, name: unknown, character: Record<string, unknown>): Promise<void> {
  const c = findChar(s, name);
  if (!(await setChar(s, c.id, fromStCharacter(character ?? {}), { replace: true }))) return;
  const book = character?.worldbook;
  if (typeof book === "string" && book && !s.world.books.some((b) => b.name === book && b.characterIds?.includes(c.id))) await linkBook(s, book, { char: c.id }, true);
}

const charExists = (s: PageSession, name: unknown) => s.world.chars.some((c) => c.name === String(name).replace(/\.png$/i, ""));

function characterCommands(s: PageSession) {
  return {
    getCharacterNames: cmd(() => s.world.chars.map((c) => c.name)),
    getCharacterIds: cmd(() => s.world.chars.map((c) => c.id)),
    getCurrentCharacterName: cmd(() => s.cast[0]?.name ?? null),
    getCurrentCharacterId: cmd(() => s.cast[0]?.id ?? null),
    getCharacter: cmd((name: unknown) => stGetCharacter(s, name)),
    replaceCharacter: cmd({ writes: true }, (name: unknown, character: Record<string, unknown>) => stReplaceCharacter(s, name, character)),
    updateCharacterWith: cmd({ writes: true }, async (name: unknown, updater: (c: Record<string, unknown>) => unknown) => {
      const next = await updater(await stGetCharacter(s, name));
      if (next && typeof next === "object") await stReplaceCharacter(s, name, next as Record<string, unknown>);
      return stGetCharacter(s, name);
    }),
    createCharacter: cmd({ writes: true }, async (name: unknown, character?: Record<string, unknown>) => {
      if (String(name) === "current" || charExists(s, name)) return false;
      await addChar(s, String(name).replace(/\.png$/i, ""), fromStCharacter(character ?? {}));
      return true;
    }),
    createOrReplaceCharacter: cmd({ writes: true }, async (name: unknown, character?: Record<string, unknown>) => {
      if (!charExists(s, name)) {
        await addChar(s, String(name).replace(/\.png$/i, ""), fromStCharacter(character ?? {}));
        return true;
      }
      await stReplaceCharacter(s, name, character ?? {});
      return false;
    }),
    deleteCharacter: cmd({ writes: true }, (name: unknown, options?: { delete_chats?: boolean }) => {
      if (options?.delete_chats) throw new Error(t("Not supported: delete_chats", "지원 안 함: delete_chats"));
      return delChar(s, name);
    }),
    importRawCharacter: cmd({ writes: true }, async (filename: unknown, content: unknown) => {
      const name = await importChar(s, content, filename);
      return new Response(JSON.stringify({ name }), { status: 200 });
    }),
    getCharData: cmd((name?: unknown) => {
      const n = name === undefined || name === "current" ? null : String(name);
      const c = n === null ? s.cast[0] : s.cast.find((x) => x.name === n || x.id === n);
      return c ? { ...c.data, name: c.name, description: c.description, personality: c.personality, scenario: c.scenario, first_mes: c.firstMessage } : null;
    }),
  };
}

// ── personas ──

/** A persona in JS-Slash-Runner's "Persona" shape (Marinara has no place settings for one: those are SillyTavern's defaults). */
function stPersona(s: PageSession, name: unknown): Record<string, unknown> {
  const p = findPersona(s, name);
  if (!p) throw new Error(t(`No persona: ${String(name ?? "current")}`, `페르소나 없음: ${String(name ?? "current")}`));
  return {
    avatar_id: p.id,
    avatar: p.avatarPath ?? "",
    name: p.name,
    title: "",
    description: p.description,
    position: 0,
    depth: 2,
    role: 0,
    lorebook: s.world.books.find((b) => b.personaIds?.includes(p.id))?.name ?? "",
    connections: [],
    is_default: false,
  };
}

async function stReplacePersona(s: PageSession, name: unknown, persona: Record<string, unknown>): Promise<void> {
  const p = findPersona(s, name);
  if (!p) throw new Error(t(`No persona: ${String(name ?? "current")}`, `페르소나 없음: ${String(name ?? "current")}`));
  const fields: Record<string, unknown> = {};
  if (persona?.name !== undefined) fields.name = persona.name;
  if (persona?.description !== undefined) fields.description = persona.description;
  if (!(await setUser(s, p.id, fields))) return;
  const book = persona?.lorebook;
  if (typeof book === "string" && book && !s.world.books.some((b) => b.name === book && b.personaIds?.includes(p.id))) await linkBook(s, book, { persona: p.id }, true);
}

function personaCommands(s: PageSession) {
  return {
    getPersonaNames: cmd(() => s.world.personas.map((p) => p.name)),
    getPersonaIds: cmd(() => s.world.personas.map((p) => p.id)),
    getCurrentPersonaName: cmd(() => (s.me.id ? s.me.name : null)),
    getCurrentPersonaId: cmd(() => s.me.id),
    getPersonaAvatarPath: cmd((name?: unknown) => findPersona(s, name)?.avatarPath ?? null),
    getPersona: cmd((name: unknown) => stPersona(s, name)),
    replacePersona: cmd({ writes: true }, (name: unknown, persona: Record<string, unknown>) => stReplacePersona(s, name, persona)),
    updatePersonaWith: cmd({ writes: true }, async (name: unknown, updater: (p: Record<string, unknown>) => unknown) => {
      const next = await updater(stPersona(s, name));
      const id = findPersona(s, name)?.id;
      if (next && typeof next === "object") await stReplacePersona(s, name, next as Record<string, unknown>);
      return stPersona(s, id);
    }),
    createPersona: cmd({ writes: true }, async (name: unknown, persona?: Record<string, unknown>) => {
      if (String(name) === "current" || s.world.personas.some((p) => p.name === String(name))) return false;
      await addUser(s, name, { description: persona?.description ?? "" });
      return true;
    }),
    createOrReplacePersona: cmd({ writes: true }, async (name: unknown, persona?: Record<string, unknown>) => {
      if (!s.world.personas.some((p) => p.name === String(name) || p.id === String(name))) {
        await addUser(s, name, { description: persona?.description ?? "" });
        return true;
      }
      await stReplacePersona(s, name, persona ?? {});
      return false;
    }),
    deletePersona: cmd({ writes: true }, (name: unknown) => delUser(s, name)),
  };
}

// ── regex scripts ──

/** A regex script in JS-Slash-Runner's "TavernRegex" shape. */
function stRegex(r: RegexScript): Record<string, unknown> {
  return {
    id: r.id,
    script_name: r.name,
    enabled: r.enabled,
    run_on_edit: false,
    scope: r.targetCharacterIds.length ? "character" : "global",
    find_regex: `/${r.findRegex}/${r.flags}`,
    trim_strings: r.trimStrings.join("\n"),
    replace_string: r.replaceString,
    source: { user_input: r.placement.includes("user_input"), ai_output: r.placement.includes("ai_output"), slash_command: false, world_info: false },
    destination: { display: r.display, prompt: r.prompt },
    min_depth: r.minDepth,
    max_depth: r.maxDepth,
  };
}

/** A "TavernRegex" a page passed, as setRegex's fields ("/find/flags" or a bare pattern). */
function fromStRegex(input: Record<string, unknown>): Record<string, unknown> {
  const out: Record<string, unknown> = {};
  if (input.id !== undefined) out.id = String(input.id);
  if (input.script_name !== undefined) out.name = input.script_name;
  if (input.enabled !== undefined) out.enabled = input.enabled !== false;
  if (input.find_regex !== undefined) {
    const m = /^\/([\s\S]*)\/([a-z]*)$/.exec(String(input.find_regex));
    out.find = m ? m[1] : String(input.find_regex);
    out.flags = m ? m[2] : "g";
  }
  if (input.replace_string !== undefined) out.replace = input.replace_string;
  if (input.trim_strings !== undefined) out.trim = String(input.trim_strings ?? "").split("\n").filter(Boolean);
  const source = input.source as Record<string, unknown> | undefined;
  if (source) out.on = ["user_input", "ai_output"].filter((k) => source[k] === true);
  const dest = input.destination as { display?: unknown; prompt?: unknown } | undefined;
  if (dest) out.mode = dest.display && dest.prompt ? "both" : dest.prompt ? "prompt" : "display";
  if (input.min_depth !== undefined) out.minDepth = input.min_depth;
  if (input.max_depth !== undefined) out.maxDepth = input.max_depth;
  return out;
}

/** JS-Slash-Runner's { type, name } as a scope of Marinara's one list. */
function stScope(option: { type?: string; name?: string } = {}): RegexScope {
  if (option?.type === "character") return { char: option.name ?? "current" };
  if (option?.type === "preset") return { preset: option.name ?? "in_use" };
  return { global: true };
}

function stRegexes(s: PageSession, option?: { type?: string; name?: string }): Record<string, unknown>[] {
  const scope = stScope(option);
  const charId = scope.char !== undefined ? findChar(s, scope.char).id : null;
  const presetId = scope.preset === undefined ? null : scope.preset === "in_use" ? s.world.presetId : (s.world.presets.find((p) => p.name === scope.preset || p.id === scope.preset)?.id ?? scope.preset);
  return s.world.regex
    .filter((r) => (charId ? r.targetCharacterIds.includes(charId) : presetId ? r.targetPromptPresetIds.includes(presetId) : !r.targetCharacterIds.length && !r.targetPromptPresetIds.length))
    .map(stRegex);
}

function regexCompatCommands(s: PageSession) {
  return {
    getTavernRegexes: cmd((option?: { type?: string; name?: string }) => stRegexes(s, option)),
    replaceTavernRegexes: cmd({ writes: true }, async (regexes: unknown, option?: { type?: string; name?: string }) => {
      await setRegex(s, (Array.isArray(regexes) ? regexes : []).map((r) => fromStRegex(r as Record<string, unknown>)), { ...stScope(option), replace: true });
    }),
    updateTavernRegexesWith: cmd({ writes: true }, async (updater: (list: Record<string, unknown>[]) => unknown, option?: { type?: string; name?: string }) => {
      const next = await updater(stRegexes(s, option));
      await setRegex(s, (Array.isArray(next) ? next : []).map((r) => fromStRegex(r as Record<string, unknown>)), { ...stScope(option), replace: true });
      return stRegexes(s, option);
    }),
    isCharacterTavernRegexesEnabled: cmd(() => true),
    formatAsTavernRegexedString: cmd((text: unknown, source: unknown, destination: unknown, options: { depth?: number } = {}) => {
      // Marinara's scripts change only replies and the person's messages
      if (source !== "ai_output" && source !== "user_input") return String(text ?? "");
      return applyRegex(s, text, { on: String(source), mode: destination === "prompt" ? "prompt" : "display", depth: options?.depth });
    }),
  };
}

export function stWorldCommands(s: PageSession) {
  return { ...worldbookCommands(s), ...characterCommands(s), ...personaCommands(s), ...regexCompatCommands(s) };
}

