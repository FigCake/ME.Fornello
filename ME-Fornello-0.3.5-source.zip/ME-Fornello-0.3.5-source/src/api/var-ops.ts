// How variables change, for every kind of variable: plain work on objects.
//
//   mergeInto      sets what is given and keeps the rest, all the way down
//                  (null or undefined deletes; lists are replaced whole)
//   insertMissing  adds only what is not there yet, all the way down
//   deletePath     takes out one value by its path ("stats.hp", "items[0]")

type Obj = Record<string, unknown>;

const isPlain = (v: unknown): v is Obj => !!v && typeof v === "object" && !Array.isArray(v) && Object.getPrototypeOf(v) === Object.prototype;

const clone = <T>(v: T): T => (v !== null && typeof v === "object" ? structuredClone(v) : v);

export function mergeInto(target: Obj, patch: Obj): Obj {
  for (const [k, v] of Object.entries(patch ?? {})) {
    if (v === null || v === undefined) delete target[k];
    else if (isPlain(v) && isPlain(target[k])) mergeInto(target[k] as Obj, v);
    else target[k] = isPlain(v) ? mergeInto({}, v) : clone(v);
  }
  return target;
}

export function insertMissing(target: Obj, patch: Obj): Obj {
  for (const [k, v] of Object.entries(patch ?? {})) {
    if (v === null || v === undefined) continue;
    if (!(k in target)) target[k] = isPlain(v) ? mergeInto({}, v) : clone(v);
    else if (isPlain(v) && isPlain(target[k])) insertMissing(target[k] as Obj, v);
  }
  return target;
}

/** "a.b[0].c" or "a/b/0/c" (a leading "/" is fine) → ["a", "b", "0", "c"]. */
export function pathParts(path: string | (string | number)[]): string[] {
  if (Array.isArray(path)) return path.map(String);
  const text = String(path);
  if (text.startsWith("/")) return text.slice(1).split("/").map((p) => p.replace(/~1/g, "/").replace(/~0/g, "~"));
  // a.b[0]["x.y"]: names between dots, and anything in brackets (quoted names may hold dots)
  const parts: string[] = [];
  const re = /\[(?:"([^"]*)"|'([^']*)'|([^\]]*))\]|([^.[\]]+)/g;
  for (let m = re.exec(text); m; m = re.exec(text)) parts.push(m[1] ?? m[2] ?? m[3] ?? m[4]);
  return parts.filter((p) => p !== "");
}

/** The value at a path, or undefined. */
export function getPath(obj: unknown, path: string | (string | number)[]): unknown {
  let at: unknown = obj;
  for (const part of pathParts(path)) {
    if (at === null || typeof at !== "object") return undefined;
    at = (at as Obj)[part];
  }
  return at;
}

/** Takes out the value at a path; true when there was one. */
export function deletePath(obj: Obj, path: string | (string | number)[]): boolean {
  const parts = pathParts(path);
  const last = parts.pop();
  if (last === undefined) return false;
  const parent = getPath(obj, parts);
  if (parent === null || typeof parent !== "object" || !(last in (parent as Obj))) return false;
  if (Array.isArray(parent) && /^\d+$/.test(last)) parent.splice(Number(last), 1);
  else delete (parent as Obj)[last];
  return true;
}
