// The component editor in the settings window (which owns the draft): code,
// where values come from, the values table, the AI's rule, tracker
// instructions and a live preview.

import { requireChat, currentChatId } from "../host/current-chat";
import { componentRule, ruleToChatBook } from "../components/rules";
import { pageApi } from "../api/page-api";
import type { TrackerState } from "../shared/tracker";
import { applyStylesheets, loadFontsFor } from "../runtime/stylesheets";
import { THEME_CSS, componentSheets } from "../components/look";
import { useFont } from "../components/host";
import type { Settings } from "../settings";
import { t } from "../shared/i18n";
import { type ComponentDef, type ComponentKind, type ComponentSource, type ComponentUse, isTagName, ownFields } from "../components/model";
import { applySwaps, bodyExample, bodyValues } from "../components/body";
import { mountTemplate, renameTemplateKey, templateKeys } from "../components/template";
import { instructionsFromChat, instructionsOf, instructionsToChat } from "../components/instructions";
import { compileComponent, mountComponent, type MountedComponent } from "../components/runtime";
import { componentName } from "../components/source";
import { FIELD_TYPES, type FieldEdit, type FieldType, codeAfter, exampleProps, exampleTagFor, fieldsFromCode, fieldsFromTemplate, isFieldName } from "../components/fields";
import { helpTip, segmented, setting, toggle } from "../shared/form";
import { showToast } from "./toast";
import { screenUi } from "./page-ui";
import { el } from "./dom";

/** What the editor needs from the settings window. */
export interface EditorHost {
  readonly settings: Settings;
  /** Draws the window again now / once a press or a focus move has landed. */
  render(): void;
  renderSoon(): void;
  /** Marinara's font families (null while not read). */
  fonts(): string[] | null;
  /** The open chat's tracker, for the field names (null when none). */
  tracker(): TrackerState | null;
  saveComponent(d: ComponentDef): Promise<void>;
  removeComponent(d: ComponentDef): Promise<void>;
  exportFile(defs: ComponentDef[], name: string): void;
  closeEditor(): void;
}

export class ComponentEditor {
  private preview: MountedComponent | null = null;
  private disposePreviewApi: (() => void) | null = null;
  /** Counts previews: one that finishes getting ready after a newer one started does not draw. */
  private previewRun = 0;
  /** The draft came from a file: its preview draws only when asked (▶), not by itself. */
  private waitToPreview = false;

  constructor(private readonly host: EditorHost) {}

  /** A new draft opens: `fromFile`, its code was not written here, so its preview waits for ▶. */
  reset(fromFile = false): void {
    this.stopPreview();
    this.waitToPreview = fromFile;
  }

  /** The editor for a component being made or changed (`d` is the draft: changes go into it). */
  draw(d: ComponentDef): HTMLElement {
    const html = d.kind === "html";
    const own = ownFields(d.kind, d.source === "body", d.body);
    const detected = html ? (isTagName(d.name) && d.code.trim() ? d.name : null) : componentName(d.code);
    if (!own && detected) d.fields = fieldsFromCode(d.code, detected, d.fields);
    const example = detected ? this.exampleTag(d, detected) : "";
    const kind = segmented(
      "fornello-component-kind",
      [
        { value: "jsx", label: "JSX", title: t("JSX component (React)", "JSX 컴포넌트(React)") },
        { value: "html", label: "HTML", title: t("HTML with {{value}} places; no code runs", "{{값}} 자리가 있는 HTML. 코드는 실행 안 됨") },
      ],
      d.kind,
      (v) => {
        // JSX and HTML are written differently: the code starts over
        if (d.code.trim() && !window.confirm(t("Switching clears the code (JSX and HTML are written differently). Switch?", "종류를 바꾸면 코드가 지워져요(JSX와 HTML은 쓰는 법이 달라요). 바꿀까요?"))) {
          this.host.render();
          return;
        }
        d.kind = v as ComponentKind;
        d.code = "";
        d.fields = [];
        d.map = {};
        this.host.render();
      },
      t("Kind", "종류"),
    );
    const label = el("input", { value: d.label, "aria-label": t("Display name", "표시 이름") });
    label.addEventListener("change", () => (d.label = label.value.trim()));
    const status = html
      ? this.templateStatus(d)
      : detected
      ? el("div", { className: "ok" }, t(`${detected} · ${d.fields.length} value(s)`, `${detected} · 값 ${d.fields.length}개`))
      : el(
          "div",
          { className: d.code.trim() ? "field-h err" : "field-h" },
          d.code.trim() ? t("No component found.", "컴포넌트를 찾지 못했어요.") : t("Paste JSX component code.", "JSX 컴포넌트 코드를 붙여 넣으세요."),
          helpTip(
            t("Write function Name(…) { … } or const Name = (…) => …; Name is the tag", "function 이름(…) { … } 또는 const 이름 = (…) => … 형태. 이름이 태그"),
            t("Component", "컴포넌트"),
          ),
        );
    const code = el("textarea", {
      className: "code",
      spellcheck: false,
      value: d.code,
      "aria-label": html ? t("Template (HTML)", "템플릿 (HTML)") : t("Component code (JSX)", "컴포넌트 코드 (JSX)"),
      placeholder: html
        ? t("<div>{{value}}</div>\n<style>div { … }</style>", "<div>{{값}}</div>\n<style>div { … }</style>")
        : "function Name({ value }) {\n  return <div>{value}</div>;\n}",
    });
    code.addEventListener("change", () => {
      d.code = code.value;
      if (html) d.fields = fieldsFromTemplate(d.code, d.fields, d.source === "body" && d.body.lines ? "rows" : undefined);
      else {
        const n = componentName(d.code);
        if (n) d.name = n;
      }
      this.host.renderSoon();
    });
    const tagName = html ? el("input", { value: d.name, placeholder: "Name", spellcheck: false, "aria-label": t("Name (tag name)", "이름 (태그 이름)") }) : null;
    tagName?.addEventListener("change", () => {
      d.name = tagName.value.trim();
      this.host.renderSoon();
    });
    const source = segmented(
      "fornello-component-source",
      [
        { value: "tag", label: t("Tag in reply", "답변 속 태그") },
        { value: "body", label: t("Text in tag", "본문"), title: t("Values as text inside the tag: <Tag>a|b</Tag>", "태그 안의 글로 값 받기: <Tag>a|b</Tag>") },
        { value: "tracker", label: t("Tracker", "트래커") },
      ],
      d.source,
      (v) => {
        d.source = v as ComponentSource;
        this.host.render();
      },
      t("Values from", "값 받는 곳"),
    );
    const left = el(
      "div",
      { className: "col" },
      setting(t("Display name", "표시 이름"), label, t("Shown when folded; empty: the component's name", "접혔을 때 보이는 이름. 비우면 컴포넌트 이름")),
      setting(
        t("New chats", "새 채팅에서"),
        segmented(
          "fornello-component-every",
          [
            { value: "on", label: t("On", "켜짐") },
            { value: "off", label: t("Off", "꺼짐") },
          ],
          d.everyChat ? "on" : "off",
          (v) => {
            d.everyChat = v === "on";
            this.host.render();
          },
          t("New chats", "새 채팅에서"),
        ),
        t("Shown in chats that did not choose", "따로 고르지 않은 채팅에서 보일지"),
      ),
      setting(
        t("Font", "글꼴"),
        el(
          "select",
          { "aria-label": t("Font", "글꼴"), onchange: (e: Event) => ((d.font = (e.target as HTMLSelectElement).value), this.host.render()) },
          el("option", { value: "", selected: !d.font }, t("Theme's font", "테마 글꼴")),
          ...[...new Set([...(this.host.fonts() ?? []), ...(d.font ? [d.font] : [])])].map((f) => el("option", { value: f, selected: f === d.font }, f)),
        ),
        t("A font added to Marinara, for the component's text", "마리나라에 넣은 글꼴로 컴포넌트 글자 쓰기"),
      ),
      tagName ? setting(t("Name", "이름"), tagName, t("The tag the AI writes (<Name …/>): English letters, a capital first", "AI가 쓰는 태그(<이름 …/>). 영문, 대문자로 시작")) : null,
      status,
      code,
      el(
        "div",
        { className: "field-h" },
        t("Theme classes and icons", "테마 클래스 · 아이콘"),
        helpTip(
          t(
            "Theme colours: var(--fc-text), --fc-muted, --fc-title, --fc-accent, --fc-card, --fc-line, --fc-radius\nClasses: fc-card, fc-title, fc-muted, fc-accent, fc-badge, fc-btn, fc-bar (<div class=\"fc-bar\" style=\"--value:70%\"><i></i></div>)\nFont Awesome and Material Symbols classes load their icons; other CSS: <link rel=\"stylesheet\">",
            "테마 색: var(--fc-text), --fc-muted, --fc-title, --fc-accent, --fc-card, --fc-line, --fc-radius\n클래스: fc-card, fc-title, fc-muted, fc-accent, fc-badge, fc-btn, fc-bar(<div class=\"fc-bar\" style=\"--value:70%\"><i></i></div>)\nFont Awesome·Material Symbols 클래스는 아이콘을 저절로 불러옴. 다른 CSS는 <link rel=\"stylesheet\">",
          ),
          t("Theme classes and icons", "테마 클래스 · 아이콘"),
        ),
      ),
      setting(
        t("Values from", "값 받는 곳"),
        source,
        t(
          "· Tag in reply: attributes (<Tag a={1} />)\n· Text in tag: <Tag>a|b|c</Tag>\n· Tracker: Marinara's tracker",
          "· 답변 속 태그: 속성(<Tag a={1} />)\n· 본문: <Tag>a|b|c</Tag>\n· 트래커: 마리나라 트래커",
        ),
      ),
    );
    if (d.source === "tracker") {
      left.append(
        setting(
          t("Instructions in this chat's tracker", "지시사항을 이 채팅 트래커에"),
          el(
            "span",
            { className: "row" },
            el("button", { disabled: !currentChatId(), onclick: () => void this.instructionsToTracker(d) }, t("Put in", "넣기")),
            el("button", { disabled: !currentChatId(), onclick: () => void this.instructionsOutOfTracker(d) }, t("Take out", "빼기")),
          ),
          t(
            "Writes each value's instruction into this chat's custom tracker fields for the Custom Tracker agent (it must be on); missing fields are added",
            "값마다 지시사항을 이 채팅의 사용자 트래커 항목에 넣음(Custom Tracker 에이전트가 켜져 있어야 함). 없는 항목은 추가",
          ),
        ),
      );
    }
    if (d.source === "body") left.append(...this.bodySettings(d));
    if (d.source !== "tracker") {
      const rule = componentRule(d.name, d.use, example, d.when, d.fields, d.source === "body" ? d.body : undefined);
      const use = segmented(
        "fornello-component-use",
        [
          { value: "status", label: t("Status", "상태창") },
          { value: "scene", label: t("Scene", "장면") },
        ],
        d.use,
        (v) => {
          d.use = v as ComponentUse;
          this.host.render();
        },
        t("How the AI uses it", "AI가 쓰는 방식"),
      );
      left.append(
        setting(
          t("How the AI uses it", "AI가 쓰는 방식"),
          use,
          t(
            "· Status: every reply, drawn under it\n· Scene: only when it fits, drawn where it is",
            "· 상태창: 답변마다, 답변 아래에\n· 장면: 맞을 때만, 그 자리에",
          ),
        ),
      );
      if (d.use === "scene") {
        const when = el("input", {
          value: d.when,
          placeholder: t("In English", "영어로"),
          "aria-label": t("When to use it", "언제 쓸지"),
        });
        when.addEventListener("change", () => {
          d.when = when.value;
          this.host.renderSoon();
        });
        left.append(setting(t("When to use it", "언제 쓸지"), when, t("Goes into the rule; write it in English", "규칙에 들어감. 영어로")));
      }
      const ruleBox = el("textarea", { className: "small", readOnly: true, value: rule, "aria-label": t("Rule for the AI", "AI에게 줄 규칙") });
      left.append(
        el(
          "div",
          { className: "field-h" },
          t("Rule for the AI", "AI에게 줄 규칙"),
          helpTip(
            t("Put this in the card or a lorebook so the AI writes the tag", "AI가 태그를 쓰도록 카드나 로어북에 넣기"),
            t("Rule for the AI", "AI에게 줄 규칙"),
          ),
        ),
        ruleBox,
        el(
          "div",
          { className: "row" },
          el("button", { onclick: () => void navigator.clipboard.writeText(rule).then(() => showToast(t("Rule copied.", "규칙을 복사했어요."), "success")) }, t("Copy", "복사")),
          el(
            "button",
            { disabled: !currentChatId(), title: t("Add as an always-on entry", "항상 켜진 항목으로 넣기"), onclick: () => void this.ruleToLore(d.name, rule) },
            t("Add to this chat's lorebook", "이 채팅 로어북에 넣기"),
          ),
        ),
      );
    }
    const box = el("div", { className: "preview" });
    const right = el(
      "div",
      { className: "col" },
      this.fieldTable(d, detected),
      el(
        "div",
        { className: "field-h" },
        t("Preview", "미리보기"),
        helpTip(t("Drawn with the examples; commands do nothing here", "예시값으로 그림. 명령은 실제로 실행 안 됨"), t("Preview", "미리보기")),
        el("span", { style: "flex:1" }),
        el("button", { onclick: () => void this.runPreview(d, box) }, t("▶ Draw", "▶ 그려 보기")),
      ),
      box,
    );
    // the preview draws by itself with the examples, each time the editor is drawn
    if (detected && !(this.waitToPreview && d.kind === "jsx")) setTimeout(() => box.isConnected && void this.runPreview(d, box), 0);
    const saveButton = el(
      "button",
      {
        className: "primary",
        disabled: !detected,
        onclick: () => {
          d.code = code.value;
          d.label = label.value.trim();
          if (tagName) d.name = tagName.value.trim();
          if (!html) d.name = componentName(d.code) ?? d.name;
          void this.host.saveComponent(d);
        },
      },
      t("Save", "저장"),
    );
    // Save follows what is typed (the editor itself is drawn again only once the field is left)
    const canSave = () => (saveButton.disabled = html ? !(isTagName(tagName?.value.trim() ?? "") && code.value.trim()) : !componentName(code.value));
    code.addEventListener("input", canSave);
    tagName?.addEventListener("input", canSave);
    const actions = el(
      "div",
      { className: "row", style: "grid-column: 1 / -1" },
      saveButton,
      this.host.settings.current.components.some((w) => w.id === d.id) ? el("button", { className: "danger", onclick: () => void this.host.removeComponent(d) }, t("Delete", "삭제")) : null,
      this.host.settings.current.components.some((w) => w.id === d.id) ? el("button", { onclick: () => this.host.exportFile([d], d.label || d.name) }, t("Export", "내보내기")) : null,
      el("button", { className: "ghost", onclick: () => this.host.closeEditor() }, t("Close", "닫기")),
    );
    return el("div", { className: "editor-wrap" }, el("div", { className: "row" }, kind), el("div", { className: "editor" }, left, right, actions));
  }
  /** The tag the AI should write, filled with the examples. */
  private exampleTag(d: ComponentDef, name: string): string {
    if (d.source !== "body") return exampleTagFor(name, d.fields);
    const text = bodyExample(d.body, d.fields);
    return d.body.lines ? `<${name}>\n${text}\n</${name}>` : `<${name}>${text}</${name}>`;
  }
  /** The values the preview draws with: the examples (or the example text inside the tag), swaps applied. */
  private previewValues(d: ComponentDef, name: string): Record<string, unknown> {
    const fields = ownFields(d.kind, d.source === "body", d.body) ? d.fields : fieldsFromCode(d.code, name, d.fields);
    const values = d.source === "body" ? bodyValues(bodyExample(d.body, fields), d.body, fields) : exampleProps(fields);
    return applySwaps(values, fields);
  }
  /** How the text inside the tag splits into values: the separator, one item a line, an example. */
  private bodySettings(d: ComponentDef): HTMLElement[] {
    const sep = segmented(
      "fornello-component-sep",
      [
        { value: "|", label: "|", title: "a|b|c" },
        { value: ":", label: ":", title: "a: b" },
      ],
      d.body.sep,
      (v) => {
        d.body.sep = v as "|" | ":";
        this.host.render();
      },
      t("Separator", "나누는 기호"),
    );
    const sample = el("textarea", {
      className: "small",
      value: d.body.sample,
      spellcheck: false,
      placeholder: bodyExample({ ...d.body, sample: "" }, d.fields) || (d.body.lines ? (d.body.sep === ":" ? "a: b\nc: d" : "a|b\nc|d") : d.body.sep === ":" ? "a: b" : "a|b|c"),
      "aria-label": t("Example text in the tag", "예시 본문"),
    });
    sample.addEventListener("change", () => {
      d.body.sample = sample.value;
      this.host.renderSoon();
    });
    return [
      setting(t("Separator", "나누는 기호"), sep, t("a|b|c or a: b; only the last part may contain it", "a|b|c 또는 a: b. 마지막 칸만 그 기호를 포함 가능")),
      setting(
        t("One item a line", "한 줄에 하나씩"),
        toggle(d.body.lines, (v) => {
          d.body.lines = v;
          this.host.render();
        }, t("One item a line", "한 줄에 하나씩")),
        t(
          "Each line becomes an item of rows: {{#rows}}…{{/rows}}, with {{1}}, {{2}}…, {{text}} and {{#a}} (lines starting with a)",
          "줄마다 rows의 항목: {{#rows}}…{{/rows}}, 안에서 {{1}}, {{2}}…, {{text}}, {{#a}}(a로 시작하는 줄)",
        ),
      ),
      setting(t("Example text in the tag", "예시 본문"), sample, t("For the preview and the rule; empty: from the examples", "미리보기·규칙용. 비우면 예시값으로"), { stack: true }),
    ];
  }
  /** An HTML template's line under its name: how many values, the places the table lacks, the values the template does not use. */
  private templateStatus(d: ComponentDef): HTMLElement {
    if (!isTagName(d.name)) return el("div", { className: "err" }, t("Name: English letters, a capital first.", "이름: 영문, 대문자로 시작."));
    const within = d.source === "body" && d.body.lines ? "rows" : undefined;
    const { keys } = templateKeys(d.code, within);
    const missing = keys.filter((k) => isFieldName(k) && !d.fields.some((f) => f.name === k));
    const unused = d.fields.filter((f) => !keys.includes(f.name)).map((f) => f.name);
    return el(
      "div",
      { className: "col", style: "gap:2px" },
      el("div", { className: d.code.trim() ? "ok" : "note" }, d.code.trim() ? t(`${d.name} · ${d.fields.length} value(s)`, `${d.name} · 값 ${d.fields.length}개`) : t("Paste an HTML template.", "HTML 템플릿을 붙여 넣으세요.")),
      missing.length
        ? el(
            "div",
            { className: "err" },
            t(`Not in the values: ${missing.join(", ")} `, `값 표에 없음: ${missing.join(", ")} `),
            el("button", { className: "mini", onclick: () => ((d.fields = fieldsFromTemplate(d.code, d.fields, within)), this.host.render()) }, t("Add", "추가")),
          )
        : null,
      unused.length ? el("div", { className: "note" }, t(`Not used in the template: ${unused.join(", ")}`, `템플릿에서 안 씀: ${unused.join(", ")}`)) : null,
    );
  }
  /** The values table: name, kind, example, instruction (and the tracker field in tracker mode); the code follows names. */
  private fieldTable(d: ComponentDef, name: string | null): HTMLElement {
    const paths = this.trackerPaths();
    const listId = "fornello-tracker-paths";
    const kinds: Record<FieldType, string> = { text: t("Text", "글자"), number: t("Number", "숫자"), bool: t("Yes/no", "참/거짓"), list: t("List", "목록"), object: t("Group", "묶음") };
    const edit = (change: FieldEdit) => {
      if (ownFields(d.kind, d.source === "body", d.body)) {
        // the table is its own: a template keeps its places (a rename follows into them), code stays as it is
        if ("add" in change) d.fields.push(change.add);
        else if ("rename" in change) {
          if (d.kind === "html") d.code = renameTemplateKey(d.code, change.rename, change.to, d.source === "body" && d.body.lines ? "rows" : undefined);
        }
        else d.fields = d.fields.filter((f) => f.name !== change.remove);
      } else {
        if (!name) return;
        d.code = codeAfter(d.code, name, change);
      }
      this.host.renderSoon();
    };
    const rows = d.fields.map((f) => {
      const nameInput = el("input", { className: "fname", value: f.name, spellcheck: false, "aria-label": t(`Name of ${f.name}`, `${f.name}의 이름`) });
      nameInput.addEventListener("change", () => {
        const to = nameInput.value.trim();
        if (to === f.name) return;
        if (!isFieldName(to) || d.fields.some((g) => g.name === to)) {
          showToast(t("Names: letters, digits and _, not starting with a digit, each once.", "이름: 영문·숫자·_ (숫자로 시작 X), 겹치지 않게."), "warning");
          nameInput.value = f.name;
          return;
        }
        if (d.map[f.name]) {
          d.map[to] = d.map[f.name];
          delete d.map[f.name];
        }
        const from = f.name;
        f.name = to;
        edit({ rename: from, to });
      });
      const type = el("select", { "aria-label": t(`Kind of ${f.name}`, `${f.name}의 종류`), onchange: (e: Event) => ((f.type = (e.target as HTMLSelectElement).value as FieldType), this.host.render()) }, ...FIELD_TYPES.map((k) => el("option", { value: k, selected: k === f.type }, kinds[k])));
      const exampleInput = el("input", { value: f.example, placeholder: t("Example", "예시값"), "aria-label": t(`Example of ${f.name}`, `${f.name}의 예시값`) });
      exampleInput.addEventListener("change", () => ((f.example = exampleInput.value), this.host.renderSoon()));
      const instruction = el("textarea", {
        className: "inst",
        value: f.instruction,
        placeholder: t("Instruction: what the AI writes here", "지시사항: AI가 이 칸에 쓸 것"),
        "aria-label": t(`Instruction for ${f.name}`, `${f.name}의 지시사항`),
      });
      instruction.addEventListener("change", () => ((f.instruction = instruction.value), this.host.renderSoon()));
      const swaps = el("textarea", {
        className: "inst swaps",
        value: f.swaps ?? "",
        placeholder: t("Swaps (optional), one a line: value=shown", "바꾸기(선택), 한 줄에 하나: 값=보일 글"),
        "aria-label": t(`Swaps for ${f.name}`, `${f.name} 바꾸기`),
      });
      swaps.addEventListener("change", () => {
        if (swaps.value.trim()) f.swaps = swaps.value;
        else delete f.swaps;
        this.host.renderSoon();
      });
      const row = el(
        "div",
        { className: "frow" },
        el("div", { className: "row" }, nameInput, type, el("button", { className: "ghost", title: t(`Remove ${f.name}`, `${f.name} 빼기`), "aria-label": t(`Remove ${f.name}`, `${f.name} 빼기`), onclick: () => edit({ remove: f.name }) }, "✕")),
        exampleInput,
        instruction,
        swaps,
      );
      if (d.source === "tracker") {
        const path = el("input", { value: d.map[f.name] ?? "", placeholder: `custom.${f.name}`, "aria-label": t(`Tracker field for ${f.name}`, `${f.name}의 트래커 항목`) });
        path.setAttribute("list", listId);
        path.addEventListener("change", () => {
          const v = path.value.trim();
          if (v) d.map[f.name] = v;
          else delete d.map[f.name];
        });
        row.append(path);
      }
      return row;
    });
    const add = () => {
      let n = d.fields.length + 1;
      while (d.fields.some((f) => f.name === `value${n}`)) n++;
      edit({ add: { name: `value${n}`, type: "text", example: "", instruction: "" } });
    };
    return el(
      "div",
      { className: "col" },
      el(
        "div",
        { className: "field-h" },
        t("Values", "값"),
        helpTip(
          t(
            "Edits here change the code or template too\nExample: for the preview\nInstruction: what the AI writes (in the rule)\nSwaps: value=shown, one a line\nTracker path: empty means the field of the same name",
            "여기서 고치면 코드·템플릿도 바뀜\n예시값: 미리보기용\n지시사항: AI가 쓸 것(규칙에 들어감)\n바꾸기: 값=보일 글, 한 줄에 하나\n트래커 경로: 비우면 같은 이름 항목",
          ),
          t("Values", "값"),
        ),
        el("span", { style: "flex:1" }),
        el("button", { className: "mini", disabled: !name && !ownFields(d.kind, d.source === "body", d.body), onclick: add }, t("+ Value", "+ 값")),
      ),
      d.fields.length
        ? el("div", { className: "ftable" }, ...rows)
        : el("div", { className: "note" }, d.kind === "html" ? t("Values the template asks for ({{name}}) show here.", "템플릿이 쓰는 값({{이름}})이 여기 나와요.") : name ? t("This component takes no values.", "값이 없는 컴포넌트예요.") : t("Values show once the code has a component.", "코드에 컴포넌트가 있으면 값이 보여요.")),
      d.source === "tracker" ? el("datalist", { id: listId }, ...paths.map((p) => el("option", { value: p }))) : null,
    );
  }
  private trackerPaths(): string[] {
    const t = this.host.tracker();
    const out = ["date", "time", "location", "weather", "temperature", "status"];
    for (const f of t?.playerStats?.customTrackerFields ?? []) out.push(`custom.${f.name}`);
    for (const f of t?.worldCustomFields ?? []) out.push(`world.${f.name}`);
    for (const c of t?.presentCharacters ?? []) for (const k of ["mood", "action", "outfit", "thoughts"]) out.push(`char.${c.name}.${k}`);
    return out;
  }
  private async instructionsToTracker(d: ComponentDef): Promise<void> {
    if (!Object.keys(instructionsOf(d)).length) {
      showToast(t("No value with an instruction for a custom tracker field.", "사용자 트래커 항목에 넣을 지시사항이 있는 값이 없어요."), "warning");
      return;
    }
    try {
      const { added, set } = await instructionsToChat(requireChat(), d);
      showToast(t(`Tracker: ${added} field(s) added, ${set} instruction(s) put in.`, `트래커: 항목 ${added}개 추가, 지시사항 ${set}개 넣음.`), "success");
    } catch (e) {
      showToast(t(`Could not write the tracker: ${e instanceof Error ? e.message : String(e)}`, `트래커에 쓰지 못했어요: ${e instanceof Error ? e.message : String(e)}`), "error");
    }
  }
  private async instructionsOutOfTracker(d: ComponentDef): Promise<void> {
    try {
      const removed = await instructionsFromChat(requireChat(), d);
      showToast(t(`Tracker: ${removed} instruction(s) taken out.`, `트래커: 지시사항 ${removed}개 뺌.`), "success");
    } catch (e) {
      showToast(t(`Could not write the tracker: ${e instanceof Error ? e.message : String(e)}`, `트래커에 쓰지 못했어요: ${e instanceof Error ? e.message : String(e)}`), "error");
    }
  }
  private async ruleToLore(name: string, rule: string): Promise<void> {
    try {
      const book = await ruleToChatBook(requireChat(), name, rule);
      showToast(t(`Added the rule to this chat's lorebook ("${book.name}").`, `이 채팅 로어북("${book.name}")에 규칙을 넣었어요.`), "success");
    } catch (e) {
      showToast(t(`Could not add to the lorebook: ${e instanceof Error ? e.message : String(e)}`, `로어북에 넣지 못했어요: ${e instanceof Error ? e.message : String(e)}`), "error");
    }
  }
  private async runPreview(d: ComponentDef, box: HTMLElement): Promise<void> {
    this.stopPreview();
    this.waitToPreview = false;
    const run = this.previewRun;
    box.replaceChildren();
    // its own shadow root, as in a reply: the component's <style> and sheets stay out of these settings (which redraw)
    const host = document.createElement("div");
    // kept in its box, as in a reply
    if (d.kind === "html") host.style.cssText = "position:relative;contain:paint";
    host.style.overflowWrap = "anywhere";
    const inner = document.createElement("div");
    const theme = document.createElement("style");
    theme.textContent = THEME_CSS;
    const shadow = host.attachShadow({ mode: "open" });
    shadow.append(theme, inner);
    box.append(host);
    const sheets = componentSheets(d.code);
    const fonts = () => sheets.length && setTimeout(() => void loadFontsFor(document, inner.textContent ?? ""), 50);
    await useFont(box, d.font);
    if (d.kind === "html") {
      this.preview = mountTemplate(inner, d.code, this.previewValues(d, d.name));
      if (sheets.length) await applyStylesheets(sheets, document, shadow);
      fonts();
      return;
    }
    const name = componentName(d.code);
    if (!name) {
      box.replaceChildren(el("div", { className: "err" }, t("No component found.", "컴포넌트를 찾지 못했어요.")));
      return;
    }
    // an error the component reports more than once (each render) shows once
    const shown = new Set<string>();
    const showErr = (m: string) => {
      if (shown.has(m)) return;
      shown.add(m);
      box.append(el("div", { className: "err" }, m));
    };
    try {
      const props = this.previewValues(d, name);
      if (sheets.length) await applyStylesheets(sheets, document, shadow);
      const api = await pageApi({ preview: true, report: showErr, ui: screenUi });
      // drawn again (or closed) while it got ready: the newer one draws
      if (run !== this.previewRun) {
        api.dispose();
        return;
      }
      this.disposePreviewApi = api.dispose;
      const compiled = compileComponent(name, d.code, api.globals);
      this.preview = mountComponent(inner, compiled, props, (e) => showErr(t(`Component error: ${e instanceof Error ? e.message : String(e)}`, `컴포넌트 오류: ${e instanceof Error ? e.message : String(e)}`)));
      fonts();
    } catch (e) {
      box.append(el("div", { className: "err" }, t(`Could not draw the preview: ${e instanceof Error ? e.message : String(e)}`, `미리보기를 그리지 못했어요: ${e instanceof Error ? e.message : String(e)}`)));
    }
  }

  /** Takes the preview away (the editor closes, or another component is opened). */
  stopPreview(): void {
    this.previewRun++;
    this.preview?.unmount();
    this.preview = null;
    this.disposePreviewApi?.();
    this.disposePreviewApi = null;
  }
}
