// Runs a prepared page: the markup goes into a same-origin frame (Marinara's
// CSP blocks its scripts there), and the scripts run in sval with `window` and
// `document` pointing at the frame. Not a security boundary: the guards only
// keep well-behaved pages from touching Marinara by accident.

import { transform } from "sucrase";
import Sval from "sval";
import { pageReact } from "../host/host-react";
import { TICK, guardLoops, prepareScript, settle, tick } from "./guard";
import { HANDLER_ATTR, type PageScript, type PreparedPage, SCRIPT_ATTR, screenHeights } from "./prepare";
import { addPageFonts, applyStylesheets, loadFontsFor, stylesheetUrls } from "./stylesheets";
import { clearTracked, sandboxScope } from "./scope";
import { ModuleSystem, isModuleCode } from "./modules";
import { backdropColor, contrast, luminance, opaque, rgba } from "../ui/color";
import { t } from "../shared/i18n";

/** `<script type="text/babel">` the way Babel compiles it in the browser: JSX → React.createElement. */
export function compileJsx(code: string, kind: NonNullable<PageScript["jsx"]>): string {
  return transform(code, { transforms: kind === "tsx" ? ["jsx", "typescript"] : ["jsx"], jsxRuntime: "classic", production: true }).code;
}

export interface RunOptions {
  /** Globals the page can use besides the browser's own (the page commands). */
  globals?: Record<string, unknown>;
  /** Run the scripts (false: show the page only). */
  run: boolean;
  maxHeight?: number;
  onError?(message: string): void;
  /** Gets the way to add a name the page's scripts see later (page-api.ts bindScope). */
  onScope?: (define: (name: string, value: unknown) => void) => void;
  /** The frame loaded again (it was moved) and is blank. */
  onReload?(): void;
}

export interface MountedPage {
  frame: HTMLIFrameElement;
  /** Resolves once the scripts ran (or immediately when not running). */
  ready: Promise<void>;
  /** Takes the surrounding text style again (after a theme change). */
  restyle(): void;
  /** The color behind the page: its own, the frame's, or the message's. */
  background(): string;
  dispose(): void;
}

/** screenHeights for styles the page's scripts add later. */
function watchScreenHeights(doc: Document): () => void {
  const fix = (el: Element) => {
    if (el.id === BASE_ID) return;
    if (el.localName === "style") {
      const css = el.textContent ?? "";
      if (/vh\b/i.test(css)) {
        const next = screenHeights(css);
        if (next !== css) el.textContent = next;
      }
    }
    const inline = el.getAttribute("style");
    if (inline && /vh\b/i.test(inline)) {
      const next = screenHeights(inline);
      if (next !== inline) el.setAttribute("style", next);
    }
  };
  const observer = new MutationObserver((records) => {
    for (const r of records) {
      if (r.type === "attributes" && r.target instanceof doc.defaultView!.Element) fix(r.target);
      else if (r.type === "characterData") {
        const parent = r.target.parentElement;
        if (parent?.localName === "style") fix(parent);
      } else {
        if (r.target instanceof doc.defaultView!.Element && r.target.localName === "style") fix(r.target);
        for (const n of r.addedNodes) {
          if (!(n instanceof doc.defaultView!.Element)) continue;
          fix(n);
          for (const el of n.querySelectorAll("style, [style]")) fix(el);
        }
      }
    }
  });
  observer.observe(doc.documentElement, { subtree: true, childList: true, characterData: true, attributes: true, attributeFilter: ["style"] });
  return () => observer.disconnect();
}

/** Default text style for the page: what the message text around `around` uses. */
function baseCss(around: Element): string {
  const cs = getComputedStyle(around);
  const scheme = getComputedStyle(document.documentElement).colorScheme || "normal";
  if (!cs.color) return "";
  // html takes the page's height, else height: 100% would follow the frame, which follows the page
  return `:root{--fornello-vh:${window.innerHeight / 100}px}html{height:auto!important;min-height:0!important}:where(:root){color-scheme:${scheme};color:${cs.color};font-family:${cs.fontFamily};font-size:${cs.fontSize};line-height:${cs.lineHeight};-webkit-text-size-adjust:100%}:where(body){margin:0}`;
}

const BASE_ID = "fornello-base";

/** The page's markup with the base style first in its <head> (before the page's own styles). */
function withBase(html: string, css: string): string {
  const tag = `<style id="${BASE_ID}">${css}</style>`;
  for (const re of [/<head\b[^>]*>/i, /<html\b[^>]*>/i, /<!doctype[^>]*>/i]) {
    const m = re.exec(html);
    if (m) return html.slice(0, m.index + m[0].length) + tag + html.slice(m.index + m[0].length);
  }
  return tag + html;
}

/** Outside stylesheets and fonts (blocked in the frame) are fetched here and handed in; fonts follow the text as it changes. */
function watchFonts(doc: Document, html: string): () => void {
  const urls = stylesheetUrls(html);
  const own = [...doc.querySelectorAll("style")].map((s) => s.textContent ?? "").join("\n");
  if (!urls.length && !/@font-face/i.test(own)) return () => {};
  let timer: ReturnType<typeof setTimeout> | null = null;
  const load = () => void loadFontsFor(doc, doc.body?.textContent ?? "");
  void applyStylesheets(urls, doc, doc.head, screenHeights).then(() => {
    addPageFonts(doc, own, location.href);
    load();
  });
  const observer = new MutationObserver(() => {
    if (timer) clearTimeout(timer);
    timer = setTimeout(load, 400);
  });
  observer.observe(doc.body, { childList: true, subtree: true, characterData: true });
  return () => {
    observer.disconnect();
    if (timer) clearTimeout(timer);
  };
}

/** The content's height, from the body's children: a body with min-height: 100vh would grow with the frame. */
function contentHeight(doc: Document): number {
  const body = doc.body;
  const view = doc.defaultView!;
  const cs = view.getComputedStyle(body);
  let bottom = 0;
  for (const child of Array.from(body.children)) {
    const r = child.getBoundingClientRect();
    if (!r.width && !r.height) continue;
    if (view.getComputedStyle(child).position === "fixed") continue;
    bottom = Math.max(bottom, r.bottom + view.scrollY + (parseFloat(view.getComputedStyle(child).marginBottom) || 0));
  }
  if (!bottom) return Math.ceil(body.scrollHeight);
  const after = (parseFloat(cs.paddingBottom) || 0) + (parseFloat(cs.borderBottomWidth) || 0) + (parseFloat(cs.marginBottom) || 0);
  return Math.ceil(bottom + after);
}

// The frame is see-through and the page takes the message's text color and
// font as defaults; text that would not show on the message gets a backdrop.

export function mountPage(container: HTMLElement, page: PreparedPage, options: RunOptions): MountedPage {
  const frame = document.createElement("iframe");
  // scripts on so the interpreter's handlers and timers work (the CSP still blocks the page's own)
  frame.setAttribute("sandbox", `allow-same-origin${options.run ? " allow-scripts" : ""} allow-forms allow-popups allow-popups-to-escape-sandbox`);
  frame.setAttribute("referrerpolicy", "no-referrer");
  frame.setAttribute("title", "Fornello page");
  frame.style.cssText = "display:block;width:100%;height:160px;border:0;background:transparent;";
  let disposed = false;
  let resize: ResizeObserver | null = null;
  let fonts: (() => void) | null = null;
  let heights: (() => void) | null = null;
  const timers = new Set<number>();
  let resolveReady!: () => void;
  const ready = new Promise<void>((r) => (resolveReady = r));

  /** A plain backdrop when most of the uncovered text is too close in color to the message. */
  let fill = "transparent";
  let backdropTimer: ReturnType<typeof setTimeout> | null = null;
  const backdrop = () => {
    const doc = frame.contentDocument;
    const view = doc?.defaultView;
    if (!doc?.body || !view || disposed) return;
    const behind = rgba(backdropColor(container));
    const covered = new Map<Element, boolean>();
    const isCovered = (el: Element | null): boolean => {
      if (!el) return false;
      let known = covered.get(el);
      if (known === undefined) covered.set(el, (known = opaque(view.getComputedStyle(el)) || isCovered(el.parentElement)));
      return known;
    };
    let total = 0;
    let faint = 0;
    const walker = doc.createTreeWalker(doc.body, NodeFilter.SHOW_TEXT);
    for (let node = walker.nextNode(), seen = 0; node && seen < 400; node = walker.nextNode(), seen++) {
      const text = node.textContent?.trim().length ?? 0;
      const el = node.parentElement;
      if (!text || !el || !behind || isCovered(el)) continue;
      const cs = view.getComputedStyle(el);
      // SVG text is painted with `fill`, not `color`
      const color = rgba(el instanceof view.SVGElement ? cs.fill : cs.color);
      // no color of its own (a gradient fill, clipped background text): nothing to judge
      if (!color || color[3] === 0 || !el.getClientRects().length) continue;
      total += text;
      if (contrast(color, behind) < 2.5) faint += text;
    }
    const want = total && faint / total > 0.3 ? (luminance(behind!) < 0.4 ? "#ffffff" : "#16161a") : "transparent";
    if (want !== fill) frame.style.background = fill = want;
  };
  const laterBackdrop = () => {
    if (backdropTimer) clearTimeout(backdropTimer);
    backdropTimer = setTimeout(backdrop, 250);
  };

  const fit = () => {
    const doc = frame.contentDocument;
    if (!doc?.body || disposed) return;
    const h = contentHeight(doc);
    const max = options.maxHeight ?? 1600;
    frame.style.height = `${Math.min(max, Math.max(60, h + 2))}px`;
    laterBackdrop();
  };

  frame.addEventListener(
    "load",
    () => {
      if (disposed) return;
      const doc = frame.contentDocument!;
      resize = new ResizeObserver(fit);
      resize.observe(doc.body);
      fit();
      fonts = watchFonts(doc, page.html);
      heights = watchScreenHeights(doc);
      if (!options.run || !page.hasBehavior) {
        resolveReady();
        return;
      }
      void runScripts(frame, page, options, timers)
        .catch((e) => options.onError?.(e instanceof Error ? e.message : String(e)))
        .finally(() => {
          fit();
          resolveReady();
        });
    },
    { once: true },
  );
  // a load after the first: the frame was moved
  let loads = 0;
  frame.addEventListener("load", () => {
    if (++loads > 1 && !disposed) options.onReload?.();
  });
  frame.srcdoc = container.isConnected ? withBase(page.html, baseCss(container)) : page.html;
  container.append(frame);

  return {
    frame,
    ready,
    restyle: () => {
      const doc = frame.contentDocument;
      const style = doc?.getElementById(BASE_ID);
      if (style && container.isConnected) style.textContent = baseCss(container);
      backdrop();
    },
    background: () => (fill !== "transparent" ? fill : backdropColor(container)),
    dispose: () => {
      fonts?.();
      heights?.();
      if (backdropTimer) clearTimeout(backdropTimer);
      disposed = true;
      resize?.disconnect();
      const win = frame.contentWindow;
      for (const id of timers) clearTracked(win, id);
      frame.remove();
    },
  };
}

/** Events `<body on…>` hands to the window (the HTML standard's list). */
const WINDOW_EVENTS = new Set([
  "afterprint", "beforeprint", "beforeunload", "blur", "error", "focus", "hashchange", "languagechange", "load", "message",
  "messageerror", "offline", "online", "pagehide", "pageshow", "popstate", "rejectionhandled", "resize", "scroll", "storage",
  "unhandledrejection", "unload",
]);

/** Errors thrown in the page's event listeners (and onclick-style properties) show in its error box too. */
function catchListenerErrors(real: Window & typeof globalThis, report: (e: unknown) => void): void {
  const guarded = new WeakMap<object, (...a: unknown[]) => unknown>();
  const originals = new WeakMap<object, unknown>();
  const guard = (fn: (...a: unknown[]) => unknown) => {
    let g = guarded.get(fn);
    if (!g) {
      g = function (this: unknown, ...a: unknown[]) {
        try {
          const result = fn.apply(this, a);
          // an async listener fails later
          if (result && typeof (result as Promise<unknown>).then === "function") (result as Promise<unknown>).then(undefined, report);
          return result;
        } catch (err) {
          report(err);
        }
      };
      guarded.set(fn, g);
      originals.set(g, fn);
    }
    return g;
  };
  const proto = real.EventTarget.prototype;
  const add = proto.addEventListener;
  const remove = proto.removeEventListener;
  const wrap = (listener: EventListenerOrEventListenerObject | null) =>
    typeof listener === "function" ? (guard(listener as (...a: unknown[]) => unknown) as EventListener) : listener;
  proto.addEventListener = function (type: string, listener: EventListenerOrEventListenerObject | null, opts?: boolean | AddEventListenerOptions) {
    add.call(this, type, wrap(listener), opts);
  };
  proto.removeEventListener = function (type: string, listener: EventListenerOrEventListenerObject | null, opts?: boolean | EventListenerOptions) {
    remove.call(this, type, (listener && guarded.get(listener)) ?? listener, opts);
  };
  // el.onclick = …, document.onkeydown = …
  for (const target of [real.HTMLElement.prototype, real.SVGElement.prototype, real.Document.prototype, real]) {
    for (const name of Object.getOwnPropertyNames(target)) {
      if (!name.startsWith("on")) continue;
      const d = Object.getOwnPropertyDescriptor(target, name);
      if (!d?.set || !d.get || !d.configurable) continue;
      const { get, set } = d;
      Object.defineProperty(target, name, {
        ...d,
        get(this: unknown) {
          const fn = get.call(this);
          return (fn && originals.get(fn)) ?? fn;
        },
        set(this: unknown, fn: unknown) {
          set.call(this, typeof fn === "function" ? guard(fn as (...a: unknown[]) => unknown) : fn);
        },
      });
    }
  }
}

async function runScripts(frame: HTMLIFrameElement, page: PreparedPage, options: RunOptions, timers: Set<number>): Promise<void> {
  const real = frame.contentWindow as Window & typeof globalThis;
  const doc = frame.contentDocument!;
  const report = (e: unknown) => {
    // the console keeps the whole error (where it happened), for whoever writes the page
    console.warn("[Fornello] page error:", e);
    options.onError?.(e instanceof Error ? e.message : String(e));
  };

  // sources in order; outside scripts are fetched
  const codes: { code: string; at: number; module: boolean }[] = [];
  for (const [at, s] of page.scripts.entries()) {
    let code = s.code;
    if (code === undefined && s.src) {
      try {
        const url = new URL(s.src, "https://invalid.example/");
        if (url.protocol !== "https:") throw new Error("only https scripts are loaded");
        const res = await fetch(url.href, { credentials: "omit", referrerPolicy: "no-referrer" });
        if (!res.ok) throw new Error(`HTTP ${res.status}`);
        code = await res.text();
      } catch (e) {
        report(t(`Could not load an external script (${s.src}): ${e instanceof Error ? e.message : e}`, `외부 스크립트를 불러오지 못했어요 (${s.src}): ${e instanceof Error ? e.message : e}`));
      }
    }
    if (code === undefined) continue;
    if (s.jsx) {
      try {
        code = compileJsx(code, s.jsx);
      } catch (e) {
        report(t(`Could not convert the JSX: ${e instanceof Error ? e.message : e}`, `JSX를 바꾸지 못했어요: ${e instanceof Error ? e.message : e}`));
        continue;
      }
    }
    codes.push({ code, at, module: !!s.module });
  }

  const declared = new Set<string>();
  // React from a CDN: Marinara's own, at full speed (the interpreter cannot run React's builds)
  let react = {};
  if (page.react) {
    try {
      react = pageReact();
    } catch (e) {
      report(e);
    }
  }
  let define: (name: string, value: unknown) => void = () => {};
  const scope = sandboxScope(real, doc, { ...react, ...options.globals }, timers, {
    declared,
    report,
    onScope: (d) => {
      define = d;
      options.onScope?.(d);
    },
  });
  catchListenerErrors(real, report);
  // document.write after the page was parsed would wipe it: what it writes goes at the end instead
  doc.write = (...html: string[]) => doc.body.insertAdjacentHTML("beforeend", html.join(""));
  doc.writeln = (...html: string[]) => doc.body.insertAdjacentHTML("beforeend", `${html.join("")}\n`);

  // the script running now, as the browser tells it (none for module scripts)
  let current: Element | null = null;
  try {
    Object.defineProperty(doc, "currentScript", { configurable: true, get: () => current });
  } catch {
    // the frame's document would not take it: currentScript stays null
  }

  const interp = new Sval({ ecmaVer: "latest", sandBox: true });
  const modules = new ModuleSystem((source) => {
    settle();
    interp.run(`with (__fornelloScope) {\n${source}\n}`);
  }, report);
  interp.import({ __fornelloScope: scope, [TICK]: tick, __fornelloReport: report, __fornelloDefine: modules.define });
  // the libraries SillyTavern card pages expect, when the page uses them and does not bring its own
  await modules.builtins(codes.map((c) => c.code).join("\n"), page.scripts.map((s) => s.src ?? ""), define, report);
  const handlerSrc = page.handlers
    .map((h) => {
      try {
        return guardLoops(`(function (event) {\n${h.body}\n})`);
      } catch (e) {
        report(`on${h.type}: ${e instanceof Error ? e.message : e}`);
        return "null";
      }
    })
    .join(",\n");
  // handlers first, so a failing script leaves them in place
  try {
    interp.run(`with (__fornelloScope) {\nexports.__handlers = [${handlerSrc}];\n}`);
  } catch (e) {
    report(e);
  }
  // each script on its own, as in a browser, with shared top-level names; module
  // scripts after the others (as deferred ones), each in its own scope
  for (const { code, at, module } of [...codes.filter((c) => !c.module), ...codes.filter((c) => c.module)]) {
    try {
      if (module && isModuleCode(code)) {
        // what it imports is fetched first, then it runs in its own scope
        await modules.runModule(code);
        continue;
      }
      const ready = prepareScript(module ? `(async () => {\n${code}\n})().catch(__fornelloReport);` : code);
      for (const name of ready.names) declared.add(name);
      settle();
      current = module ? null : doc.querySelector(`script[${SCRIPT_ATTR}="${at}"]`);
      interp.run(`with (__fornelloScope) {\n${ready.code}\n}`);
    } catch (e) {
      report(e);
    } finally {
      current = null;
    }
  }
  const compiled = (interp.exports.__handlers ?? []) as ((this: Element, e: Event) => unknown)[];
  const marked = [...doc.querySelectorAll(`[${HANDLER_ATTR}]`)];
  page.handlers.forEach((h, i) => {
    const el = marked.find((m) => m.getAttribute(HANDLER_ATTR) === String(h.element));
    const fn = compiled[i];
    if (!el || !fn) return;
    // <body onload>, onresize… are the window's events, as in a browser
    const target = (el.localName === "body" || el.localName === "frameset") && WINDOW_EVENTS.has(h.type) ? real : el;
    target.addEventListener(h.type, (e) => {
      try {
        const result = fn.call(target as Element, e);
        if (result === false) e.preventDefault();
      } catch (err) {
        report(err);
      }
    });
  });
  // the page is already parsed: replay the load events its scripts wait for
  doc.dispatchEvent(new real.Event("DOMContentLoaded", { bubbles: true }));
  real.dispatchEvent(new real.Event("load"));
}
