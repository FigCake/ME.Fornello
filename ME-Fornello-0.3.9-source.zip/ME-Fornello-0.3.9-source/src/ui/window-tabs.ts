// Fornello's one window: four tabs (components, scripts, character assets, Status), each its own
// view. A tab press swaps the view in place, at the same size, so they read as one window.

import { LANG_NAMES, type LangChoice, langChoice, setLangChoice, t } from "../shared/i18n";
import { el } from "./dom";
import { ICON_BOOK, ICON_GEAR, ICON_IMAGES, ICON_PUZZLE, ICON_SCROLL } from "./icons";

export type FornelloTab = "components" | "scripts" | "assets" | "status";

/** Shows a tab (the window it was on goes); `gear` opens the ⚙ settings with it. */
export type GoToTab = (tab: FornelloTab, options?: { gear?: boolean }) => void;

/** The same size for every tab, and the tab bar in the header. */
export const TABS_CSS = `
.win.tabbed { width: min(1040px, 100%) !important; height: min(860px, 100%); max-height: none; }
header .tabs { display: flex; gap: 2px; padding: 2px; border: 1px solid var(--d-line); border-radius: 999px; background: var(--d-field); flex: none; }
header .tabs button { border: none; background: none; border-radius: 999px; padding: 4px 14px; display: inline-flex; align-items: center; color: var(--d-muted); }
header .tabs button[aria-current="page"] { color: var(--d-accent, var(--d-text)); background: var(--d-hl-bg); box-shadow: inset 0 0 0 1px var(--d-btn-border-active); }
header .tabs svg { width: 16px; height: 16px; }
header select.lang { width: auto; flex: none; padding: 4px 6px; font-size: 12px; }
header button.gear { display: inline-flex; align-items: center; padding: 5px 7px; }
header button.gear[aria-pressed="true"] { background: var(--d-hl-bg); box-shadow: inset 0 0 0 1px var(--d-btn-border-active); }
@media (max-width: 600px) { header { flex-wrap: wrap; } header .tabs { order: 5; width: 100%; } header .tabs button { flex: 1; justify-content: center; } header select.lang { width: 4.4em; } }
`;

const TABS: { tab: FornelloTab; icon: string; name: () => string }[] = [
  { tab: "components", icon: ICON_PUZZLE, name: () => t("Components", "컴포넌트") },
  { tab: "scripts", icon: ICON_SCROLL, name: () => t("Scripts", "스크립트") },
  { tab: "assets", icon: ICON_IMAGES, name: () => t("Character assets", "캐릭터 에셋") },
  { tab: "status", icon: ICON_BOOK, name: () => t("Status", "상태창") },
];

/** "🔥 Fornello", the tab bar, the language and ⚙ (the Fornello settings: pages and component display), for a window's header. */
export function tabHeader(active: FornelloTab, go: GoToTab, gear: { open: boolean; toggle?: () => void } = { open: false }): HTMLElement[] {
  const bar = el("nav", { className: "tabs", "aria-label": t("Fornello tabs", "Fornello 탭") });
  for (const { tab, icon, name } of TABS) {
    const b = el("button", { type: "button", title: name(), "aria-label": name(), "aria-current": tab === active ? "page" : undefined, onclick: () => tab !== active && go(tab) });
    b.innerHTML = icon;
    bar.append(b);
  }
  const lang = el(
    "select",
    { className: "lang", title: t("Language", "언어"), "aria-label": t("Language", "언어"), "data-key": "lang", onchange: (e: Event) => setLangChoice((e.target as HTMLSelectElement).value as LangChoice) },
    ...(["auto", "en", "ko"] as LangChoice[]).map((c) => el("option", { value: c, selected: c === langChoice() }, `🌐 ${LANG_NAMES[c]()}`)),
  );
  const cog = el("button", { type: "button", className: "gear", title: t("Fornello settings", "Fornello 설정"), "aria-label": t("Fornello settings", "Fornello 설정"), "aria-pressed": String(gear.open), onclick: () => (gear.toggle ? gear.toggle() : go("components", { gear: true })) });
  cog.innerHTML = ICON_GEAR;
  return [el("h2", { style: "flex:none" }, "🔥 Fornello"), bar, el("span", { style: "flex:1" }), lang, cog];
}
