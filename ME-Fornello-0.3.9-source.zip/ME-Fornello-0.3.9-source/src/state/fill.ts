// Filling in a forgotten block: when a reply has no change block, a model the person picks (a
// cheap one is enough) reads the reply with the values it started from and writes the block the
// reply should have ended with. What it writes is kept on the reply's swipe (not in its text), and
// counted as if the reply had written it. The text for that model is English, like the rest the AI reads.

import { howToText, shownValues } from "./prompt";
import { readUpdates } from "./update";
import type { Definition } from "./engine";

type Obj = Record<string, unknown>;

/** Whether a reply already reports its changes (a pesto block, or one of the tags read with it). */
export function hasBlock(text: string): boolean {
  return readUpdates(text).spans.length > 0;
}

/** The reply's text as the engine reads it: with the filled-in block after it, when the reply had none. */
export function withFilled(text: string, filled: unknown): string {
  if (typeof filled !== "string" || !filled.trim() || hasBlock(text)) return text;
  return `${text}\n\n\`\`\`pesto\n${filled.trim()}\n\`\`\``;
}

/** Whether the card lets the AI change anything (else there is nothing to fill in). */
export const fillable = (def: Definition) => howToText(def) !== "";

/** What the helper model is sent: how blocks are written, the values before the reply, and the reply. */
export function fillMessages(def: Definition, before: Obj, reply: string): { role: "system" | "user"; content: string }[] {
  const values = shownValues(def, before).map(([path, text]) => `${path}: ${text}`);
  return [
    {
      role: "system",
      content: [
        "You read one reply of an ongoing roleplay. Its writer was asked to end it with a block of the story's changes and forgot. Write that block for them.",
        "Report only what the reply itself makes happen; when nothing changed, answer with the single word none.",
        "",
        howToText(def),
        "",
        "[Values before this reply]",
        ...(values.length ? values : ["(none shown)"]),
        "",
        "Answer with the block alone (```pesto … ```), or none. No other words.",
      ].join("\n"),
    },
    { role: "user", content: reply.trim() || "(empty reply)" },
  ];
}

/** The block's lines from the helper's answer ("" when it found no change). */
export function readFill(answer: string): string {
  const text = answer.trim();
  const fenced = /```[ \t]*(?:pesto(?![\w-]))?[^\n]*\n([\s\S]*?)(?:```|$(?![\s\S]))/i.exec(text);
  const body = (fenced ? fenced[1] : text).trim();
  if (!body || /^none\.?$/i.test(body)) return "";
  return body;
}
