// HTML templates: plain HTML with {{value}} places, drawn without running any
// code. Values go in as escaped text (a line break as <br>), never as markup.
//
//   {{name}}                the value; {{stats.hp}} a value inside one
//   {{#cast}}…{{/cast}}     once per item of a list (inside, {{name}} is the
//                           item's own, {{.}} the item itself); once for any
//                           other value that is set; not at all when empty
//   {{^cast}}…{{/cast}}     only when the value is empty (no list, no text)
//
// Scripts and on… attributes are left out (<details> and labelled radio buttons still work).

import type { MountedComponent } from "./runtime";

type Node =
  | { kind: "text"; text: string }
  | { kind: "value"; path: string }
  | { kind: "section"; path: string; inverted: boolean; body: Node[] };

const TAG = /\{\{\s*([#^/]?)\s*([^{}]*?)\s*\}\}/g;

/** The template as text, value places and sections (a section left open runs to the end). */
function parse(template: string): Node[] {
  const root: Node[] = [];
  const stack: { path: string; body: Node[] }[] = [];
  let into = root;
  let at = 0;
  for (const m of template.matchAll(TAG)) {
    if (m.index > at) into.push({ kind: "text", text: template.slice(at, m.index) });
    at = m.index + m[0].length;
    const [, sign, path] = m;
    if (!path) continue;
    if (sign === "#" || sign === "^") {
      const section: Node = { kind: "section", path, inverted: sign === "^", body: [] };
      into.push(section);
      stack.push({ path, body: into });
      into = section.body;
    } else if (sign === "/") {
      // the matching opening one (a stray closing tag is dropped)
      const i = stack.map((s) => s.path).lastIndexOf(path);
      if (i < 0) continue;
      into = stack[i].body;
      stack.length = i;
    } else into.push({ kind: "value", path });
  }
  if (at < template.length) into.push({ kind: "text", text: template.slice(at) });
  return root;
}

const ENTITIES: Record<string, string> = { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" };

/** Text made safe to put in HTML. */
const escapeHtml = (text: string): string => text.replace(/[&<>"']/g, (c) => ENTITIES[c]);

/** A value as text: lists joined with commas, objects as JSON. */
function asText(v: unknown): string {
  if (v === undefined || v === null || v === false) return "";
  if (typeof v === "string") return v;
  if (Array.isArray(v)) return v.map(asText).join(", ");
  if (typeof v === "object") return JSON.stringify(v);
  return String(v);
}

/** Looks a path up in the nearest context that has its first part. */
function lookup(path: string, contexts: unknown[]): unknown {
  if (path === ".") return contexts[contexts.length - 1];
  const [first, ...rest] = path.split(".");
  for (let i = contexts.length - 1; i >= 0; i--) {
    const c = contexts[i];
    // own keys only: {{constructor}} is not Object's
    if (c && typeof c === "object" && Object.hasOwn(c, first)) {
      let v: unknown = (c as Record<string, unknown>)[first];
      for (const part of rest) v = v && typeof v === "object" && Object.hasOwn(v, part) ? (v as Record<string, unknown>)[part] : undefined;
      return v;
    }
  }
  return undefined;
}

const empty = (v: unknown) => v === undefined || v === null || v === false || v === "" || (Array.isArray(v) && !v.length);

function draw(nodes: Node[], contexts: unknown[]): string {
  let out = "";
  for (const n of nodes) {
    if (n.kind === "text") out += n.text;
    else if (n.kind === "value") out += escapeHtml(asText(lookup(n.path, contexts))).replace(/\r?\n/g, "<br>");
    else {
      const v = lookup(n.path, contexts);
      if (n.inverted) {
        if (empty(v)) out += draw(n.body, contexts);
      } else if (Array.isArray(v)) for (const item of v) out += draw(n.body, [...contexts, item]);
      else if (!empty(v)) out += draw(n.body, typeof v === "object" ? [...contexts, v] : contexts);
    }
  }
  return out;
}

/** The template filled with the values, as HTML. */
export function fillTemplate(template: string, values: Record<string, unknown>): string {
  return draw(parse(template), [values]);
}

/**
 * The values a template asks for at its top level, in order of first use
 * (inside a list's section they are its items'); `lists`: names used as a
 * section. With `within`, the items' values inside that section instead.
 */
export function templateKeys(template: string, within?: string): { keys: string[]; lists: Set<string> } {
  const keys: string[] = [];
  const lists = new Set<string>();
  const add = (path: string) => {
    const first = path.split(".")[0];
    if (first && first !== "." && first !== "text" && !/^\d/.test(first) && !keys.includes(first)) keys.push(first);
  };
  const inside = (nodes: Node[]) => {
    for (const n of nodes) {
      if (n.kind === "value") add(n.path);
      else if (n.kind === "section") inside(n.body);
    }
  };
  for (const n of parse(template)) {
    if (within !== undefined) {
      if (n.kind === "section" && !n.inverted && n.path === within) inside(n.body);
      continue;
    }
    if (n.kind === "value") add(n.path);
    else if (n.kind === "section") {
      add(n.path);
      if (!n.inverted) lists.add(n.path.split(".")[0]);
    }
  }
  return { keys, lists };
}

/** The template with a top-level value renamed (items' values inside a list stay); with `within`, an item value of that list. */
export function renameTemplateKey(template: string, from: string, to: string, within?: string): string {
  // the sections open at each place, to know whose value a name is (a section's own name belongs where it opens)
  const open: { path: string; inverted: boolean }[] = [];
  const ours = () => {
    const lists = open.filter((s) => !s.inverted).map((s) => s.path);
    // inside the list, an item's marks ({{#E}}) hold its own values too
    return within === undefined ? !lists.length : lists[0] === within;
  };
  return template.replace(TAG, (whole, sign: string, path: string) => {
    const [first, ...rest] = path.split(".");
    if (sign === "/") {
      const i = open.map((s) => s.path).lastIndexOf(path);
      if (i >= 0) open.length = i;
    }
    const out = first === from && ours() ? `{{${sign}${[to, ...rest].join(".")}}}` : whole;
    if (sign === "#" || sign === "^") open.push({ path, inverted: sign === "^" });
    return out;
  });
}

/** The text without control characters and spaces (as a browser reads a link's scheme). */
const squeeze = (v: string) => [...v].filter((c) => c.charCodeAt(0) > 32 && c.charCodeAt(0) !== 127).join("");

/** What is drawn: no scripts, no on… attributes, no javascript: links. */
function cleanHtml(root: ParentNode): void {
  for (const s of root.querySelectorAll("script, iframe, object, embed, base, meta")) s.remove();
  for (const el of root.querySelectorAll("*")) {
    for (const a of [...el.attributes]) {
      // a browser reads "java\tscript:" as "javascript:": tabs, line breaks and spaces are left out before looking
      if (/^on/i.test(a.name) || (/^(href|src|action|formaction|xlink:href)$/i.test(a.name) && /^javascript:/i.test(squeeze(a.value)))) el.removeAttribute(a.name);
    }
  }
}

/** Draws a template into `target` (in a shadow root); new values redraw it, keeping open <details> and ticked boxes. */
export function mountTemplate(target: HTMLElement, template: string, values: Record<string, unknown>): MountedComponent {
  const paint = (v: Record<string, unknown>) => {
    const details = [...target.querySelectorAll("details")].map((d) => d.open);
    const inputs = [...target.querySelectorAll<HTMLInputElement>("input[type=radio], input[type=checkbox]")].map((i) => i.checked);
    const box = document.createElement("template");
    box.innerHTML = fillTemplate(template, v);
    cleanHtml(box.content);
    target.replaceChildren(box.content);
    if (details.length) target.querySelectorAll("details").forEach((d, i) => i < details.length && (d.open = details[i]));
    if (inputs.length) target.querySelectorAll<HTMLInputElement>("input[type=radio], input[type=checkbox]").forEach((el, i) => i < inputs.length && (el.checked = inputs[i]));
  };
  paint(values);
  return { update: paint, unmount: () => target.replaceChildren() };
}
