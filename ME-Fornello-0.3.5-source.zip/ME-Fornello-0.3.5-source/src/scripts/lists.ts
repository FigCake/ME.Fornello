// The three script lists the library window edits: the person's own
// (settings), a character's (its card) and a chat's (the chat). A list the
// person changes there is allowed as it now is.

import { characterData, saveCharacter } from "../api/library";
import { readChatData, updateChatData } from "../api/chat-data";
import type { Settings } from "../settings";
import { chatTrustKey } from "./host";
import { type LibraryItem, cardTree, libraryHash, scriptsOf, withCardTree } from "./model";

export type ListPlace = { kind: "global" } | { kind: "card"; characterId: string; characterName: string } | { kind: "chat"; chatId: string };

/** The same place (to find a list's spot in the window). */
export const placeKey = (p: ListPlace): string => (p.kind === "global" ? "global" : p.kind === "card" ? `card:${p.characterId}` : `chat:${p.chatId}`);

export async function readList(settings: Settings, place: ListPlace): Promise<LibraryItem[]> {
  if (place.kind === "global") return structuredClone(settings.current.scripts);
  if (place.kind === "card") return cardTree(await characterData(place.characterId));
  return (await readChatData(place.chatId)).scripts;
}

export async function writeList(settings: Settings, place: ListPlace, items: LibraryItem[]): Promise<void> {
  if (place.kind === "global") {
    await settings.set({ scripts: items });
    return;
  }
  let key: string;
  let hash: string;
  if (place.kind === "card") {
    const data = withCardTree(await characterData(place.characterId), items);
    await saveCharacter(place.characterId, data);
    key = place.characterId;
    hash = scriptsOf({ id: place.characterId, name: place.characterName, data })?.hash ?? "";
  } else {
    await updateChatData(place.chatId, (d) => ({ ...d, scripts: items }));
    key = chatTrustKey(place.chatId);
    hash = items.length ? libraryHash(items) : "";
  }
  // the person wrote it: allowed as it is now
  const trustedScripts = { ...settings.current.trustedScripts };
  if (hash) trustedScripts[key] = hash;
  else delete trustedScripts[key];
  await settings.set({ trustedScripts });
}
