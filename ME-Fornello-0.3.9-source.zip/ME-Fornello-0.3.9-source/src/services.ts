// The parts of Fornello that listen to the window or keep something between
// pages: started once by main.ts. Nothing listens at import time; the stop
// this returns removes every listener and clears every cache and flag.

import { clearChatData } from "./api/chat-data";
import { startChatStore } from "./api/chat-store";
import { chatWatch } from "./api/chat-watch";
import { resetSending } from "./api/commands/messages";
import { startPageStorage } from "./api/page-storage";
import { clearQuietEdits } from "./api/quiet-edits";
import { startSharedVars } from "./api/shared-vars";
import { clearEvents } from "./api/event-bus";
import { stopExtraVars } from "./api/extra-vars";
import { clearSharedGlobals } from "./api/shared-globals";
import { startGenerationHold } from "./host/generation-hold";
import { startInjections } from "./api/injections";
import { forgetRegexScripts } from "./regex";
import { forgetLibrary } from "./api/library";
import { forgetModules } from "./runtime/modules";
import { forgetStylesheets } from "./runtime/stylesheets";
import { forgetColors } from "./ui/color";
import { forgetRuleHashes } from "./assets/rule-sync";
import { forgetPageAssets } from "./assets/page-assets";
import { forgetPictureRegex } from "./assets/picture-regex";

export function startServices(): () => void {
  const stops = [startChatStore(), startSharedVars(), startPageStorage(), startGenerationHold(), startInjections()];
  return () => {
    // newest first: the pages' last storage writes go out, then the modules stop listening and forget
    for (const stop of stops.reverse()) stop();
    clearChatData();
    clearEvents();
    clearSharedGlobals();
    stopExtraVars();
    chatWatch.reset();
    clearQuietEdits();
    resetSending();
    forgetRegexScripts();
    forgetLibrary();
    forgetStylesheets();
    forgetModules();
    forgetColors();
    forgetRuleHashes();
    forgetPageAssets();
    forgetPictureRegex();
  };
}
