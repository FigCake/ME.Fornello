// The scope a page's (or component's) scripts run in: the window's names with
// storage, network, dialogs and timers swapped for guarded ones, plus the page
// commands.

import { PageStorage } from "../api/page-storage";

/**
 * The language's own globals, taken from the interpreter; every other name
 * comes from the page's frame. A fixed list, because the interpreter's sandbox
 * copies every name of Marinara's window.
 */
const LANGUAGE_GLOBALS = new Set([
  "Object", "Function", "Array", "Number", "parseFloat", "parseInt", "Infinity", "NaN", "undefined", "Boolean", "String", "Symbol",
  "Date", "Promise", "RegExp", "Error", "AggregateError", "EvalError", "RangeError", "ReferenceError", "SyntaxError", "TypeError", "URIError",
  "JSON", "Math", "Intl", "ArrayBuffer", "SharedArrayBuffer", "Atomics", "DataView", "Uint8Array", "Int8Array", "Uint8ClampedArray",
  "Uint16Array", "Int16Array", "Uint32Array", "Int32Array", "Float32Array", "Float64Array", "BigInt64Array", "BigUint64Array", "BigInt",
  "Map", "Set", "WeakMap", "WeakSet", "WeakRef", "FinalizationRegistry", "Proxy", "Reflect", "Iterator",
  "decodeURI", "decodeURIComponent", "encodeURI", "encodeURIComponent", "escape", "unescape", "eval", "isFinite", "isNaN",
]);

/** Clears a timer or (negative id) an animation frame that sandboxScope tracked. */
export function clearTracked(win: Window | null | undefined, id: number): void {
  if (!win) return;
  if (id < 0) win.cancelAnimationFrame(-id);
  else {
    win.clearTimeout(id);
    win.clearInterval(id);
  }
}

export interface ScopeOptions {
  /** Names the page's scripts declared at top level: theirs win over the window's own. */
  declared?: Set<string>;
  /** Where errors from the page's timers go (they are not the first run's). */
  report?: (e: unknown) => void;
  /** Gets the way to add a name the scripts see later (waitGlobalInitialized makes the shared name a global). */
  onScope?: (define: (name: string, value: unknown) => void) => void;
}

/**
 * The names a page's scripts see: the window's (frame or Marinara's), with
 * storage, network and dialogs replaced, `parent`/`top` pointing back at the
 * page, plus `globals` (the page commands). Used with `with (scope) { … }`.
 */
export function sandboxScope(real: Window & typeof globalThis, doc: Document, globals: Record<string, unknown>, timers: Set<number>, options: ScopeOptions = {}): object {
  const declared = options.declared ?? new Set<string>();
  const report = options.report ?? ((e: unknown) => console.error("[Fornello]", e));
  /** A callback the browser calls later: its error goes to the page's error box. */
  const caught =
    <A extends unknown[]>(fn: (...a: A) => unknown) =>
    (...a: A) => {
      try {
        fn(...a);
      } catch (e) {
        report(e);
      }
    };
  // bound once: a new function per access would make every call slower
  const bound = new WeakMap<object, unknown>();
  // pages get their chat's storages through `globals`; these last only as long as the page
  const memoryLocal = new PageStorage(new Map());
  const memorySession = new PageStorage(new Map());
  const guardedFetch = (input: RequestInfo | URL, init?: RequestInit) => {
    const href = typeof input === "string" ? input : input instanceof URL ? input.href : input.url;
    const url = new URL(href, location.href);
    if (url.origin === location.origin) return Promise.reject(new TypeError("Fornello pages cannot call Marinara directly; use the page commands (genChat, getVars, …) instead."));
    return real.fetch(url.href, { ...init, credentials: "omit" });
  };
  // timers the page starts are cleared with it; animation frames are kept as negative ids
  const later = (fn: (handler: TimerHandler, ms?: number, ...rest: unknown[]) => number, once: boolean) => (handler: TimerHandler, ms?: number, ...rest: unknown[]): number => {
    if (typeof handler !== "function") return 0; // string code: never evaluated
    let id = 0;
    const call = caught(handler as (...x: unknown[]) => void);
    const run = once
      ? (...a: unknown[]) => {
          timers.delete(id);
          call(...a);
        }
      : call;
    id = fn(run as TimerHandler, ms, ...rest);
    timers.add(id);
    return id;
  };
  const clear = (fn: (id?: number) => void) => (id?: number) => {
    if (id !== undefined) timers.delete(id);
    fn(id);
  };
  const frameLater = (cb: FrameRequestCallback): number => {
    let id = 0;
    const call = caught(cb);
    id = real.requestAnimationFrame((t) => {
      timers.delete(-id);
      call(t);
    });
    timers.add(-id);
    return id;
  };
  const overrides: Record<string | symbol, unknown> = {
    // the screen's height, not the frame's (which follows the page): see screenHeights
    get innerHeight() {
      return window.innerHeight;
    },
    set innerHeight(_: unknown) {},
    alert: (m?: unknown) => window.alert(String(m ?? "")),
    confirm: (m?: unknown) => window.confirm(String(m ?? "")),
    prompt: (m?: unknown, d?: unknown) => window.prompt(String(m ?? ""), d === undefined ? undefined : String(d)),
    localStorage: memoryLocal,
    sessionStorage: memorySession,
    indexedDB: undefined,
    fetch: guardedFetch,
    XMLHttpRequest: undefined,
    WebSocket: undefined,
    setTimeout: later(real.setTimeout.bind(real) as never, true),
    setInterval: later(real.setInterval.bind(real) as never, false),
    clearTimeout: clear(real.clearTimeout.bind(real)),
    clearInterval: clear(real.clearInterval.bind(real)),
    requestAnimationFrame: frameLater,
    cancelAnimationFrame: (id: number) => {
      timers.delete(-id);
      real.cancelAnimationFrame(id);
    },
    ...globals,
  };
  const winProxy: Window = new Proxy(real, {
    get(target, prop) {
      if (prop in overrides) return overrides[prop];
      if (prop === "parent" || prop === "top" || prop === "window" || prop === "self" || prop === "globalThis" || prop === "frames") return winProxy;
      if (prop === "opener" || prop === "frameElement") return null;
      // `window.Object === Object` must hold: lodash finds the global object that way
      if (typeof prop === "string" && LANGUAGE_GLOBALS.has(prop) && prop in globalThis) return (globalThis as Record<string, unknown>)[prop];
      const value = Reflect.get(target, prop, target);
      // Window methods need the real window as `this`; constructors must stay unbound
      if (typeof value === "function" && typeof prop === "string" && /^[a-z]/.test(prop)) {
        let fn = bound.get(value);
        if (!fn) bound.set(value, (fn = value.bind(target)));
        return fn;
      }
      return value;
    },
    set(target, prop, value) {
      if (prop in overrides) {
        overrides[prop] = value;
        return true;
      }
      return Reflect.set(target, prop, value, target);
    },
    has(target, prop) {
      return prop in overrides || prop in target;
    },
  });
  options.onScope?.((name, value) => {
    overrides[name] = value;
  });
  overrides.window = winProxy;
  overrides.self = winProxy;
  overrides.globalThis = winProxy;
  overrides.parent = winProxy;
  overrides.top = winProxy;
  overrides.document = doc;

  // `with (scope)`: bare names resolve on the frame's window, except the language's builtins
  const scope = new Proxy(Object.create(null) as object, {
    has(_t, prop) {
      if (typeof prop !== "string") return false;
      if (declared.has(prop)) return false;
      if (prop in overrides) return true;
      return prop in real && !LANGUAGE_GLOBALS.has(prop);
    },
    get(_t, prop) {
      if (prop === Symbol.unscopables) return undefined;
      return (winProxy as unknown as Record<string | symbol, unknown>)[prop];
    },
    set(_t, prop, value) {
      (winProxy as unknown as Record<string | symbol, unknown>)[prop] = value;
      return true;
    },
  });

  return scope;
}
