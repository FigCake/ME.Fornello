// share / getShared, catchErrors, reload, getVersion.

import { version } from "../../../package.json";
import { t } from "../../shared/i18n";
import { cmd } from "../command";
import type { PageSession } from "../session";
import { shareGlobal, waitForGlobal } from "../shared-globals";

const FORNELLO_VERSION: string = version;

/** `fn`, with its errors (thrown or a rejected promise) shown as the page's notes instead of lost. */
export function catchErrors(s: PageSession, fn: unknown): (...a: unknown[]) => unknown {
  if (typeof fn !== "function") throw new TypeError(t("catchErrors needs a function.", "catchErrors에는 함수가 필요해요."));
  return (...a: unknown[]) => {
    try {
      const result = (fn as (...x: unknown[]) => unknown)(...a);
      if (result instanceof Promise) return result.catch((e) => s.report(e));
      return result;
    } catch (e) {
      s.report(e);
      return undefined;
    }
  };
}

export function reloadPage(s: PageSession): void {
  if (!s.reload) throw new Error(t("Not available here: reload", "여기서는 안 됨: reload"));
  // after the current call returns: the page goes away with it
  setTimeout(() => s.reload?.(), 0);
}

/** The shared value, also made a name the page's scripts can use (as JS-Slash-Runner's waitGlobalInitialized does). */
export async function getShared(s: PageSession, name: unknown): Promise<unknown> {
  const value = await waitForGlobal(String(name));
  if (!s.disposed) s.define(String(name), value);
  return value;
}

export function toolCommands(s: PageSession) {
  return {
    share: cmd((name: unknown, value: unknown) => shareGlobal(String(name), value)),
    getShared: cmd((name: unknown) => getShared(s, name)),
    catchErrors: cmd((fn: unknown) => catchErrors(s, fn)),
    reload: cmd(() => reloadPage(s)),
    getVersion: cmd(() => FORNELLO_VERSION),
  };
}
