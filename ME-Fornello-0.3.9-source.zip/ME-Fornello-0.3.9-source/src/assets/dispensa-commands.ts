// Character assets in Dispensa's scripts and QRs: /asset name → the picture's address, /assets → the
// open chat's pictures as JSON. Added when Dispensa is there (or starts later), taken out when Fornello stops.

import { DISPENSA_READY } from "../shared/dispensa-bridge";
import { chatAssetList, chatAssetUrl } from "./page-assets";

export function addAssetCommands(): () => void {
  let removers: (() => void)[] = [];
  const add = () => {
    for (const off of removers) off();
    removers = [];
    const register = window.__dispensa?.registerCommand;
    if (typeof register !== "function") return;
    removers = [
      register({
        name: "asset",
        help: "The address of a picture of the chat's characters (Fornello's character assets): /asset [person=…] name",
        from: "Fornello",
        run: ({ text, named }) => chatAssetUrl(text, named.person || undefined),
      }),
      register({
        name: "assets",
        help: "The chat's characters' pictures as JSON: [{character, name, url, person?}]",
        from: "Fornello",
        run: async () => JSON.stringify(await chatAssetList()),
      }),
    ];
  };
  add();
  window.addEventListener(DISPENSA_READY, add);
  return () => {
    window.removeEventListener(DISPENSA_READY, add);
    for (const off of removers) off();
    removers = [];
  };
}
