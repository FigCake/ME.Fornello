// Running a component: its code runs in the interpreter like a page's (JSX
// compiled first), and Marinara's React draws it at full speed.

import Sval from "sval";
import { type AnyReact, hostReact } from "../host/host-react";
import { TICK, guardLoops, tick } from "../runtime/guard";
import { compileJsx } from "../runtime/page";
import { clearTracked, sandboxScope } from "../runtime/scope";
import { cleanSource } from "./source";
import { t } from "../shared/i18n";

const HOOKS = [
  "useState",
  "useEffect",
  "useLayoutEffect",
  "useMemo",
  "useCallback",
  "useRef",
  "useReducer",
  "useContext",
  "useId",
  "useTransition",
  "useDeferredValue",
  "useImperativeHandle",
  "useSyncExternalStore",
];

export interface CompiledComponent {
  component: unknown;
  /** Timers the component started (cleared when it goes away). */
  timers: Set<number>;
}

/** The component function, ready to draw; `globals` are the page commands for its message. */
export function compileComponent(name: string, code: string, globals: Record<string, unknown>, onScope?: (define: (name: string, value: unknown) => void) => void): CompiledComponent {
  const { React, ReactDOM } = hostReact();
  const js = compileJsx(cleanSource(code), "tsx");
  const timers = new Set<number>();
  const extra: Record<string, unknown> = { React, ReactDOM, Fragment: React.Fragment, ...globals };
  for (const hook of HOOKS) if (React[hook]) extra[hook] = React[hook];
  const scope = sandboxScope(window as Window & typeof globalThis, document, extra, timers, { onScope });
  const interp = new Sval({ ecmaVer: "latest", sandBox: true });
  interp.import({ __fornelloScope: scope, [TICK]: tick });
  interp.run(`with (__fornelloScope) {\n${guardLoops(js)}\n;exports.__component = typeof ${name} !== "undefined" ? ${name} : null;\n}`);
  const component = interp.exports.__component;
  if (!component || (typeof component !== "function" && typeof component !== "object")) throw new Error(t(`No "${name}" component in the code.`, `"${name}" 컴포넌트를 코드에서 찾지 못했어요.`));
  return { component, timers };
}

let boundaryClass: AnyReact = null;

/** Catches a component's own errors so one broken component never takes the chat down. */
function errorBoundary(): AnyReact {
  if (boundaryClass) return boundaryClass;
  const { React } = hostReact();
  boundaryClass = class extends React.Component {
    state: { error: unknown } = { error: null };
    static getDerivedStateFromError(error: unknown) {
      return { error };
    }
    componentDidCatch(error: unknown) {
      this.props.onError?.(error);
    }
    render() {
      const error = this.state.error;
      if (!error) return this.props.children;
      return React.createElement("div", { className: "fc-error" }, t(`Component error: ${error instanceof Error ? error.message : String(error)}`, `컴포넌트 오류: ${error instanceof Error ? error.message : String(error)}`));
    }
  };
  return boundaryClass;
}

export interface MountedComponent {
  update(props: Record<string, unknown>): void;
  unmount(): void;
}

export function mountComponent(target: Element, compiled: CompiledComponent, props: Record<string, unknown>, onError: (e: unknown) => void): MountedComponent {
  const { React, ReactDOM } = hostReact();
  const root = ReactDOM.createRoot(target);
  const Boundary = errorBoundary();
  const draw = (p: Record<string, unknown>) => root.render(React.createElement(Boundary, { onError }, React.createElement(compiled.component, p)));
  draw(props);
  return {
    update: draw,
    unmount: () => {
      root.unmount();
      for (const id of compiled.timers) clearTracked(window, id);
      compiled.timers.clear();
    },
  };
}
