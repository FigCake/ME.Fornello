// The popup asking whether a card's (or chat's) scripts may run, one at a
// time. "Not now" (or closing it) lasts until a reload; "Don't ask again" is
// kept. The dialog takes the focus, not a button, since the person may be typing.

import { t } from "../shared/i18n";
import { CONTROLS, THEME_TOKENS } from "../shared/theme";
import { BACKDROP_CSS } from "./dom";
import type { ScriptAsk } from "../scripts/host";

const STYLE = `
${THEME_TOKENS}
:host { position: fixed; inset: 0; z-index: 2147482600; }
* { box-sizing: border-box; }
${CONTROLS}
${BACKDROP_CSS}
.back { padding: 16px; }
.box { width: min(420px, 100%); display: flex; flex-direction: column; gap: 12px; padding: 16px 18px;
  font: 13px/1.5 var(--d-font); color: var(--d-text); background: var(--d-panel-solid); border: 1px solid var(--d-line); border-radius: var(--d-radius); box-shadow: var(--d-shadow); }
h2 { margin: 0; font-size: 15px; color: var(--d-title); }
p { margin: 0; color: var(--d-muted); }
.row { display: flex; flex-wrap: wrap; gap: 6px; justify-content: flex-end; }
.box:focus { outline: none; }
button.primary { border-color: var(--d-btn-border-active); color: var(--d-btn-text-active); background: var(--d-btn-bg-active); }
`;

export class ScriptAskPopup {
  private element: HTMLElement | null = null;
  private showing: string | null = null;
  /** Asks already put up on this screen (answered or closed). */
  private readonly seen = new Set<string>();
  private waiting: ScriptAsk[] = [];

  /** The open chat's unanswered asks: the first not yet seen comes up. */
  show(asks: ScriptAsk[]): void {
    this.waiting = asks;
    if (this.showing && !asks.some((a) => a.key === this.showing)) this.close();
    this.next();
  }

  close(): void {
    this.element?.remove();
    this.element = null;
    this.showing = null;
    document.removeEventListener("keydown", this.onKey, true);
  }

  private next(): void {
    if (this.showing) return;
    const ask = this.waiting.find((a) => !this.seen.has(a.key));
    if (!ask) return;
    this.seen.add(ask.key);
    this.showing = ask.key;
    this.element = this.draw(ask);
    document.body.append(this.element);
    document.addEventListener("keydown", this.onKey, true);
    this.element.shadowRoot?.querySelector<HTMLElement>(".box")?.focus();
  }

  private readonly onKey = (e: KeyboardEvent) => {
    if (e.key !== "Escape") return;
    e.stopPropagation();
    this.done();
  };

  /** Closes this one and puts up the next. */
  private done(): void {
    this.close();
    this.next();
  }

  private draw(ask: ScriptAsk): HTMLElement {
    const host = document.createElement("div");
    host.id = "fornello-script-ask";
    const root = host.attachShadow({ mode: "open" });
    const style = document.createElement("style");
    style.textContent = STYLE;
    const button = (label: string, run: () => void, className = "") => {
      const b = document.createElement("button");
      b.type = "button";
      b.textContent = label;
      if (className) b.className = className;
      b.addEventListener("click", () => {
        this.done();
        run();
      });
      return b;
    };
    const title = document.createElement("h2");
    title.textContent = ask.title ?? (ask.chat ? t("This chat has scripts", "이 채팅에 스크립트가 있어요") : t(`“${ask.name}” has scripts`, `“${ask.name}” 카드에 스크립트가 있어요`));
    const note = document.createElement("p");
    note.textContent = ask.note ?? t(`Run ${ask.count} script(s) while this chat is open?`, `이 채팅이 열려 있는 동안 스크립트 ${ask.count}개를 실행할까요?`);
    const row = document.createElement("div");
    row.className = "row";
    const never = ask.chat ? t("Don't ask again for this chat", "이 채팅은 다시 묻지 않기") : t("Don't ask again for this card", "이 카드는 다시 묻지 않기");
    row.append(
      button(never, ask.decline, "ghost"),
      button(t("See the code", "코드 보기"), ask.show),
      button(t("Not now", "지금은 안 함"), ask.notNow),
      button(t("Run", "실행"), ask.allow, "primary"),
    );
    const box = document.createElement("div");
    box.className = "box";
    box.setAttribute("role", "dialog");
    box.tabIndex = -1;
    box.setAttribute("aria-modal", "true");
    box.setAttribute("aria-label", title.textContent);
    box.append(title, note, row);
    const back = document.createElement("div");
    back.className = "back";
    back.addEventListener("click", (e) => e.target === back && this.done());
    back.append(box);
    root.append(style, back);
    return host;
  }
}
