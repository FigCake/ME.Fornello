// Fornello settings in its Marinara extension storage.

import { getMarinara } from "./shared/marinara-global";
import { DEFAULT_DISPLAY, type ComponentDef, type ComponentDisplay, type ComponentSet, normalizeDisplay, normalizeComponent, normalizeSets } from "./components/model";
import { t } from "./shared/i18n";
import { type LibraryItem, libraryScripts, normalizeLibrary } from "./scripts/model";
import { type ScriptPlace, normalizePlaces } from "./scripts/places";
import { type AssetDisplay, DEFAULT_ASSET_DISPLAY, normalizeAssetDisplay } from "./assets/display";
import { DEFAULT_STORY, normalizeStory, type StorySettings } from "./state/settings";
import { DEFAULT_TEMPLATES, normalizeTemplates, type TemplateSettings } from "./ejs/settings";

/** ask: show pages, run their scripts on a click. always: run the recent ones as they come on screen. off: leave the chat alone. */
export type RunMode = "ask" | "always" | "off";

export const RUN_MODES: Record<RunMode, string> = {
  get always() {
    return t("Run at once", "바로 실행");
  },
  get ask() {
    return t("Click to run", "눌러서 실행");
  },
  get off() {
    return t("Off", "끄기");
  },
};

export interface FornelloSettings {
  mode: RunMode;
  maxHeight: number;
  components: ComponentDef[];
  /** Named groups of the components. */
  componentSets: ComponentSet[];
  display: ComponentDisplay;
  /** "바로 실행": how many of the most recent messages have their pages start by themselves (every page in them; older ones wait for ▶ 실행). */
  autoRun: number;
  /** Cards whose components the person allowed: character id → what the components were then (cards.ts). */
  trustedCards: Record<string, string>;
  /** Background scripts the person keeps here (every chat). */
  scripts: LibraryItem[];
  /** Cards whose scripts the person answered: character id → the scripts' hash (allowed) or "no:" + it (declined). */
  trustedScripts: Record<string, string>;
  /** Scripts the person switched on or off (by key), over what the card says. */
  scriptSwitch: Record<string, boolean>;
  /** Where each script's buttons show (by key): the Dock, the Status tab (places.ts). */
  scriptPlaces: Record<string, Partial<ScriptPlace>>;
  /** Saved before buttons had a place: a card's or chat's script not placed yet stays on the Dock. */
  legacyDock: boolean;
  /** Marinara's character import brings a .charx, JPEG card or card bundle in with its pictures (import-hook.ts). */
  marinaraImport: boolean;
  /** Character assets in chat messages (off until the person turns them on). */
  assets: AssetDisplay;
  /** Pesto for cards that bring a schema (off until the person turns it on). */
  story: StorySettings;
  /** SillyTavern cards' lorebook templates: which may run, and how long a reply waits for them. */
  templates: TemplateSettings;
}

export const AUTO_RUN_MAX = 20;

/**
 * Where buttons show. Settings saved before there was a choice put every button on the Dock: their own
 * scripts start there, and so do cards' and chats' scripts (legacyDock); scripts added later don't.
 */
function placesOf(stored: Partial<FornelloSettings> | undefined): Pick<FornelloSettings, "scriptPlaces" | "legacyDock"> {
  if (!stored || stored.scriptPlaces !== undefined) return { scriptPlaces: normalizePlaces(stored?.scriptPlaces), legacyDock: stored?.legacyDock === true };
  const scriptPlaces: Record<string, Partial<ScriptPlace>> = {};
  // buttons may be stored or made by a script's code: every script there was keeps the Dock
  for (const { script } of libraryScripts(normalizeLibrary(stored.scripts))) scriptPlaces[`global:${script.id}`] = { dock: true };
  return { scriptPlaces, legacyDock: true };
}

function normalizeSwitches(raw: unknown): Record<string, boolean> {
  const out: Record<string, boolean> = {};
  if (raw && typeof raw === "object" && !Array.isArray(raw)) for (const [k, v] of Object.entries(raw)) if (typeof v === "boolean") out[k] = v;
  return out;
}

function normalizeTrusted(raw: unknown): Record<string, string> {
  const out: Record<string, string> = {};
  if (raw && typeof raw === "object" && !Array.isArray(raw)) for (const [k, v] of Object.entries(raw)) if (typeof v === "string") out[k] = v;
  return out;
}

const DEFAULTS: FornelloSettings = { mode: "always", maxHeight: 1600, components: [], componentSets: [], display: DEFAULT_DISPLAY, autoRun: 3, trustedCards: {}, scripts: [], trustedScripts: {}, scriptSwitch: {}, scriptPlaces: {}, legacyDock: false, marinaraImport: true, assets: DEFAULT_ASSET_DISPLAY, story: DEFAULT_STORY, templates: DEFAULT_TEMPLATES };

export class Settings {
  private value: FornelloSettings = { ...DEFAULTS };
  /** Read from storage: until then nothing is written over what is there. */
  private loaded = false;
  private readonly listeners = new Set<(s: FornelloSettings) => void>();

  get current(): FornelloSettings {
    return this.value;
  }

  async load(): Promise<void> {
    const stored = (await getMarinara().storage.get()).settings as Partial<FornelloSettings> | undefined;
    const components = Array.isArray(stored?.components) ? stored.components.map(normalizeComponent).filter((w): w is ComponentDef => !!w) : [];
    this.value = {
      mode: stored?.mode && Object.hasOwn(RUN_MODES, stored.mode) ? stored.mode : DEFAULTS.mode,
      maxHeight: Number(stored?.maxHeight) >= 200 ? Number(stored?.maxHeight) : DEFAULTS.maxHeight,
      components,
      componentSets: normalizeSets(stored?.componentSets, components),
      display: normalizeDisplay(stored?.display),
      trustedCards: normalizeTrusted(stored?.trustedCards),
      scripts: normalizeLibrary(stored?.scripts),
      trustedScripts: normalizeTrusted(stored?.trustedScripts),
      scriptSwitch: normalizeSwitches(stored?.scriptSwitch),
      ...placesOf(stored),
      marinaraImport: stored?.marinaraImport !== false,
      assets: normalizeAssetDisplay(stored?.assets),
      story: normalizeStory(stored?.story),
      templates: normalizeTemplates(stored?.templates),
      autoRun: Number.isFinite(Number(stored?.autoRun)) && stored?.autoRun !== undefined ? Math.max(0, Math.min(AUTO_RUN_MAX, Math.round(Number(stored.autoRun)))) : DEFAULTS.autoRun,
    };
    this.loaded = true;
  }

  /** Reads the settings, with retries; if they cannot be read, pages wait for a click (the person may have chosen that). */
  async loadOrSafe(tries = 3, pause = 1000): Promise<boolean> {
    for (let i = 0; i < tries; i++) {
      try {
        await this.load();
        return true;
      } catch {
        if (i < tries - 1) await new Promise((r) => setTimeout(r, pause));
      }
    }
    this.value = { ...DEFAULTS, mode: "ask" };
    return false;
  }

  async set(patch: Partial<FornelloSettings>): Promise<void> {
    if (!this.loaded) throw new Error(t("Settings could not be read, so nothing was saved. Try reloading.", "설정을 읽지 못해서 저장하지 않았어요. 새로고침해 보세요."));
    // saved first: a failed save leaves the settings as they were
    const next = { ...this.value, ...patch };
    await getMarinara().storage.patch({ settings: next });
    this.value = next;
    for (const fn of this.listeners) fn(this.value);
  }

  subscribe(fn: (s: FornelloSettings) => void): () => void {
    this.listeners.add(fn);
    return () => this.listeners.delete(fn);
  }
}
