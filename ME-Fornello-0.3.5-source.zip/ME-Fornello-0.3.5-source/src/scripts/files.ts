// Script files: out as Tavern Helper's script-tree JSON; in from that JSON, a
// zip of such files (a directory as a folder), a character card (PNG or JSON),
// or a plain .js file. No DOM here.

import { type LibraryItem, type ScriptFolder, cardTree, isFolder, newScriptId, normalizeLibrary, toScriptTrees } from "./model";

/** Items as a file: one as an object, several as a list. `withData`: keep the scripts' variables (they may hold keys). */
export function exportJson(items: LibraryItem[], withData = true): string {
  const trees = toScriptTrees(items).map((tree) => (withData ? tree : dropData(tree)));
  return JSON.stringify(trees.length === 1 ? trees[0] : trees, null, 2);
}

const dropData = (tree: Record<string, unknown>): Record<string, unknown> =>
  tree.type === "folder" ? { ...tree, scripts: (tree.scripts as Record<string, unknown>[]).map(dropData) } : { ...tree, data: {} };

/** Whether any script among the items keeps variables (asked about before they go into a file). */
export const hasData = (items: LibraryItem[]): boolean => items.some((i) => (isFolder(i) ? i.scripts.some((g) => Object.keys(g.data).length) : Object.keys(i.data).length));

// ── zip (read only) ──

/** The files in a zip: stored or deflated entries, read through the central directory. */
export async function unzip(bytes: Uint8Array): Promise<{ path: string; data: Uint8Array }[]> {
  const view = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);
  let end = -1;
  for (let i = bytes.length - 22; i >= Math.max(0, bytes.length - 65_557); i--) {
    if (view.getUint32(i, true) === 0x06054b50) {
      end = i;
      break;
    }
  }
  if (end < 0) return [];
  const count = view.getUint16(end + 10, true);
  let at = view.getUint32(end + 16, true);
  const out: { path: string; data: Uint8Array }[] = [];
  for (let n = 0; n < count && view.getUint32(at, true) === 0x02014b50; n++) {
    const method = view.getUint16(at + 10, true);
    const size = view.getUint32(at + 20, true);
    const nameLength = view.getUint16(at + 28, true);
    const skip = view.getUint16(at + 30, true) + view.getUint16(at + 32, true);
    const local = view.getUint32(at + 42, true);
    const path = new TextDecoder().decode(bytes.subarray(at + 46, at + 46 + nameLength));
    at += 46 + nameLength + skip;
    if (path.endsWith("/")) continue;
    const start = local + 30 + view.getUint16(local + 26, true) + view.getUint16(local + 28, true);
    const raw = bytes.subarray(start, start + size);
    if (method === 0) out.push({ path, data: raw });
    else if (method === 8) out.push({ path, data: new Uint8Array(await new Response(new Blob([raw.slice()]).stream().pipeThrough(new DecompressionStream("deflate-raw"))).arrayBuffer()) });
  }
  return out;
}

/** The scripts of a zip: each .json in it; a directory becomes a folder (when the files do not say one). */
async function scriptsFromZip(bytes: Uint8Array): Promise<LibraryItem[]> {
  const out: LibraryItem[] = [];
  const folders = new Map<string, ScriptFolder>();
  for (const file of await unzip(bytes)) {
    if (!/\.json$/i.test(file.path)) continue;
    let items: LibraryItem[];
    try {
      items = normalizeLibrary([JSON.parse(new TextDecoder().decode(file.data))].flat());
    } catch {
      continue;
    }
    const dir = file.path.includes("/") ? file.path.slice(0, file.path.lastIndexOf("/")).split("/").pop()! : "";
    if (!dir) {
      out.push(...items);
      continue;
    }
    let folder = folders.get(dir);
    if (!folder) {
      folder = { type: "folder", id: newScriptId(), name: dir, enabled: true, icon: "", color: "", scripts: [] };
      folders.set(dir, folder);
      out.push(folder);
    }
    for (const item of items) {
      if (isFolder(item)) out.push(item);
      else folder.scripts.push(item);
    }
  }
  return out;
}

/** A name a file can have. */
export const fileName = (name: string, ext = "json"): string =>
  `${([...name].map((c) => (c.charCodeAt(0) < 32 || '\\/:*?"<>|'.includes(c) ? " " : c)).join("").replace(/\s+/g, " ").trim() || "scripts").slice(0, 80)}.${ext}`;

/** The text a PNG card keeps its JSON in (tEXt "ccv3" or "chara", base64), or null. */
export function pngCardJson(bytes: Uint8Array): string | null {
  const sig = [137, 80, 78, 71, 13, 10, 26, 10];
  if (bytes.length < 8 || sig.some((b, i) => bytes[i] !== b)) return null;
  const view = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);
  // tEXt is latin1 (a TextDecoder, since spreading a large chunk into String.fromCharCode overflows the stack)
  const latin1 = new TextDecoder("latin1");
  const found: Record<string, string> = {};
  for (let at = 8; at + 8 <= bytes.length; ) {
    const length = view.getUint32(at);
    const type = latin1.decode(bytes.subarray(at + 4, at + 8));
    const data = bytes.subarray(at + 8, at + 8 + length);
    if (type === "tEXt") {
      const zero = data.indexOf(0);
      if (zero > 0) found[latin1.decode(data.subarray(0, zero))] = latin1.decode(data.subarray(zero + 1));
    }
    if (type === "IEND") break;
    at += 12 + length;
  }
  const b64 = found.ccv3 ?? found.chara;
  if (!b64) return null;
  try {
    const raw = atob(b64);
    return new TextDecoder().decode(Uint8Array.from(raw, (c) => c.charCodeAt(0)));
  } catch {
    return null;
  }
}

export interface FoundScripts {
  items: LibraryItem[];
  /** Where they came from: a card's name, or the file's. */
  from: string;
}

/** The scripts in a file (fresh ids, so they never clash with what is kept). */
export async function scriptsFromFile(name: string, bytes: Uint8Array): Promise<FoundScripts> {
  const base = name.replace(/\.[^.]+$/, "");
  let items: LibraryItem[] = [];
  let from = base;
  const fromJson = (json: unknown) => {
    const o = json && typeof json === "object" ? (json as Record<string, unknown>) : null;
    // a character card (V2 / V3, or its data alone): the scripts it carries
    const data = (o?.data && typeof o.data === "object" ? o.data : o?.extensions ? o : null) as Record<string, unknown> | null;
    if (data && (o?.spec || data.extensions)) {
      from = typeof data.name === "string" && data.name ? data.name : base;
      return cardTree(data);
    }
    return normalizeLibrary(Array.isArray(json) ? json : [json]);
  };
  if (/\.zip$/i.test(name)) {
    items = await scriptsFromZip(bytes);
  } else if (/\.png$/i.test(name)) {
    const json = pngCardJson(bytes);
    try {
      items = json ? fromJson(JSON.parse(json)) : [];
    } catch {
      items = [];
    }
  } else {
    const text = new TextDecoder().decode(bytes);
    if (/\.json$/i.test(name)) {
      try {
        items = fromJson(JSON.parse(text));
      } catch {
        items = [];
      }
    } else if (text.trim()) items = normalizeLibrary([{ name: base, code: text }]);
  }
  const fresh = items.map((i): LibraryItem => (isFolder(i) ? { ...i, id: newScriptId(), scripts: i.scripts.map((g) => ({ ...g, id: newScriptId() })) } : { ...i, id: newScriptId() }));
  return { items: fresh, from };
}
