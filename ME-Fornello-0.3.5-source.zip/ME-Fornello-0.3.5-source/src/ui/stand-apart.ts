// Marinara applies a reply's <style> to the whole message, so a page's
// `div { … }` could squeeze what Fornello adds; these boxes keep their own layout.

const OWN_LAYOUT: [string, string][] = [
  ["display", "block"],
  ["position", "relative"],
  ["float", "none"],
  ["width", "100%"],
  ["min-width", "0"],
  ["max-width", "100%"],
  ["height", "auto"],
  ["flex", "1 0 100%"],
  ["align-self", "stretch"],
  ["visibility", "visible"],
  ["opacity", "1"],
  ["transform", "none"],
];

export function standApart(el: HTMLElement): HTMLElement {
  for (const [prop, value] of OWN_LAYOUT) el.style.setProperty(prop, value, "important");
  return el;
}
