// What the AI is shown of Pesto, in two lorebook entries (the text is English, whatever the
// screen language). "How to" stays the same while the card's entries do, so it sits with the
// character definitions and keeps the prompt cache; "now" (the values, and what the last reply
// got wrong) changes every reply, so it goes in the chat near the end. Both are kept short:
// only what the AI may change is explained, and hidden values (`hidden: true`, a name starting
// with "_", a `show_when` that is false) are left out.

import { evaluate } from "./expr";
import { derived, scopeFor, type Definition, type Turn } from "./engine";
import type { Field } from "./schema";

type Obj = Record<string, unknown>;

const isPlain = (v: unknown): v is Obj => !!v && typeof v === "object" && !Array.isArray(v);
const hiddenName = (name: string) => name.startsWith("_");

function kindText(f: Field): string {
  switch (f.kind) {
    case "number":
    case "int": {
      const word = f.kind === "int" ? "whole number" : "number";
      if (f.min !== undefined && f.max !== undefined) return `${word} ${f.min}..${f.max}`;
      if (f.min !== undefined) return `${word} ≥ ${f.min}`;
      if (f.max !== undefined) return `${word} ≤ ${f.max}`;
      return word;
    }
    case "text":
      return "text";
    case "bool":
      return "true/false";
    case "enum":
      return `one of ${f.values?.join(", ")}`;
    case "list":
      return `list${f.item ? ` of ${itemText(f.item)}` : ""}${f.maxItems !== undefined ? `, at most ${f.maxItems}` : ""}`;
    case "map":
      return `names and values${f.item ? ` (${itemText(f.item)})` : ""}`;
    case "object":
      return `{${Object.keys(f.fields ?? {}).join(", ")}}`;
    default:
      return "any value";
  }
}

const itemText = (f: Field) => (f.kind === "object" ? `{${Object.keys(f.fields ?? {}).join(", ")}}` : kindText(f));

interface Writable {
  line: string;
  /** an example change for the block */
  example: string;
}

/** An example line for one value, as the AI would write it. */
function exampleFor(path: string, f: Field): string {
  const key = f.kind === "map" ? path.replace(".<name>", ".someone") : path;
  const item = f.kind === "map" ? (f.item ?? { kind: "any" as const }) : f;
  switch (item.kind) {
    case "number":
    case "int":
      return `${key} -= 1`;
    case "enum":
      return `${key} = ${item.values?.[item.values.length > 1 ? 1 : 0] ?? "…"}`;
    case "list":
      return `${key} += "…"`;
    case "bool":
      return `${key} = true`;
    default:
      return `${key} = "…"`;
  }
}

/** The values the AI may change, one line each (a map's entries as `trust.<name>`). */
function writableLines(field: Field, prefix: string, inherited: boolean, out: Writable[]) {
  for (const [name, f] of Object.entries(field.fields ?? {})) {
    if (f.hidden || hiddenName(name)) continue;
    const path = prefix ? `${prefix}.${name}` : name;
    const ai = f.write ? f.write.includes("ai") : inherited;
    if (f.kind === "object") {
      writableLines(f, path, ai, out);
      continue;
    }
    if (!ai) continue;
    const key = f.kind === "map" ? `${path}.<name>` : path;
    const kind = f.kind === "map" && f.item ? kindText(f.item) : kindText(f);
    out.push({ line: `- ${key}: ${kind}${f.note ? ` — ${f.note}` : ""}`, example: exampleFor(key, f) });
  }
}

/** How to report changes: the block's form, what may be changed, the events. Empty when the AI may change nothing. */
export function howToText(def: Definition): string {
  const fields: Writable[] = [];
  writableLines(def.schema.root, "", def.schema.root.write ? def.schema.root.write.includes("ai") : true, fields);
  const events = Object.entries(def.rules.events)
    .filter(([name]) => !hiddenName(name))
    .map(([name, e]) => {
      const params = Object.entries(e.params).map(([k, v]) => (v === null || v === undefined ? k : `${k}=${JSON.stringify(v)}`));
      return `- do ${[name, ...params].join(" ")}${e.note ? ` — ${e.note}` : ""}${e.when ? ` (only when ${e.when})` : ""}`;
    });
  if (!fields.length && !events.length) return "";
  const firstEvent = Object.keys(def.rules.events).find((name) => !hiddenName(name));
  const example = [...fields.slice(0, 2).map((f) => f.example), ...(firstEvent ? [`do ${firstEvent}`] : [])];
  return [
    "[Pesto]",
    "Fornello keeps this story's values and works them out; you report what happened. End each reply with one block of this reply's changes (leave it out when nothing changed), using only the names below:",
    "```pesto",
    ...example,
    "```",
    "`=` sets, `+=` adds (to a number, or an item to a list), `-=` takes away, `remove name` clears it. Write the change, not the new total. The current values are given near the end of the chat; never write them out yourself.",
    ...(fields.length ? ["Values you may change:", ...fields.map((f) => f.line)] : []),
    ...(events.length ? ["Events (`do name value=…`; Fornello works out what they change):", ...events] : []),
  ].join("\n");
}

function valueText(v: unknown): string {
  if (v === null || v === undefined) return "none";
  if (Array.isArray(v)) return v.length ? (v.every((x) => !x || typeof x !== "object") ? v.map((x) => valueText(x)).join(", ") : JSON.stringify(v)) : "(none)";
  if (isPlain(v)) {
    const entries = Object.entries(v);
    if (!entries.length) return "(none)";
    return entries.every(([, x]) => !x || typeof x !== "object") ? entries.map(([k, x]) => `${k}=${valueText(x)}`).join(", ") : JSON.stringify(v);
  }
  const text = String(v);
  return text.length > 400 ? `${text.slice(0, 400)}…` : text;
}

/** The values the AI is shown, by path; groups by their paths. */
function valueLines(field: Field, values: Obj, prefix: string, shown: (f: Field) => boolean, out: [string, string][]) {
  for (const [name, f] of Object.entries(field.fields ?? {})) {
    if (f.hidden || hiddenName(name) || !shown(f)) continue;
    const path = prefix ? `${prefix}.${name}` : name;
    if (f.kind === "object") valueLines(f, isPlain(values[name]) ? (values[name] as Obj) : {}, path, shown, out);
    else out.push([path, valueText(values[name])]);
  }
}

/** The values as the AI (and Marinara's tracker) is shown them: [path, text], hidden ones left out, the computed ones last. */
export function shownValues(def: Definition, values: Obj): [string, string][] {
  const scope = scopeFor(def, values);
  const shown = (f: Field) => {
    if (!f.showWhen) return true;
    try {
      return !!evaluate(f.showWhen, scope);
    } catch {
      return true;
    }
  };
  const out: [string, string][] = [];
  valueLines(def.schema.root, values, "", shown, out);
  for (const [name, v] of Object.entries(derived(def, values))) if (!hiddenName(name)) out.push([name, valueText(v)]);
  return out;
}

/** The values now, with what went wrong in the last reply's block (so the AI can put it right), and the coming reply's dice. */
export function nowText(def: Definition, values: Obj, last?: Turn, dice?: Obj): string {
  const lines = shownValues(def, values).map(([path, text]) => `${path}: ${text}`);
  if (!lines.length && !last && !dice) return "";
  const out = ["[Pesto now]", ...lines];
  if (last) {
    const refused = last.problems
      .filter((p) => p.by === "ai")
      .slice(0, 5)
      .map((p) => `${p.event && !p.path ? `do ${p.event}` : (p.path ?? "the block")}: ${p.detail ?? p.why}`);
    if (refused.length) out.push(`Not applied from your last reply: ${refused.join("; ")}`);
    const kept = last.changes.filter((c) => c.clamped && c.by === "ai").map((c) => `${c.path} kept at ${valueText(c.to)}`);
    if (kept.length) out.push(`Kept within limits: ${kept.slice(0, 5).join("; ")}`);
  }
  if (dice && Object.keys(dice).length)
    out.push(`Dice for this reply, already rolled (let them decide how things turn out): ${Object.entries(dice).map(([k, v]) => `${k} ${valueText(v)}`).join(", ")}`);
  return out.join("\n");
}
