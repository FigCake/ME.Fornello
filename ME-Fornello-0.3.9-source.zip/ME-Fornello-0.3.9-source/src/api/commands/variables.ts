// Page commands for variables: the chat's (in the chat, shared by its pages;
// not `writes`, see command.ts), or global, a script's, a character's (extra-vars.ts).

import { t } from "../../shared/i18n";
import { cmd } from "../command";
import { writeVariables } from "../chat-data";
import type { PageSession } from "../session";
import { copyOf } from "../shared-vars";
import { type ExtraScope, readExtra, writeExtra } from "../extra-vars";
import { cardVariables } from "../../scripts/model";
import { mergeInto } from "../var-ops";
import { changeMsgData, getMsgData } from "./msg-data";

function persist(s: PageSession, values: Record<string, unknown>, replace = false): Promise<void> {
  // the preview keeps its values to itself
  if (s.preview) return Promise.resolve();
  s.vars.writing++;
  return writeVariables(values ?? {}, { replace }, s.here())
    .catch((e) => s.report(t(`Could not save the variables: ${e instanceof Error ? e.message : e}`, `변수를 저장하지 못했어요: ${e instanceof Error ? e.message : e}`)))
    .finally(() => s.vars.writing--);
}

const readVars = (s: PageSession): Record<string, unknown> => copyOf(s.vars.values);

/** Changes the chat's variables on a copy and saves the names whose value changed. */
function changeVars(s: PageSession, change: (vars: Record<string, unknown>) => void): Promise<void> {
  const before = s.vars.values;
  const next = copyOf(before);
  change(next);
  const changed: Record<string, unknown> = {};
  for (const k of new Set([...Object.keys(before), ...Object.keys(next)])) {
    if (JSON.stringify(before[k]) !== JSON.stringify(next[k])) changed[k] = k in next ? next[k] : null;
  }
  for (const k of Object.keys(before)) delete before[k];
  Object.assign(before, next);
  return Object.keys(changed).length ? persist(s, changed) : Promise.resolve();
}

/** The variables become exactly these. */
function replaceVars(s: PageSession, values: Record<string, unknown>): Promise<void> {
  for (const k of Object.keys(s.vars.values)) delete s.vars.values[k];
  Object.assign(s.vars.values, copyOf(values ?? {}));
  return persist(s, values ?? {}, true);
}

// ── variables of other kinds ──

/** Where getVariables(options) and the like read and write: the chat's (no type, or "chat"), Fornello's own store, or nowhere. */
type VarPlace = { kind: "chat" } | { kind: ExtraScope; key: string; initial: Record<string, unknown> } | { kind: "message"; num: number } | { kind: "none" };

function varPlace(s: PageSession, options: unknown): VarPlace {
  // a kind by name (getVars("global")) or as options ({ type: "global" })
  const type = String((typeof options === "string" ? options : (options as { type?: unknown } | undefined)?.type) ?? "chat");
  if (type === "chat") return { kind: "chat" };
  if (type === "message") {
    // a message's data (getMsgData); message_id counts from 0 as in SillyTavern, negative from the end, "latest" the last
    const id = (options as { message_id?: unknown }).message_id;
    const n = id === undefined || id === "latest" ? -1 : Number(id);
    return { kind: "message", num: n < 0 ? n : n + 1 };
  }
  if (type === "global") return { kind: "global", key: "", initial: {} };
  if (type === "script") {
    if (s.script) return { kind: "script", key: s.script.def.key, initial: s.script.def.data };
    s.report(t('Scripts only: "script" variables', '스크립트 전용: "script" 변수'));
    return { kind: "none" };
  }
  if (type === "character") {
    const c = s.cast[0];
    if (c) return { kind: "character", key: c.id, initial: cardVariables(c.data) };
    return { kind: "none" };
  }
  s.report(t(`Not supported: "${type}" variables`, `지원 안 함: "${type}" 변수`));
  return { kind: "none" };
}

export function getAny(s: PageSession, options: unknown): Record<string, unknown> {
  const at = varPlace(s, options);
  if (at.kind === "chat") return readVars(s);
  if (at.kind === "message") return getMsgData(s, at.num);
  if (at.kind === "none") return {};
  return readExtra(at.kind, at.key, at.initial);
}

/** Changes the variables of a kind with `change`, on a copy, then saves them (a preview changes nothing). */
export function changeAny(s: PageSession, options: unknown, change: (vars: Record<string, unknown>) => void): Promise<void> | void {
  const at = varPlace(s, options);
  if (at.kind === "chat") return changeVars(s, change);
  if (at.kind === "message") return changeMsgData(s, at.num, change);
  if (at.kind === "none" || s.preview) return;
  const vars = readExtra(at.kind, at.key, at.initial);
  change(vars);
  writeExtra(at.kind, at.key, vars, { replace: true, initial: at.initial });
}

export function setAny(s: PageSession, values: Record<string, unknown>, options: unknown, replace: boolean): Promise<void> | void {
  if (replace && varPlace(s, options).kind === "chat") return replaceVars(s, values);
  return changeAny(s, options, (vars) => {
    if (replace) for (const k of Object.keys(vars)) delete vars[k];
    mergeInto(vars, values ?? {});
  });
}

export function variableCommands(s: PageSession) {
  return {
    // getVars() / setVars(values): the chat's; getVars("global" | "script" | "character") the other kinds
    getVars: cmd((kind?: unknown) => getAny(s, kind)),
    setVars: cmd((values: Record<string, unknown>, kind?: unknown) => setAny(s, values, kind, false)),
  };
}
