// The text that tells the AI about a character's pictures: how to write a
// tag and which names there are. It is for the AI, so it is English whatever
// the screen language, and short: one line of names per person.

import type { Asset } from "./model";

/** The lorebook entry's name, in a card's book or the chat's. */
export const RULE_ENTRY = "Credenza";
export const PER_REPLY = { min: 1, max: 5, default: 2 };

export interface RulePerson {
  /** The character the assets belong to. */
  name: string;
  assets: Asset[];
}

/** The names, by who they show (a card's people, else the character), each name once. */
function namesByPerson(people: RulePerson[]): [string, string[]][] {
  const out = new Map<string, Set<string>>();
  for (const p of people) {
    for (const a of p.assets) {
      if (a.place !== "gallery") continue;
      const who = a.person || p.name;
      if (!out.has(who)) out.set(who, new Set());
      out.get(who)!.add(a.name);
    }
  }
  // the AI is told a name without its extension, unless another picture has the same name in another type
  const EXT = /\.(png|jpe?g|gif|webp|avif|svg|mp4|webm)$/i;
  return [...out].map(([who, names]) => {
    const all = [...names];
    const bare = all.map((n) => n.replace(EXT, ""));
    return [who, [...new Set(all.map((n, i) => (bare.filter((b) => b.toLowerCase() === bare[i].toLowerCase()).length > 1 ? n : bare[i])))]];
  });
}

/** The rule for these characters' pictures; empty when they have none to name. */
export function pictureRule(people: RulePerson[], perReply: number = PER_REPLY.default): string {
  const lines = namesByPerson(people);
  if (!lines.length) return "";
  const most = Math.max(PER_REPLY.min, Math.min(PER_REPLY.max, Math.round(perReply)));
  return [
    "[Pictures]",
    `After a paragraph you may show a picture by writing [img:name] on its own line: at most ${most} per reply, only when one fits the moment. Use only these names:`,
    ...lines.map(([who, names]) => `${who}: ${names.join(", ")}`),
    "For a picture of someone other than the one speaking, write [img:person:name].",
    "In an HTML page, write {{raw::name}} where its address goes (<img src=\"{{raw::name}}\">), choosing pictures that fit the scene.",
  ].join("\n");
}
