// Page commands for a message's data (one per swipe), swipes, hiding and
// branching. Numbers count from 1; a negative one from the end (-1 = last).

import { cmd } from "../command";
import { MESSAGE_DATA } from "../chat-store";
import { addSwipe, branchChat, deleteSwipe, listSwipes, patchMessageExtra, setActiveSwipe, setMessagesHidden, type Swipe } from "../marinara";
import { messageAt, type PageSession } from "../session";
import { mergeInto } from "../var-ops";

/** The page's own message, or the last one. */
const defaultNum = (s: PageSession): number => s.ownNum() ?? s.messages.length;

export function getMsgData(s: PageSession, num?: unknown): Record<string, unknown> {
  const m = messageAt(s.messages, num ?? defaultNum(s));
  return structuredClone(m.data ?? {});
}

// Each page's data writes go one after another, so a later one reads what an earlier one saved
const lastWrite = new WeakMap<PageSession, Promise<unknown>>();
function inTurn<T>(s: PageSession, write: () => Promise<T>): Promise<T> {
  const next = (lastWrite.get(s) ?? Promise.resolve()).catch(() => undefined).then(write);
  lastWrite.set(s, next);
  return next;
}

/** Changes a message's data at once in the page's list, then saves it (the variable commands answer right away). */
export function changeMsgData(s: PageSession, num: unknown, change: (data: Record<string, unknown>) => void): Promise<void> {
  const m = messageAt(s.messages, num ?? defaultNum(s));
  const next = structuredClone(m.data ?? {});
  change(next);
  m.data = next;
  if (s.preview) return Promise.resolve();
  return inTurn(s, () => patchMessageExtra(s.here(), m.id, { [MESSAGE_DATA]: next })).catch((e) => s.report(e instanceof Error ? e.message : String(e)));
}

/** Sets what is given all the way down (null deletes); `replace`: the data becomes exactly this. */
function setMsgData(s: PageSession, num: unknown, values: Record<string, unknown>, options: { replace?: boolean } = {}): Promise<Record<string, unknown>> {
  return inTurn(s, async () => {
    const m = messageAt(await s.freshMessages(), num ?? defaultNum(s));
    const next = options.replace ? mergeInto({}, values ?? {}) : mergeInto(structuredClone(m.data ?? {}), values ?? {});
    if (!s.preview) await patchMessageExtra(s.here(), m.id, { [MESSAGE_DATA]: next });
    m.data = next;
    const held = s.messages.find((x) => x.id === m.id);
    if (held) held.data = next;
    return structuredClone(next);
  });
}

async function getSwipes(s: PageSession, num: unknown): Promise<Swipe[]> {
  const m = messageAt(await s.freshMessages(), num);
  return listSwipes(s.here(), m.id);
}

export async function setHidden(s: PageSession, nums: unknown, hidden: boolean): Promise<number> {
  const list = await s.freshMessages();
  const ids = (Array.isArray(nums) ? nums : [nums]).map((n) => messageAt(list, n).id);
  await setMessagesHidden(s.here(), ids, hidden);
  await s.freshMessages();
  return ids.length;
}

/** Shows swipe `index` of a message (from 0). */
export async function showSwipe(s: PageSession, num: unknown, index: unknown): Promise<void> {
  await setActiveSwipe(s.here(), messageAt(await s.freshMessages(), num).id, Number(index));
  // the page's copy follows: getMsgData now reads that swipe's data
  await s.freshMessages();
}

export function msgDataCommands(s: PageSession) {
  const at = async (num: unknown) => messageAt(await s.freshMessages(), num);
  // after a change to swipes, the page's copy of the chat is read again
  const then = async <T>(done: T): Promise<T> => (await s.freshMessages(), done);
  return {
    getMsgData: cmd((num?: unknown) => getMsgData(s, num)),
    setMsgData: cmd((num: unknown, values: Record<string, unknown>, options?: { replace?: boolean }) => setMsgData(s, num, values, options)),
    getSwipes: cmd((num: unknown) => getSwipes(s, num)),
    setSwipe: cmd({ writes: true }, (num: unknown, index: unknown) => showSwipe(s, num, index)),
    addSwipe: cmd({ writes: true }, async (num: unknown, text: unknown, options: { show?: boolean } = {}) =>
      then(await addSwipe(s.here(), (await at(num)).id, String(text ?? ""), options.show === false)),
    ),
    delSwipe: cmd({ writes: true }, async (num: unknown, index: unknown) => then(await deleteSwipe(s.here(), (await at(num)).id, Number(index)))),
    hideMsg: cmd({ writes: true }, (nums: unknown) => setHidden(s, nums, true)),
    showMsg: cmd({ writes: true }, (nums: unknown) => setHidden(s, nums, false)),
    branch: cmd({ writes: true }, async (num?: unknown) => branchChat(s.here(), (await at(num ?? -1)).id)),
  };
}
