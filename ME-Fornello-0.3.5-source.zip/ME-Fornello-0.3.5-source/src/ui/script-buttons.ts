// Where the running scripts' buttons show: a 🔥 bubble in Dispensa's Dock, or
// the top-bar menu when Dispensa or its Dock is missing (a Dispensa without
// dockShown counts as shown). The bubble stays with the Dock either way.

import { DISPENSA_READY, type DockGroup } from "../shared/dispensa-bridge";
import type { ScriptButtonView } from "../scripts/host";
import { t } from "../shared/i18n";
import { MENU_ICONS, type TopMenuItem } from "../shared/top-menu";

const DOCK_ID = "fornello";

/** Dispensa's Dock is there and shown. */
function dockShows(): boolean {
  const dispensa = window.__dispensa;
  if (typeof dispensa?.setDockGroup !== "function") return false;
  if (typeof dispensa.dockShown !== "function") return true;
  try {
    return dispensa.dockShown() !== false;
  } catch {
    return true;
  }
}

export class ScriptButtons {
  private list: ScriptButtonView[] = [];
  private readonly onDispensa = () => this.toDock();

  start(): void {
    window.addEventListener(DISPENSA_READY, this.onDispensa);
  }

  stop(): void {
    window.removeEventListener(DISPENSA_READY, this.onDispensa);
    this.list = [];
    this.toDock();
  }

  set(list: ScriptButtonView[]): void {
    this.list = list;
    this.toDock();
  }

  /** The buttons as top-bar menu entries, when Dispensa's Dock does not show them. */
  menuItems(): TopMenuItem[] {
    if (dockShows()) return [];
    return this.list.map((b) => ({ icon: MENU_ICONS.play, label: b.label, group: t(`Script: ${b.script}`, `스크립트: ${b.script}`), run: b.press }));
  }

  private toDock(): void {
    const dispensa = window.__dispensa;
    if (typeof dispensa?.setDockGroup !== "function") return;
    const group: DockGroup | null = this.list.length
      ? { name: t("Scripts (Fornello)", "스크립트 (Fornello)"), icon: "🔥", items: this.list.map((b) => ({ label: b.label, group: b.script, title: t(`Script: ${b.script}`, `스크립트: ${b.script}`), run: b.press })) }
      : null;
    try {
      dispensa.setDockGroup(DOCK_ID, group);
    } catch {
      // a Dispensa that is stopping: the menu shows them meanwhile
    }
  }
}
