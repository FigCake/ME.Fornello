// Page scripts run on Marinara's own thread, so an endless loop would freeze
// the app: every loop gets a check that stops the script once the thread has
// been busy too long. Each script runs on its own, so its top-level names are
// made global by hand, as a browser shares them between a page's scripts.

import Sval from "sval";
import { t } from "../shared/i18n";

export const TICK = "__fornelloTick";

/** How long the thread may stay busy in a page's loop before it is stopped (ms). */
const BUSY_LIMIT = 4000;
let busyLimit = BUSY_LIMIT;

/** Changes the limit (tests use a short one); no argument puts the usual one back. */
export function setBusyLimit(ms = BUSY_LIMIT): void {
  busyLimit = ms;
}

let busySince = 0;
let freed = true;

/** Called on every loop turn: throws once the thread has not been free for the busy limit. */
export function tick(): void {
  const now = performance.now();
  if (freed) {
    // the thread was free since the last check: a new stretch of work starts here
    freed = false;
    busySince = now;
    setTimeout(() => (freed = true), 0);
  } else if (now - busySince > busyLimit) {
    throw new Error(t(`Stopped: ran over ${busyLimit / 1000} s without a break`, `멈춤: ${busyLimit / 1000}초 넘게 쉬지 않고 실행`));
  }
}

/** Back at the top (between a page's scripts): what runs next starts a new stretch. */
export function settle(): void {
  freed = true;
}

type AnyNode = Record<string, unknown> & { type: string; start: number; end: number };

const LOOPS = new Set(["WhileStatement", "DoWhileStatement", "ForStatement", "ForInStatement", "ForOfStatement"]);

function walk(node: unknown, visit: (n: AnyNode) => void): void {
  if (!node || typeof node !== "object") return;
  if (Array.isArray(node)) {
    for (const n of node) walk(n, visit);
    return;
  }
  const n = node as AnyNode;
  if (typeof n.type !== "string") return;
  visit(n);
  for (const key of Object.keys(n)) {
    if (key === "type" || key === "start" || key === "end" || key === "loc") continue;
    walk(n[key], visit);
  }
}

interface Edit {
  at: number;
  /** Text taken out from `at` (0: an insertion). */
  remove: number;
  text: string;
}

function apply(code: string, edits: Edit[]): string {
  let out = code;
  // from the end, so earlier positions stay right
  for (const e of [...edits].sort((a, b) => b.at - a.at || b.remove - a.remove)) out = out.slice(0, e.at) + e.text + out.slice(e.at + e.remove);
  return out;
}

// sval's own parser (acorn, bundled inside it): the same reading the interpreter will do
let parser: Sval | null = null;
const read = (code: string) => (parser ??= new Sval({ ecmaVer: "latest", sandBox: false })).parse(code) as unknown as AnyNode;

/**
 * What is wrong with code a card brings to run in a locked Worker, or null: it doesn't read (as a
 * script), or it loads a module (import), the one way out a Worker's locks can't shut. Read by the
 * parser, so no spelling (comments, spaces) gets past it.
 */
export function codeProblem(code: string): string | null {
  let tree: AnyNode;
  try {
    tree = read(code);
  } catch (e) {
    return e instanceof Error ? e.message : String(e);
  }
  let found: string | null = null;
  walk(tree, (n) => {
    if (!found && (n.type === "ImportExpression" || n.type === "ImportDeclaration")) found = t("import is not allowed here", "여기서는 import를 쓸 수 없어요");
  });
  return found;
}

/** A check at the start of every loop body. */
export function guardLoops(code: string): string {
  const edits: Edit[] = [];
  walk(read(code), (n) => {
    if (!LOOPS.has(n.type)) return;
    const body = n.body as AnyNode;
    if (body.type === "BlockStatement") edits.push({ at: body.start + 1, remove: 0, text: `${TICK}();` });
    else {
      edits.push({ at: body.start, remove: 0, text: `{${TICK}();` });
      edits.push({ at: body.end, remove: 0, text: "}" });
    }
  });
  return apply(code, edits);
}

function patternNames(p: AnyNode | null, out: string[]): void {
  if (!p) return;
  if (p.type === "Identifier") out.push(p.name as string);
  else if (p.type === "ObjectPattern") for (const prop of p.properties as AnyNode[]) patternNames((prop.type === "RestElement" ? prop.argument : prop.value) as AnyNode, out);
  else if (p.type === "ArrayPattern") for (const el of p.elements as (AnyNode | null)[]) patternNames(el, out);
  else if (p.type === "AssignmentPattern") patternNames(p.left as AnyNode, out);
  else if (p.type === "RestElement") patternNames(p.argument as AnyNode, out);
}

/**
 * Top-level declarations become globals: let/const → var, classes →
 * var X = class X, functions → var f = function f at the top. `names` are
 * what it declares; they win over the window's own (`location`, `history`).
 */
function shareTopLevel(code: string): { code: string; names: string[] } {
  const edits: Edit[] = [];
  const hoisted: string[] = [];
  const names: string[] = [];
  for (const n of (read(code).body as AnyNode[]) ?? []) {
    if (n.type === "VariableDeclaration") {
      for (const d of n.declarations as AnyNode[]) patternNames(d.id as AnyNode, names);
      if (n.kind !== "var") edits.push({ at: n.start, remove: String(n.kind).length, text: "var" });
    } else if (n.type === "ClassDeclaration") {
      const name = (n.id as AnyNode).name as string;
      names.push(name);
      edits.push({ at: n.start, remove: 0, text: `var ${name} = ` });
      edits.push({ at: n.end, remove: 0, text: ";" });
    } else if (n.type === "FunctionDeclaration") {
      const name = (n.id as AnyNode).name as string;
      names.push(name);
      hoisted.push(`var ${name} = ${code.slice(n.start, n.end)};`);
      edits.push({ at: n.start, remove: n.end - n.start, text: "" });
    }
  }
  const body = apply(code, edits);
  return { code: hoisted.length ? `${hoisted.join("\n")}\n${body}` : body, names };
}

/** A page script, ready to run on its own: loops checked, its names shared. Throws on a syntax error. */
export function prepareScript(code: string): { code: string; names: string[] } {
  return shareTopLevel(guardLoops(code));
}
