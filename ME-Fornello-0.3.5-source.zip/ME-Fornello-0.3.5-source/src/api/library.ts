// Marinara's library through its /api: characters, personas, whole lorebooks
// and regex scripts (lorebook entries are in marinara.ts). Each write refreshes
// Marinara's screens.

import { api } from "../shared/api";
import { getMarinara } from "../shared/marinara-global";
import { refreshQueries } from "../shared/react-bridge";
import { forgetRegexScripts } from "../regex";
import { chatDetail, forgetChat, forgetDetail, forgetLore, forgetPeople } from "./chat-store";
import { parseList, parseObject } from "./parse";
import type { LoreBook } from "./types";

const enc = encodeURIComponent;
const items = (res: unknown): Record<string, unknown>[] => (Array.isArray(res) ? res : ((res as { items?: unknown[] })?.items ?? [])) as Record<string, unknown>[];

// the lists change seldom and every page loads them: kept a minute, dropped when Fornello changes them
const KEEP = 60_000;
const lists = new Map<string, { at: number; value: Promise<unknown> }>();

function kept<T>(key: string, load: () => Promise<T>): Promise<T> {
  const hit = lists.get(key);
  if (hit && Date.now() - hit.at < KEEP) return hit.value as Promise<T>;
  const value = load();
  lists.set(key, { at: Date.now(), value });
  value.catch(() => lists.delete(key));
  return value;
}

/** The lists are read again next time (all of them, or one). */
export function forgetLibrary(key?: "characters" | "personas" | "presets"): void {
  if (key) lists.delete(key);
  else lists.clear();
}

// ── characters ──

export interface CharacterName {
  id: string;
  name: string;
}

/** Every character in the library, by name (Marinara hands the catalog out a page at a time). */
export function characterNames(): Promise<CharacterName[]> {
  return kept("characters", async () => {
    const out: CharacterName[] = [];
    for (let offset = 0; offset < 100_000; ) {
      const page = await api<{ items?: Record<string, unknown>[]; hasMore?: boolean; limit?: number }>(`/characters/catalog?limit=100&offset=${offset}`);
      const got = items(page);
      out.push(...got.map((c) => ({ id: String(c.id), name: String(c.name ?? "") })));
      if (!page?.hasMore || !got.length) break;
      offset += got.length;
    }
    return out;
  });
}

/** A character's card data (SillyTavern's V2 card fields). */
export async function characterData(id: string): Promise<Record<string, unknown>> {
  const raw = await api<{ data?: unknown }>(`/characters/${enc(id)}`);
  return parseObject(raw.data);
}

/** The card data becomes `data` (fields left out are kept by Marinara). */
export async function saveCharacter(id: string, data: Record<string, unknown>): Promise<void> {
  await api(`/characters/${enc(id)}`, { method: "PATCH", body: { data } });
  forgetPeople();
  forgetLibrary("characters");
  refreshQueries([["characters"]]);
}

export async function createCharacter(data: Record<string, unknown>): Promise<string> {
  const made = await api<{ id: string }>("/characters", { method: "POST", body: { data } });
  forgetLibrary("characters");
  refreshQueries([["characters"]]);
  return made.id;
}

export async function deleteCharacter(id: string): Promise<void> {
  await api(`/characters/${enc(id)}`, { method: "DELETE" });
  forgetPeople();
  forgetLibrary("characters");
  refreshQueries([["characters"]]);
}

/** Imports a SillyTavern card (its JSON, or a PNG card); the new character's id comes back. */
export async function importCharacter(file: Blob | Record<string, unknown>, filename: string): Promise<string | null> {
  let res: { success?: boolean; error?: string; characterId?: string; id?: string };
  if (file instanceof Blob) {
    // a PNG card goes as a file upload (api() sends JSON only)
    const form = new FormData();
    form.append("importEmbeddedLorebook", "true");
    form.append("file", file, filename || "card.png");
    const sent = await (getMarinara().fetch ?? fetch)("/api/import/st-character", { method: "POST", headers: { "x-marinara-csrf": "1" }, body: form, credentials: "same-origin" });
    res = await sent.json().catch(() => ({ success: false, error: `${sent.status}` }));
  } else {
    res = await api("/import/st-character", { method: "POST", body: { ...file, importEmbeddedLorebook: true } });
  }
  if (res?.success === false) throw new Error(res.error ?? "Import failed");
  forgetLibrary("characters");
  refreshQueries([["characters"], ["lorebooks"], ["regex-scripts"]]);
  forgetLore();
  forgetRegexScripts();
  return res?.characterId ?? res?.id ?? null;
}

// ── personas ──

export interface PersonaRow {
  id: string;
  name: string;
  description: string;
  personality: string;
  scenario: string;
  backstory: string;
  appearance: string;
  comment: string;
  tags: string[];
  avatarPath: string | null;
}

const personaRow = (p: Record<string, unknown>): PersonaRow => ({
  id: String(p.id),
  name: String(p.name ?? ""),
  description: String(p.description ?? ""),
  personality: String(p.personality ?? ""),
  scenario: String(p.scenario ?? ""),
  backstory: String(p.backstory ?? ""),
  appearance: String(p.appearance ?? ""),
  comment: String(p.comment ?? ""),
  tags: parseList(p.tags),
  avatarPath: typeof p.avatarPath === "string" && p.avatarPath ? p.avatarPath : null,
});

export function personaList(): Promise<PersonaRow[]> {
  return kept("personas", async () => items(await api<unknown>("/characters/personas/list")).map(personaRow));
}

export async function savePersona(id: string, fields: Record<string, unknown>): Promise<void> {
  await api(`/characters/personas/${enc(id)}`, { method: "PATCH", body: fields });
  forgetPeople();
  forgetLibrary("personas");
  refreshQueries([["personas"]]);
}

export async function createPersona(fields: Record<string, unknown>): Promise<string> {
  const made = await api<{ id: string }>("/characters/personas", { method: "POST", body: fields });
  forgetLibrary("personas");
  refreshQueries([["personas"]]);
  return made.id;
}

export async function deletePersona(id: string): Promise<void> {
  await api(`/characters/personas/${enc(id)}`, { method: "DELETE" });
  forgetPeople();
  forgetLibrary("personas");
  refreshQueries([["personas"]]);
}

/** The persona the chat speaks as. */
export async function setChatPersona(chatId: string, personaId: string | null): Promise<void> {
  await api(`/chats/${enc(chatId)}`, { method: "PATCH", body: { personaId } });
  forgetChat(chatId);
  forgetPeople();
  refreshQueries([["chats", "detail", chatId]]);
}

// ── whole lorebooks ──

/** Every lorebook with what it is linked to. */
export async function bookList(): Promise<LoreBook[]> {
  return items(await api<unknown>("/lorebooks")).map((b) => ({
    id: String(b.id),
    name: String(b.name ?? ""),
    characterIds: parseList(b.characterIds),
    personaIds: parseList(b.personaIds),
    chatId: typeof b.chatId === "string" && b.chatId ? b.chatId : null,
    isGlobal: b.isGlobal === true || b.isGlobal === "true",
    enabled: b.enabled !== false && b.enabled !== "false",
    category: String(b.category ?? ""),
  }));
}

/** Changes a book's own settings (its links: isGlobal, characterIds, personaIds, chatId). */
export async function patchBook(id: string, patch: Record<string, unknown>): Promise<void> {
  await api(`/lorebooks/${enc(id)}`, { method: "PATCH", body: patch });
  forgetLore();
  refreshQueries([["lorebooks"]]);
}

export async function deleteBook(id: string): Promise<void> {
  await api(`/lorebooks/${enc(id)}`, { method: "DELETE" });
  forgetLore();
  refreshQueries([["lorebooks"]]);
}

/** Imports a SillyTavern lorebook (its JSON); the new book's id comes back. */
export async function importBook(json: Record<string, unknown>, filename: string): Promise<string | null> {
  const res = await api<{ success?: boolean; error?: string; lorebookId?: string; id?: string }>("/import/st-lorebook", { method: "POST", body: { ...json, __filename: filename } });
  if (res?.success === false) throw new Error(res.error ?? "Import failed");
  forgetLore();
  refreshQueries([["lorebooks"]]);
  return res?.lorebookId ?? res?.id ?? null;
}

/** Books the person added to this chat (Marinara's chat lorebook picker). */
export async function chatBookIds(chatId: string): Promise<string[]> {
  return parseList(parseObject((await chatDetail(chatId)).metadata).activeLorebookIds);
}

export async function setChatBookIds(chatId: string, ids: string[]): Promise<void> {
  await api(`/chats/${enc(chatId)}/metadata`, { method: "PATCH", body: { activeLorebookIds: ids } });
  forgetDetail(chatId);
  forgetLore();
  refreshQueries([["chats", "detail", chatId], ["lorebooks"]]);
}

// ── prompt presets ──

export function presetList(): Promise<{ id: string; name: string }[]> {
  return kept("presets", async () => items(await api<unknown>("/prompts")).map((p) => ({ id: String(p.id), name: String(p.name ?? "") })));
}

// ── regex scripts ──

export async function createRegex(fields: Record<string, unknown>): Promise<string> {
  const made = await api<{ id: string }>("/regex-scripts", { method: "POST", body: fields });
  forgetRegexScripts();
  refreshQueries([["regex-scripts"]]);
  return made.id;
}

export async function patchRegex(id: string, fields: Record<string, unknown>): Promise<void> {
  await api(`/regex-scripts/${enc(id)}`, { method: "PATCH", body: fields });
  forgetRegexScripts();
  refreshQueries([["regex-scripts"]]);
}

export async function deleteRegex(id: string): Promise<void> {
  await api(`/regex-scripts/${enc(id)}`, { method: "DELETE" });
  forgetRegexScripts();
  refreshQueries([["regex-scripts"]]);
}

/** A font file the person added to Marinara (Settings → fonts): one face of a family. */
export interface ServerFont {
  family: string;
  url: string;
  weight: string;
  style: string;
  unicodeRange?: string;
}

/** A face with the two fields Fornello needs. */
function usableFace(face: ServerFont | null | undefined): face is ServerFont {
  if (!face) return false;
  return typeof face.url === "string" && typeof face.family === "string";
}

/** Marinara's own fonts (/api/fonts), each face. */
export function serverFonts(): Promise<ServerFont[]> {
  return kept("fonts", () => api<ServerFont[]>("/fonts").then((list) => (Array.isArray(list) ? list.filter(usableFace) : [])));
}
