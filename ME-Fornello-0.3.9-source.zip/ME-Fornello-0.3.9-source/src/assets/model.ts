// A character's assets: pictures a reply can show by name ([img:name]). The
// list lives in the card itself (extensions.fornello.assets) so it travels
// with the card; each asset names a file of the character's Gallery or of its
// sprites, by file name, which Marinara keeps when a card is exported and
// imported again. The character's sprites count as assets too, named by
// their expression, without being listed.

import { parseObject } from "../api/parse";

/** Where an asset's file is: the character's Gallery or its sprites. */
export type AssetPlace = "gallery" | "sprite";

export interface Asset {
  /** The name a reply uses, as the person named it; several assets may share one. */
  name: string;
  /** The file's name in its place. */
  file: string;
  place: AssetPlace;
  /** Who in the card it shows, for a card with several people (none: the card's own character). */
  person?: string;
  /** Words that show it when a reply uses them. */
  words?: string[];
  /** A short hash of the file's bytes, kept for a picture imported from a card file, so importing that card again skips it. */
  hash?: string;
}

/** The card's key for what Fornello keeps there (extensions.fornello). */
export const CARD_KEY = "fornello";
const NAME_MAX = 120;
const WORDS_MAX = 20;

const text = (v: unknown, max: number) => (typeof v === "string" ? v.trim().slice(0, max) : "");

export function normalizeAsset(raw: unknown): Asset | null {
  const r = parseObject(raw);
  const name = text(r.name, NAME_MAX);
  const file = text(r.file, 200);
  // a file name only: an asset never points outside its place
  if (!name || !file || /[\\/]|^\.+$/.test(file)) return null;
  const place: AssetPlace = r.place === "sprite" ? "sprite" : "gallery";
  const person = text(r.person, NAME_MAX);
  const words = Array.isArray(r.words) ? [...new Set(r.words.map((w) => text(w, 60)).filter(Boolean))].slice(0, WORDS_MAX) : [];
  const hash = text(r.hash, 40);
  return { name, file, place, ...(person ? { person } : {}), ...(words.length ? { words } : {}), ...(/^[0-9a-z-]+$/.test(hash) ? { hash } : {}) };
}

/** The assets a card lists (a character's `data`, as Marinara keeps it). */
export function cardAssets(data: Record<string, unknown>): Asset[] {
  const ours = parseObject(parseObject(data.extensions)[CARD_KEY]);
  return Array.isArray(ours.assets) ? ours.assets.map(normalizeAsset).filter((a): a is Asset => !!a) : [];
}

/** A character's sprites as assets, named by their expression. */
export function spriteAssets(sprites: { expression: string; filename: string }[]): Asset[] {
  return sprites.filter((s) => s.expression && s.filename).map((s) => ({ name: s.expression, file: s.filename, place: "sprite" as const }));
}

/** Where the browser loads an asset of `characterId`. */
export function assetUrl(characterId: string, asset: Asset): string {
  const id = encodeURIComponent(characterId);
  const file = encodeURIComponent(asset.file);
  return asset.place === "sprite" ? `/api/sprites/${id}/file/${file}` : `/api/characters/${id}/gallery/file/${file}`;
}

/** A character's assets: its card's list, then its sprites not listed there (a sprite given words is listed already). */
export function withSprites(listed: Asset[], sprites: Asset[]): Asset[] {
  return [...listed, ...sprites.filter((sp) => !listed.some((a) => a.place === "sprite" && a.file === sp.file))];
}
