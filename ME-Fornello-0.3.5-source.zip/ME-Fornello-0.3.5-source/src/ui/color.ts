// Colors and contrast, for a page's backdrop when its text would vanish on the message.

export type Rgba = [number, number, number, number];

const colors = new Map<string, Rgba | null>();
let probe: CanvasRenderingContext2D | null | undefined;

export function forgetColors(): void {
  colors.clear();
  probe = undefined;
}

/** Any CSS color (rgb, oklch, color-mix…) as red, green, blue (0–255) and alpha (0–1). */
export function rgba(color: string): Rgba | null {
  if (!color) return null;
  const known = colors.get(color);
  if (known !== undefined) return known;
  if (probe === undefined) {
    const canvas = document.createElement("canvas");
    canvas.width = canvas.height = 1;
    probe = canvas.getContext("2d", { willReadFrequently: true });
  }
  let out: Rgba | null = null;
  if (probe) {
    probe.clearRect(0, 0, 1, 1);
    probe.fillStyle = "rgba(0, 0, 0, 0)";
    probe.fillStyle = color;
    probe.fillRect(0, 0, 1, 1);
    const d = probe.getImageData(0, 0, 1, 1).data;
    out = [d[0], d[1], d[2], d[3] / 255];
  }
  if (colors.size > 200) colors.clear();
  colors.set(color, out);
  return out;
}

/** Relative luminance (WCAG), 0 for black to 1 for white. */
export function luminance([r, g, b]: Rgba): number {
  const c = (v: number) => {
    const x = v / 255;
    return x <= 0.03928 ? x / 12.92 : ((x + 0.055) / 1.055) ** 2.4;
  };
  return 0.2126 * c(r) + 0.7152 * c(g) + 0.0722 * c(b);
}

/** WCAG contrast ratio of two colors (1 to 21). */
export const contrast = (a: Rgba, b: Rgba) => {
  const [hi, lo] = [luminance(a), luminance(b)].sort((x, y) => y - x);
  return (hi + 0.05) / (lo + 0.05);
};

/** The first color behind an element, looking up through shadow roots. */
export function backdropColor(start: Element): string {
  let el: Element | null = start;
  while (el) {
    const cs = getComputedStyle(el);
    const c = rgba(cs.backgroundColor);
    if (c && c[3] > 0.4) return cs.backgroundColor;
    el = el.parentElement ?? ((el.getRootNode() as ShadowRoot).host ?? null);
  }
  return getComputedStyle(document.body).backgroundColor || "rgb(255, 255, 255)";
}

/** The element paints something behind its text: a background image, or a mostly solid color. */
export const opaque = (cs: CSSStyleDeclaration) => cs.backgroundImage !== "none" || (rgba(cs.backgroundColor)?.[3] ?? 0) > 0.4;
