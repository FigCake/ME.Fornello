// Page commands for Pesto: the story's values (with the computed ones beside them) after a
// message, setting one as the person's own change, and hearing when they change.

import { onStoryChange, storyAccess } from "../../state/access";
import { cmd } from "../command";
import { messageAt, type PageSession } from "../session";

type Values = Record<string, unknown>;

/** The values after message `num` (the page's own, or the last); null where the chat has no Pesto. */
async function getState(s: PageSession, num?: unknown): Promise<Values | null> {
  const access = storyAccess();
  if (!access || s.preview) return null;
  const list = await s.freshMessages();
  const at = num === undefined || num === null ? (s.ownNum() ?? list.length) : num;
  const id = list.length ? messageAt(list, at).id : null;
  const view = await access.at(s.here(), id);
  return view ? { ...view.values, ...view.derived } : null;
}

/** Sets a value at message `num` (the last by default), as the person's change; null takes that change back. */
async function setState(s: PageSession, path: unknown, value: unknown, num?: unknown): Promise<Values | null> {
  const access = storyAccess();
  if (!access || typeof path !== "string" || !path) return null;
  const list = await s.freshMessages();
  const message = messageAt(list, num ?? -1);
  await access.edit(s.here(), message.id, [{ path, value: value === undefined ? null : value }]);
  return getState(s, message.num);
}

/** Calls `fn(values)` (after the last message) whenever the page's chat's values may have changed. */
function onStateChange(s: PageSession, fn: (values: Values) => unknown): () => void {
  if (typeof fn !== "function" || s.preview) return () => {};
  const chatId = s.here();
  const stop = onStoryChange((id) => {
    if (id !== chatId || s.disposed) return;
    void getState(s, -1)
      .then((values) => values && fn(values))
      .catch(s.report);
  });
  s.onDispose(stop);
  return stop;
}

export function storyCommands(s: PageSession) {
  return {
    getState: cmd((num?: unknown) => getState(s, num)),
    setState: cmd({ writes: true }, (path: unknown, value: unknown, num?: unknown) => setState(s, path, value, num)),
    onStateChange: cmd((fn: (values: Values) => unknown) => onStateChange(s, fn)),
  };
}
