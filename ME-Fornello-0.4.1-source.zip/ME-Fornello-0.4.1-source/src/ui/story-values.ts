// The Pesto window: the open chat's values after any message, what that message changed
// and what was refused, its dice; values can be set there, kept on the message as the person's
// own changes (counted after the AI's), and taken back.

import { chatCharacters, listMessages } from "../api/chat-store";
import type { CharacterInfo, Message } from "../api/types";
import { currentChatId } from "../host/current-chat";
import { t } from "../shared/i18n";
import { type GoToTab, TABS_CSS, tabHeader } from "./window-tabs";
import type { ScriptButtonView } from "../scripts/host";
import { FORM_CSS, section } from "../shared/form";
import { CONTROLS, THEME_TOKENS } from "../shared/theme";
import { onStoryChange, storyAccess, type StoryView } from "../state/access";
import type { Change, DefinitionProblem, Problem, Turn } from "../state/engine";
import { fieldAt, type Field } from "../state/schema";
import { BACKDROP_CSS, el } from "./dom";
import { GRAPH_CSS, valueGraph } from "./story-graph";
import { varName } from "../state/vars";
import { addStarterEntries } from "../state/starter";
import { showToast } from "./toast";

const STYLE = `
${THEME_TOKENS}
:host { position: fixed; inset: 0; z-index: 2147482700; }
* { box-sizing: border-box; }
${CONTROLS}
${FORM_CSS}
${BACKDROP_CSS}
${TABS_CSS}
details.part { border: 1px solid var(--d-line); border-radius: var(--d-radius-sm); padding: 6px 10px; margin-bottom: 10px; }
details.part > summary { cursor: pointer; color: var(--d-muted); font-size: 12px; }
details.part[open] > summary { margin-bottom: 6px; }
.win { width: min(760px, 100%); height: min(860px, 100%); display: flex; flex-direction: column; overflow: hidden;
  font: 13px/1.45 var(--d-font); color: var(--d-text); background: var(--d-panel-solid); border: 1px solid var(--d-line); border-radius: var(--d-radius); box-shadow: var(--d-shadow); }
header { display: flex; align-items: center; gap: 8px; padding: 10px 14px; border-bottom: 1px solid var(--d-divider); flex-wrap: wrap; }
header h2 { margin: 0; font-size: 15px; color: var(--d-title); flex: 1; white-space: nowrap; }
header .pick { display: flex; align-items: center; gap: 8px; min-width: 0; }
header select { width: auto; max-width: 22em; min-width: 0; }
/* a phone: the message picker gets its own row under the title and ✕ */
@media (max-width: 520px) {
  header .pick { order: 3; flex: 1 0 100%; }
  header .pick select { flex: 1; max-width: none; }
}
main { flex: 1; min-height: 0; overflow: auto; padding: 8px 14px 18px; }
.note { color: var(--d-muted); font-size: 12px; }
.vals { display: grid; grid-template-columns: minmax(8em, max-content) minmax(0, 1fr) auto; gap: 6px 10px; align-items: center; }
.vals .path { font: 12px var(--d-mono); color: var(--d-muted); overflow-wrap: anywhere; }
.vals input, .vals select, .vals textarea { width: 100%; min-width: 0; font-size: 12px; padding: 3px 6px; }
.vals textarea { font: 12px/1.4 var(--d-mono); min-height: 2.4em; resize: vertical; }
.vals .computed { font: 12px var(--d-mono); }
.badge { font-size: 11px; padding: 0 6px; border-radius: 999px; border: 1px solid var(--d-line); color: var(--d-muted); white-space: nowrap; }
.badge.mine { border-color: var(--d-btn-border-active); color: var(--d-text); }
button.mini { padding: 1px 6px; font-size: 11px; min-width: 0; }
ul.log { margin: 0; padding-left: 18px; font-size: 12px; }
${GRAPH_CSS}
textarea.try { width: 100%; box-sizing: border-box; font: 12px/1.45 var(--d-mono); resize: vertical; }
.tried { margin-top: 6px; display: grid; gap: 4px; }
ul.log li { overflow-wrap: anywhere; }
.bad { color: var(--d-danger, #e5484d); }
pre.code { margin: 0; max-height: 260px; overflow: auto; font: 11px/1.45 var(--d-mono); padding: 8px; border: 1px solid var(--d-line); border-radius: var(--d-radius-sm); background: var(--d-field); white-space: pre; }
`;

const show = (v: unknown) => (v === null || v === undefined ? "—" : typeof v === "object" ? JSON.stringify(v) : String(v));

/** A value as the person typed it, read for its field: numbers, yes/no, a word of the list, or JSON for lists and groups. */
export function typedValue(field: Field, text: string): unknown {
  switch (field.kind) {
    case "number":
    case "int": {
      const n = Number(text.trim());
      if (text.trim() === "" || !Number.isFinite(n)) throw new Error(t("Needs a number.", "숫자를 넣어 주세요."));
      return n;
    }
    case "bool":
      return text === "true";
    case "text":
    case "enum":
      return text;
    default:
      try {
        return JSON.parse(text);
      } catch {
        if (field.kind === "any") return text;
        throw new Error(t("Needs JSON, like [\"rope\"] or {\"a\": 3}.", "JSON으로 넣어 주세요. 예: [\"rope\"], {\"a\": 3}"));
      }
  }
}

export class StoryValues {
  private element: HTMLElement | null = null;
  private root: ShadowRoot | null = null;
  private returnFocus: HTMLElement | null = null;
  private chatId: string | null = null;
  private messages: Message[] = [];
  /** The message whose values are shown (null: the last). */
  private messageId: string | null = null;
  private view: StoryView | null = null;
  private code: { code: string; allowed: boolean | undefined; hash: string } | null = null;
  private loaded = false;
  /** The chat's cards, read when it has no Pesto yet (for adding the entries). */
  private cast: CharacterInfo[] = [];
  private adding = false;
  /** The card's entries: their problems, and a converted card's entries written out. */
  private card: { problems: DefinitionProblem[]; from?: "initvar" | "tags"; schemaFrom?: "script"; schema?: string; start?: string } | null = null;
  /** The number values over the last messages, for the graphs. */
  private history: { ids: string[]; nums: number[]; series: Record<string, (number | null)[]> } | null = null;
  /** The reply being tried, and what it would do. */
  private tryText = "";
  private tried: { turn: Turn; values: Record<string, unknown> } | null = null;
  private stopWatch: (() => void) | null = null;
  /** The tabs of Fornello's window (main.ts sets it). */
  tabs: GoToTab | null = null;
  /** Pesto's settings and the cards' templates, at the top of the tab. */
  settingsPart: (() => (HTMLElement | null)[]) | null = null;
  private partOpen = false;
  /** The scripts' buttons put on this tab. */
  buttons: (() => ScriptButtonView[]) | null = null;

  async open(): Promise<void> {
    if (!this.element) {
      this.element = document.createElement("div");
      this.element.id = "fornello-story";
      this.root = this.element.attachShadow({ mode: "open" });
      this.returnFocus = document.activeElement instanceof HTMLElement ? document.activeElement : null;
      document.addEventListener("keydown", this.onKey, true);
      document.body.append(this.element);
      this.stopWatch = onStoryChange((chatId) => {
        if (chatId === this.chatId) void this.load();
      });
    }
    this.chatId = currentChatId();
    this.messageId = null;
    await this.load();
  }

  close(): void {
    document.removeEventListener("keydown", this.onKey, true);
    this.stopWatch?.();
    this.stopWatch = null;
    const wasOpen = !!this.element;
    this.element?.remove();
    this.element = null;
    this.root = null;
    if (wasOpen && this.returnFocus?.isConnected) this.returnFocus.focus();
  }

  /** Redraws when open (the language changed). */
  refresh(): void {
    if (this.element) this.render();
  }

  private readonly onKey = (e: KeyboardEvent) => {
    if (e.key === "Escape" && this.element) {
      e.stopPropagation();
      this.close();
    }
  };

  private async load(): Promise<void> {
    const chatId = this.chatId;
    this.loaded = false;
    this.render();
    if (!chatId) {
      this.view = null;
      this.loaded = true;
      this.render();
      return;
    }
    try {
      this.messages = await listMessages(chatId, { fresh: true });
      if (this.messageId && !this.messages.some((m) => m.id === this.messageId)) this.messageId = null;
      const access = storyAccess();
      this.view = (await access?.at(chatId, this.messageId)) ?? null;
      // the rest at once: they read what at() just read
      const [code, card, history] = this.view ? await Promise.all([access?.codeOf?.(chatId), access?.cardOf?.(chatId), access?.history?.(chatId)]) : [];
      this.code = code ?? null;
      this.card = card ?? null;
      this.history = history ?? null;
      this.tried = null;
      this.cast = this.view ? [] : await chatCharacters(chatId).catch(() => []);
    } catch (e) {
      this.view = null;
      showToast(e instanceof Error ? e.message : String(e), "warning");
    }
    if (chatId !== this.chatId) return;
    this.loaded = true;
    this.render();
  }

  private async save(path: string, value: unknown): Promise<void> {
    const chatId = this.chatId;
    const messageId = this.messageId ?? this.messages.at(-1)?.id;
    if (!chatId || !messageId) return;
    try {
      // the change is told to every reader (onStoryChange), this window too: it reads again from that
      await storyAccess()?.edit(chatId, messageId, [{ path, value }]);
    } catch (e) {
      showToast(e instanceof Error ? e.message : String(e), "warning");
      await this.load();
    }
  }

  private render(): void {
    if (!this.root) return;
    const scroll = this.root.querySelector("main")?.scrollTop ?? 0;
    const shownId = this.messageId ?? this.messages.at(-1)?.id ?? "";
    const select = el(
      "select",
      {
        "aria-label": t("After message", "메시지 다음"),
        "data-key": "story-message",
        disabled: !this.messages.length,
        onchange: (e: Event) => {
          const id = (e.target as HTMLSelectElement).value;
          this.messageId = id === this.messages.at(-1)?.id ? null : id;
          void this.load();
        },
      },
      ...this.messages.map((m) =>
        el("option", { value: m.id, selected: m.id === shownId }, `#${m.num} ${m.name}: ${m.text.replace(/```[\s\S]*?(```|$)/g, "").replace(/\s+/g, " ").trim().slice(0, 40) || "…"}`),
      ),
    );
    const head = el(
      "header",
      {},
      ...(this.tabs ? tabHeader("status", this.tabs) : [el("h2", {}, t("📜 Status", "📜 상태창"))]),
      el("button", { className: "ghost", "aria-label": t("Close", "닫기"), onclick: () => this.close() }, "✕"),
    );
    const part = this.settingsPart ? el("details", { className: "part", open: this.partOpen, ontoggle: (e: Event) => (this.partOpen = (e.target as HTMLDetailsElement).open) }, el("summary", {}, t("Settings", "설정")), ...this.settingsPart()) : null;
    const buttons = this.buttons?.() ?? [];
    const pressable = buttons.length ? el("div", { className: "row", style: "margin-bottom:10px;flex-wrap:wrap" }, ...buttons.map((b) => el("button", { title: t(`Script: ${b.script}`, `스크립트: ${b.script}`), onclick: () => b.press() }, b.label))) : null;
    const main = el("main", {}, part, pressable, el("div", { className: "pick", style: "margin-bottom:8px" }, el("span", { className: "note" }, t("after", "기준 메시지")), select), ...this.body());
    const win = el("div", { className: `win${this.tabs ? " tabbed" : ""}`, role: "dialog", "aria-modal": "true", "aria-label": t("Status", "상태창"), tabIndex: -1 }, head, main);
    const back = el("div", { className: "back", onclick: (e: Event) => e.target === back && this.close() }, win);
    this.root.replaceChildren(el("style", {}, STYLE), back);
    const newMain = this.root.querySelector("main");
    if (newMain) newMain.scrollTop = scroll;
  }

  private body(): HTMLElement[] {
    if (!this.loaded) return [el("div", { className: "note" }, t("Reading…", "읽는 중…"))];
    if (!this.chatId) return [el("div", { className: "note" }, t("Open a chat first.", "먼저 채팅을 여세요."))];
    const view = this.view;
    if (!view)
      return [
        el(
          "div",
          { className: "note" },
          t(
            "This chat has no Pesto: turn it on in the settings, for a card with a pesto:schema lorebook entry.",
            "이 채팅에는 Pesto가 없어요. 설정에서 켜고, 로어북에 pesto:schema 항목이 있는 카드로 써 보세요.",
          ),
        ),
        ...(this.cast.length ? [this.starterSection()] : []),
      ];
    return [this.valuesSection(view), this.turnSection(view), ...this.graphSection(), this.trySection(), ...(this.card ? [this.cardSection(this.card)] : []), ...(this.code ? [this.codeSection(this.code)] : [])];
  }

  private valuesSection(view: StoryView): HTMLElement {
    const rows: HTMLElement[] = [];
    const mine = new Set(view.edits.map((e) => e.path));
    const walk = (field: Field, values: Record<string, unknown>, prefix: string) => {
      for (const [name, f] of Object.entries(field.fields ?? {})) {
        const path = prefix ? `${prefix}.${name}` : name;
        const value = values?.[name];
        if (f.kind === "object") {
          walk(f, value && typeof value === "object" ? (value as Record<string, unknown>) : {}, path);
          continue;
        }
        const writable = fieldAt(view.def.schema.root, path.split("."))?.write.includes("user") ?? false;
        rows.push(el("div", { className: "path", title: t(`Marinara variable: ${varName(path)}`, `마리나라 변수: ${varName(path)}`) }, path), this.input(f, path, value, writable), this.badges(f, path, mine.has(path), writable));
      }
    };
    walk(view.def.schema.root, view.values, "");
    for (const [name, v] of Object.entries(view.derived)) rows.push(el("div", { className: "path" }, name), el("div", { className: "computed" }, show(v)), el("span", { className: "badge" }, t("computed", "계산값")));
    return section(
      t("Values", "값"),
      t(
        "Set a value here: it is kept on this message as your change, counted after the AI's. ✕ takes your change back",
        "여기서 값을 바꾸면 이 메시지에 내 변경으로 저장되고, AI의 변경 다음에 적용돼요. ✕를 누르면 내 변경을 되돌려요",
      ),
      [],
      el("div", { className: "vals" }, ...rows),
    );
  }

  private input(f: Field, path: string, value: unknown, writable: boolean): HTMLElement {
    const label = t(`Value of ${path}`, `${path} 값`);
    const commit = (text: string) => {
      let v: unknown;
      try {
        v = typedValue(f, text);
      } catch (e) {
        showToast(e instanceof Error ? e.message : String(e), "warning");
        return;
      }
      void this.save(path, v);
    };
    if (f.kind === "enum" || f.kind === "bool") {
      const options = f.kind === "bool" ? ["true", "false"] : (f.values ?? []);
      return el(
        "select",
        { "aria-label": label, "data-key": `story-${path}`, disabled: !writable, onchange: (e: Event) => commit((e.target as HTMLSelectElement).value) },
        ...options.map((o) => el("option", { value: o, selected: String(value) === o }, o)),
      );
    }
    if (f.kind === "number" || f.kind === "int" || f.kind === "text")
      return el("input", {
        type: f.kind === "text" ? "text" : "number",
        value: value === null || value === undefined ? "" : String(value),
        "aria-label": label,
        "data-key": `story-${path}`,
        disabled: !writable,
        onchange: (e: Event) => commit((e.target as HTMLInputElement).value),
      });
    return el("textarea", {
      value: JSON.stringify(value ?? null),
      "aria-label": label,
      "data-key": `story-${path}`,
      disabled: !writable,
      onchange: (e: Event) => commit((e.target as HTMLTextAreaElement).value),
    });
  }

  private badges(f: Field, path: string, mine: boolean, writable: boolean): HTMLElement {
    const out = el("span", { className: "row" });
    if (mine)
      out.append(
        el("span", { className: "badge mine" }, t("your change", "내 변경")),
        el("button", { className: "mini ghost", title: t("Take your change back", "내 변경 되돌리기"), "aria-label": t(`Take back your change of ${path}`, `${path}의 내 변경 되돌리기`), onclick: () => void this.save(path, null) }, "✕"),
      );
    else if (!writable) out.append(el("span", { className: "badge" }, t("fixed", "고정")));
    if (f.hidden || path.split(".").some((p) => p.startsWith("_"))) out.append(el("span", { className: "badge" }, t("hidden from the AI", "AI에게 숨김")));
    return out;
  }

  /** The card's code: what it is, and whether it may run. */
  /** The number values over the chat, a small graph each; a click shows that message. */
  private graphSection(): HTMLElement[] {
    const h = this.history;
    if (!h || h.ids.length < 2) return [];
    const shownId = this.messageId ?? h.ids.at(-1)!;
    const pick = (i: number) => {
      const id = h.ids[i];
      this.messageId = id === this.messages.at(-1)?.id ? null : id;
      void this.load();
    };
    const graphs = Object.entries(h.series)
      .filter(([, values]) => values.filter((v) => v !== null).length >= 2)
      .slice(0, 12)
      .map(([path, values]) => valueGraph({ path, values, nums: h.nums, selected: Math.max(0, h.ids.indexOf(shownId)), pick }))
      .filter((g): g is HTMLElement => !!g);
    if (!graphs.length) return [];
    return [
      section(
        t("Over the chat", "흐름"),
        t(
          `The number values over the last ${h.ids.length} messages; the dashed line is the message shown above. Point at a graph for a message's value, click to show that message`,
          `최근 메시지 ${h.ids.length}개 동안의 숫자 값이에요. 점선은 위에서 고른 메시지예요. 그래프에 올리면 그 메시지의 값이 보이고, 누르면 그 메시지로 가요`,
        ),
        [],
        el("div", { className: "graphs" }, ...graphs),
      ),
    ];
  }

  /** For card makers: a reply tried after the chosen message, without saving anything. */
  private trySection(): HTMLElement {
    const box = el("textarea", {
      className: "try",
      rows: 4,
      "aria-label": t("A reply to try", "시험할 답장"),
      "data-key": "story-try-text",
      placeholder: t("Falls down.\n```pesto\nhp -= 5\n```", "넘어졌다.\n```pesto\nhp -= 5\n```"),
      oninput: (e: Event) => (this.tryText = (e.target as HTMLTextAreaElement).value),
    }) as HTMLTextAreaElement;
    box.value = this.tryText;
    const run = async () => {
      const chatId = this.chatId;
      if (!chatId || !this.tryText.trim()) return;
      try {
        const out = await storyAccess()?.tryReply?.(chatId, this.messageId, this.tryText);
        this.tried = out ? { turn: out.turn, values: out.values } : null;
      } catch (e) {
        showToast(e instanceof Error ? e.message : String(e), "warning");
      }
      this.render();
    };
    const tried = this.tried;
    const by = (c: Change | Problem) => (c.by === "ai" ? "AI" : c.by === "rules" ? t("rules", "규칙") : c.by === "user" ? t("you", "나") : "");
    return section(
      t("Try a reply", "답장 시험해 보기"),
      t(
        "For making a card: paste a reply (with its block) to see what it would change after the message chosen above, and what would be refused. Nothing is saved, and the card's code runs without its effects",
        "카드를 만들 때 써요. 답장(블록 포함)을 붙여 넣으면, 위에서 고른 메시지 다음에 왔을 때 무엇이 바뀌고 무엇이 거부되는지 보여 줘요. 아무것도 저장하지 않고, 카드 코드는 효과 없이 돌아요",
      ),
      [el("button", { className: "mini", "data-key": "story-try", onclick: () => void run() }, t("Try", "시험"))],
      box,
      tried
        ? el(
            "div",
            { className: "tried" },
            tried.turn.changes.length
              ? el("ul", { className: "log" }, ...tried.turn.changes.map((c) => el("li", {}, `${c.path}: ${show(c.from)} → ${show(c.to)} · ${by(c)}${c.event ? ` (${c.event})` : ""}${c.clamped ? t(" · kept within limits", " · 범위 안으로") : ""}`)))
              : el("div", { className: "note" }, t("It would change nothing.", "바뀌는 값이 없어요.")),
            tried.turn.problems.length ? el("div", { className: "note" }, t("Would not be applied:", "적용 안 될 것:")) : null,
            tried.turn.problems.length ? el("ul", { className: "log" }, ...tried.turn.problems.map((p) => el("li", { className: "bad" }, `${p.path ?? (p.event ? `do ${p.event}` : "")}${p.path || p.event ? ": " : ""}${p.detail ?? p.why}`))) : null,
            tried.turn.effects?.length ? el("div", { className: "note" }, t(`Effects it would ask for: ${tried.turn.effects.map((e) => e.cmd).join(", ")}`, `부탁할 효과: ${tried.turn.effects.map((e) => e.cmd).join(", ")}`)) : null,
          )
        : null,
    );
  }

  /** For a card without Pesto: its four entries added to its lorebook, turned off, with examples to write over. */
  private starterSection(): HTMLElement {
    const chatId = this.chatId;
    const add = async (c: CharacterInfo) => {
      if (!chatId || this.adding) return;
      this.adding = true;
      this.render();
      try {
        const { added, where } = await addStarterEntries(chatId, c);
        const names = added.map((k) => `pesto:${k}`).join(", ");
        const place = where === "card" ? t(`${c.name}'s lorebook`, `${c.name}의 로어북`) : t("this chat's lorebook", "이 채팅 로어북");
        showToast(added.length ? t(`Added ${names} to ${place} (turned off).`, `${place}에 ${names}를 넣었어요(꺼진 상태).`) : t(`${place} already has them.`, `${place}에 이미 있어요.`), "info");
      } catch (e) {
        showToast(e instanceof Error ? e.message : String(e), "warning");
      }
      this.adding = false;
      await this.load();
    };
    return section(
      t("Add Pesto entries", "Pesto 항목 넣기"),
      t(
        "Adds pesto:schema, pesto:start, pesto:rules and pesto:code to the card's lorebook, turned off, each with an example to write over. Only pesto:schema is needed: delete the others if you don't use them",
        "카드 로어북에 pesto:schema, pesto:start, pesto:rules, pesto:code를 꺼진 상태로 넣어요. 안에 예시가 있으니 고쳐 쓰세요. 꼭 필요한 건 pesto:schema뿐이고, 나머지는 쓰지 않으면 지워도 돼요",
      ),
      this.cast.map((c) =>
        el(
          "button",
          { className: "mini", "data-key": `story-starter-${c.id}`, disabled: this.adding, onclick: () => void add(c) },
          this.cast.length > 1 ? t(`Add to ${c.name}`, `${c.name}에 넣기`) : t("Add", "넣기"),
        ),
      ),
      el("div", { className: "note" }, t("Only pesto:schema is needed; delete the others if you don't use them.", "꼭 필요한 건 pesto:schema뿐이에요. 나머지는 쓰지 않으면 지워도 돼요.")),
    );
  }

  /** The card's entries: what is wrong in them, and a card read from its own variable data written as Fornello's entries, to copy. */
  private cardSection(card: { problems: DefinitionProblem[]; from?: "initvar" | "tags"; schemaFrom?: "script"; schema?: string; start?: string }): HTMLElement {
    const copy = (text: string) =>
      void navigator.clipboard
        .writeText(text)
        .then(() => showToast(t("Copied.", "복사했어요."), "info"))
        .catch(() => showToast(t("Could not copy: select the text and copy it.", "복사하지 못했어요. 글을 골라서 복사해 주세요."), "warning"));
    const from = card.from === "initvar" ? t("the card's [InitVar] entries", "카드의 [InitVar] 항목") : card.from === "tags" ? t("the starting tags of the first message", "첫 메시지의 시작 태그") : "";
    return section(
      t("The card's entries", "카드 항목"),
      t(
        "What is wrong in the card's Pesto entries; for a card read from another system's data, that data written as pesto:schema and pesto:start, to copy into its lorebook",
        "카드의 Pesto 항목에서 문제 있는 곳이에요. 다른 방식의 데이터로 읽은 카드라면, 그 데이터를 pesto:schema와 pesto:start로 바꾼 것을 복사해 로어북에 넣을 수 있어요",
      ),
      [
        ...(card.schema ? [el("button", { className: "mini", "data-key": "story-copy-schema", onclick: () => copy(card.schema!) }, t("Copy pesto:schema", "pesto:schema 복사"))] : []),
        ...(card.start ? [el("button", { className: "mini", "data-key": "story-copy-start", onclick: () => copy(card.start!) }, t("Copy pesto:start", "pesto:start 복사"))] : []),
      ],
      from ? el("div", { className: "note" }, t(`Read from ${from}.`, `${from}에서 읽었어요.`)) : null,
      card.schemaFrom ? el("div", { className: "note" }, t("Kinds and ranges from the card's script.", "종류와 범위는 카드 스크립트에서 읽었어요.")) : null,
      card.problems.length
        ? el("ul", { className: "log" }, ...card.problems.map((p) => el("li", { className: "bad" }, `pesto:${p.entry} ${p.path || t("(top)", "(맨 위)")}: ${p.why}`)))
        : el("div", { className: "note" }, t("No problems.", "문제없어요.")),
      card.schema ? el("pre", { className: "code" }, card.schema) : null,
    );
  }

  private codeSection(code: { code: string; allowed: boolean | undefined; hash: string }): HTMLElement {
    const answer = (allow: boolean | null) =>
      void storyAccess()
        ?.answerCode?.(code.hash, allow)
        .then(() => this.load())
        .catch((e: unknown) => showToast(e instanceof Error ? e.message : String(e), "warning"));
    const state = code.allowed === true ? t("Runs", "실행 중") : code.allowed === false ? t("Not allowed", "허락 안 함") : t("Not answered yet", "아직 답하지 않음");
    return section(
      t("The card's code", "카드의 코드"),
      t(
        "pesto:code: run after each reply in a Worker cut off from the network; its changes are checked like the rules', its effects are page commands, run once for a new reply",
        "pesto:code: 답변마다 네트워크가 막힌 Worker에서 돌아요. 바꾸는 값은 규칙처럼 검사하고, 효과는 페이지 명령으로 새 답변에 한 번만 실행해요",
      ),
      [
        el("span", { className: "badge" }, state),
        code.allowed === true
          ? el("button", { className: "mini", "data-key": "story-code-stop", onclick: () => answer(false) }, t("Stop allowing", "허락 취소"))
          : el("button", { className: "mini", "data-key": "story-code-allow", onclick: () => answer(true) }, t("Allow", "허락")),
      ],
      el("pre", { className: "code" }, code.code),
    );
  }

  private turnSection(view: StoryView): HTMLElement {
    const turn = view.turn;
    const by = (c: Change | Problem) =>
      // a reply without its own block: what "the AI" changed is the helper model's block
      c.by === "ai" ? (view.filled !== undefined ? t("helper model", "보조 모델") : "AI") : c.by === "rules" ? t("rules", "규칙") : c.by === "user" ? t("you", "나") : c.by === "start" ? t("start", "시작") : "";
    const changes = (turn?.changes ?? []).map((c) =>
      el("li", {}, `${c.path}: ${show(c.from)} → ${show(c.to)} · ${by(c)}${c.event ? ` (${c.event})` : ""}${c.clamped ? t(" · kept within limits", " · 범위 안으로") : ""}`),
    );
    const problems = (turn?.problems ?? []).map((p) => el("li", { className: "bad" }, `${p.path ?? (p.event ? `do ${p.event}` : "")}${p.path || p.event ? ": " : ""}${p.detail ?? p.why} · ${by(p)}`));
    const dice = turn?.dice ? Object.entries(turn.dice).map(([k, v]) => `${k} ${show(v)}`).join(", ") : "";
    return section(
      t("This message", "이 메시지"),
      undefined,
      [],
      dice ? el("div", { className: "note" }, t(`Dice: ${dice}`, `주사위: ${dice}`)) : null,
      view.filled === undefined
        ? null
        : el(
            "div",
            { className: "note" },
            view.filled
              ? t("The reply had no change block: the helper model filled one in.", "답장에 변경 블록이 없어서 보조 모델이 채웠어요.")
              : t("The reply had no change block: the helper model found no change.", "답장에 변경 블록이 없었고, 보조 모델도 바뀐 걸 찾지 못했어요."),
          ),
      changes.length ? el("ul", { className: "log" }, ...changes) : el("div", { className: "note" }, t("It changed nothing.", "바꾼 값이 없어요.")),
      problems.length ? el("div", { className: "note" }, t("Not applied:", "적용 안 됨:")) : null,
      problems.length ? el("ul", { className: "log" }, ...problems) : null,
    );
  }
}
