// Marinara's own character import (its import window) with pictures: a .charx, a JPEG card or a
// card's .zip bundle picked or dropped there is brought in by Fornello (card-import.ts), so the
// pictures land in the character's Gallery; JSON, PNG and .marinara files stay Marinara's.
// Marinara's window: packages/client/src/components/modals/ImportCharacterModal.tsx (a file
// input accepting ".json,.png,.marinara,.charx", a drop zone, both inside a role="dialog" modal).

import { t } from "../shared/i18n";
import type { Settings } from "../settings";
import { showToast } from "../ui/toast";
import { readCardFile } from "../assets/card-file";
import { cardImportMessage, importCardFile } from "../assets/card-import";
import { onScreenChange } from "./screen-watch";

const OURS = /\.(charx|zip|jpe?g)$/i;
const MARK = "fornelloImport";

/** Marinara's character import input (marked once seen, since its accept is widened). */
function isImportInput(el: unknown): el is HTMLInputElement {
  if (!(el instanceof HTMLInputElement) || el.type !== "file") return false;
  return el.dataset[MARK] === "1" || (/\.charx\b/.test(el.accept) && /\.marinara\b/.test(el.accept));
}

/**
 * The picker takes .zip and JPEG too. On a touch screen it filters nothing: Android's picker greys out
 * files whose type it doesn't know (.charx, .zip…) when filtered by extension, and what a file holds is
 * looked at after anyway.
 */
function widen(input: HTMLInputElement): void {
  if (input.dataset[MARK] === "1") return;
  input.dataset[MARK] = "1";
  if (window.matchMedia?.("(pointer: coarse)").matches) input.removeAttribute("accept");
  else input.accept = `${input.accept},.zip,.jpg,.jpeg`;
}

async function importFiles(files: File[]): Promise<void> {
  for (const file of files) {
    showToast(t(`${file.name}: Fornello is bringing it in with its pictures…`, `${file.name}: Fornello가 그림까지 함께 가져오는 중…`), "info");
    try {
      const found = await readCardFile(file.name, new Uint8Array(await file.arrayBuffer()));
      if (!found.card) {
        showToast(t(`${file.name}: no character card found in it.`, `${file.name}: 캐릭터 카드를 찾지 못했어요.`), "warning");
        continue;
      }
      const result = await importCardFile(found, file, null);
      showToast(cardImportMessage(found.name, result), result.failed.length ? "warning" : "success");
      if (result.failed.length) console.warn("[Fornello] card import", result.failed);
    } catch (e) {
      showToast(t(`${file.name}: not imported (${e instanceof Error ? e.message : e})`, `${file.name}: 가져오지 못했어요 (${e instanceof Error ? e.message : e})`), "warning");
    }
  }
}

/** Starts watching Marinara's import window; returns what stops it. */
export function hookCharacterImport(settings: Settings): () => void {
  const on = () => settings.current.marinaraImport;
  const scan = () => {
    if (!on()) return;
    for (const input of document.querySelectorAll<HTMLInputElement>('input[type="file"]')) if (isImportInput(input)) widen(input);
  };
  const stopWatch = onScreenChange(scan);
  scan();

  // picked: ours are taken before Marinara sees the change; the rest go on to it as they were
  const onChange = (e: Event) => {
    const input = e.target;
    if (!on() || !isImportInput(input) || !input.files?.length) return;
    const files = [...input.files];
    const ours = files.filter((f) => OURS.test(f.name));
    if (!ours.length) return;
    e.stopImmediatePropagation();
    const rest = files.filter((f) => !ours.includes(f));
    if (rest.length) {
      const dt = new DataTransfer();
      for (const f of rest) dt.items.add(f);
      input.files = dt.files;
      input.dispatchEvent(new Event("change", { bubbles: true }));
    } else input.value = "";
    void importFiles(ours);
  };
  // dropped on the import window: the same
  const onDrop = (e: DragEvent) => {
    if (!on() || !e.dataTransfer?.files.length) return;
    const input = [...document.querySelectorAll('input[type="file"]')].find(isImportInput);
    const dialog = input?.closest('[role="dialog"]');
    if (!dialog || !(e.target instanceof Node) || !dialog.contains(e.target)) return;
    const files = [...e.dataTransfer.files];
    const ours = files.filter((f) => OURS.test(f.name));
    if (!ours.length) return;
    e.preventDefault();
    e.stopImmediatePropagation();
    const rest = files.filter((f) => !ours.includes(f));
    if (rest.length) {
      const dt = new DataTransfer();
      for (const f of rest) dt.items.add(f);
      e.target.dispatchEvent(new DragEvent("drop", { bubbles: true, cancelable: true, dataTransfer: dt }));
    }
    void importFiles(ours);
  };
  document.addEventListener("change", onChange, true);
  document.addEventListener("drop", onDrop, true);
  return () => {
    stopWatch();
    document.removeEventListener("change", onChange, true);
    document.removeEventListener("drop", onDrop, true);
  };
}
