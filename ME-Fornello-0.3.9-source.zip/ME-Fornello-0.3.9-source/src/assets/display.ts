// How character assets show in chat messages. Everything starts off, so a
// chat looks as before until the person turns a way on.

import { PER_REPLY } from "./rule";

/** Where a reply's expression sprite goes: not shown, or above / below the reply. */
export type ExpressionPlace = "off" | "above" | "below";

/** Where the AI is told the picture names: each card's own lorebook, the chat's, or nowhere. */
export type RulePlace = "card" | "chat" | "off";

export interface AssetDisplay {
  /** [img:name] (and the other cards' forms) become the picture. */
  tags: boolean;
  /** The expression Marinara's Expression agent chose for a reply. */
  expressions: ExpressionPlace;
  /** Assets with words show when a reply uses one. */
  words: boolean;
  /** The widest a picture shows (px). */
  width: number;
  /** Where the AI learns the names (while tags are on). */
  tell: RulePlace;
  /** The most pictures the AI is asked to put in one reply. */
  perReply: number;
}

export const DEFAULT_ASSET_DISPLAY: AssetDisplay = { tags: false, expressions: "off", words: false, width: 320, tell: "card", perReply: PER_REPLY.default };
export const ASSET_WIDTH = { min: 80, max: 1200 };

export function normalizeAssetDisplay(raw: unknown): AssetDisplay {
  const r = (raw && typeof raw === "object" ? raw : {}) as Record<string, unknown>;
  const width = Number(r.width);
  const perReply = Number(r.perReply);
  return {
    tags: r.tags === true,
    expressions: r.expressions === "above" || r.expressions === "below" ? r.expressions : "off",
    words: r.words === true,
    width: Number.isFinite(width) ? Math.max(ASSET_WIDTH.min, Math.min(ASSET_WIDTH.max, Math.round(width))) : DEFAULT_ASSET_DISPLAY.width,
    tell: r.tell === "chat" || r.tell === "off" ? r.tell : "card",
    perReply: Number.isFinite(perReply) ? Math.max(PER_REPLY.min, Math.min(PER_REPLY.max, Math.round(perReply))) : PER_REPLY.default,
  };
}

/** Whether any way is on (otherwise the chat isn't looked at for assets). */
export const assetsOn = (d: AssetDisplay) => d.tags || d.words || d.expressions !== "off";
