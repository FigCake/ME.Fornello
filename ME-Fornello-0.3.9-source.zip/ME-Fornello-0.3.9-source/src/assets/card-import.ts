// Bringing a card file in: a new character made from it (or one there is), its pictures uploaded
// (emotions as sprites, the rest to the Gallery, listed under their names), a bundle's lorebooks
// linked to the character and its QR sets handed to Dispensa (on in that character's chats). Used by the assets tab and by
// Marinara's own character import (import-hook.ts).

import { importCharacter, importLorebook } from "../api/library";
import { t } from "../shared/i18n";
import { type CardFile, picturesToImport } from "./card-file";
import { listFile } from "./edit";
import type { Asset } from "./model";
import { readAssets, saveAssets, setPortrait, uploadSprite, uploadToGallery } from "./store";

export interface CardImportResult {
  characterId: string;
  /** Pictures to upload, and how many went. */
  total: number;
  done: number;
  /** Pictures there already, not uploaded again. */
  skipped: number;
  failed: string[];
  /** What came in besides the pictures (lorebooks, QR sets), for the message. */
  extras: string[];
  /** A picture or a sprite is new: the chat should draw again. */
  changed: boolean;
}

/**
 * `into`: the character to put the pictures in, with its asset list; null makes one from the card.
 * `file`: the file picked (a bundle's card goes as its own file). `progress` says what is being done.
 */
export async function importCardFile(found: CardFile, file: File, into: { id: string; assets: Asset[] } | null, progress: (what: string) => void = () => undefined): Promise<CardImportResult> {
  let target = into?.id ?? "";
  if (!into) {
    progress(t("Making the character…", "캐릭터 만드는 중…"));
    const cardFile = found.source ? new File([found.source.bytes.slice()], found.source.name, { type: "image/png" }) : file;
    // a PNG card goes as it is (Marinara takes its picture as the portrait); otherwise its JSON
    // a bundle's world info file is the card's book: Marinara isn't to make the embedded one too
    target = (await importCharacter(found.form === "png" ? cardFile : (found.card ?? {}), cardFile.name, !found.lorebooks?.length)) ?? "";
    if (!target) throw new Error(t("Marinara made no character", "마리나라가 캐릭터를 만들지 않았어요"));
    // from a .charx or a JPEG card Marinara gets only the JSON: the portrait goes in after
    if (found.form !== "png" && found.portrait) {
      const portrait = found.portrait;
      await setPortrait(target, portrait.bytes, portrait.type).catch(() => undefined);
    }
  }
  const todo = picturesToImport(found.pictures, into?.assets ?? []);
  const added: Asset[] = [];
  const failed: string[] = [];
  let sprites = 0;
  let done = 0;
  for (const [i, p] of todo.entries()) {
    progress(t(`Importing ${i + 1} of ${todo.length}…`, `${todo.length}장 중 ${i + 1}장 가져오는 중…`));
    try {
      if (p.kind === "emotion") {
        await uploadSprite(target, p.name, p.bytes, p.type);
        sprites++;
      } else {
        const pic = await uploadToGallery(target, new Blob([p.bytes.slice()], { type: `image/${p.type}` }), p.fileName, p.prompt ?? "");
        added.push({ name: p.name, file: pic.file, place: "gallery", hash: p.hash });
      }
      done++;
    } catch (e) {
      failed.push(`${p.name}: ${e instanceof Error ? e.message : e}`);
    }
  }
  if (added.length) {
    try {
      // onto the list as it is now (read again: it may have changed meanwhile)
      const now = await readAssets(target);
      await saveAssets(target, added.reduce((list, a) => listFile(list, "gallery", a.file, a.name, a.hash), now));
    } catch (e) {
      failed.push(t(`The names were not saved (the pictures are in the Gallery): ${e instanceof Error ? e.message : e}`, `이름을 저장하지 못했어요 (그림은 갤러리에 있어요): ${e instanceof Error ? e.message : e}`));
    }
  }
  const extras: string[] = [];
  for (const book of found.lorebooks ?? []) {
    progress(t(`Lorebook ${book.name}…`, `로어북 ${book.name}…`));
    await importLorebook(book.json, book.name, target).then(
      (r) => extras.push(r.already ? t(`lorebook ${book.name} (there already)`, `로어북 ${book.name} (이미 있음)`) : t(`lorebook ${book.name}`, `로어북 ${book.name}`)),
      (e) => failed.push(`${book.name}: ${e instanceof Error ? e.message : e}`),
    );
  }
  for (const set of found.qrSets ?? []) {
    const importQrs = window.__dispensa?.importQrs;
    if (typeof importQrs !== "function") {
      failed.push(t(`${set.name}: QR sets need Dispensa`, `${set.name}: QR 세트는 Dispensa가 있어야 가져올 수 있어요`));
      continue;
    }
    await importQrs(set.json, set.name, { characterId: target }).then(
      (n) => (n ? extras.push(t(`QR set ${set.name} (${n})`, `QR 세트 ${set.name} (${n}개)`)) : failed.push(t(`${set.name}: not a QR file`, `${set.name}: QR 파일이 아니에요`))),
      (e) => failed.push(`${set.name}: ${e instanceof Error ? e.message : e}`),
    );
  }
  return { characterId: target, total: todo.length, done, skipped: found.pictures.length - todo.length, failed, extras, changed: added.length > 0 || sprites > 0 };
}

/** The message after an import. */
export function cardImportMessage(name: string, r: CardImportResult): string {
  const pictures = r.total ? t(`Imported ${r.done} of ${r.total} pictures from ${name}.`, `${name}에서 그림 ${r.total}장 중 ${r.done}장 가져옴.`) : t(`${name}: no new pictures.`, `${name}: 새 그림 없음.`);
  const failed = r.failed.length ? t(` ${r.failed.length} failed: ${r.failed.join("; ")}`, ` 실패 ${r.failed.length}개: ${r.failed.join("; ")}`) : "";
  return pictures + (r.extras.length ? ` + ${r.extras.join(", ")}` : "") + failed;
}
