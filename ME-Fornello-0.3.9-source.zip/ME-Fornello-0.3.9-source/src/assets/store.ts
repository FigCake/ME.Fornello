// Reading and writing a character's assets in Marinara: its Gallery (list,
// upload, delete), its sprites (list, upload), and the asset list in its
// card. The list is saved without a card version (Marinara keeps one per
// edit otherwise) and as a whole array, since Marinara merges objects but
// replaces arrays.

import { forgetPeople } from "../api/chat-store";
import { characterData, forgetLibrary } from "../api/library";
import { parseObject } from "../api/parse";
import { api } from "../shared/api";
import { getMarinara } from "../shared/marinara-global";
import { refreshQueries } from "../shared/react-bridge";
import { t } from "../shared/i18n";
import { type Asset, CARD_KEY, cardAssets, spriteAssets } from "./model";

const enc = encodeURIComponent;

export interface GalleryPicture {
  /** The Gallery's id for it (for deleting). */
  id: string;
  /** Its file name, which an asset points at. */
  file: string;
  url: string;
  /** What Marinara keeps with it (a generation prompt). */
  prompt: string;
}

const toPicture = (raw: Record<string, unknown>): GalleryPicture | null => {
  const file = String(raw.filePath ?? "").split("/").pop() ?? "";
  return raw.id && file ? { id: String(raw.id), file, url: String(raw.url ?? ""), prompt: String(raw.prompt ?? "") } : null;
};

export async function galleryOf(characterId: string): Promise<GalleryPicture[]> {
  const list = await api<Record<string, unknown>[]>(`/characters/${enc(characterId)}/gallery`);
  return (Array.isArray(list) ? list : []).map(toPicture).filter((p): p is GalleryPicture => !!p);
}

export async function spriteListOf(characterId: string): Promise<Asset[]> {
  const list = await api<{ expression?: string; filename?: string }[]>(`/sprites/${enc(characterId)}`).catch(() => []);
  return spriteAssets((Array.isArray(list) ? list : []).map((s) => ({ expression: String(s.expression ?? ""), filename: String(s.filename ?? "") })));
}

/** Uploads a picture to the character's Gallery (a file upload: api() sends JSON only). */
export async function uploadToGallery(characterId: string, file: Blob, fileName: string, prompt = ""): Promise<GalleryPicture> {
  const form = new FormData();
  form.append("prompt", prompt);
  form.append("file", file, fileName);
  const res = await (getMarinara().fetch ?? fetch)(`/api/characters/${enc(characterId)}/gallery/upload`, { method: "POST", headers: { "x-marinara-csrf": "1" }, body: form, credentials: "same-origin" });
  const body = parseObject(await res.json().catch(() => ({})));
  const picture = res.ok ? toPicture(body) : null;
  if (!picture) throw new Error(String(body.error ?? t(`Upload failed (${res.status})`, `올리지 못했어요 (${res.status})`)));
  return picture;
}

/** Bytes as base64, a piece at a time (spreading a large picture into String.fromCharCode at once overflows the stack). */
function base64(bytes: Uint8Array): string {
  let text = "";
  for (let i = 0; i < bytes.length; i += 0x8000) text += String.fromCharCode(...bytes.subarray(i, i + 0x8000));
  return btoa(text);
}

/** Uploads a sprite for an expression (as a data URL; Marinara replaces a sprite of the same expression). `type`: png, jpeg, gif, webp or avif. */
export async function uploadSprite(characterId: string, expression: string, bytes: Uint8Array, type: string): Promise<void> {
  await api(`/sprites/${enc(characterId)}`, { method: "POST", body: { expression, image: `data:image/${type};base64,${base64(bytes)}` } });
}

/** Sets a character's portrait (Marinara's avatar) from a picture's bytes. */
export async function setPortrait(characterId: string, bytes: Uint8Array, type: string): Promise<void> {
  await api(`/characters/${enc(characterId)}/avatar`, { method: "POST", body: { avatar: `data:image/${type};base64,${base64(bytes)}` } });
  forgetPeople();
  refreshQueries([["characters"]]);
}

export async function deleteFromGallery(characterId: string, pictureId: string): Promise<void> {
  await api(`/characters/${enc(characterId)}/gallery/${enc(pictureId)}`, { method: "DELETE" });
}

/** The card's asset list, read fresh. */
export async function readAssets(characterId: string): Promise<Asset[]> {
  return cardAssets(await characterData(characterId));
}

/** Saves the card's asset list (the whole list). */
export async function saveAssets(characterId: string, assets: Asset[]): Promise<void> {
  await api(`/characters/${enc(characterId)}`, { method: "PATCH", body: { data: { extensions: { [CARD_KEY]: { assets } } }, skipVersionSnapshot: true } });
  forgetPeople();
  forgetLibrary("characters");
  refreshQueries([["characters"]]);
}
