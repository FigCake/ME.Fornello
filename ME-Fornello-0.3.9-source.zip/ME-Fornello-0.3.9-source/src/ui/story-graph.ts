// One number value over the chat's messages, drawn small in the Pesto window: a 2px line in
// the theme's accent (one value a graph, so no legend: its path is the title), a crosshair and a
// tooltip ("#12 · 34") under the pointer, the message shown in the window marked, and a click
// choosing that message. Values of different sizes get a graph each, never a second axis.

import { el } from "./dom";

/** The line's path in a 0..100 × 0..100 box (y down), broken where a message has no value. */
export function linePath(values: (number | null)[], lo: number, hi: number): string {
  const n = values.length;
  const x = (i: number) => (n > 1 ? (i / (n - 1)) * 100 : 50);
  const y = (v: number) => 100 - ((v - lo) / (hi - lo)) * 100;
  let d = "";
  let pen = false;
  values.forEach((v, i) => {
    if (v === null) {
      pen = false;
      return;
    }
    d += `${pen ? "L" : "M"}${round(x(i))} ${round(y(v))}`;
    pen = true;
  });
  return d;
}

const round = (v: number) => Math.round(v * 100) / 100;

/** The value range drawn: the values' own, a little room above and below, a flat line in the middle. */
export function rangeOf(values: (number | null)[]): { lo: number; hi: number; min: number; max: number } | null {
  const nums = values.filter((v): v is number => v !== null);
  if (!nums.length) return null;
  const min = Math.min(...nums);
  const max = Math.max(...nums);
  const pad = max === min ? Math.max(1, Math.abs(max) * 0.1) : (max - min) * 0.12;
  return { lo: min - pad, hi: max + pad, min, max };
}

const show = (v: number) => (Number.isInteger(v) ? String(v) : v.toFixed(2).replace(/\.?0+$/, ""));

export interface GraphInput {
  path: string;
  values: (number | null)[];
  /** the messages' numbers, for the tooltip */
  nums: number[];
  /** the message shown in the window (index), marked */
  selected: number;
  pick(index: number): void;
}

export const GRAPH_CSS = `
.graphs { display: grid; grid-template-columns: repeat(auto-fill, minmax(220px, 1fr)); gap: 10px; }
.graph { display: grid; gap: 2px; }
.graph .top { display: flex; align-items: baseline; gap: 6px; font-size: 12px; }
.graph .name { color: var(--d-title); font-family: var(--d-mono); overflow: hidden; text-overflow: ellipsis; white-space: nowrap; flex: 1; }
.graph .now { color: var(--d-text); font-variant-numeric: tabular-nums; }
.graph .span { color: var(--d-muted); font-size: 11px; font-variant-numeric: tabular-nums; }
.graph .plot { position: relative; height: 56px; cursor: pointer; border-bottom: 1px solid var(--d-line); touch-action: pan-y; }
.graph svg { position: absolute; inset: 4px 0; width: 100%; height: calc(100% - 8px); overflow: visible; }
.graph path.line { fill: none; stroke: var(--d-accent); stroke-width: 2; stroke-linejoin: round; stroke-linecap: round; vector-effect: non-scaling-stroke; }
.graph .mark, .graph .hair { position: absolute; top: 0; bottom: 0; width: 0; border-left: 1px dashed var(--d-muted); opacity: .55; pointer-events: none; }
.graph .hair { border-left-style: solid; opacity: .8; display: none; }
.graph .dot { position: absolute; width: 8px; height: 8px; margin: -4px 0 0 -4px; border-radius: 50%; background: var(--d-accent); box-shadow: 0 0 0 2px var(--d-panel, #141414); pointer-events: none; display: none; }
.graph .tip { position: absolute; top: -4px; transform: translate(-50%, -100%); padding: 2px 6px; border-radius: 6px; font-size: 11px; white-space: nowrap; color: var(--d-text); background: var(--d-field); border: 1px solid var(--d-line); pointer-events: none; display: none; font-variant-numeric: tabular-nums; z-index: 1; }
.graph .plot:hover .hair, .graph .plot:hover .dot, .graph .plot:hover .tip { display: block; }
`;

/** A small graph of one value, or null when it never had a number. */
export function valueGraph(g: GraphInput): HTMLElement | null {
  const range = rangeOf(g.values);
  if (!range) return null;
  const n = g.values.length;
  const xPct = (i: number) => (n > 1 ? (i / (n - 1)) * 100 : 50);
  const yPct = (v: number) => 4 / 56 * 100 + (100 - ((v - range.lo) / (range.hi - range.lo)) * 100) * (48 / 56);
  const svg = document.createElementNS("http://www.w3.org/2000/svg", "svg");
  svg.setAttribute("viewBox", "0 0 100 100");
  svg.setAttribute("preserveAspectRatio", "none");
  svg.setAttribute("aria-hidden", "true");
  const line = document.createElementNS("http://www.w3.org/2000/svg", "path");
  line.setAttribute("class", "line");
  line.setAttribute("d", linePath(g.values, range.lo, range.hi));
  svg.append(line);
  const hair = el("div", { className: "hair" });
  const dot = el("div", { className: "dot" });
  const tip = el("div", { className: "tip" });
  const mark = el("div", { className: "mark", style: `left:${xPct(g.selected)}%` });
  // the nearest message that has a value, under the pointer
  const nearest = (clientX: number, box: DOMRect) => {
    const raw = n > 1 ? Math.round(((clientX - box.left) / Math.max(1, box.width)) * (n - 1)) : 0;
    let best = -1;
    for (let d = 0; d < n && best < 0; d++) {
      if (g.values[raw - d] !== null && g.values[raw - d] !== undefined) best = raw - d;
      else if (g.values[raw + d] !== null && g.values[raw + d] !== undefined) best = raw + d;
    }
    return best;
  };
  const point = (i: number) => {
    const v = g.values[i]!;
    for (const x of [hair, dot, tip]) x.style.left = `${xPct(i)}%`;
    dot.style.top = `${yPct(v)}%`;
    tip.textContent = `#${g.nums[i]} · ${show(v)}`;
  };
  const last = [...g.values.keys()].reverse().find((i) => g.values[i] !== null) ?? 0;
  point(last);
  const plot = el(
    "div",
    {
      className: "plot",
      onpointermove: (e: PointerEvent) => {
        const i = nearest(e.clientX, (e.currentTarget as HTMLElement).getBoundingClientRect());
        if (i >= 0) point(i);
      },
      onclick: (e: MouseEvent) => {
        const i = nearest(e.clientX, (e.currentTarget as HTMLElement).getBoundingClientRect());
        if (i >= 0) g.pick(i);
      },
    },
    svg,
    mark,
    hair,
    dot,
    tip,
  );
  const first = g.values.find((v) => v !== null)!;
  return el(
    "div",
    { className: "graph", role: "img", "aria-label": `${g.path}: ${show(first)} → ${show(g.values[last]!)} (${show(range.min)}–${show(range.max)})`, "data-path": g.path },
    el("div", { className: "top" }, el("span", { className: "name", title: g.path }, g.path), el("span", { className: "now" }, show(g.values[last]!)), el("span", { className: "span" }, `${show(range.min)}–${show(range.max)}`)),
    plot,
  );
}
