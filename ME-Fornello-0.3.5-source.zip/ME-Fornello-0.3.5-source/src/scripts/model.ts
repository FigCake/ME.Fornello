// Background scripts (Tavern Helper scripts): their shapes and where they come
// from. No DOM, no Marinara. A card keeps them in data.extensions:
//   tavern_helper: { scripts: [...] }  (or as pairs: [["scripts", [...]], ["variables", {...}]])
//   TavernHelper_scripts: [...]        (some cards carry both)
// One script: { type: "script", id, name, content, enabled, info, button: { enabled, buttons: [{ name, visible }] }, data }
// or { id, name, content, enabled, buttons }. Folders hold more scripts.

import { randomPart, sha256 } from "../hash";
import { t } from "../shared/i18n";

export interface ScriptButton {
  name: string;
  visible: boolean;
}

export interface ScriptDef {
  /** Unique among all scripts: "global:<id>" or "card:<characterId>:<id>". */
  key: string;
  /** The script's own id (getScriptId). */
  id: string;
  name: string;
  code: string;
  /** On as the card (or the person) left it. */
  enabled: boolean;
  /** In a folder that is switched off: it does not run, whatever its own switch says. */
  folderOff?: boolean;
  /** The author's note about it. */
  info: string;
  buttons: ScriptButton[];
  /** Its variables as the card brings them (getVariables({ type: "script" }) starts from these). */
  data: Record<string, unknown>;
  source: "global" | "card" | "chat";
  card?: { characterId: string; characterName: string };
  /** The chat a chat script belongs to. */
  chatId?: string;
}

/** A script the person keeps (in Fornello's settings for every chat, or in one chat). */
export interface GlobalScript {
  id: string;
  name: string;
  code: string;
  enabled: boolean;
  buttons: ScriptButton[];
  /** The author's note about it. */
  info: string;
  /** Its variables to start from (getVariables({ type: "script" })). */
  data: Record<string, unknown>;
}

/** A folder of scripts; switched off, none of them runs. */
export interface ScriptFolder {
  type: "folder";
  id: string;
  name: string;
  enabled: boolean;
  icon: string;
  color: string;
  scripts: GlobalScript[];
}

/** A folder's icon as text: an emoji or letters as they are; a Font Awesome class (Tavern Helper) shows the plain folder. */
export const folderIconText = (icon: string): string => (/\bfa-[\w-]+/.test(icon) || /^[\w-]+(?:\s+[\w-]+)+$/.test(icon.trim()) ? "📁" : icon.trim());

/** What a list of scripts holds: scripts and folders of them (as Tavern Helper's script trees). */
export type LibraryItem = GlobalScript | ScriptFolder;

export const isFolder = (item: LibraryItem): item is ScriptFolder => (item as ScriptFolder).type === "folder";

export interface CardScripts {
  characterId: string;
  characterName: string;
  /** SHA-256 of the card's scripts: changes when any of them does (asked again then). */
  hash: string;
  scripts: ScriptDef[];
  /** The card's own variables (getVariables({ type: "character" })). */
  variables: Record<string, unknown>;
}

const obj = (v: unknown): Record<string, unknown> => (v && typeof v === "object" && !Array.isArray(v) ? (v as Record<string, unknown>) : {});
const str = (v: unknown): string => (typeof v === "string" ? v : v === undefined || v === null ? "" : String(v));

export function normalizeButtons(raw: unknown): ScriptButton[] {
  if (!Array.isArray(raw)) return [];
  const out: ScriptButton[] = [];
  for (const b of raw) {
    const name = str(obj(b).name ?? (typeof b === "string" ? b : "")).trim();
    if (name && !out.some((x) => x.name === name)) out.push({ name, visible: obj(b).visible !== false });
  }
  return out;
}

/** tavern_helper as an object, whichever way the card wrote it. */
function tavernHelper(raw: unknown): Record<string, unknown> {
  if (Array.isArray(raw)) {
    const out: Record<string, unknown> = {};
    for (const pair of raw) if (Array.isArray(pair) && typeof pair[0] === "string") out[pair[0]] = pair[1];
    return out;
  }
  return obj(raw);
}

/** Every script in a list, folders opened; a script in a folder that is switched off comes with `folderOff`. */
function flatten(list: unknown, into: Record<string, unknown>[] = [], folderOn = true): Record<string, unknown>[] {
  if (!Array.isArray(list)) return into;
  for (const item of list) {
    const o = obj(item);
    if (o.type === "folder" || (!("content" in o) && (Array.isArray(o.scripts) || Array.isArray(o.value)))) flatten(o.scripts ?? o.value, into, folderOn && o.enabled !== false);
    else if ("content" in o) into.push(folderOn ? o : { ...o, folderOff: true });
  }
  return into;
}

/** The script objects themselves in a list, in flatten's order (to know each one's place). */
function scriptRefs(list: unknown, into: object[] = []): object[] {
  if (!Array.isArray(list)) return into;
  for (const item of list) {
    if (!item || typeof item !== "object" || Array.isArray(item)) continue;
    const o = item as Record<string, unknown>;
    if (o.type === "folder" || (!("content" in o) && (Array.isArray(o.scripts) || Array.isArray(o.value)))) scriptRefs(o.scripts ?? o.value, into);
    else if ("content" in o) into.push(o);
  }
  return into;
}

/** A card's script lists (newer, older); a script without an id gets its place among all of them, so its switch finds it again. */
function cardLists(ext: Record<string, unknown>): { newer: unknown; older: unknown } {
  const helper = tavernHelper(ext.tavern_helper);
  const places = new Map<object, string>();
  [...scriptRefs(helper.scripts), ...scriptRefs(ext.TavernHelper_scripts)].forEach((o, i) => {
    // (one object in both lists keeps its first place)
    if (!str((o as Record<string, unknown>).id) && !places.has(o)) places.set(o, `${i}`);
  });
  const fill = (list: unknown): unknown => {
    if (!Array.isArray(list)) return list;
    return list.map((item) => {
      const place = item && typeof item === "object" ? places.get(item) : undefined;
      if (place) return { ...item, id: place };
      const o = obj(item);
      if (Array.isArray(o.scripts)) return { ...o, scripts: fill(o.scripts) };
      if (Array.isArray(o.value)) return { ...o, value: fill(o.value) };
      return item;
    });
  };
  return { newer: fill(helper.scripts), older: fill(ext.TavernHelper_scripts) };
}

/** The card's own variables (tavern_helper.variables). */
export const cardVariables = (data: Record<string, unknown>): Record<string, unknown> => obj(tavernHelper(obj(data.extensions).tavern_helper).variables);

/** A card's scripts: the newer list, and the older one for scripts not in it. */
export function scriptsOf(character: { id: string; name: string; data: Record<string, unknown> }): CardScripts | null {
  const ext = obj(character.data.extensions);
  const helper = tavernHelper(ext.tavern_helper);
  const lists = cardLists(ext);
  const raw = [...flatten(lists.newer), ...flatten(lists.older)];
  const scripts: ScriptDef[] = [];
  raw.forEach((s, i) => {
    const id = str(s.id);
    const name = str(s.name).trim() || `Script ${i + 1}`;
    if (scripts.some((x) => x.id === id || (x.name === name && x.code === str(s.content)))) return;
    const button = obj(s.button);
    const buttons = normalizeButtons(Array.isArray(button.buttons) ? button.buttons : s.buttons);
    scripts.push({
      key: `card:${character.id}:${id}`,
      id,
      name,
      code: str(s.content),
      enabled: s.enabled !== false && !s.folderOff,
      ...(s.folderOff ? { folderOff: true } : {}),
      info: str(s.info),
      // a script whose buttons the author switched off shows none
      buttons: button.enabled === false ? [] : buttons,
      data: obj(s.data),
      source: "card",
      card: { characterId: character.id, characterName: character.name },
    });
  });
  if (!scripts.length) return null;
  return {
    characterId: character.id,
    characterName: character.name,
    hash: sha256(scripts.map((s) => `${s.id}\n${s.name}\n${s.code}`).join("\n\n")),
    scripts,
    variables: obj(helper.variables),
  };
}

/** The heading each script's buttons go under (by key): its name, made unique with its card's name, then a number. */
export function scriptHeadings(defs: Pick<ScriptDef, "key" | "name" | "source" | "card">[]): Map<string, string> {
  const count = (names: string[], name: string) => names.filter((n) => n === name).length;
  const plain = defs.map((d) => d.name);
  const named = defs.map((d, i) => {
    if (count(plain, plain[i]) < 2) return plain[i];
    return d.card ? `${d.name} (${d.card.characterName})` : d.source === "chat" ? `${d.name} (${t("this chat", "이 채팅")})` : d.name;
  });
  const out = new Map<string, string>();
  const seen = new Map<string, number>();
  defs.forEach((d, i) => {
    const n = (seen.get(named[i]) ?? 0) + 1;
    seen.set(named[i], n);
    out.set(d.key, n > 1 ? `${named[i]} ${n}` : named[i]);
  });
  return out;
}

/** A kept script as one that runs: in every chat, or (`chatId`) in that chat. A folder switched off turns it off. */
export function globalDef(g: GlobalScript, folder: ScriptFolder | null = null, chatId?: string): ScriptDef {
  const folderOff = folder ? !folder.enabled : false;
  const base = { id: g.id, name: g.name, code: g.code, enabled: g.enabled && !folderOff, ...(folderOff ? { folderOff } : {}), info: g.info, buttons: g.buttons, data: g.data };
  return chatId ? { ...base, key: `chat:${chatId}:${g.id}`, source: "chat", chatId } : { ...base, key: `global:${g.id}`, source: "global" };
}

/** A script in Fornello's shape (code) or Tavern Helper's (content, button: { enabled, buttons }). */
export function normalizeGlobalScript(raw: unknown): GlobalScript | null {
  const r = obj(raw);
  const code = str(r.code ?? r.content);
  const name = str(r.name).trim();
  if (!name && !code.trim()) return null;
  const button = obj(r.button);
  return {
    id: str(r.id) || newScriptId(),
    name: name || "Script",
    code,
    enabled: r.enabled !== false,
    // a script whose buttons the author switched off shows none
    buttons: button.enabled === false ? [] : normalizeButtons(r.buttons ?? button.buttons),
    info: str(r.info),
    data: obj(r.data),
  };
}

/** A list of scripts and folders, from any of the shapes Fornello and Tavern Helper wrote. */
export function normalizeLibrary(raw: unknown): LibraryItem[] {
  if (!Array.isArray(raw)) return [];
  const out: LibraryItem[] = [];
  for (const item of raw) {
    const o = obj(item);
    if (o.type === "folder" || (!("content" in o) && !("code" in o) && Array.isArray(o.scripts))) {
      out.push({
        type: "folder",
        id: str(o.id) || newScriptId(),
        name: str(o.name).trim() || "Folder",
        enabled: o.enabled !== false,
        icon: str(o.icon),
        color: str(o.color),
        scripts: (o.scripts as unknown[]).map(normalizeGlobalScript).filter((g): g is GlobalScript => !!g),
      });
    } else {
      const g = normalizeGlobalScript(o);
      if (g) out.push(g);
    }
  }
  return out;
}

/** Every script in a list, with the folder it is in. */
export function libraryScripts(items: LibraryItem[]): { script: GlobalScript; folder: ScriptFolder | null }[] {
  return items.flatMap((i): { script: GlobalScript; folder: ScriptFolder | null }[] => (isFolder(i) ? i.scripts.map((script) => ({ script, folder: i })) : [{ script: i, folder: null }]));
}

/** The list with each script put through `change` (null takes it out). */
export function mapLibrary(items: LibraryItem[], change: (g: GlobalScript) => GlobalScript | null): LibraryItem[] {
  const one = (g: GlobalScript) => change(g);
  return items.flatMap((i): LibraryItem[] => {
    if (isFolder(i)) return [{ ...i, scripts: i.scripts.map(one).filter((g): g is GlobalScript => !!g) }];
    const g = one(i);
    return g ? [g] : [];
  });
}

/** A list in Tavern Helper's script-tree shape (getScriptTrees). */
export function toScriptTrees(items: LibraryItem[]): Record<string, unknown>[] {
  const script = (g: GlobalScript) => ({
    type: "script",
    enabled: g.enabled,
    name: g.name,
    id: g.id,
    content: g.code,
    info: g.info,
    button: { enabled: true, buttons: g.buttons.map((b) => ({ ...b })) },
    data: structuredClone(g.data),
  });
  return items.map((i) => (isFolder(i) ? { type: "folder", enabled: i.enabled, name: i.name, id: i.id, icon: i.icon, color: i.color, scripts: i.scripts.map(script) } : script(i)));
}

/** A hash of a list (a chat's scripts are asked about again when it changes). */
export const libraryHash = (items: LibraryItem[]): string =>
  sha256(libraryScripts(items).map(({ script: s }) => `${s.id}\n${s.name}\n${s.code}`).join("\n\n"));

// ── a card's scripts, written ──

/** The card's script list as it keeps it (folders and all), older scripts not in the newer list after it. */
export function cardTree(data: Record<string, unknown>): LibraryItem[] {
  const lists = cardLists(obj(data.extensions));
  const newer = normalizeLibrary(lists.newer);
  const known = libraryScripts(newer).map((x) => x.script);
  // older list: a script from a switched-off folder comes switched off; copies of newer scripts are left out
  const older = normalizeLibrary(flatten(lists.older).map(({ folderOff, ...o }) => (folderOff ? { ...o, enabled: false } : o))).filter(
    (i) => isFolder(i) || !known.some((k) => k.id === i.id || (k.name === i.name && k.code === i.code)),
  );
  return [...newer, ...older];
}

/** The card's data with its scripts replaced in the newer list (in the card's shape); the older list is emptied. */
export function withCardTree(data: Record<string, unknown>, items: LibraryItem[]): Record<string, unknown> {
  const ext = { ...obj(data.extensions) };
  const raw = ext.tavern_helper;
  const scripts = toScriptTrees(items);
  if (Array.isArray(raw)) {
    const pairs = raw.filter((p) => !(Array.isArray(p) && p[0] === "scripts"));
    ext.tavern_helper = [...pairs, ["scripts", scripts]];
  } else ext.tavern_helper = { ...obj(raw), scripts };
  // emptied rather than left out: Marinara keeps a field a save leaves out
  if ("TavernHelper_scripts" in ext) ext.TavernHelper_scripts = [];
  return { ...data, extensions: ext };
}

export const newScriptId = (): string => `s${randomPart()}`;
