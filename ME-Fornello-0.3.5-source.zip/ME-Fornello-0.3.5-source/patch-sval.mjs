// Fixes to sval 0.6.12, applied by the build and the tests:
// - a template literal gets its value, not its raw text (`a\nb` holds a line break);
// - a class body sees the class's own name (`static { Name.x = 1 }`);
// - a class made inside an async function (every script runs in one) gets a plain
//   default constructor and field setter, not generators (else `new` throws);
// - a subclass without a constructor passes its arguments to its parent.

const RAW = /(function\*? \w+\(e, t\) \{\n\s*return e\.value\.)raw;/g;
// the plain (non-generator) field setter's name, from the class code outside async functions
const PLAIN_FIELDS = /l\.type === "PropertyDefinition" && !l\.static && (\w+)\(l, t, \{ klass: n, superClass: r \}\);/;
const DEFAULT_SUPER = /const n = r \? tt\(this, r\) : this;/g;
const ASYNC_CLASS = /(\w+ = )function\* \(n\) \{(\n\s*for \(let u = 0; u < i\.length; u\+\+\) \{\n\s*const l = i\[u\];\n\s*l\.type === "PropertyDefinition" && !l\.static && )\(yield\* \w+(\(l, t, \{ klass: n, superClass: r \}\))\);(\n\s*\}\n\s*\};\n\s*let a = )function\* \(\) \{(\n\s*const n = r \? tt\(this, r, \[\.\.\.arguments\]\) : this;\n\s*return )yield\* (s\(n\), n;)/g;
const CLASS_BODY = /(return r && Jt\(a, r\), (?:yield\* )?\w+\(e\.body, )t(, \{ klass: a, superClass: r \}\))/g;

function swap(code, re, wanted, what, replace) {
    let count = 0;
    const out = code.replace(re, (...m) => {
        count++;
        return replace(...m);
    });
    if (count !== wanted) throw new Error(`patch-sval: expected ${wanted} ${what} in sval, found ${count} (sval changed: check whether it still needs this)`);
    return out;
}

export function patchSval(code) {
    const templates = swap(code, RAW, 2, "template spots", (_, head) => `${head}cooked ?? e.value.raw;`);
    const bodies = swap(templates, CLASS_BODY, 2, "class bodies", (_, head, tail) => `${head}(e.id ? ((c) => (c.const(e.id.name, a), c))(new V(t)) : t)${tail}`);
    const plain = PLAIN_FIELDS.exec(bodies)?.[1];
    if (!plain) throw new Error("patch-sval: no plain field setter in sval (sval changed: check whether it still needs this)");
    const supers = swap(bodies, DEFAULT_SUPER, 2, "default constructors", () => "const n = r ? tt(this, r, [...arguments]) : this;");
    return swap(supers, ASYNC_CLASS, 1, "async class constructors", (_, s, loop, args, between, ctor, ret) => `${s}function (n) {${loop}${plain}${args};${between}function () {${ctor}${ret}`);
}

export const svalFile = /[\\/]node_modules[\\/]sval[\\/]dist[\\/]sval\.js$/;
