// Splits an HTML page into what the browser shows (markup, styles) and what
// Fornello runs itself (scripts, inline handlers), which Marinara's CSP blocks.

export interface PageScript {
  /** Inline source, or a URL to fetch. */
  code?: string;
  src?: string;
  /** JSX (and TypeScript) to turn into plain JavaScript before running, as Babel's in-browser compiler would. */
  jsx?: "jsx" | "tsx";
  /** `<script type="module">`: its own scope, top-level await, run after the other scripts. */
  module?: boolean;
}

/** The inert stand-in a script leaves in the page (`data-fornello-script` = its place in `scripts`), for document.currentScript. */
export const SCRIPT_ATTR = "data-fornello-script";

export interface PageHandler {
  /** Index into the elements marked with data-fornello-h. */
  element: number;
  /** "click", "input", … */
  type: string;
  body: string;
}

export interface PreparedPage {
  /** A whole HTML document without scripts or on* attributes. */
  html: string;
  scripts: PageScript[];
  handlers: PageHandler[];
  /** True when there is anything to run. */
  hasBehavior: boolean;
  /** The page loads React from a CDN: it gets Marinara's instead (see host-react.ts). */
  react: boolean;
}

export const HANDLER_ATTR = "data-fornello-h";
/** Every type a browser runs as JavaScript (the HTML standard's list, plus "module"). */
const RUNNABLE = new Set([
  "", "module", "text/javascript", "application/javascript", "text/ecmascript", "application/ecmascript", "application/x-javascript",
  "application/x-ecmascript", "text/x-javascript", "text/x-ecmascript", "text/jscript", "text/livescript",
  "text/javascript1.0", "text/javascript1.1", "text/javascript1.2", "text/javascript1.3", "text/javascript1.4", "text/javascript1.5",
]);
/** Script types Babel compiles in the browser (`<script type="text/babel">`). */
const COMPILED = new Set(["text/babel", "text/jsx", "text/tsx", "text/typescript"]);
/** Babel's in-browser compiler: Fornello compiles those scripts itself, so the 3 MB library is skipped. */
const BABEL_SRC = /@babel\/standalone|babel-standalone|\/babel(\.min)?\.js(\?|#|$)/i;

/** React's browser builds (unpkg, jsdelivr, cdnjs, or a copy named like them). */
const REACT_SRC = /\/react(-dom)?@[^/]*\/umd\/|\/ajax\/libs\/react(-dom)?\/|\/react(-dom)?(\.(production|development|profiling))?(\.min)?\.js(\?|#|$)/i;

/**
 * `100vh` (and dvh, svh, lvh) → Marinara's screen height, so the frame can
 * size itself to the page. Only values change, not names like `.h-100vh`;
 * running it twice changes nothing.
 */
export function screenHeights(css: string): string {
  return css.replace(/(^|[\s(:,/*+>])(-?(?:\d+\.?\d*|\.\d+))[dsl]?vh\b/gi, "$1calc($2 * var(--fornello-vh))");
}

/** The page brings its own document (a doctype, <html> or <body>), so it is not wrapped in one. */
function looksLikeDocument(code: string): boolean {
  return /<!doctype\s+html|<html[\s>]|<body[\s>]/i.test(code);
}

export function preparePage(code: string): PreparedPage {
  const source = looksLikeDocument(code)
    ? code
    : `<!DOCTYPE html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"></head><body>${code}</body></html>`;
  // so the parser never fetches a script
  const doc = new DOMParser().parseFromString(source.replace(/(<script\b[^>]*?\s)src(\s*=)/gi, "$1data-fornello-src$2"), "text/html");
  // <noscript> parses as markup here but as text in the frame, so it could turn into live tags
  for (const el of [...doc.querySelectorAll("noscript")]) el.remove();
  const scripts: PageScript[] = [];
  let react = false;
  for (const el of [...doc.querySelectorAll("script")]) {
    const type = (el.getAttribute("type") ?? "").split(";")[0].trim().toLowerCase();
    // a browser that runs modules skips the fallback for those that do not
    if (el.hasAttribute("nomodule")) {
      el.remove();
      continue;
    }
    if (RUNNABLE.has(type) || COMPILED.has(type)) {
      const src = el.getAttribute("data-fornello-src");
      const presets = el.getAttribute("data-presets") ?? "";
      const jsx = COMPILED.has(type) ? (type === "text/tsx" || type === "text/typescript" || /typescript/i.test(presets) ? "tsx" : "jsx") : undefined;
      if (src && !jsx && BABEL_SRC.test(src)) {
        // nothing to do: the compiled scripts below are compiled by Fornello
      } else if (src && !jsx && REACT_SRC.test(src)) {
        react = true;
      } else if (src || el.textContent?.trim()) {
        const module = type === "module" ? true : undefined;
        scripts.push(src ? { src, jsx, module } : { code: el.textContent ?? "", jsx, module });
        // an empty, inert script stays in its place: document.currentScript (and a page looking for its scripts) finds it
        const stand = doc.createElement("script");
        for (const attr of [...el.attributes]) if (!/^(type|src|data-fornello-src)$/i.test(attr.name)) stand.setAttribute(attr.name, attr.value);
        stand.setAttribute("type", "text/x-fornello");
        stand.setAttribute(SCRIPT_ATTR, String(scripts.length - 1));
        el.replaceWith(stand);
        continue;
      }
      el.remove();
    }
    // other types (templates, JSON data) stay as inert data the page can read
  }
  const handlers: PageHandler[] = [];
  let marked = 0;
  for (const el of [...doc.querySelectorAll("*")]) {
    let mine = false;
    for (const attr of [...el.attributes]) {
      const name = attr.name.toLowerCase();
      if (/^on[a-z]+$/.test(name)) {
        handlers.push({ element: marked, type: name.slice(2), body: attr.value });
        el.removeAttribute(attr.name);
        mine = true;
      } else if ((name === "href" || name === "action" || name === "src") && /^\s*javascript:/i.test(attr.value)) {
        handlers.push({ element: marked, type: "click", body: `event.preventDefault(); ${attr.value.replace(/^\s*javascript:/i, "")}` });
        el.setAttribute(attr.name, "#");
        mine = true;
      }
    }
    if (mine) el.setAttribute(HANDLER_ATTR, String(marked++));
  }
  // A refresh would reload the frame and drop the running page
  for (const meta of [...doc.querySelectorAll("meta[http-equiv]")]) if (/refresh/i.test(meta.getAttribute("http-equiv") ?? "")) meta.remove();
  // 100vh in a frame sized to its page would grow forever: use Marinara's screen height (--fornello-vh)
  for (const el of [...doc.querySelectorAll("style")]) el.textContent = screenHeights(el.textContent ?? "");
  for (const el of [...doc.querySelectorAll("[style]")]) el.setAttribute("style", screenHeights(el.getAttribute("style") ?? ""));
  const html = `<!DOCTYPE html>\n${doc.documentElement.outerHTML}`;
  return { html, scripts, handlers, hasBehavior: scripts.length > 0 || handlers.length > 0, react };
}
