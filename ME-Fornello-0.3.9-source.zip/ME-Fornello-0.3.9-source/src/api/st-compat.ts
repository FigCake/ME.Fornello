// The names SillyTavern card pages call, answered by Fornello's own
// commands. SillyTavern counts messages from 0; Marinara (and the short names) from 1.

import { t } from "../shared/i18n";
import { type Command, cmd, plain } from "./command";
import { toast } from "./commands/chat";
import { stopMyGens, stopRun } from "./commands/generate";
import { beforeGen } from "./commands/replies";
import { uninject } from "./injections";
import { IFRAME_EVENTS, ST_GEN_TYPE, stGenerate, stGenerateRaw, stInjectPrompts } from "./st-generate";
import { addMsg, delMsg, listen, setMsg } from "./commands/messages";
import { changeMsgData, setHidden, showSwipe } from "./commands/msg-data";
import { listSwipes } from "./marinara";
import { changeAny, getAny, setAny } from "./commands/variables";
import { deletePath, insertMissing } from "./var-ops";
import { catchErrors, getShared, reloadPage } from "./commands/tools";
import { shareGlobal } from "./shared-globals";
import { updateChatData } from "./chat-data";
import type { PageSession } from "./session";
import type { Message } from "./types";
import type { WatchKind } from "./chat-watch";
import { runSlash } from "./slash";
import { emitEvent, onEvent } from "./event-bus";
import { stWorldCommands } from "./st-world";

// ── messages and events ──

// SillyTavern's events Marinara has no counterpart for: listening to one leaves a note
const NOT_IN_MARINARA = {
  APP_READY: "app_ready",
  CHAT_CREATED: "chat_created",
  CHAT_DELETED: "chat_deleted",
  GENERATION_STOPPED: "generation_stopped",
  GENERATE_BEFORE_COMBINE_PROMPTS: "generate_before_combine_prompts",
  GENERATE_AFTER_COMBINE_PROMPTS: "generate_after_combine_prompts",
  CHAT_COMPLETION_PROMPT_READY: "chat_completion_prompt_ready",
  CHAT_COMPLETION_SETTINGS_READY: "chat_completion_settings_ready",
  STREAM_TOKEN_RECEIVED: "stream_token_received",
  WORLDINFO_UPDATED: "worldinfo_updated",
  CHARACTER_EDITED: "character_edited",
  SETTINGS_UPDATED: "settings_updated",
  IMPERSONATE_READY: "impersonate_ready",
  GROUP_UPDATED: "group_updated",
};
const TAVERN_EVENTS = Object.freeze({
  MESSAGE_RECEIVED: "message_received",
  MESSAGE_SENT: "message_sent",
  GENERATION_ENDED: "generation_ended",
  CHARACTER_MESSAGE_RENDERED: "character_message_rendered",
  USER_MESSAGE_RENDERED: "user_message_rendered",
  MESSAGE_SWIPED: "message_swiped",
  MESSAGE_EDITED: "message_edited",
  MESSAGE_UPDATED: "message_updated",
  MESSAGE_DELETED: "message_deleted",
  CHAT_CHANGED: "chat_id_changed",
  GENERATION_STARTED: "generation_started",
  GENERATION_AFTER_COMMANDS: "GENERATION_AFTER_COMMANDS",
  ...NOT_IN_MARINARA,
});
/** The moment before a reply (generation-hold.ts): listeners get SillyTavern's (type, options, dryRun). */
const BEFORE_GEN_EVENTS = new Set(["generation_started", "GENERATION_AFTER_COMMANDS"]);
/** SillyTavern's message events, and what Fornello notices that answers them (chat-watch.ts). */
const WATCHED: Record<string, WatchKind> = {
  message_sent: "send",
  user_message_rendered: "send",
  message_received: "msg",
  generation_ended: "msg",
  character_message_rendered: "msg",
  message_swiped: "swipe",
  message_edited: "edit",
  message_updated: "edit",
  message_deleted: "delete",
};
/** Heard but never sent: pages and scripts start afresh in each chat, as in SillyTavern, so none is there when it changes. */
const QUIET_EVENTS = new Set(["chat_id_changed"]);
const MISSING_EVENTS = new Set<string>(Object.values(NOT_IN_MARINARA));

const stRole = (m: Message) => (m.role === "user" ? "user" : m.role === "char" ? "assistant" : "system");

const stMessage = (m: Message) => ({
  message_id: m.num - 1,
  name: m.name,
  role: stRole(m),
  is_hidden: m.hidden,
  message: m.text,
  data: structuredClone(m.data ?? {}),
  extra: {},
});

interface StGetOptions {
  role?: string;
  hide_state?: string;
  include_swipes?: boolean;
}

/** getChatMessages: answered at once from the page's copy of the chat; with include_swipes it waits for Marinara's swipes. */
function stGetMessages(s: PageSession, range: unknown, options: StGetOptions = {}) {
  const list = s.messages;
  const wanted = new Set(stRange(range, list.length - 1));
  const role = options.role ?? "all";
  const hide = options.hide_state ?? "all";
  const found = list.filter((m) => wanted.has(m.num - 1) && (role === "all" || stRole(m) === role) && (hide === "all" || m.hidden === (hide === "hidden")));
  if (!options.include_swipes) return found.map(stMessage);
  return Promise.all(
    found.map(async (m) => {
      const swipes = await listSwipes(s.here(), m.id);
      return {
        message_id: m.num - 1,
        name: m.name,
        role: stRole(m),
        is_hidden: m.hidden,
        swipe_id: m.swipe ?? 0,
        swipes: swipes.map((w) => w.text),
        swipes_data: swipes.map((w) => w.data),
        swipes_info: swipes.map(() => ({})),
      };
    }),
  );
}

interface StSetItem {
  message_id: number;
  message?: unknown;
  is_hidden?: boolean;
  data?: Record<string, unknown>;
  swipe_id?: number;
  swipes?: unknown;
  swipes_data?: unknown;
}

/** setChatMessages: the text, hidden or not, the data (replaced whole) and the swipe on screen. */
async function stSetMessages(s: PageSession, items: StSetItem[], refresh: boolean): Promise<void> {
  const list = Array.isArray(items) ? items : [items];
  if (list.some((item) => item.swipes !== undefined || item.swipes_data !== undefined)) throw new Error(t("Not supported: swipes", "지원 안 함: swipes"));
  for (const item of list) {
    const id = Number(item.message_id);
    const num = id < 0 ? id : id + 1;
    if (item.swipe_id !== undefined) await showSwipe(s, num, item.swipe_id);
    if (item.message !== undefined) await setMsg(s, num, item.message, { refresh });
    if (item.is_hidden !== undefined) await setHidden(s, num, item.is_hidden === true);
    if (item.data !== undefined) {
      const data = item.data ?? {};
      await changeMsgData(s, num, (d) => {
        for (const k of Object.keys(d)) delete d[k];
        Object.assign(d, structuredClone(data));
      });
    }
  }
}

interface StCreateItem {
  role?: string;
  name?: string;
  message?: unknown;
  is_hidden?: boolean;
  data?: Record<string, unknown>;
}

/** createChatMessages: added in order at the end, or before message `insert_before` (from 0, negative from the end). */
async function stCreateMessages(s: PageSession, items: StCreateItem[], options: { insert_before?: number | "end" } = {}): Promise<void> {
  const at = options.insert_before;
  const before = at === undefined || at === "end" ? undefined : Number(at) < 0 ? Number(at) : Number(at) + 1;
  // each goes in before the same message, so they keep their order
  const anchor = before === undefined ? undefined : (await s.byNum(before)).id;
  for (const item of Array.isArray(items) ? items : [items]) {
    const role = item.role === "user" ? "user" : item.role === "system" ? "narrator" : "char";
    const num = anchor ? (await s.freshMessages()).find((m) => m.id === anchor)?.num : undefined;
    // a name is used only when it is one of the chat's characters
    const name = role === "char" && item.name && s.cast.some((c) => c.name === item.name) ? item.name : undefined;
    await addMsg(s, item.message, role, { name, hidden: item.is_hidden === true, data: item.data, before: num });
  }
}

/** SillyTavern message ids (from 0) a range names: 3, -1 (the last), "2-5", "-3--1", "{{lastMessageId}}". Only ids up to `last`. */
export function stRange(range: unknown, last: number): number[] {
  if (range === undefined || range === null || range === "") return Array.from({ length: last + 1 }, (_, i) => i);
  if (typeof range === "number") return [range < 0 ? last + 1 + range : range];
  const m = /^\s*(-?\d+)\s*(?:-\s*(-?\d+))?\s*$/.exec(String(range).replace(/\{\{lastMessageId\}\}/g, String(last)));
  if (!m) return [];
  // a negative end counts from the last message (-1 = the last)
  const end = (n: number) => (n < 0 ? last + 1 + n : n);
  const a = end(Number(m[1]));
  const b = m[2] === undefined ? a : end(Number(m[2]));
  const out: number[] = [];
  // only messages that exist (a range like 0-99999 would otherwise build a huge list)
  for (let i = Math.max(0, Math.min(a, b)); i <= Math.min(last, Math.max(a, b)); i++) out.push(i);
  return out;
}

/** The `SillyTavern` object pages read (getContext(), chatMetadata and its saving). */
function sillyTavern(s: PageSession, saveMetadata: () => unknown) {
  const chatMetadata = s.vars.meta;
  const st = {
    chatId: s.chatId,
    name1: s.me.name,
    name2: s.cast[0]?.name ?? "",
    chatMetadata,
    updateChatMetadata: (patch: Record<string, unknown>, reset = false) => {
      if (reset) for (const k of Object.keys(chatMetadata)) delete chatMetadata[k];
      Object.assign(chatMetadata, patch ?? {});
    },
    saveMetadata,
    saveMetadataDebounced: () => void Promise.resolve().then(saveMetadata).catch(s.report),
    getContext: () => st,
  };
  return st;
}

async function saveMetadata(s: PageSession): Promise<void> {
  if (!s.chatId) return;
  const snapshot = { ...s.vars.meta };
  await updateChatData(s.chatId, (data) => ({ ...data, meta: snapshot }));
}

interface PageListener {
  event: string;
  fn: unknown;
  stop: () => void;
}

/**
 * A page's event listeners: SillyTavern's message events come from Marinara's,
 * its others leave a note, any other name goes to event-bus.ts. All stop with the page.
 */
function pageEvents(s: PageSession) {
  let own: PageListener[] = [];
  s.onDispose(() => {
    for (const l of own.splice(0)) l.stop();
  });
  const off = (pick: (l: PageListener) => boolean) => {
    const gone = own.filter(pick);
    own = own.filter((l) => !gone.includes(l));
    for (const l of gone) l.stop();
  };
  const on = (event: string, fn: (...a: unknown[]) => unknown, once: boolean, place: "first" | "last" | null = null) => {
    const name = String(event);
    // the same listener twice is one listener (eventMakeFirst/Last move it instead)
    const already = own.find((l) => l.event === name && l.fn === fn);
    if (already) {
      if (!place) return { stop: () => off((l) => l === already) };
      off((l) => l === already);
    }
    let stopped = false;
    const entry: PageListener = { event: name, fn, stop: () => {} };
    const stop = () => {
      if (stopped) return;
      stopped = true;
      entry.stop();
      own = own.filter((l) => l !== entry);
    };
    const kind = WATCHED[name];
    if (QUIET_EVENTS.has(name)) return { stop: () => {} };
    if (BEFORE_GEN_EVENTS.has(name)) {
      entry.stop = beforeGen(s, fn, (f, gen) => {
        if (once) stop();
        return f(ST_GEN_TYPE[gen.kind], {}, false);
      });
    } else if (kind) {
      entry.stop = listen(s, kind, (m: Message) => {
        if (once) stop();
        return fn(m.num - 1);
      });
    } else if (MISSING_EVENTS.has(name) || !event) {
      s.report(t(`Not in Marinara: ${name}`, `마리나라에 없음: ${name}`));
      return { stop: () => {} };
    } else {
      entry.stop = onEvent(
        name,
        (...a: unknown[]) => {
          if (once) stop();
          return fn(...a);
        },
        place === "first",
      );
    }
    own.push(entry);
    return { stop };
  };
  return { on, off };
}

/** Those names. `guard` checks SillyTavern.saveMetadata, which is reached through an object, not by name. */
export function stCommands(s: PageSession, guard: (name: string, command: Command) => (...a: unknown[]) => unknown) {
  const save = cmd({ writes: true }, () => saveMetadata(s));
  const events = pageEvents(s);
  return {
    ...stWorldCommands(s),
    generate: cmd({ costs: true }, (config: unknown) => stGenerate(s, config)),
    generateRaw: cmd({ costs: true }, (config: unknown) => stGenerateRaw(s, config)),
    iframe_events: plain(IFRAME_EVENTS),
    injectPrompts: cmd({ writes: true }, (prompts: unknown, options?: { once?: boolean }) => stInjectPrompts(s, prompts, options)),
    uninjectPrompts: cmd({ writes: true }, (ids: unknown) => uninject(s.here(), (Array.isArray(ids) ? ids : [ids]).map(String))),
    stopGenerationById: cmd((id: unknown) => stopRun(s, String(id))),
    // merged all the way down, answered with the variables as they now are
    getVariables: cmd((options?: unknown) => getAny(s, options)),
    insertOrAssignVariables: cmd((values: Record<string, unknown>, options?: unknown) => {
      void setAny(s, values, options, false);
      return getAny(s, options);
    }),
    insertVariables: cmd((values: Record<string, unknown>, options?: unknown) => {
      void changeAny(s, options, (vars) => insertMissing(vars, values ?? {}));
      return getAny(s, options);
    }),
    replaceVariables: cmd((values: Record<string, unknown>, options?: unknown) => {
      void setAny(s, values, options, true);
      return getAny(s, options);
    }),
    deleteVariable: cmd((path: string, options?: unknown) => {
      let occurred = false;
      void changeAny(s, options, (vars) => (occurred = deletePath(vars, path)));
      return { variables: getAny(s, options), delete_occurred: occurred };
    }),
    updateVariablesWith: cmd(async (fn: (vars: Record<string, unknown>) => unknown, options?: unknown) => {
      const next = await fn(getAny(s, options));
      const values = next && typeof next === "object" ? (next as Record<string, unknown>) : getAny(s, options);
      await setAny(s, values, options, true);
      return getAny(s, options);
    }),
    getChatMessages: cmd((range?: unknown, options?: StGetOptions) => stGetMessages(s, range, options)),
    getCurrentMessageId: cmd(() => {
      const num = s.ownNum();
      return num === null ? -1 : num - 1;
    }),
    getLastMessageId: cmd(() => s.messages.length - 1),
    setChatMessage: cmd({ writes: true }, (fields: { message?: unknown } | string, messageId: number, options: { refresh?: string } = {}) => {
      const text = typeof fields === "string" ? fields : fields?.message;
      if (text === undefined) return Promise.resolve(false);
      return setMsg(s, Number(messageId) + 1, text, { refresh: options.refresh !== "none" });
    }),
    setChatMessages: cmd({ writes: true }, (list: StSetItem[], options: { refresh?: string } = {}) => stSetMessages(s, list, options.refresh !== "none")),
    createChatMessages: cmd({ writes: true }, (list: StCreateItem[], options?: { insert_before?: number | "end" }) => stCreateMessages(s, list, options)),
    deleteChatMessages: cmd({ writes: true }, (ids: number[]) => delMsg(s, (Array.isArray(ids) ? ids : [ids]).map((i) => (Number(i) < 0 ? Number(i) : Number(i) + 1)))),
    rotateChatMessages: cmd(() => {
      throw new Error(t("Not supported: rotateChatMessages", "지원 안 함: rotateChatMessages"));
    }),
    triggerSlash: cmd({ writes: true }, (line: unknown) => runSlash(s, line)),
    tavern_events: plain(TAVERN_EVENTS),
    eventOn: cmd((event: string, fn: (...a: unknown[]) => unknown) => events.on(event, fn, false)),
    eventOnce: cmd((event: string, fn: (...a: unknown[]) => unknown) => events.on(event, fn, true)),
    eventMakeFirst: cmd((event: string, fn: (...a: unknown[]) => unknown) => events.on(event, fn, false, "first")),
    eventMakeLast: cmd((event: string, fn: (...a: unknown[]) => unknown) => events.on(event, fn, false, "last")),
    eventEmit: cmd((event: string, ...args: unknown[]) => emitEvent(String(event), args, s.report)),
    eventRemoveListener: cmd((event: string, fn: unknown) => events.off((l) => l.event === String(event) && l.fn === fn)),
    eventClearEvent: cmd((event: string) => events.off((l) => l.event === String(event))),
    eventClearListener: cmd((fn: unknown) => events.off((l) => l.fn === fn)),
    eventClearAll: cmd(() => events.off(() => true)),
    initializeGlobal: cmd((name: unknown, value: unknown) => shareGlobal(String(name), value)),
    waitGlobalInitialized: cmd((name: unknown) => getShared(s, name)),
    errorCatched: cmd((fn: unknown) => catchErrors(s, fn)),
    reloadIframe: cmd(() => reloadPage(s)),
    getTavernHelperVersion: cmd(() => {
      throw new Error(t("Use getVersion().", "getVersion()을 쓰세요."));
    }),
    stopAllGeneration: cmd(() => stopMyGens(s)),
    toastr: plain(
      Object.freeze({
        success: (m: unknown) => toast(s, m, "success"),
        info: (m: unknown) => toast(s, m, "info"),
        warning: (m: unknown) => toast(s, m, "warning"),
        error: (m: unknown) => toast(s, m, "error"),
      }),
    ),
    SillyTavern: plain(sillyTavern(s, guard("saveMetadata", save))),
  };
}
