// Some SillyTavern variable cards describe their values in a card script instead of an entry: a
// schema built with zod calls (z.object, z.coerce.number, z.enum, z.record…) and handed to
// registerMvuSchema(…). The script is never run; its text is read here and turned into a Pesto
// schema, so the values keep their kinds, ranges and defaults:
//
//   z.coerce.number().transform(v => _.clamp(v, -100, 100)).prefault(0)
//     → { type: number, min: -100, max: 100, default: 0 }
//   z.enum(['a', 'b'])                       → { type: enum, of: [a, b] }
//   z.record(z.enum(['x', 'y']), inner)      → a group x, y, each shaped like inner
//   z.record(z.string(), inner)              → { type: map, of: inner }
//
// What isn't understood becomes `any`, so a value is still kept and can still be changed.

type Obj = Record<string, unknown>;

interface Token {
  kind: "name" | "num" | "str" | "punct";
  text: string;
  value?: unknown;
}

/** The script's text as tokens: names, numbers, strings and punctuation (comments left out). */
function tokens(code: string): Token[] {
  const out: Token[] = [];
  let i = 0;
  while (i < code.length) {
    const c = code[i];
    if (/\s/.test(c)) i++;
    else if (c === "/" && code[i + 1] === "/") while (i < code.length && code[i] !== "\n") i++;
    else if (c === "/" && code[i + 1] === "*") {
      const end = code.indexOf("*/", i + 2);
      i = end < 0 ? code.length : end + 2;
    } else if (c === '"' || c === "'" || c === "`") {
      let j = i + 1;
      let text = "";
      while (j < code.length && code[j] !== c) {
        if (code[j] === "\\") {
          const n = code[j + 1] ?? "";
          text += n === "n" ? "\n" : n === "t" ? "\t" : n;
          j += 2;
        } else text += code[j++];
      }
      out.push({ kind: "str", text: code.slice(i, j + 1), value: text });
      i = j + 1;
    } else if (/[\d.]/.test(c) && /\d/.test(c === "." ? (code[i + 1] ?? "") : c)) {
      const m = /^(?:0[xX][\da-fA-F]+|\d*\.?\d+(?:[eE][+-]?\d+)?)/.exec(code.slice(i))!;
      out.push({ kind: "num", text: m[0], value: Number(m[0]) });
      i += m[0].length;
    } else if (/[\p{L}_$]/u.test(c)) {
      const m = /^[\p{L}\p{N}_$]+/u.exec(code.slice(i))!;
      out.push({ kind: "name", text: m[0] });
      i += m[0].length;
    } else if (code.startsWith("=>", i)) {
      out.push({ kind: "punct", text: "=>" });
      i += 2;
    } else {
      out.push({ kind: "punct", text: c });
      i++;
    }
  }
  return out;
}

const OPEN: Record<string, string> = { "(": ")", "[": "]", "{": "}" };

/** What a zod call chain stands for, before it is written as a Pesto field. */
interface Shape {
  type: string;
  min?: number;
  max?: number;
  default?: unknown;
  of?: unknown;
  note?: string;
  /** a group's fields */
  fields?: Record<string, Shape>;
  /** an enum's words */
  words?: string[];
}

const ANY: Shape = { type: "any" };

class Reader {
  private pos = 0;
  private readonly bindings = new Map<string, number>();
  /** names being read, so a schema that names itself doesn't go round forever */
  private readonly reading = new Set<string>();

  constructor(private readonly toks: Token[]) {
    for (let i = 0; i + 2 < toks.length; i++) {
      if (toks[i].kind === "name" && /^(?:const|let|var)$/.test(toks[i].text) && toks[i + 1].kind === "name" && toks[i + 2].text === "=" && toks[i + 3]?.text !== "=") {
        if (!this.bindings.has(toks[i + 1].text)) this.bindings.set(toks[i + 1].text, i + 3);
      }
    }
  }

  /** Where registerMvuSchema( … ) starts its argument, or -1. */
  registered(): number {
    for (let i = 0; i + 1 < this.toks.length; i++) if (this.toks[i].text === "registerMvuSchema" && this.toks[i + 1].text === "(" && this.toks[i - 1]?.text !== ".") return i + 2;
    return -1;
  }

  at(pos: number): Shape {
    this.pos = pos;
    return this.expr();
  }

  private peek = (k = 0) => this.toks[this.pos + k];
  private take = () => this.toks[this.pos++];
  private is = (text: string, k = 0) => this.peek(k)?.text === text;

  /** Skips one argument (up to the next , or closing bracket at this depth). */
  private skipArg(): void {
    let depth = 0;
    while (this.pos < this.toks.length) {
      const t = this.peek();
      if (depth === 0 && (t.text === "," || t.text === ")" || t.text === "]" || t.text === "}")) return;
      if (OPEN[t.text]) depth++;
      else if (t.text === ")" || t.text === "]" || t.text === "}") depth--;
      this.pos++;
    }
  }

  /** The tokens of one argument, skipped. */
  private argTokens(): Token[] {
    const from = this.pos;
    this.skipArg();
    return this.toks.slice(from, this.pos);
  }

  /** Reads `( a, b, … )` with each argument read by `each`. */
  private args<T>(each: () => T): T[] {
    const out: T[] = [];
    if (!this.is("(")) return out;
    this.pos++;
    while (this.pos < this.toks.length && !this.is(")")) {
      out.push(each());
      // whatever is left of an argument that wasn't all read
      this.skipArg();
      if (!this.is(",")) break;
      this.pos++;
    }
    if (this.is(")")) this.pos++;
    return out;
  }

  /** A plain value: a number, string, true/false/null, or an array or object of those. */
  private literal(): unknown {
    const t = this.peek();
    if (!t) return undefined;
    if (t.text === "-" && this.peek(1)?.kind === "num") {
      this.pos += 2;
      return -(this.toks[this.pos - 1].value as number);
    }
    if (t.kind === "num" || t.kind === "str") {
      this.pos++;
      return t.value;
    }
    if (t.kind === "name" && /^(?:true|false|null)$/.test(t.text)) {
      this.pos++;
      return t.text === "true" ? true : t.text === "false" ? false : null;
    }
    if (t.text === "[") {
      this.pos++;
      const out: unknown[] = [];
      while (this.pos < this.toks.length && !this.is("]")) {
        out.push(this.literal());
        this.skipArg();
        if (this.is(",")) this.pos++;
      }
      this.pos++;
      return out;
    }
    if (t.text === "{") {
      this.pos++;
      const out: Obj = {};
      while (this.pos < this.toks.length && !this.is("}")) {
        const key = this.take();
        if (this.is(":")) {
          this.pos++;
          const k = key.kind === "str" ? String(key.value) : key.text;
          if (k !== "__proto__") out[k] = this.literal();
        }
        this.skipArg();
        if (this.is(",")) this.pos++;
      }
      this.pos++;
      return out;
    }
    return undefined;
  }

  /** A zod chain: z.kind(…) then .method(…) calls; or a name bound to one. */
  private expr(): Shape {
    let shape = this.base();
    while (this.is(".") && this.peek(1)?.kind === "name") {
      const method = this.toks[this.pos + 1].text;
      this.pos += 2;
      shape = this.method(shape, method);
    }
    return shape;
  }

  private base(): Shape {
    const t = this.peek();
    if (!t || t.kind !== "name") return ANY;
    if (t.text !== "z") {
      this.pos++;
      const at = this.bindings.get(t.text);
      if (at === undefined || this.reading.has(t.text)) return ANY;
      const back = this.pos;
      this.reading.add(t.text);
      const shape = this.at(at);
      this.reading.delete(t.text);
      this.pos = back;
      return structuredClone(shape);
    }
    this.pos++;
    // z.coerce.number(), z.number(), …
    let kind = "";
    while (this.is(".") && this.peek(1)?.kind === "name") {
      kind = this.toks[this.pos + 1].text;
      this.pos += 2;
      if (kind !== "coerce") break;
    }
    return this.kind(kind);
  }

  private kind(kind: string): Shape {
    switch (kind) {
      case "number":
      case "bigint":
        this.args(() => undefined);
        return { type: "number" };
      case "int":
      case "int32":
        this.args(() => undefined);
        return { type: "int" };
      case "string":
        this.args(() => undefined);
        return { type: "text" };
      case "boolean":
        this.args(() => undefined);
        return { type: "bool" };
      case "enum": {
        const [words] = this.args(() => this.literal());
        const list = Array.isArray(words) ? words : words && typeof words === "object" ? Object.values(words) : [];
        return list.length ? { type: "enum", words: list.map(String) } : ANY;
      }
      case "literal": {
        const [v] = this.args(() => this.literal());
        return typeof v === "string" ? { type: "enum", words: [v], default: v } : { type: "any", default: v };
      }
      case "object":
      case "strictObject":
      case "looseObject": {
        const [fields] = this.args(() => this.objectFields());
        return { type: "object", fields: fields ?? {} };
      }
      case "array":
      case "set": {
        const [item] = this.args(() => this.expr());
        return { type: "list", ...(item && item.type !== "any" ? { of: item } : {}) };
      }
      case "record":
      case "map": {
        const [key, value] = this.args(() => this.expr());
        const item = value ?? ANY;
        if (key?.type === "enum" && key.words) return { type: "object", fields: Object.fromEntries(key.words.map((w) => [w, structuredClone(item)])) };
        return { type: "map", ...(item.type !== "any" ? { of: item } : {}) };
      }
      case "optional":
      case "nullable":
      case "nullish":
      case "readonly": {
        const [inner] = this.args(() => this.expr());
        return inner ?? ANY;
      }
      default:
        this.args(() => undefined);
        return ANY;
    }
  }

  /** `{ name: z…, … }` inside z.object(…). */
  private objectFields(): Record<string, Shape> {
    const out: Record<string, Shape> = {};
    if (!this.is("{")) return out;
    this.pos++;
    while (this.pos < this.toks.length && !this.is("}")) {
      const key = this.take();
      if (this.is(":")) {
        this.pos++;
        const name = key.kind === "str" ? String(key.value) : key.text;
        const shape = this.expr();
        if (name !== "__proto__") out[name] = shape;
      }
      this.skipArg();
      if (this.is(",")) this.pos++;
    }
    if (this.is("}")) this.pos++;
    return out;
  }

  private method(shape: Shape, method: string): Shape {
    switch (method) {
      case "default":
      case "prefault":
      case "catch": {
        const [v] = this.args(() => this.literal());
        if (v !== undefined && shape.default === undefined && !(shape.type === "object" && v && typeof v === "object")) shape.default = v;
        return shape;
      }
      case "min":
      case "gte":
      case "max":
      case "lte": {
        const [n] = this.args(() => this.literal());
        if (typeof n === "number" && (shape.type === "number" || shape.type === "int")) shape[method === "min" || method === "gte" ? "min" : "max"] = n;
        return shape;
      }
      case "int":
        this.args(() => undefined);
        if (shape.type === "number") shape.type = "int";
        return shape;
      case "describe": {
        const [note] = this.args(() => this.literal());
        if (typeof note === "string" && note.trim()) shape.note = note.trim();
        return shape;
      }
      case "transform": {
        const [body] = this.args(() => this.argTokens());
        const range = clampIn(body ?? []);
        if (range && (shape.type === "number" || shape.type === "int")) Object.assign(shape, range);
        return shape;
      }
      case "pipe": {
        const [next] = this.args(() => this.expr());
        return next && next.type !== "any" ? { ...next, ...(shape.default !== undefined ? { default: shape.default } : {}) } : shape;
      }
      case "or":
        this.args(() => undefined);
        return { type: "any", ...(shape.default !== undefined ? { default: shape.default } : {}) };
      default:
        // checks and wrappers that don't change what is kept (optional, refine, passthrough…)
        this.args(() => undefined);
        return shape;
    }
  }
}

/** The bounds of a clamp in a transform's function: _.clamp(v, a, b), or Math.min(Math.max(v, a), b) either way round. */
function clampIn(toks: Token[]): { min: number; max: number } | null {
  const text = toks.map((t) => t.text).join(" ");
  const n = String.raw`(-\s*)?(\d+(?:\.\d+)?)`;
  const num = (sign: string | undefined, digits: string) => (sign ? -1 : 1) * Number(digits);
  const clamp = new RegExp(String.raw`\bclamp \( [\p{L}\p{N}_$]+ , ${n} , ${n} \)`, "u").exec(text);
  if (clamp) return ordered(num(clamp[1], clamp[2]), num(clamp[3], clamp[4]));
  const minMax = new RegExp(String.raw`Math \. (min|max) \( Math \. (min|max) \( [\p{L}\p{N}_$]+ , ${n} \) , ${n} \)`, "u").exec(text);
  if (minMax && minMax[1] !== minMax[2]) return ordered(num(minMax[3], minMax[4]), num(minMax[5], minMax[6]));
  return null;
}

const ordered = (a: number, b: number) => (a < b ? { min: a, max: b } : a > b ? { min: b, max: a } : null);

/** A shape as a field of a Pesto schema (the form readSchema reads). */
function field(shape: Shape): unknown {
  if (shape.type === "object") {
    const out: Obj = {};
    for (const [k, s] of Object.entries(shape.fields ?? {})) out[k] = field(s);
    // a group can't carry a note or a default; an empty one is any value, so it still can be written
    return Object.keys(out).length ? out : { type: "any" };
  }
  const out: Obj = { type: shape.type };
  if (shape.words) out.of = shape.words;
  if (shape.of !== undefined) out.of = field(shape.of as Shape);
  if (shape.min !== undefined) out.min = shape.min;
  if (shape.max !== undefined) out.max = shape.max;
  if (shape.type === "int" && [shape.min, shape.max].some((b) => b !== undefined && !Number.isInteger(b))) out.type = "number";
  // (an empty list or map is where they start anyway)
  const empty = shape.default !== null && typeof shape.default === "object" && !Object.keys(shape.default).length;
  if (shape.default !== undefined && shape.default !== null && !empty) out.default = shape.default;
  if (shape.note) out.note = shape.note;
  return out;
}

/**
 * The Pesto schema a card's script describes with registerMvuSchema(z.object(…)), as
 * `{ fields }`; null when no script does. Scripts are read in order; the first that registers wins.
 */
export function scriptSchema(codes: string[]): { fields: Obj } | null {
  for (const code of codes) {
    if (!code.includes("registerMvuSchema")) continue;
    const reader = new Reader(tokens(code));
    const at = reader.registered();
    if (at < 0) continue;
    const shape = reader.at(at);
    if (shape.type !== "object" || !shape.fields || !Object.keys(shape.fields).length) continue;
    return { fields: field(shape) as Obj };
  }
  return null;
}
