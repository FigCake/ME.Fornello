// Fornello: runs HTML pages with their scripts inside Marinara.

import { ChatPages } from "./chat";
import { getMarinara } from "./shared/marinara-global";
import { Settings } from "./settings";
import { PageBlock } from "./ui/block";
import { SettingsPanel } from "./ui/settings-panel";
import { removeToasts, showToast } from "./ui/toast";
import { ComponentHost } from "./components/host";
import { ScriptHost } from "./scripts/host";
import { setLibraryStore } from "./scripts/library-store";
import { ScriptLibrary } from "./ui/script-library";
import { ScriptAskPopup } from "./ui/script-ask";
import { ScriptButtons } from "./ui/script-buttons";
import { MENU_ICONS, addMenuSource, keepTopMenu } from "./shared/top-menu";
import { onLangChange, t } from "./shared/i18n";
import { startServices } from "./services";

/** What other extensions (Dispensa's 🌟 viewer) use to show a page through Fornello. */
export interface FornelloBridge {
  version: 1;
  /** Shows the page in the container; scripts run on a click, or at once when `run` is true. */
  mount(container: HTMLElement, code: string, options?: { run?: boolean }): { dispose(): void };
  /** Opens Fornello's settings (Dispensa and Polyglot link to it). */
  openSettings?(): void;
}

declare global {
  interface Window {
    __fornello?: FornelloBridge;
  }
}

export async function start(): Promise<() => void> {
  const marinara = getMarinara();
  const stopServices = startServices();
  const settings = new Settings();
  if (!(await settings.loadOrSafe())) {
    marinara.log.warn("settings not loaded: pages wait for a click until a reload");
    showToast(t("Settings could not be read: until a reload, pages run only on a click.", "설정을 읽지 못해서, 다시 불러올 때까지 페이지는 눌러야 실행돼요."), "warning");
  }
  const panel = new SettingsPanel(settings);
  const openSettings = (componentId?: string) => panel.open(componentId);
  const chat = new ChatPages(settings, { openSettings: () => openSettings() });
  chat.start();
  const components = new ComponentHost(settings, {
    openSettings,
    report: (name, message) => showToast(`${name}: ${message}`, "warning"),
  });
  components.start();
  panel.onChatComponents = () => components.reset();
  const askPopup = new ScriptAskPopup();
  const scriptButtons = new ScriptButtons();
  scriptButtons.start();
  const scripts = new ScriptHost(settings, {
    openScripts: () => void library.open(),
    report: (name, message) => showToast(`${name}: ${message}`, "warning"),
    ask: (asks) => askPopup.show(asks),
    buttons: (list) => scriptButtons.set(list),
  });
  const library = new ScriptLibrary(settings, scripts);
  panel.attachScripts(scripts, () => void library.open());
  scripts.start();
  setLibraryStore({
    global: () => settings.current.scripts,
    setGlobal: (items) => settings.set({ scripts: items }),
    refresh: () => scripts.refresh(),
    buttons: () => scripts.buttons(),
  });
  // Fornello's entries in the top-bar menu (Polyglot's, or the one this or Dispensa puts up)
  const removeMenu = addMenuSource({
    id: "fornello",
    name: "Fornello",
    order: 20,
    items: () => [
      { icon: MENU_ICONS.flame, label: t("Fornello settings", "Fornello 설정"), run: () => openSettings() },
      { icon: MENU_ICONS.panel, label: t("Components", "컴포넌트"), run: () => panel.openComponents() },
      { icon: MENU_ICONS.scroll, label: t("Script library", "스크립트 보관함"), run: () => void library.open() },
      ...scriptButtons.menuItems(),
    ],
  });
  const stopTopMenu = keepTopMenu();
  // pages other extensions put up: they go when Fornello does
  const mounted = new Set<PageBlock>();
  let last = settings.current;
  const unsubscribe = settings.subscribe((s) => {
    if (s.mode !== last.mode) chat.reset();
    else if (s.autoRun !== last.autoRun) chat.rerank();
    if (s.mode === "off") for (const block of mounted) block.stop();
    if (s.mode !== last.mode || s.components !== last.components || s.display !== last.display || s.trustedCards !== last.trustedCards) components.reset();
    if (s.mode !== last.mode || s.scripts !== last.scripts || s.trustedScripts !== last.trustedScripts || s.scriptSwitch !== last.scriptSwitch) scripts.refresh();
    last = s;
  });
  const bridge: FornelloBridge = {
    version: 1,
    mount: (container, code, options = {}) => {
      const block = new PageBlock(code, { settings, autoRun: options.run === true, openSettings: () => openSettings() });
      container.append(block.element);
      mounted.add(block);
      return {
        dispose: () => {
          mounted.delete(block);
          block.dispose();
        },
      };
    },
    openSettings: () => openSettings(),
  };
  window.__fornello = bridge;
  // Theme switches: <html> attributes and theme CSS in <head>
  let themeTimer: ReturnType<typeof setTimeout> | null = null;
  const themeObserver = new MutationObserver(() => {
    if (themeTimer) clearTimeout(themeTimer);
    themeTimer = setTimeout(() => PageBlock.refreshLooks(), 150);
  });
  themeObserver.observe(document.documentElement, { attributes: true, attributeFilter: ["data-theme", "class", "style"] });
  themeObserver.observe(document.head, { childList: true, subtree: true, characterData: true });
  // the screen height pages measure against (100vh) follows the window
  const onResize = () => {
    if (themeTimer) clearTimeout(themeTimer);
    themeTimer = setTimeout(() => PageBlock.refreshLooks(), 150);
  };
  window.addEventListener("resize", onResize);
  // a language switch (here, in Dispensa, or Marinara's own): the words again, running pages untouched
  const unwatchLang = onLangChange(() => {
    panel.refresh();
    library.refresh();
    PageBlock.relabelAll();
    scripts.refresh();
    components.reset();
  });
  window.dispatchEvent(new CustomEvent("fornello:ready"));
  const cleanup = () => {
    if (themeTimer) clearTimeout(themeTimer);
    themeObserver.disconnect();
    window.removeEventListener("resize", onResize);
    unwatchLang();
    stopTopMenu();
    removeMenu();
    unsubscribe();
    chat.stop();
    components.stop();
    scripts.stop();
    panel.close();
    library.close();
    askPopup.close();
    scriptButtons.stop();
    for (const block of mounted) block.dispose();
    mounted.clear();
    removeToasts();
    // after the pages: their last saves are written, then the modules stop listening and forget
    stopServices();
    setLibraryStore(null);
    if (window.__fornello === bridge) delete window.__fornello;
  };
  marinara.onCleanup(cleanup);
  marinara.log.info("Fornello ready");
  return cleanup;
}
