// Character assets in chat messages, three ways (each turned on in the
// settings): a tag the reply wrote ([img:name]) becomes the picture after its
// paragraph and the tag's text is blanked; the expression Marinara's
// Expression agent chose for the reply shows above or below it; assets with
// words show under a reply that uses one. {{raw::name}} in a card's HTML
// (a style or a src) becomes the picture's address. Nothing of Marinara's is
// moved: pictures go beside its elements, and blanked text is put back when
// the pictures go.

import { chatCharacters, isSaved, listMessages } from "../api/chat-store";
import type { CharacterInfo, Message } from "../api/types";
import { quickHash } from "../hash";
import { MessageScanner } from "../message-scanner";
import type { Settings } from "../settings";
import { assetsOn } from "./display";
import { syncPictureRules } from "./rule-sync";
import { ensurePictureRegex } from "./picture-regex";
import { type Asset, assetUrl, cardAssets, withSprites } from "./model";
import { spriteListOf } from "./store";
import { findAssets, nameKey, pickOne, samePerson } from "./names";
import { PICTURE_CLASS, assetPicture } from "./picture";
import { findTags, mayHoldTags } from "./tags";
import { assetsByWords } from "./words";

/** Text of a message Fornello moved after a picture (see `placeTags`). */
const MOVED_TEXT = "fornello-text";
const OURS = `.fornello-pages, .fornello-components, .fornello-block, .${PICTURE_CLASS}, .${MOVED_TEXT}`;
/** Text never looked at for tags: code shows a tag as it is. */
const SKIP = "pre, code, script, style, textarea";
const BLOCK = "p, li, blockquote, h1, h2, h3, h4, h5, h6, div, table";
/** HTML attributes {{raw::name}} is filled in. */
const RAW_ATTRS = ["style", "src", "href", "poster", "srcset"];

interface Person {
  id: string;
  name: string;
  assets: Asset[];
}

interface Placed {
  /** The message's text on screen after the pictures went in. */
  sig: string;
  nodes: HTMLElement[];
  /** Text this blanked, to put back. */
  blanked: { node: Text; was: string; now: string }[];
  /** Attributes {{raw::}} was filled in, to put back. */
  attrs: { el: HTMLElement; name: string; was: string; now: string }[];
}

const emptyPlaced = (sig = ""): Placed => ({ sig, nodes: [], blanked: [], attrs: [] });

/** The text nodes of `root` a tag may be in. */
function textNodes(root: HTMLElement): Text[] {
  const out: Text[] = [];
  const walk = (node: Node) => {
    for (const child of node.childNodes) {
      if (child.nodeType === Node.TEXT_NODE) out.push(child as Text);
      else if (child instanceof Element && !child.matches(`${SKIP}, ${OURS}`)) walk(child);
    }
  };
  walk(root);
  return out;
}

export class ChatAssets extends MessageScanner {
  private people: Person[] = [];
  private readonly sprites = new Map<string, Promise<Asset[]>>();
  private readonly placed = new Map<string, Placed>();
  private reload = false;
  /** The chat and settings the picture rules were last brought in line for. */
  private ruled = "";
  /** The rules are written one bring-in-line at a time (two at once would both add an entry). */
  private ruling: Promise<void> = Promise.resolve();

  constructor(settings: Settings) {
    super(settings);
  }

  protected clear(): void {
    for (const id of [...this.placed.keys()]) this.drop(id);
    // drawn again from fresh reads: a card's sprites or assets may have changed (the asset window)
    this.sprites.clear();
    this.reload = true;
  }

  protected override replyDone(): void {
    this.reload = true;
    this.schedule();
  }

  protected override chatChanged(): void {
    this.people = [];
    this.sprites.clear();
    this.reload = false;
  }

  protected override async read(chatId: string): Promise<() => void> {
    const [list, read] = await Promise.all([listMessages(chatId, { fresh: true }), chatCharacters(chatId).catch(() => null)]);
    const cast = read ?? [];
    // a cast read that failed (or a card read as a stand-in with no data) says nothing about the rules
    const whole = read !== null && read.every((c) => Object.keys(c.data).length > 0);
    const people = await Promise.all(cast.map(async (c) => ({ id: c.id, name: c.name, assets: withSprites(cardAssets(c.data), await this.spritesOf(c.id)) })));
    return () => {
      this.messages = new Map(list.map((m) => [m.id, m]));
      this.people = people;
      if (whole) this.syncRules(chatId, cast);
    };
  }

  /** The picture rules, once a chat (and again when the settings or a card's assets change). */
  private syncRules(chatId: string, cast: CharacterInfo[]): void {
    const look = this.settings.current.assets;
    const key = [chatId, look.tags, look.tell, look.perReply, ...cast.map((c) => `${c.id}:${quickHash(JSON.stringify(cardAssets(c.data)))}`)].join("|");
    if (key === this.ruled) return;
    this.ruled = key;
    if (look.tags) void ensurePictureRegex().catch((e) => console.warn("[Fornello] picture regex", e));
    this.ruling = this.ruling.then(() =>
      syncPictureRules(chatId, cast, look).catch((e) => {
        // tried again on the next read
        this.ruled = "";
        console.warn("[Fornello] picture rules", e);
      }),
    );
  }

  /** A character's sprites, read once a chat. */
  private spritesOf(id: string): Promise<Asset[]> {
    let p = this.sprites.get(id);
    if (!p) {
      p = spriteListOf(id);
      this.sprites.set(id, p);
    }
    return p;
  }

  private drop(id: string): void {
    const p = this.placed.get(id);
    if (!p) return;
    for (const node of p.nodes) node.remove();
    // blanked text back, unless Marinara drew the message again meanwhile
    for (const b of p.blanked) if (b.node.isConnected && b.node.nodeValue === b.now) b.node.nodeValue = b.was;
    for (const a of p.attrs) if (a.el.isConnected && a.el.getAttribute(a.name) === a.now) a.el.setAttribute(a.name, a.was);
    this.placed.delete(id);
  }

  protected async scan(chatId: string | null): Promise<void> {
    const look = this.settings.current.assets;
    if (!chatId || !assetsOn(look)) {
      if (this.placed.size) this.clear();
      // everything turned off: the rules written for this chat go too
      if (chatId && this.ruled.startsWith(`${chatId}|true|`)) void chatCharacters(chatId).then((cast) => this.syncRules(chatId, cast)).catch(() => undefined);
      return;
    }
    const elements = [...document.querySelectorAll<HTMLElement>("[data-message-id]")].filter((el) => !el.parentElement?.closest(OURS) && isSaved(el.dataset.messageId));
    if (!elements.length) return;
    const sigOf = (el: HTMLElement) => quickHash(el.textContent ?? "");
    const stale = elements.some((el) => {
      const id = el.dataset.messageId!;
      return !this.messages.has(id) || this.placed.get(id)?.sig !== sigOf(el);
    });
    if ((stale || this.reload) && this.loadAllowed()) {
      this.reload = false;
      await this.load(chatId);
    }
    if (this.stopped || !assetsOn(this.settings.current.assets)) return;
    const live = new Set<string>();
    for (const el of elements) {
      const id = el.dataset.messageId!;
      const message = this.messages.get(id);
      if (!message) continue;
      live.add(id);
      const was = this.placed.get(id);
      if (message.role === "user" || message.role === "system") {
        // nothing goes on the person's own messages; their text is kept so a look sees they haven't changed
        if (was?.sig !== sigOf(el)) this.placed.set(id, emptyPlaced(sigOf(el)));
        continue;
      }
      if (was && was.sig === sigOf(el) && was.nodes.every((n) => n.isConnected)) continue;
      this.drop(id);
      const placed = emptyPlaced();
      this.placeAll(el, message, placed);
      placed.sig = sigOf(el);
      this.placed.set(id, placed);
    }
    for (const id of [...this.placed.keys()]) if (!live.has(id)) this.drop(id);
  }

  /** Who a reply's own assets belong to: its writer, else the chat's first character. */
  private speaker(message: Message): Person | undefined {
    return this.people.find((p) => p.id === message.characterId) ?? this.people[0];
  }

  /** An asset a tag names: a chat character it names, the speaker's (or someone in the speaker's card), then anyone's. */
  private resolve(name: string, person: string | undefined, speaker: Person | undefined): { asset: Asset; owner: Person } | null {
    const named = person ? this.people.find((p) => samePerson(person, p.name)) : undefined;
    const order = [...(named ? [{ p: named, person: undefined }] : []), ...(speaker ? [{ p: speaker, person }] : []), ...this.people.filter((p) => p !== speaker && p !== named).map((p) => ({ p, person }))];
    for (const { p, person: who } of order) {
      const found = findAssets(p.assets, { name, person: who });
      if (found.length) return { asset: found[0], owner: p };
    }
    return null;
  }

  private placeAll(el: HTMLElement, message: Message, placed: Placed): void {
    const look = this.settings.current.assets;
    const contents = [...el.querySelectorAll<HTMLElement>(".mari-message-content")].filter((c) => !c.closest(OURS));
    if (!contents.length) return;
    const speaker = this.speaker(message);
    const picture = (asset: Asset, owner: Person, label: string) => assetPicture(assetUrl(owner.id, asset), label, look.width);
    // several pictures of one name: the same one each time this message is drawn
    const pick = (name: string, person: string | undefined) => {
      const hit = this.resolve(name, person, speaker);
      if (!hit) return null;
      const same = findAssets(hit.owner.assets, { name, person: hit.owner === speaker ? person : undefined });
      return { asset: pickOne(same.length ? same : [hit.asset], `${message.id}:${nameKey(name)}`)!, owner: hit.owner };
    };
    // what goes under the reply goes after its last part, in order
    let after: HTMLElement = contents[contents.length - 1];
    if (look.expressions !== "off" && speaker) {
      const expression = message.expressions?.[speaker.id];
      const sprite = expression ? speaker.assets.find((a) => a.place === "sprite" && nameKey(a.name) === nameKey(expression)) : undefined;
      if (sprite) {
        const node = picture(sprite, speaker, expression!);
        if (look.expressions === "above") contents[0].before(node);
        else {
          after.after(node);
          after = node;
        }
        placed.nodes.push(node);
      }
    }
    if (look.tags) for (const c of contents) this.placeTags(c, pick, placed, picture);
    if (look.words && speaker) {
      const text = contents.map((c) => c.textContent ?? "").join("\n");
      // a picture a tag or the expression already shows isn't shown twice
      const shown = new Set(placed.nodes.map((n) => nameKey(n.dataset.asset ?? "")));
      for (const asset of assetsByWords(text, speaker.assets.filter((a) => !shown.has(nameKey(a.name))))) {
        const node = picture(asset, speaker, asset.name);
        after.after(node);
        after = node;
        placed.nodes.push(node);
      }
    }
  }

  private placeTags(content: HTMLElement, pick: (name: string, person?: string) => { asset: Asset; owner: Person } | null, placed: Placed, picture: (a: Asset, o: Person, label: string) => HTMLElement): void {
    const names = [...this.people.map((p) => p.name), ...new Set(this.people.flatMap((p) => p.assets.map((a) => a.person ?? "")).filter(Boolean))];
    this.fillRaw(content, pick, placed);
    const nodes = textNodes(content);
    const full = nodes.map((n) => n.nodeValue ?? "").join("");
    if (!mayHoldTags(full)) return;
    const spans: { start: number; end: number }[] = [];
    const lastAfter = new Map<Node, HTMLElement>();
    // pictures that go inside a text node, at the end of the tag's line (offsets in the node as it was)
    const inText = new Map<Text, { start: number; cuts: { at: number; pic: HTMLElement }[] }>();
    for (const tag of findTags(full, names)) {
      if (tag.kind !== "img") continue;
      const hit = pick(tag.name, tag.person);
      // a name with no asset stays as written, so the person sees what the reply asked for
      if (!hit) continue;
      spans.push(tag);
      let offset = 0;
      let start = 0;
      const node =
        nodes.find((n) => {
          start = offset;
          offset += n.nodeValue?.length ?? 0;
          return offset >= tag.end;
        }) ?? nodes[nodes.length - 1];
      const pic = picture(hit.asset, hit.owner, tag.name);
      placed.nodes.push(pic);
      const block = node.parentElement?.closest(BLOCK);
      if (block && block !== content && content.contains(block)) {
        // the picture goes after the paragraph the tag ends in
        const prev = lastAfter.get(block);
        (prev ?? block).after(pic);
        lastAfter.set(block, pic);
        continue;
      }
      // a message drawn as one text with line breaks (Marinara's roleplay replies): after the tag's line
      const value = node.nodeValue ?? "";
      const local = Math.min(value.length, Math.max(0, tag.end - start));
      const line = value.indexOf("\n", local);
      const entry = inText.get(node) ?? { start, cuts: [] };
      entry.cuts.push({ at: line < 0 ? value.length : line + 1, pic });
      inText.set(node, entry);
    }
    // the tags' text goes, in place (Marinara can still redraw the message)
    let offset = 0;
    for (const n of nodes) {
      const start = offset;
      const value = n.nodeValue ?? "";
      offset += value.length;
      let text = value;
      for (const s of [...spans].sort((a, b) => b.start - a.start)) {
        const a = Math.max(s.start, start) - start;
        const b = Math.min(s.end, offset) - start;
        if (a < b) text = text.slice(0, a) + text.slice(b);
      }
      if (text !== value) {
        placed.blanked.push({ node: n, was: value, now: text });
        n.nodeValue = text;
      }
    }
    for (const [node, { start, cuts }] of inText) this.splitAround(node, start, cuts, spans, placed);
  }

  /**
   * Puts pictures inside a text node: the node keeps the text up to the first
   * picture (so Marinara can still redraw it), the text after each picture
   * goes in a span of Fornello's, taken out with the pictures. The text on
   * screen stays the same, letter for letter.
   */
  private splitAround(node: Text, start: number, cuts: { at: number; pic: HTMLElement }[], spans: { start: number; end: number }[], placed: Placed): void {
    // an offset in the node as it was → in the node with the tags blanked
    const blankedBefore = (at: number) => spans.reduce((n, s) => n + Math.max(0, Math.min(s.end, start + at) - Math.max(s.start, start)), 0);
    const text = node.nodeValue ?? "";
    const sorted = [...cuts].sort((a, b) => a.at - b.at).map((c) => ({ at: c.at - blankedBefore(c.at), pic: c.pic }));
    let after: ChildNode = node;
    for (const [i, { at, pic }] of sorted.entries()) {
      after.after(pic);
      after = pic;
      const end = sorted[i + 1]?.at ?? text.length;
      if (end > at && sorted[i + 1]?.at !== at) {
        const rest = document.createElement("span");
        rest.className = MOVED_TEXT;
        rest.textContent = text.slice(at, end);
        after.after(rest);
        after = rest;
        placed.nodes.push(rest);
      }
    }
    const kept = text.slice(0, sorted[0]?.at ?? text.length);
    if (kept === text) return;
    const blanked = placed.blanked.find((b) => b.node === node);
    if (blanked) blanked.now = kept;
    else placed.blanked.push({ node, was: text, now: kept });
    node.nodeValue = kept;
  }

  /** {{raw::name}} in a card's HTML attributes becomes the picture's address. */
  private fillRaw(content: HTMLElement, pick: (name: string, person?: string) => { asset: Asset; owner: Person } | null, placed: Placed): void {
    // as written, or as Marinara shows it through Fornello's display regex (picture-regex.ts)
    for (const node of content.querySelectorAll<HTMLElement>(RAW_ATTRS.flatMap((a) => [`[${a}*="{{"]`, `[${a}*="fornello-pic::"]`]).join(", "))) {
      if (node.closest(OURS)) continue;
      for (const attr of RAW_ATTRS) {
        const value = node.getAttribute(attr);
        if (!value || !mayHoldTags(value)) continue;
        let next = value;
        for (const tag of findTags(value).reverse()) {
          if (tag.kind !== "raw") continue;
          const hit = pick(tag.name, tag.person);
          if (hit) next = next.slice(0, tag.start) + assetUrl(hit.owner.id, hit.asset) + next.slice(tag.end);
        }
        if (next !== value) {
          placed.attrs.push({ el: node, name: attr, was: value, now: next });
          node.setAttribute(attr, next);
        }
      }
    }
  }
}
