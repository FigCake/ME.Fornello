// Same file in Dispensa and Fornello (src/shared/): after a change, run
// `npm run shared -- sync <path to the other repository>`.

// Same-origin calls to Marinara's /api. Writes need the CSRF header; none of
// the chat or generation routes need the admin secret, so it is never sent.

import { getMarinara } from "./marinara-global";

export class ApiError extends Error {
  constructor(
    message: string,
    readonly status: number,
    readonly body: unknown,
  ) {
    super(message);
    this.name = "ApiError";
  }
}

export interface RequestOptions {
  method?: "GET" | "POST" | "PATCH" | "PUT" | "DELETE";
  body?: unknown;
  signal?: AbortSignal;
}

export async function api<T = unknown>(path: string, options: RequestOptions = {}): Promise<T> {
  const method = options.method ?? "GET";
  const hasBody = options.body !== undefined;
  const headers: Record<string, string> = { Accept: "application/json" };
  if (method !== "GET") headers["x-marinara-csrf"] = "1";
  if (hasBody) headers["Content-Type"] = "application/json";
  const doFetch = getMarinara().fetch ?? fetch;
  const res = await doFetch(`/api${path}`, {
    method,
    headers,
    body: hasBody ? JSON.stringify(options.body) : undefined,
    credentials: "same-origin",
    cache: "no-store",
    signal: options.signal,
  });
  const text = await res.text();
  let data: unknown = text;
  try {
    data = text ? JSON.parse(text) : null;
  } catch {
    // keep raw text
  }
  if (!res.ok) {
    const message = (data && typeof data === "object" && "error" in data ? String((data as { error: unknown }).error) : "") || `${res.status} ${res.statusText}`;
    throw new ApiError(message, res.status, data);
  }
  return data as T;
}
