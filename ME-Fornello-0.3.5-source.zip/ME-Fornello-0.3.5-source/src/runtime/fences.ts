// Code fences (``` blocks) in a message's text, found as Marinara finds them,
// and which are HTML pages. chat.ts matches them to what is on screen.

export interface Fence {
  lang: string;
  code: string;
  /** An HTML page: ```html, or a bare ``` block holding a whole HTML document. */
  html: boolean;
  /** The closing fence arrived (or, left open at the end, the </html>). */
  complete: boolean;
  /** Its closing fence is there (one left open runs to the end of the message). */
  closed: boolean;
  start: number;
  end: number;
}

/**
 * How Marinara finds code blocks:
 * - "lines" (Markdown): a line of 3+ backticks and a language opens, a line of
 *   backticks only closes;
 * - "html" (roleplay replies holding HTML): any run of 3+ backticks opens, the
 *   first backticks-only line closes; scripts and styles are removed first.
 */
export type FenceRules = "lines" | "html";

/**
 * A bare ``` block is a page only when it holds a whole document (<html> or a
 * leading doctype): stricter than looksLikeDocument in prepare.ts, so a code
 * sample with a <body> tag stays a code sample.
 */
const isDocument = (code: string) => /<html[\s>]/i.test(code) || /^\s*<!doctype\s+html/i.test(code);

function fence(lang: string, code: string, closed: boolean, start: number, end: number): Fence {
  const doc = isDocument(code);
  // saved messages: a closed fence is finished; one left open at the end, once its </html> is there
  return { lang, code, html: /^html?$/i.test(lang) || (!lang && doc), complete: closed || (doc && /<\/html\s*>/i.test(code)), closed, start, end };
}

function lineFences(text: string): Fence[] {
  const out: Fence[] = [];
  let open: { lang: string; indent: number; start: number; lines: string[] } | null = null;
  let at = 0;
  for (const raw of text.split("\n")) {
    const line = raw.replace(/\r$/, "");
    const lineEnd = at + raw.length;
    if (open) {
      if (/^`{3,}\s*$/.test(line.trim())) {
        out.push(fence(open.lang, open.lines.join("\n"), true, open.start, lineEnd));
        open = null;
      } else {
        let cut = 0;
        while (cut < open.indent && line[cut] === " ") cut++;
        open.lines.push(line.slice(cut));
      }
    } else {
      const lead = line.trimStart();
      const m = /^`{3,}(.*)$/.exec(lead);
      if (m && !lead.slice(3).includes("`")) open = { lang: m[1].trim(), indent: line.length - lead.length, start: at, lines: [] };
    }
    at = lineEnd + 1;
  }
  if (open) out.push(fence(open.lang, open.lines.join("\n"), false, open.start, text.length));
  return out;
}

// what Marinara's cleaner takes out first, blanked to the same length so places still match the text
const GONE_RE = /<script\b[\s\S]*?<\/script\s*>|<style\b[\s\S]*?<\/style\s*>|<!--[\s\S]*?-->/gi;
const HTML_FENCE_RE = /(?<=^|\n)[^\S\n]*`{3,}([^\n<]*?)\r?\n([\s\S]*?)\r?\n[^\S\n]*`{3,}[^\S\n]*(?=\r?\n|$)/g;

// a fence opened after the last closed one and never closed (the reply ends in its </html>)
const OPEN_FENCE_RE = /(?<=^|\n)[^\S\n]*`{3,}([^\n<`]*?)\r?\n/;

function htmlFences(text: string): Fence[] {
  const seen = text.replace(GONE_RE, (m) => " ".repeat(m.length));
  const out = [...seen.matchAll(HTML_FENCE_RE)].map((m) => {
    const start = m.index;
    const end = start + m[0].length;
    const codeStart = start + m[0].indexOf("\n") + 1;
    const codeEnd = start + m[0].lastIndexOf("\n");
    return fence(m[1].trim(), text.slice(codeStart, codeEnd).replace(/\r$/, ""), true, start, end);
  });
  // an open fence at the end: Marinara leaves it as text and draws the HTML after it
  const from = out.at(-1)?.end ?? 0;
  const open = OPEN_FENCE_RE.exec(seen.slice(from));
  if (open) {
    const start = from + open.index;
    const tail = fence(open[1].trim(), text.slice(start + open[0].length).trimEnd(), false, start, text.length);
    if (tail.html && tail.complete) out.push(tail);
  }
  return out;
}

/** Every ``` code block of a text, in order, as Marinara would find them. */
export function codeFences(text: string, rules: FenceRules = "lines"): Fence[] {
  return rules === "html" ? htmlFences(text) : lineFences(text);
}

/** The rules Marinara uses for a message on screen. */
export function fenceRulesFor(el: Element, text: string): FenceRules {
  return el.closest("[data-chat-mode]")?.getAttribute("data-chat-mode") === "roleplay" && /<[a-z][\w-]*\b[^<>]*>/i.test(text) ? "html" : "lines";
}
