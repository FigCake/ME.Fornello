// Assets shown by words: an asset with words appears when a reply uses one
// of them, so the AI needn't know about assets at all (no tags, no tokens).

import type { Asset } from "./model";

const LATIN = /^[\p{Script=Latin}\d]/u;

/** Where `word` appears in `text`: Latin words whole (so "cry" isn't found in "crystal"), others anywhere ("웃" in "웃었다"). */
function at(text: string, word: string): number {
  const w = word.normalize("NFKC").toLowerCase();
  if (!w) return -1;
  if (!LATIN.test(w)) return text.indexOf(w);
  const escaped = w.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
  return text.search(new RegExp(`(?<![\\p{L}\\d])${escaped}(?![\\p{L}\\d])`, "u"));
}

/** The assets whose words `text` uses, in the order they first appear, each once (at most `max`). */
export function assetsByWords(text: string, assets: Asset[], max = 2): Asset[] {
  const lower = text.normalize("NFKC").toLowerCase();
  const hits: { asset: Asset; pos: number }[] = [];
  for (const asset of assets) {
    const positions = (asset.words ?? []).map((w) => at(lower, w)).filter((p) => p >= 0);
    if (positions.length) hits.push({ asset, pos: Math.min(...positions) });
  }
  return hits
    .sort((a, b) => a.pos - b.pos)
    .slice(0, max)
    .map((h) => h.asset);
}
