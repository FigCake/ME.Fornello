// Where a script's buttons show: on Dispensa's Dock and on the Status tab, each when the person puts
// them there (a script's ⋮ menu). Before that choice existed every button went to the Dock: settings
// saved then keep that for the scripts that had buttons (settings.ts).

import type { FornelloSettings } from "../settings";

export interface ScriptPlace {
  dock: boolean;
  status: boolean;
}

export function placeOf(s: Pick<FornelloSettings, "scriptPlaces" | "legacyDock">, key: string): ScriptPlace {
  const p = s.scriptPlaces[key];
  // a card's or a chat's script, met before there was a choice: on the Dock as it was
  return { dock: p?.dock ?? (s.legacyDock && !key.startsWith("global:")), status: p?.status ?? false };
}

export function withPlace(s: Pick<FornelloSettings, "scriptPlaces" | "legacyDock">, key: string, change: Partial<ScriptPlace>): Record<string, Partial<ScriptPlace>> {
  return { ...s.scriptPlaces, [key]: { ...placeOf(s, key), ...change } };
}

export function normalizePlaces(raw: unknown): Record<string, Partial<ScriptPlace>> {
  const out: Record<string, Partial<ScriptPlace>> = {};
  if (!raw || typeof raw !== "object" || Array.isArray(raw)) return out;
  for (const [k, v] of Object.entries(raw)) {
    if (!v || typeof v !== "object") continue;
    const o = v as Record<string, unknown>;
    out[k] = { ...(typeof o.dock === "boolean" ? { dock: o.dock } : {}), ...(typeof o.status === "boolean" ? { status: o.status } : {}) };
  }
  return out;
}
