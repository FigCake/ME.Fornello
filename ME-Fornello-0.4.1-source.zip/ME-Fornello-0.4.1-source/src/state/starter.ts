// "Add Pesto entries" in the Status tab: the four Pesto entries put in a card's own lorebook,
// turned off, with a small example in each to write over. Entries the card already has are
// left as they are. A card whose book slot holds a book Marinara didn't link gets them in the
// chat's lorebook instead.

import { forgetPeople } from "../api/chat-store";
import { chatLoreBook, createLoreEntry, loreEntries } from "../api/marinara";
import type { CharacterInfo } from "../api/types";
import { cardBook } from "../assets/rule-sync";
import { t } from "../shared/i18n";

export const STARTER_KINDS = ["schema", "start", "rules", "code"] as const;
export type StarterKind = (typeof STARTER_KINDS)[number];

/** Each entry's first text: a working example, with how to write it in comments. */
export function starterText(kind: StarterKind): string {
  switch (kind) {
    case "schema":
      return t(
        `# The values Fornello keeps (required). Write over the example.
# name: { type, min, max, default, note }
# types: int, number, text, bool, enum (of: [...]), list, map; a name without type is a group
fields:
  affection: { type: int, min: 0, max: 100, default: 30, note: "+1 to +3 when treated kindly, -3 to -5 when treated rudely" }
  mood: { type: enum, of: [calm, happy, angry, sad], default: calm }
  items: { type: list, of: text, max_items: 10 }
`,
        `# Fornello가 기억할 값(필수). 예시를 지우고 쓰세요.
# 이름: { type, min, max, default, note }
# type: int, number, text, bool, enum (of: [...]), list, map. type이 없으면 묶음
fields:
  호감도: { type: int, min: 0, max: 100, default: 30, note: "다정하게 대하면 +1~3, 무례하면 -3~5" }
  기분: { type: enum, of: [평온, 기쁨, 화남, 슬픔], default: 평온 }
  소지품: { type: list, of: text, max_items: 10 }
`,
      );
    case "start":
      return t(
        `# The values at the first message (optional; a value not here starts at its default). Delete this entry if not needed.
affection: 30
`,
        `# 첫 메시지 때의 값(선택. 없는 값은 default로 시작). 필요 없으면 이 항목을 지우세요.
호감도: 30
`,
      );
    case "rules":
      return t(
        `# Events the AI can call, steps after every reply, dice, triggers (optional). Delete this entry if not needed.
# events:
#   rest:
#     params: { hours: 8 }
#     do:
#       - add: { hp: hours * 5 }
# each_reply:
#   - add: { turn: 1 }
# dice:
#   check: 1d20
# triggers:
#   upset:
#     when: mood == "angry"
#     text: Short, sharp answers.
`,
        `# AI가 부르는 이벤트, 답변마다 도는 단계, 주사위, 트리거(선택). 필요 없으면 이 항목을 지우세요.
# events:
#   쉬기:
#     params: { 시간: 8 }
#     do:
#       - add: { 체력: 시간 * 5 }
# each_reply:
#   - add: { 턴: 1 }
# dice:
#   판정: 1d20
# triggers:
#   화남:
#     when: 기분 == "화남"
#     text: 말이 짧고 날카로워진다.
`,
      );
    case "code":
      return t(
        `// JavaScript run after each reply, once you allow it (optional). Delete this entry if not needed.
// function onReply({ values, derived, changes, events, dice, text }) {
//   if (values.affection >= 80) return { set: { mood: "happy" } };
// }
`,
        `// 답변마다 도는 자바스크립트. 허락해야 돌아요(선택). 필요 없으면 이 항목을 지우세요.
// function onReply({ values, derived, changes, events, dice, text }) {
//   if (values.호감도 >= 80) return { set: { 기분: "기쁨" } };
// }
`,
      );
  }
}

const entryName = (kind: StarterKind) => `pesto:${kind}`;

/** Adds the Pesto entries a card lacks; says which were added and where ("card" or the chat's lorebook). */
export async function addStarterEntries(chatId: string, c: CharacterInfo): Promise<{ added: StarterKind[]; where: "card" | "chat" }> {
  let book = await cardBook(c, true);
  let where: "card" | "chat" = "card";
  if (!book) {
    book = (await chatLoreBook(chatId)).id;
    where = "chat";
  }
  const have = new Set((await loreEntries(book)).map((e) => String(e.name ?? "").trim().toLowerCase()));
  const added: StarterKind[] = [];
  for (const kind of STARTER_KINDS) {
    if (have.has(entryName(kind)) || (kind === "start" && have.has("pesto:init"))) continue;
    await createLoreEntry(book, { name: entryName(kind), content: starterText(kind), enabled: false });
    added.push(kind);
  }
  forgetPeople();
  return { added, where };
}
