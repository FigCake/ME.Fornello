// Marinara's window events, all in one place.

const GENERATION_COMPLETE = "marinara:generation-complete";
const REGENERATE_REQUEST = "marinara:chat-regenerate-request";

/** Calls `fn` when Marinara finished writing a reply (with the chat's id when it says). Returns the way to stop. */
export function onGenerationComplete(fn: (chatId: string | null) => void): () => void {
  const listener = (e: Event) => fn((e as CustomEvent<{ chatId?: string } | undefined>).detail?.chatId ?? null);
  window.addEventListener(GENERATION_COMPLETE, listener);
  return () => window.removeEventListener(GENERATION_COMPLETE, listener);
}

/** Asks Marinara to write the chat's last reply again. */
export function requestRegenerate(chatId: string): void {
  window.dispatchEvent(new CustomEvent(REGENERATE_REQUEST, { detail: { chatId } }));
}
