// SillyTavern cards that bring their own variable data, read as Pesto without being changed: their
// starting data becomes a schema (the kinds, read from the values) and the start values.
//
// - Some keep their starting data in lorebook entries whose names hold "[InitVar]": JSON (with
//   comments allowed) or YAML, where each value is a pair `[value, "what it is / when it changes"]`,
//   and an object may say `"$meta": { "extensible": true }` (names can be added: read as a map).
//   The AI changes them with `_.set('path', old, new)` in <UpdateVariable>, which update.ts reads.
// - Others put their starting data in the first message, in <VariableInsert> or <VariableEdit>
//   tags (JSON); the AI changes them with those tags too.
//
// Only the formats are read here; what the values mean is left to the card's own entries.

import { readYaml } from "./yaml";

type Obj = Record<string, unknown>;

const isPlain = (v: unknown): v is Obj => !!v && typeof v === "object" && !Array.isArray(v);

/** A mark in a list that may grow, not a value. */
const LIST_MARK = "$__META_EXTENSIBLE__$";

/** JSON as people write it by hand: comments and trailing commas taken out (strings left alone). */
export function looseJson(text: string): string {
  let out = "";
  let quote = "";
  for (let i = 0; i < text.length; i++) {
    const c = text[i];
    if (quote) {
      out += c;
      if (c === "\\") out += text[++i] ?? "";
      else if (c === quote) quote = "";
      continue;
    }
    if (c === '"' || c === "'") {
      quote = c;
      out += c;
    } else if (c === "/" && text[i + 1] === "/") {
      while (i < text.length && text[i] !== "\n") i++;
      out += "\n";
    } else if (c === "/" && text[i + 1] === "*") {
      const end = text.indexOf("*/", i + 2);
      i = end < 0 ? text.length : end + 1;
    } else out += c;
  }
  return out.replace(/,(\s*[}\]])/g, "$1");
}

/** An entry's text without a ``` fence around it. */
export const withoutFence = (text: string) => text.trim().replace(/^```[\w-]*\n([\s\S]*?)\n?```$/, "$1");

/** An entry's data: JSON (loosely), else YAML; null when it can't be read. */
export function readData(text: string): unknown {
  const body = withoutFence(text);
  try {
    return JSON.parse(looseJson(body));
  } catch {
    try {
      return readYaml(body);
    } catch {
      return null;
    }
  }
}

/** `[value, "note"]`: a value with what it is. */
const isPair = (v: unknown): v is [unknown, string] => Array.isArray(v) && v.length === 2 && typeof v[1] === "string" && v[1] !== LIST_MARK && !isPlain(v[0]);

/** The values alone: pairs to their value, marks left out. */
export function plainValues(v: unknown): unknown {
  if (isPair(v)) return plainValues(v[0]);
  if (Array.isArray(v)) return v.filter((x) => x !== LIST_MARK).map(plainValues);
  if (isPlain(v)) return Object.fromEntries(Object.entries(v).filter(([k]) => k !== "$meta").map(([k, x]) => [k, plainValues(x)]));
  return v;
}

/** A number range written in a note, as such cards often do: "[-30,100]之间", "[0, 1]". */
function rangeIn(note: string): { min: number; max: number } | null {
  const m = /\[\s*(-?\d+(?:\.\d+)?)\s*,\s*(-?\d+(?:\.\d+)?)\s*\]/.exec(note);
  if (!m) return null;
  const min = Number(m[1]);
  const max = Number(m[2]);
  return min < max ? { min, max } : null;
}

/** The kind of a list's items, when they are all one plain kind. */
function itemKind(items: unknown[]): string {
  const kinds = new Set(items.map((x) => (typeof x === "number" ? (Number.isInteger(x) ? "int" : "number") : typeof x === "string" ? "text" : typeof x === "boolean" ? "bool" : "any")));
  if (kinds.size === 2 && kinds.has("int") && kinds.has("number")) return "number";
  return kinds.size === 1 ? [...kinds][0] : "any";
}

/** A schema field for one value of the starting data (pairs give their note). */
function fieldFor(raw: unknown, inherited = false): Obj {
  const note = isPair(raw) ? raw[1].trim() : "";
  const v = isPair(raw) ? raw[0] : raw;
  const withNote = (f: Obj) => (note ? { ...f, note } : f);
  if (typeof v === "number") {
    const range = note ? rangeIn(note) : null;
    return withNote({ type: Number.isInteger(v) && (!range || (Number.isInteger(range.min) && Number.isInteger(range.max))) ? "int" : "number", ...(range ?? {}) });
  }
  if (typeof v === "string") return withNote({ type: "text" });
  if (typeof v === "boolean") return withNote({ type: "bool" });
  if (Array.isArray(v)) {
    const items = v.filter((x) => x !== LIST_MARK).map(plainValues);
    const kind = itemKind(items);
    return withNote({ type: "list", ...(items.length ? { of: kind } : {}) });
  }
  if (isPlain(v)) {
    const meta = isPlain(v.$meta) ? v.$meta : {};
    const open = meta.extensible === true || meta.recursiveExtensible === true || (inherited && meta.extensible !== false);
    const children = Object.entries(v).filter(([k]) => k !== "$meta");
    if (open) {
      // names can be added: a map, its values shaped like the template or the first one
      const sample = meta.template !== undefined ? meta.template : children[0]?.[1];
      return withNote({ type: "map", ...(sample !== undefined ? { of: fieldFor(sample, meta.recursiveExtensible === true) } : {}) });
    }
    const group: Obj = {};
    for (const [k, x] of children) group[k] = fieldFor(x, inherited || meta.recursiveExtensible === true);
    // a group can't carry a note: an empty one is any value, so it still can be written
    return children.length ? group : withNote({ type: "any" });
  }
  return withNote({ type: "any" });
}

/** The schema and start values for a card's starting data. */
export function fromData(data: unknown): { schema: Obj; start: Obj } | null {
  if (!isPlain(data)) return null;
  const top = isPlain(data.stat_data) ? data.stat_data : data;
  const fields: Obj = {};
  for (const [k, v] of Object.entries(top)) if (k !== "$meta") fields[k] = fieldFor(v, isPlain(top.$meta) && top.$meta.recursiveExtensible === true);
  if (!Object.keys(fields).length) return null;
  return { schema: { fields }, start: plainValues(top) as Obj };
}

/** Deep-merges b into a (later entries add to and override earlier ones). */
function merge(a: unknown, b: unknown): unknown {
  if (isPlain(a) && isPlain(b)) {
    const out: Obj = { ...a };
    for (const [k, v] of Object.entries(b)) out[k] = k in out ? merge(out[k], v) : v;
    return out;
  }
  return b;
}

/** A card's starting data, from its "[InitVar]" entries (in their order). */
export function initVarData(entries: { name?: unknown; content?: unknown }[]): unknown {
  let data: unknown = null;
  for (const e of entries) {
    if (!/\[initvar\]/i.test(String(e.name ?? ""))) continue;
    const read = readData(String(e.content ?? ""));
    if (isPlain(read)) data = data === null ? read : merge(data, read);
  }
  return data;
}

/** A card's starting data, from the first message's <VariableInsert> / <VariableEdit> tags. */
export function startTagData(firstMessage: string): unknown {
  let data: unknown = null;
  for (const m of firstMessage.matchAll(/<(VariableInsert|VariableEdit)>([\s\S]*?)<\/\1>/gi)) {
    const read = readData(m[2]);
    if (isPlain(read)) data = data === null ? read : merge(data, read);
  }
  return data;
}

/** A name as YAML reads it back: plain when it is a simple word, else in double quotes. */
const yamlKey = (k: string) => (/^[A-Za-z_][\w-]*$/.test(k) ? k : JSON.stringify(k));

/** A value on one line ({ … } and [ … ]), strings in double quotes. */
function flow(v: unknown): string {
  if (Array.isArray(v)) return `[${v.map(flow).join(", ")}]`;
  if (isPlain(v)) {
    const parts = Object.entries(v).map(([k, x]) => `${yamlKey(k)}: ${flow(x)}`);
    return parts.length ? `{ ${parts.join(", ")} }` : "{}";
  }
  return typeof v === "string" ? JSON.stringify(v) : v === undefined ? "null" : String(v);
}

/**
 * Data as YAML a card's entry can hold: groups as indented blocks, everything else on one line (a
 * schema field, which has a `type`, too). For copying a converted card's schema and start values.
 */
export function writeYaml(data: Obj, indent = ""): string {
  const lines: string[] = [];
  for (const [k, v] of Object.entries(data)) {
    if (isPlain(v) && typeof v.type !== "string" && Object.keys(v).length) lines.push(`${indent}${yamlKey(k)}:`, writeYaml(v, `${indent}  `));
    else lines.push(`${indent}${yamlKey(k)}: ${flow(v)}`);
  }
  return lines.join("\n");
}
