// Components: a JSX component or an HTML template drawn in replies, its values
// from a tag the AI writes, the text inside a tag, or Marinara's tracker.

import { randomPart } from "../hash";
import { type ComponentField, fieldsFromCode, normalizeFields } from "./fields";

/** Where values come from: a tag's attributes, Marinara's tracker, or the text inside a tag. */
export type ComponentSource = "tag" | "tracker" | "body";

/** How the text inside a tag splits into values (source "body"). */
export interface BodyFormat {
  /** What separates the parts: "|" (a|b|c) or ":" (a: b). */
  sep: "|" | ":";
  /** One item per line (a list, `rows`), or the whole text as one set of values. */
  lines: boolean;
  /** An example text inside the tag, for the preview and the rule. */
  sample: string;
}

export const DEFAULT_BODY: BodyFormat = { sep: "|", lines: false, sample: "" };
/** How the AI is told to use a tag-mode component: status (every reply, at the end) or scene (when it fits, in place). */
export type ComponentUse = "status" | "scene";

/** What the code is: a JSX component, or an HTML template with {{value}} places. */
export type ComponentKind = "jsx" | "html";

export interface ComponentDef {
  id: string;
  kind: ComponentKind;
  /** The component's name (a JSX component's function name); in tag mode also the tag (<Name …/>). */
  name: string;
  /** A name for people ("Status panel"); the name when empty. */
  label: string;
  /** The JSX code, or the HTML template. */
  code: string;
  /** One of Marinara's own fonts (its family name) for the component's text; empty: the theme's. */
  font: string;
  enabled: boolean;
  /** Shown in chats where nothing was chosen for it (new chats); a chat can turn it on or off for itself. */
  everyChat: boolean;
  source: ComponentSource;
  body: BodyFormat;
  /** Tracker mode: component value → tracker path (date, custom.<field>, char.<name>.<stat> …). */
  map: Record<string, string>;
  /** Its values: kind, example, instruction for the AI (in the order the code takes them). */
  fields: ComponentField[];
  /** The rule this component's draft is written for. */
  use: ComponentUse;
  /** Scene rule: when the story calls for it ("a match is watched or talked about"). */
  when: string;
  /** Brought by a character card (not saved in the settings). */
  card?: { characterId: string; characterName: string };
}

/** A named group of the person's components: turned on or off in a chat together, saved to a file together. */
export interface ComponentSet {
  id: string;
  name: string;
  /** The components in it, by id. */
  componentIds: string[];
}

export function normalizeSets(raw: unknown, components: ComponentDef[]): ComponentSet[] {
  if (!Array.isArray(raw)) return [];
  const ids = new Set(components.map((c) => c.id));
  const out: ComponentSet[] = [];
  for (const r of raw) {
    if (!r || typeof r !== "object") continue;
    const o = r as Record<string, unknown>;
    const name = str(o.name).trim();
    if (!name) continue;
    // a component deleted since leaves the set
    const componentIds = Array.isArray(o.componentIds) ? [...new Set(o.componentIds.map(String))].filter((id) => ids.has(id)) : [];
    out.push({ id: str(o.id) || newComponentId(), name, componentIds });
  }
  return out;
}

export interface ComponentDisplay {
  /** How many of the latest replies show their components open. */
  recent: number;
  /** Components of older replies: a one-line bar to open, or nothing. */
  older: "collapsed" | "hidden";
}

export const DEFAULT_DISPLAY: ComponentDisplay = { recent: 3, older: "collapsed" };

/** A tag name for an HTML template (the AI writes <Name …/>): a capital letter first. */
export const isTagName = (name: string): boolean => /^[A-Z][\w$]*$/.test(name);

export function newComponentId(): string {
  return `w${randomPart()}`;
}

const str = (v: unknown) => (typeof v === "string" ? v : "");

export function normalizeComponent(raw: unknown): ComponentDef | null {
  if (!raw || typeof raw !== "object") return null;
  const r = raw as Record<string, unknown>;
  const code = str(r.code);
  const name = str(r.name).trim();
  if (!code.trim() || !/^[A-Za-z_$][\w$]*$/.test(name)) return null;
  const kind: ComponentKind = r.kind === "html" ? "html" : "jsx";
  const map: Record<string, string> = {};
  if (r.map && typeof r.map === "object") for (const [k, v] of Object.entries(r.map as Record<string, unknown>)) if (typeof v === "string" && v.trim()) map[k] = v.trim();
  return {
    id: str(r.id) || newComponentId(),
    kind,
    name,
    label: str(r.label).trim(),
    font: str(r.font).trim(),
    code,
    enabled: r.enabled !== false,
    everyChat: r.everyChat !== false,
    source: r.source === "tracker" ? "tracker" : r.source === "body" ? "body" : "tag",
    body: normalizeBody(r.body),
    map,
    fields: ownFields(kind, r.source === "body", normalizeBody(r.body)) ? normalizeFields(r.fields) : fieldsFromCode(code, name, normalizeFields(r.fields)),
    use: r.use === "scene" ? "scene" : "status",
    when: str(r.when),
  };
}

function normalizeBody(raw: unknown): BodyFormat {
  const r = (raw && typeof raw === "object" ? raw : {}) as Record<string, unknown>;
  return { sep: r.sep === ":" ? ":" : "|", lines: r.lines === true, sample: str(r.sample) };
}

/** Whether the values table is the component's own rather than read from its code: HTML templates, and JSX taking lines of text (`rows`). */
export const ownFields = (kind: ComponentKind, body: boolean, format: BodyFormat): boolean => kind === "html" || (body && format.lines);

export function normalizeDisplay(raw: unknown): ComponentDisplay {
  const r = (raw && typeof raw === "object" ? raw : {}) as Record<string, unknown>;
  const recent = Number(r.recent);
  return {
    recent: Number.isFinite(recent) && recent >= 0 ? Math.min(50, Math.floor(recent)) : DEFAULT_DISPLAY.recent,
    older: r.older === "hidden" ? "hidden" : "collapsed",
  };
}
