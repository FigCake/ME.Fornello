// The moment before and after Marinara writes a reply, and tracker writes:
// Marinara sends no events for these. Every reply starts with one request to
// /api/generate, so Fornello wraps window.fetch and holds that request until
// the listeners are done (they may write lorebook entries the prompt reads).
// The reply streams back on that request, so its end is the reply's end.

export type GenKind = "send" | "regenerate" | "continue" | "impersonate";

export interface GenStart {
  kind: GenKind;
  chatId: string;
  /** The message written again or continued (regenerate, continue). */
  messageId: string | null;
  /** What the person sent with it, if anything. */
  userMessage: string | null;
  /** Set once the reply went on without waiting longer for the listeners (MAX_HOLD): what they write after that, the AI didn't see. */
  late?: boolean;
}

type Listener = (gen: GenStart) => unknown;
type EndListener = (gen: GenStart, ok: boolean) => void;

/** The longest a reply waits for a listener (ms): a slow one never keeps the person waiting long. A listener may ask for more (a card's templates that call the AI), for itself only. */
const MAX_HOLD = 5000;

/** The longest Marinara's read of a chat's tracker waits while Fornello writes it (ms). */
const MAX_READ_HOLD = 30_000;

/** A header on Fornello's own reads of the tracker, so they are never held. */
export const OWN_READ = "x-fornello-read";

const readHolds = new Map<string, Promise<unknown>>();

/**
 * Marinara's reads of a chat's tracker (GET …/chats/:id/game-state) wait until `until` settles, or
 * MAX_READ_HOLD: Fornello is writing values into it, and Marinara reads it once a reply ends.
 */
export function holdTrackerReads(chatId: string, until: Promise<unknown>): void {
  // a hold nobody lets go of ends by itself, so later reads don't each wait
  const bounded = Promise.race([until, new Promise((resolve) => setTimeout(resolve, MAX_READ_HOLD))]);
  readHolds.set(chatId, bounded);
  void bounded.finally(() => readHolds.get(chatId) === bounded && readHolds.delete(chatId));
}

/** The chat whose tracker a request reads, when that read is Marinara's (not Fornello's own). */
export function trackerRead(input: RequestInfo | URL, init: RequestInit | undefined): string | null {
  const request = typeof input === "object" && "url" in input ? input : null;
  const method = String(init?.method ?? request?.method ?? "GET").toUpperCase();
  if (method !== "GET") return null;
  const href = typeof input === "string" ? input : input instanceof URL ? input.href : input.url;
  let path: string;
  try {
    path = new URL(href, location.href).pathname;
  } catch {
    return null;
  }
  const own = /^\/api\/chats\/([^/]+)\/game-state$/.exec(path);
  if (!own) return null;
  if (new Headers(init?.headers ?? request?.headers).has(OWN_READ)) return null;
  return decodeURIComponent(own[1]);
}

/** Each listener with how long a reply may wait for it (ms, or a function read each time). */
const listeners = new Map<Listener, () => number>();
const endListeners = new Set<EndListener>();
const trackerListeners = new Set<(chatId: string) => void>();

/** Calls `fn` (with the chat) after something may have changed a chat's tracker. */
export function onTrackerWrite(fn: (chatId: string) => void): () => void {
  trackerListeners.add(fn);
  return () => trackerListeners.delete(fn);
}

export function trackerWritten(chatId: string): void {
  for (const fn of [...trackerListeners]) {
    try {
      fn(chatId);
    } catch (e) {
      console.warn("[Fornello]", e);
    }
  }
}

export function onGenerationStart(fn: Listener, wait: () => number = () => MAX_HOLD): () => void {
  listeners.set(fn, () => Math.max(MAX_HOLD, wait()));
  return () => listeners.delete(fn);
}

/** Calls `fn` when a reply's stream has ended: ok, or failed / stopped. */
export function onGenerationEnd(fn: EndListener): () => void {
  endListeners.add(fn);
  return () => endListeners.delete(fn);
}

function ended(gen: GenStart, ok: boolean): void {
  for (const fn of [...endListeners]) {
    try {
      fn(gen, ok);
    } catch (e) {
      console.warn("[Fornello]", e);
    }
  }
  // a reply's agents write the tracker on the same stream
  trackerWritten(gen.chatId);
}

/** The chat whose tracker a request writes: PATCH …/chats/:id/game-state, or a re-run of the agents. */
export function trackerWrite(input: RequestInfo | URL, init: RequestInit | undefined): string | null {
  const href = typeof input === "string" ? input : input instanceof URL ? input.href : input.url;
  const method = String(init?.method ?? (typeof input === "object" && "method" in input ? input.method : "GET")).toUpperCase();
  if (method === "GET") return null;
  let path: string;
  try {
    path = new URL(href, location.href).pathname;
  } catch {
    return null;
  }
  const own = /^\/api\/chats\/([^/]+)\/(?:messages\/[^/]+\/)?game-state$/.exec(path);
  if (own) return decodeURIComponent(own[1]);
  if (path === "/api/generate/retry-agents" && typeof init?.body === "string") {
    try {
      const chatId = (JSON.parse(init.body) as { chatId?: unknown }).chatId;
      return typeof chatId === "string" ? chatId : null;
    } catch {
      return null;
    }
  }
  return null;
}

/** Tells the tracker listeners once the response (for a stream, its end) is in. */
function afterTrackerWrite(chatId: string, res: Response): Response {
  if (!res.body || !res.headers.get("content-type")?.includes("event-stream")) {
    queueMicrotask(() => trackerWritten(chatId));
    return res;
  }
  const [mine, theirs] = res.body.tee();
  void (async () => {
    const reader = mine.getReader();
    try {
      while (!(await reader.read()).done);
    } catch {
      // the stream broke: what got saved is read anyway
    }
    trackerWritten(chatId);
  })();
  return new Response(theirs, { status: res.status, statusText: res.statusText, headers: res.headers });
}

/** Marinara reads the reply as before; a copy of the stream tells when it ends, and whether it failed. */
function watchEnd(gen: GenStart, res: Response): Response {
  if (!res.body) {
    ended(gen, res.ok);
    return res;
  }
  const [mine, theirs] = res.body.tee();
  void (async () => {
    const reader = mine.getReader();
    const decoder = new TextDecoder();
    let ok = res.ok;
    try {
      for (;;) {
        const { done, value } = await reader.read();
        if (done) break;
        const text = decoder.decode(value, { stream: true });
        if (text.includes('"type":"error"') || text.includes('"type":"aborted"')) ok = false;
      }
    } catch {
      ok = false;
    }
    ended(gen, ok);
  })();
  return new Response(theirs, { status: res.status, statusText: res.statusText, headers: res.headers });
}

/** What a request to /api/generate says about the reply it starts, or null for any other request. */
export function generationStart(input: RequestInfo | URL, init: RequestInit | undefined): GenStart | null {
  const href = typeof input === "string" ? input : input instanceof URL ? input.href : input.url;
  let path: string;
  try {
    path = new URL(href, location.href).pathname;
  } catch {
    return null;
  }
  if (path !== "/api/generate" || typeof init?.body !== "string") return null;
  let body: Record<string, unknown>;
  try {
    body = JSON.parse(init.body);
  } catch {
    return null;
  }
  if (typeof body.chatId !== "string") return null;
  const kind: GenKind = body.impersonate ? "impersonate" : body.regenerateMessageId ? "regenerate" : body.continueMessageId ? "continue" : "send";
  const text = body.userMessage;
  return {
    kind,
    chatId: body.chatId,
    messageId: String(body.regenerateMessageId ?? body.continueMessageId ?? "") || null,
    userMessage: typeof text === "string" ? text : null,
  };
}

async function hold(gen: GenStart): Promise<void> {
  if (!listeners.size) return;
  // each listener for as long as it may take; one that takes longer marks the reply late
  await Promise.all(
    [...listeners].map(async ([fn, wait]) => {
      let done = false;
      const run = Promise.resolve()
        .then(() => fn(gen))
        .catch((e) => console.warn("[Fornello] before a reply:", e))
        .then(() => (done = true));
      await Promise.race([run, new Promise((resolve) => setTimeout(resolve, wait()))]);
      if (!done) gen.late = true;
    }),
  );
}

/** Wraps window.fetch; the returned function undoes it. */
export function startGenerationHold(): () => void {
  const previous = window.fetch;
  // if something wrapped fetch after us, ours stays in its chain and only passes calls on
  let stopped = false;
  const wrapped: typeof fetch = async (input, init) => {
    if (stopped) return previous.call(window, input, init);
    const gen = generationStart(input, init);
    if (!gen) {
      const read = trackerRead(input, init);
      const held = read ? readHolds.get(read) : undefined;
      if (held) await Promise.race([held.catch(() => undefined), new Promise((resolve) => setTimeout(resolve, MAX_READ_HOLD))]);
      const tracked = trackerWrite(input, init);
      if (!tracked) return previous.call(window, input, init);
      return afterTrackerWrite(tracked, await previous.call(window, input, init));
    }
    await hold(gen);
    try {
      return watchEnd(gen, await previous.call(window, input, init));
    } catch (e) {
      ended(gen, false);
      throw e;
    }
  };
  window.fetch = wrapped;
  return () => {
    stopped = true;
    if (window.fetch === wrapped) window.fetch = previous;
    listeners.clear();
    endListeners.clear();
    trackerListeners.clear();
    readHolds.clear();
  };
}
