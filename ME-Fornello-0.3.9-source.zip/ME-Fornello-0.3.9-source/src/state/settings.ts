// Pesto's settings: off until the person turns it on, how near the end of the chat the
// values go (0 = after the last message), the person's answers about cards' code, who reports a
// reply's changes (the AI; a helper model costs a call), and showing the values in
// Marinara's tracker (off), reading SillyTavern cards' own variable data (on), and giving the values to
// Marinara's prompts as chat variables (off).

export interface StorySettings {
  on: boolean;
  depth: number;
  /** A card's `pesto:code`, by its SHA-256: allowed to run (true) or not (false); changed code is asked again. */
  code: Record<string, boolean>;
  /** Who reports a reply's changes: the AI ("ai"), the AI with a helper model for a reply that has none ("fill"), or the helper model alone ("helper": the AI isn't asked for blocks). */
  writer: StoryWriter;
  /** The helper's connection, by id ("": the chat's own). */
  fillWith: string;
  /** The values shown in Marinara's tracker too (the World panel's custom fields). */
  tracker: boolean;
  /** Cards without pesto:schema are read from their own starting data. */
  others: boolean;
  /** The values are also Marinara chat variables ("story_hp"), for `{{getvar}}` and `{{#if}}` in prompts. */
  vars: boolean;
}

export type StoryWriter = "ai" | "fill" | "helper";
export const STORY_WRITERS: readonly StoryWriter[] = ["ai", "fill", "helper"];

export const DEFAULT_STORY: StorySettings = { on: false, depth: 1, code: {}, writer: "ai", fillWith: "", tracker: false, others: true, vars: false };
export const STORY_DEPTH = { min: 0, max: 4 };

export function normalizeStory(raw: unknown): StorySettings {
  const r = (raw && typeof raw === "object" ? raw : {}) as Record<string, unknown>;
  const depth = Number(r.depth);
  return {
    on: r.on === true,
    depth: Number.isFinite(depth) && r.depth !== null && r.depth !== "" ? Math.max(STORY_DEPTH.min, Math.min(STORY_DEPTH.max, Math.round(depth))) : DEFAULT_STORY.depth,
    code: Object.fromEntries(Object.entries(r.code && typeof r.code === "object" && !Array.isArray(r.code) ? r.code : {}).filter((e): e is [string, boolean] => typeof e[1] === "boolean")),
    // `fill: true` is how an earlier Fornello kept "the AI, with a helper"
    writer: STORY_WRITERS.includes(r.writer as StoryWriter) ? (r.writer as StoryWriter) : r.fill === true ? "fill" : "ai",
    fillWith: typeof r.fillWith === "string" ? r.fillWith.trim() : "",
    tracker: r.tracker === true,
    others: r.others !== false,
    vars: r.vars === true,
  };
}
