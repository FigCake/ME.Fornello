// A component's values table: name, kind, example and instruction for the AI.
// An HTML template's table is its own; a JSX component's follows the values
// its code takes (`function Card({ hp = 80 })`), and edits to the table
// rewrite the code.

import { componentProps, parseLiteral, renameProp, rewriteProps } from "./source";
import { templateKeys } from "./template";

export type FieldType = "text" | "number" | "bool" | "list" | "object";

export const FIELD_TYPES: FieldType[] = ["text", "number", "bool", "list", "object"];

export interface ComponentField {
  name: string;
  type: FieldType;
  /** As the person typed it: plain text, a number, true/false, or JSON for a list or an object. */
  example: string;
  /** What the AI should write in it (goes into the rule, or the tracker field). */
  instruction: string;
  /** What to show instead of a value, one `value=shown` a line. */
  swaps?: string;
}

const NAME = /^[A-Za-z_$][\w$]*$/;
export const isFieldName = (name: string): boolean => NAME.test(name);

/** The kind of value a default in the code is. */
function typeOfValue(v: unknown): FieldType {
  if (typeof v === "number") return "number";
  if (typeof v === "boolean") return "bool";
  if (Array.isArray(v)) return "list";
  if (v && typeof v === "object") return "object";
  return "text";
}

/** A value as the table shows it. */
function exampleText(v: unknown): string {
  if (v === undefined || v === null) return "";
  if (typeof v === "string") return v;
  if (typeof v === "number" || typeof v === "boolean") return String(v);
  return JSON.stringify(v);
}

/** A default written in the code, read as data ("" when it is not plain data). */
function literalValue(text: string): unknown {
  if (!text.trim()) return undefined;
  try {
    return parseLiteral(text);
  } catch {
    return undefined;
  }
}

/** The example as a value of the field's kind (text when it does not read as that kind). */
export function exampleValue(f: ComponentField): unknown {
  const raw = f.example.trim();
  if (f.type === "number") return raw && Number.isFinite(Number(raw)) ? Number(raw) : raw ? f.example : 0;
  if (f.type === "bool") return /^(true|yes|on|1|예|네)$/i.test(raw);
  if (f.type === "list" || f.type === "object") {
    if (!raw) return f.type === "list" ? [] : {};
    try {
      return parseLiteral(raw);
    } catch {
      return f.example;
    }
  }
  return f.example;
}

/** The example as JavaScript, for the code's default. */
function exampleLiteral(f: ComponentField): string {
  return JSON.stringify(exampleValue(f));
}

/** The table for a JSX component in its code's order: known values stay, new ones start from the code's default. */
export function fieldsFromCode(code: string, name: string, previous: ComponentField[]): ComponentField[] {
  return componentProps(code, name).map((p) => {
    const kept = previous.find((f) => f.name === p.name);
    if (kept) return kept;
    const v = literalValue(p.fallback);
    return { name: p.name, type: typeOfValue(v), example: exampleText(v), instruction: "" };
  });
}

/** One change to the table that the code follows. */
export type FieldEdit = { add: ComponentField } | { rename: string; to: string } | { remove: string };

/** The code after a change in the table (unchanged when its values could not be found). */
export function codeAfter(code: string, name: string, edit: FieldEdit): string {
  const props = componentProps(code, name);
  if ("add" in edit) return rewriteProps(code, name, [...props.map((p) => ({ name: p.name, from: p.name })), { name: edit.add.name, fallback: exampleLiteral(edit.add) }]);
  if ("rename" in edit) return renameProp(code, name, edit.rename, edit.to);
  return rewriteProps(code, name, props.filter((p) => p.name !== edit.remove).map((p) => ({ name: p.name, from: p.name })));
}

/** The tag the AI should write, filled with the examples (for the rule and the preview). */
export function exampleTagFor(name: string, fields: ComponentField[]): string {
  const attrs = fields.map((f) => {
    const v = exampleValue(f);
    return typeof v === "string" ? `${f.name}="${v.replace(/"/g, "&quot;")}"` : `${f.name}={${JSON.stringify(v)}}`;
  });
  return `<${name}${attrs.length ? ` ${attrs.join(" ")}` : ""} />`;
}

/** The examples as the component's values (the preview). */
export function exampleProps(fields: ComponentField[]): Record<string, unknown> {
  return Object.fromEntries(fields.map((f) => [f.name, exampleValue(f)]));
}

/** Saved fields, whatever shape they were kept in. */
export function normalizeFields(raw: unknown): ComponentField[] {
  if (!Array.isArray(raw)) return [];
  const out: ComponentField[] = [];
  for (const r of raw) {
    if (!r || typeof r !== "object") continue;
    const o = r as Record<string, unknown>;
    const name = typeof o.name === "string" ? o.name.trim() : "";
    if (!isFieldName(name) || out.some((f) => f.name === name)) continue;
    out.push({
      name,
      type: FIELD_TYPES.includes(o.type as FieldType) ? (o.type as FieldType) : "text",
      example: typeof o.example === "string" ? o.example : exampleText(o.example),
      instruction: typeof o.instruction === "string" ? o.instruction : "",
      ...(typeof o.swaps === "string" && o.swaps.trim() ? { swaps: o.swaps } : {}),
    });
  }
  return out;
}

/** The table for an HTML template: the values it had, then the ones the template asks for (a section's name is a list). */
export function fieldsFromTemplate(template: string, previous: ComponentField[], within?: string): ComponentField[] {
  const { keys, lists } = templateKeys(template, within);
  const out = [...previous];
  for (const k of keys) if (isFieldName(k) && !out.some((f) => f.name === k)) out.push({ name: k, type: lists.has(k) ? "list" : "text", example: "", instruction: "" });
  return out;
}
