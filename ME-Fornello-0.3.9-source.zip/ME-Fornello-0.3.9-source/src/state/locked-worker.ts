// A Worker for code a card brings (Pesto's code, lorebook templates), its script starting with
// every way out shut (code.ts lockSource). A request gets its answer, or an error when it took too
// long (the Worker goes; the next request starts a new one) or the script can't load (then every
// request says so). On the way, the script may ask the page for things ({ call, callId, args }),
// answered by the request's `call`.

export type WorkerAnswer = { ok: true; data: Record<string, unknown> } | { ok: false; error: string };

export class LockedWorker {
  private worker: Worker | null = null;
  private url: string | null = null;
  private next = 0;
  private waiting = new Map<number, { done: (a: WorkerAnswer) => void; call?: (name: string, args: unknown[]) => Promise<unknown> }>();
  private broken = "";
  /** It has answered once: an error after that is the code failing later (a timer), not a script that can't load. */
  private answered = false;

  constructor(private readonly source: () => string) {}

  private start(): Worker {
    if (this.worker) return this.worker;
    this.url ??= URL.createObjectURL(new Blob([this.source()], { type: "text/javascript" }));
    const worker = new Worker(this.url);
    worker.onmessage = (e: MessageEvent) => {
      const d = (e.data ?? {}) as Record<string, unknown>;
      if (typeof d.call === "string" && typeof d.callId === "number") {
        const callId = d.callId;
        // the request that is going asks it (one at a time)
        const call = [...this.waiting.values()].at(-1)?.call;
        if (!call) return worker.postMessage({ callId, error: "nothing may be asked now" });
        void call(d.call, Array.isArray(d.args) ? d.args : [])
          .then((result) => worker.postMessage({ callId, result: result === undefined ? null : JSON.parse(JSON.stringify(result)) }))
          .catch((err: unknown) => worker.postMessage({ callId, error: err instanceof Error ? err.message : String(err) }));
        return;
      }
      const run = typeof d.id === "number" ? this.waiting.get(d.id) : undefined;
      if (!run) return;
      this.answered = true;
      this.waiting.delete(d.id as number);
      run.done(typeof d.error === "string" ? { ok: false, error: d.error } : { ok: true, data: d });
    };
    worker.onerror = (e: ErrorEvent) => {
      e.preventDefault();
      if (this.answered) {
        console.warn("[Fornello] card code:", e.message);
        return;
      }
      this.broken = e.message || "the code has an error";
      for (const run of this.waiting.values()) run.done({ ok: false, error: this.broken });
      this.waiting.clear();
    };
    this.worker = worker;
    return worker;
  }

  /** Sends `body` (with an id) and waits for the answer, at most `timeMs`. */
  request(body: Record<string, unknown>, timeMs: number, call?: (name: string, args: unknown[]) => Promise<unknown>): Promise<WorkerAnswer> {
    if (this.broken) return Promise.resolve({ ok: false, error: this.broken });
    let worker: Worker;
    try {
      worker = this.start();
    } catch (e) {
      this.broken = `Workers can't start here (${e instanceof Error ? e.message : e})`;
      return Promise.resolve({ ok: false, error: this.broken });
    }
    const id = this.next++;
    return new Promise<WorkerAnswer>((resolve) => {
      const timer = setTimeout(() => {
        if (!this.waiting.delete(id)) return;
        // stuck: this Worker goes, the next request gets a new one
        this.stop();
        resolve({ ok: false, error: timeMs >= 2000 ? `took longer than ${Math.round(timeMs / 1000)} s` : `took longer than ${timeMs} ms` });
      }, timeMs);
      this.waiting.set(id, {
        done: (a) => {
          clearTimeout(timer);
          resolve(a);
        },
        ...(call ? { call } : {}),
      });
      worker.postMessage({ ...JSON.parse(JSON.stringify(body)), id });
    });
  }

  private stop(): void {
    this.worker?.terminate();
    this.worker = null;
    this.answered = false;
    for (const run of this.waiting.values()) run.done({ ok: false, error: "stopped" });
    this.waiting.clear();
  }

  dispose(): void {
    this.stop();
    if (this.url) URL.revokeObjectURL(this.url);
    this.url = null;
  }
}
