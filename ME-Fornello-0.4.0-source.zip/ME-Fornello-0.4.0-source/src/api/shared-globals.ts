// Values pages and scripts hand each other by name (share / getShared,
// initializeGlobal / waitGlobalInitialized), kept while Fornello runs.

const values = new Map<string, unknown>();
const waiting = new Map<string, ((value: unknown) => void)[]>();

export function shareGlobal(name: string, value: unknown): void {
  values.set(name, value);
  for (const resolve of waiting.get(name) ?? []) resolve(value);
  waiting.delete(name);
}

/** Whether something was shared under `name`. */
export const hasGlobal = (name: string) => values.has(name);

/** The value shared under `name`, once there is one. */
export function waitForGlobal(name: string): Promise<unknown> {
  if (values.has(name)) return Promise.resolve(values.get(name));
  return new Promise((resolve) => {
    const list = waiting.get(name) ?? [];
    list.push(resolve);
    waiting.set(name, list);
  });
}

/** Everything goes (Fornello stopped). */
export function clearSharedGlobals(): void {
  values.clear();
  waiting.clear();
}
