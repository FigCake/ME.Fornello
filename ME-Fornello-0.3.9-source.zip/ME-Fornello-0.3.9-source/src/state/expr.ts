// Pesto's expressions: the small language a card's rules and schema use for computed values,
// conditions and limits ("hp + 10", "gold >= price && !dead", "clamp(trust + 5, 0, 100)"). It is
// read by its own parser and worked out over plain values, so nothing in it can run code or reach
// the page: names read the story's values (and an event's parameters), and only the functions
// listed in FUNCTIONS can be called.
//
//   numbers 1 2.5   text "a" 'b'   true false null   lists [1, 2]
//   a.b  a[0]  a[key]  list.length       ?:  || &&  (or: and or not)
//   == != < <= > >= in       + - * / % **       ! - (in front)

export class ExprError extends Error {}

type Node =
  | { k: "lit"; v: unknown }
  | { k: "id"; name: string }
  | { k: "get"; obj: Node; key: Node }
  | { k: "call"; fn: string; args: Node[] }
  | { k: "un"; op: string; a: Node }
  | { k: "bin"; op: string; a: Node; b: Node }
  | { k: "cond"; c: Node; a: Node; b: Node }
  | { k: "list"; items: Node[] };

/** What names mean while an expression is worked out, and the dice. */
export interface Scope {
  /** The value of a top-level name; throws ExprError for an unknown name. */
  name(name: string): unknown;
  /** A number in [0, 1), the same each time a story is replayed (Pesto seeds it per message). */
  random(): number;
}

type Token = { t: "num" | "str" | "id" | "op"; v: string; at: number };

const WORD_OPS: Record<string, string> = { and: "&&", or: "||", not: "!", in: "in" };
const OPS = ["**", "==", "!=", "<=", ">=", "&&", "||", "===", "!==", "+", "-", "*", "/", "%", "<", ">", "!", "?", ":", "(", ")", "[", "]", ",", "."];

function tokenize(src: string): Token[] {
  const out: Token[] = [];
  let i = 0;
  while (i < src.length) {
    const c = src[i];
    if (/\s/.test(c)) {
      i++;
      continue;
    }
    const at = i;
    const num = /^(?:\d+(?:\.\d+)?|\.\d+)(?:[eE][-+]?\d+)?/.exec(src.slice(i));
    if (num) {
      out.push({ t: "num", v: num[0], at });
      i += num[0].length;
      continue;
    }
    if (c === '"' || c === "'") {
      let j = i + 1;
      let text = "";
      while (j < src.length && src[j] !== c) {
        if (src[j] === "\\" && j + 1 < src.length) {
          const e = src[++j];
          text += e === "n" ? "\n" : e === "t" ? "\t" : e;
        } else text += src[j];
        j++;
      }
      if (j >= src.length) throw new ExprError(`a quote is not closed in "${src}"`);
      out.push({ t: "str", v: text, at });
      i = j + 1;
      continue;
    }
    const word = /^[\p{L}_$][\p{L}\p{N}_$]*/u.exec(src.slice(i));
    if (word) {
      const op = WORD_OPS[word[0]];
      out.push(op ? { t: "op", v: op, at } : { t: "id", v: word[0], at });
      i += word[0].length;
      continue;
    }
    const op = OPS.filter((o) => src.startsWith(o, i)).sort((a, b) => b.length - a.length)[0];
    if (!op) throw new ExprError(`"${c}" is not understood in "${src}"`);
    out.push({ t: "op", v: op === "===" ? "==" : op === "!==" ? "!=" : op, at });
    i += op.length;
  }
  return out;
}

// how tightly each two-sided operator holds; ** and ?: group from the right
const BINARY: Record<string, number> = { "||": 2, "&&": 3, "==": 4, "!=": 4, "<": 5, "<=": 5, ">": 5, ">=": 5, in: 5, "+": 6, "-": 6, "*": 7, "/": 7, "%": 7, "**": 8 };

class Parser {
  private i = 0;
  constructor(
    private tokens: Token[],
    private src: string,
  ) {}

  private peek(v?: string): Token | undefined {
    const t = this.tokens[this.i];
    return v === undefined || (t && t.t === "op" && t.v === v) ? t : undefined;
  }

  private expect(v: string) {
    if (!this.peek(v)) throw new ExprError(`expected "${v}" in "${this.src}"`);
    this.i++;
  }

  whole(): Node {
    const node = this.expr();
    if (this.i < this.tokens.length) throw new ExprError(`unexpected "${this.tokens[this.i].v}" in "${this.src}"`);
    return node;
  }

  private expr(): Node {
    const c = this.binary(1);
    if (!this.peek("?")) return c;
    this.i++;
    const a = this.expr();
    this.expect(":");
    return { k: "cond", c, a, b: this.expr() };
  }

  private binary(min: number): Node {
    let left = this.unary();
    for (;;) {
      const t = this.tokens[this.i];
      const power = t?.t === "op" ? BINARY[t.v] : undefined;
      if (power === undefined || power < min) return left;
      this.i++;
      const right = this.binary(t.v === "**" ? power : power + 1);
      left = { k: "bin", op: t.v, a: left, b: right };
    }
  }

  private unary(): Node {
    const t = this.peek();
    if (t?.t === "op" && (t.v === "!" || t.v === "-" || t.v === "+")) {
      this.i++;
      return { k: "un", op: t.v, a: this.unary() };
    }
    return this.postfix(this.primary());
  }

  private primary(): Node {
    const t = this.tokens[this.i++];
    if (!t) throw new ExprError(`"${this.src}" ends too soon`);
    if (t.t === "num") return { k: "lit", v: Number(t.v) };
    if (t.t === "str") return { k: "lit", v: t.v };
    if (t.t === "id") {
      if (t.v === "true" || t.v === "false") return { k: "lit", v: t.v === "true" };
      if (t.v === "null") return { k: "lit", v: null };
      if (this.peek("(")) {
        if (!Object.hasOwn(FUNCTIONS, t.v)) throw new ExprError(`there is no function "${t.v}"`);
        this.i++;
        return { k: "call", fn: t.v, args: this.items(")") };
      }
      return { k: "id", name: t.v };
    }
    if (t.v === "(") {
      const inner = this.expr();
      this.expect(")");
      return inner;
    }
    if (t.v === "[") return { k: "list", items: this.items("]") };
    throw new ExprError(`unexpected "${t.v}" in "${this.src}"`);
  }

  private items(close: string): Node[] {
    const out: Node[] = [];
    while (!this.peek(close)) {
      out.push(this.expr());
      if (this.peek(",")) this.i++;
      else if (!this.peek(close)) throw new ExprError(`expected "," or "${close}" in "${this.src}"`);
    }
    this.i++;
    return out;
  }

  private postfix(node: Node): Node {
    for (;;) {
      if (this.peek(".")) {
        this.i++;
        const t = this.tokens[this.i++];
        if (!t || (t.t !== "id" && t.t !== "num" && !(t.t === "op" && t.v === "in"))) throw new ExprError(`a name is missing after "." in "${this.src}"`);
        node = { k: "get", obj: node, key: { k: "lit", v: t.t === "op" ? "in" : t.v } };
      } else if (this.peek("[")) {
        this.i++;
        const key = this.expr();
        this.expect("]");
        node = { k: "get", obj: node, key };
      } else return node;
    }
  }
}

const parsed = new Map<string, Node>();

/** Reads an expression once (kept for next time); throws ExprError when it can't be read. */
export function parseExpr(src: string): Node {
  let node = parsed.get(src);
  if (!node) {
    node = new Parser(tokenize(src), src).whole();
    if (parsed.size > 2000) parsed.clear();
    parsed.set(src, node);
  }
  return node;
}

/** Works out an expression. Throws ExprError. */
export function evaluate(src: string, scope: Scope): unknown {
  return run(parseExpr(src), scope);
}

/** Checks that an expression can be read; the problem's text, or "". */
export function exprProblem(src: string): string {
  try {
    parseExpr(src);
    return "";
  } catch (e) {
    return e instanceof Error ? e.message : String(e);
  }
}

const BLOCKED = new Set(["__proto__", "constructor", "prototype"]);

/** One step down into a value: an object's own field, a list's or text's item or length. */
function member(obj: unknown, key: unknown): unknown {
  const name = String(key);
  if (BLOCKED.has(name)) throw new ExprError(`"${name}" can't be read`);
  if (Array.isArray(obj) || typeof obj === "string") {
    if (name === "length") return obj.length;
    if (!/^-?\d+$/.test(name)) return null;
    const i = Number(name);
    return obj[i < 0 ? obj.length + i : i] ?? null;
  }
  if (obj && typeof obj === "object") return Object.hasOwn(obj, name) ? (obj as Record<string, unknown>)[name] : null;
  return null;
}

const num = (v: unknown, what: string): number => {
  if (typeof v === "number") return v;
  if (typeof v === "boolean") return v ? 1 : 0;
  if (v === null || v === undefined) return 0;
  if (typeof v === "string" && v.trim() !== "" && !Number.isNaN(Number(v))) return Number(v);
  throw new ExprError(`${what} needs a number, not ${JSON.stringify(v)}`);
};

/** Equal for plain values: numbers and number-like text compare as numbers, lists and groups by content. */
export function same(a: unknown, b: unknown): boolean {
  if (a === b) return true;
  if (a === null || a === undefined || b === null || b === undefined) return (a ?? null) === (b ?? null);
  if (typeof a === "number" && typeof b === "string") return b.trim() !== "" && Number(b) === a;
  if (typeof a === "string" && typeof b === "number") return same(b, a);
  if (typeof a === "object" && typeof b === "object") return JSON.stringify(a) === JSON.stringify(b);
  return false;
}

function contains(where: unknown, what: unknown): boolean {
  if (Array.isArray(where)) return where.some((x) => same(x, what));
  if (typeof where === "string") return where.includes(String(what));
  if (where && typeof where === "object") return Object.hasOwn(where, String(what));
  return false;
}

function run(node: Node, scope: Scope): unknown {
  switch (node.k) {
    case "lit":
      return node.v;
    case "id":
      return scope.name(node.name);
    case "get":
      return member(run(node.obj, scope), run(node.key, scope));
    case "list":
      return node.items.map((n) => run(n, scope));
    case "cond":
      return run(node.c, scope) ? run(node.a, scope) : run(node.b, scope);
    case "call":
      return FUNCTIONS[node.fn](
        node.args.map((n) => run(n, scope)),
        scope,
      );
    case "un": {
      const a = run(node.a, scope);
      if (node.op === "!") return !a;
      return node.op === "-" ? -num(a, "-") : num(a, "+");
    }
    case "bin": {
      if (node.op === "&&") return run(node.a, scope) && run(node.b, scope);
      if (node.op === "||") return run(node.a, scope) || run(node.b, scope);
      const a = run(node.a, scope);
      const b = run(node.b, scope);
      switch (node.op) {
        case "==":
          return same(a, b);
        case "!=":
          return !same(a, b);
        case "in":
          return contains(b, a);
        case "+":
          if (typeof a === "string" || typeof b === "string") return `${a ?? ""}${b ?? ""}`;
          if (Array.isArray(a) && Array.isArray(b)) return [...a, ...b];
          return num(a, "+") + num(b, "+");
        case "<":
        case "<=":
        case ">":
        case ">=": {
          const [x, y] = typeof a === "string" && typeof b === "string" ? [a, b] : [num(a, node.op), num(b, node.op)];
          return node.op === "<" ? x < y : node.op === "<=" ? x <= y : node.op === ">" ? x > y : x >= y;
        }
      }
      const x = num(a, node.op);
      const y = num(b, node.op);
      if ((node.op === "/" || node.op === "%") && y === 0) throw new ExprError(`"${node.op}" by zero`);
      return node.op === "-" ? x - y : node.op === "*" ? x * y : node.op === "/" ? x / y : node.op === "%" ? x % y : x ** y;
    }
  }
}

/** "2d6+1", "d20", "3d6-2": the sum of the dice and the number after. */
export function rollDice(spec: string, random: () => number): number {
  const m = /^\s*(\d*)\s*d\s*(\d+)\s*(?:([+-])\s*(\d+))?\s*$/i.exec(spec);
  if (!m) throw new ExprError(`"${spec}" is not dice like "2d6+1"`);
  const count = m[1] ? Number(m[1]) : 1;
  const sides = Number(m[2]);
  if (count < 1 || count > 100 || sides < 1 || sides > 10000) throw new ExprError(`"${spec}": 1 to 100 dice of 1 to 10000 sides`);
  let total = 0;
  for (let i = 0; i < count; i++) total += 1 + Math.floor(random() * sides);
  return total + (m[3] ? (m[3] === "-" ? -1 : 1) * Number(m[4]) : 0);
}

const numbers = (args: unknown[], what: string) => (args.length === 1 && Array.isArray(args[0]) ? args[0] : args).map((v) => num(v, what));

const FUNCTIONS: Record<string, (args: unknown[], scope: Scope) => unknown> = Object.assign(Object.create(null), {
  min: (a: unknown[]) => Math.min(...numbers(a, "min")),
  max: (a: unknown[]) => Math.max(...numbers(a, "max")),
  sum: (a: unknown[]) => numbers(a, "sum").reduce((s, x) => s + x, 0),
  clamp: (a: unknown[]) => Math.min(Math.max(num(a[0], "clamp"), num(a[1], "clamp")), num(a[2], "clamp")),
  round: (a: unknown[]) => {
    const f = 10 ** num(a[1] ?? 0, "round");
    return Math.round(num(a[0], "round") * f) / f;
  },
  floor: (a: unknown[]) => Math.floor(num(a[0], "floor")),
  ceil: (a: unknown[]) => Math.ceil(num(a[0], "ceil")),
  abs: (a: unknown[]) => Math.abs(num(a[0], "abs")),
  len: (a: unknown[]) => (Array.isArray(a[0]) || typeof a[0] === "string" ? a[0].length : a[0] && typeof a[0] === "object" ? Object.keys(a[0]).length : 0),
  has: (a: unknown[]) => contains(a[0], a[1]),
  keys: (a: unknown[]) => (a[0] && typeof a[0] === "object" && !Array.isArray(a[0]) ? Object.keys(a[0]) : []),
  num: (a: unknown[]) => num(a[0], "num"),
  int: (a: unknown[]) => Math.trunc(num(a[0], "int")),
  str: (a: unknown[]) => (a[0] === null || a[0] === undefined ? "" : typeof a[0] === "object" ? JSON.stringify(a[0]) : String(a[0])),
  lower: (a: unknown[]) => String(a[0] ?? "").toLowerCase(),
  upper: (a: unknown[]) => String(a[0] ?? "").toUpperCase(),
  roll: (a: unknown[], s: Scope) => rollDice(String(a[0] ?? "d6"), () => s.random()),
  chance: (a: unknown[], s: Scope) => s.random() * 100 < num(a[0], "chance"),
  pick: (a: unknown[], s: Scope) => {
    const list = a.length === 1 && Array.isArray(a[0]) ? a[0] : a;
    return list.length ? list[Math.floor(s.random() * list.length)] : null;
  },
});
