// Background scripts in the open chat: the person's own, the chat's cards'
// and the chat's own (once allowed; asked again when they change). They start
// with the chat and stop when another opens or the settings change; "Off" runs none.

import { chatCharacters } from "../api/chat-store";
import { readChatData } from "../api/chat-data";
import { emitEvent } from "../api/event-bus";
import { buttonEvent } from "../api/commands/script";
import { type PageApi, pageApi } from "../api/page-api";
import { currentChatId } from "../host/current-chat";
import { oncePerFrame, onScreenChange } from "../host/screen-watch";
import type { Settings } from "../settings";
import { t } from "../shared/i18n";
import { screenUi } from "../ui/page-ui";
import { sha256 } from "../hash";
import { type CardScripts, type LibraryItem, type ScriptButton, type ScriptDef, globalDef, libraryHash, libraryScripts, scriptHeadings, scriptsOf } from "./model";
import { type RunningScript, runScript } from "./runtime";

/** How many of a script's latest errors are kept for the settings. */
const KEEP_ERRORS = 5;
/** How many lines of a script's log (its console and its errors) are kept. */
const KEEP_LOG = 200;

export interface LogLine {
  at: number;
  kind: "log" | "warn" | "error";
  text: string;
}

/** A value as a log shows it. */
function shown(v: unknown): string {
  if (typeof v === "string") return v;
  if (v instanceof Error) return v.message;
  try {
    return JSON.stringify(v) ?? String(v);
  } catch {
    return String(v);
  }
}

interface Running {
  def: ScriptDef;
  /** What it was started with: a change starts it again. */
  sig: string;
  buttons: ScriptButton[];
  api: PageApi | null;
  run: RunningScript | null;
  stopped: boolean;
  /** Its code did not parse: kept (so it is not started again until it changes) but not running. */
  failed: boolean;
}

export interface ScriptHostHooks {
  /** Opens the script library. */
  openScripts(): void;
  /** A script's error, shown as a note. */
  report(name: string, message: string): void;
  /** The open chat's cards and chat scripts that wait for the person's word (the popup asks). */
  ask(asks: ScriptAsk[]): void;
  /** The buttons of what runs now (Dispensa's Dock, else the top-bar menu). */
  buttons(list: ScriptButtonView[]): void;
}

/** A card or a chat whose scripts wait for the person's word. */
export interface ScriptAsk {
  /** The same question while the scripts stay the same. */
  key: string;
  name: string;
  /** The chat's own scripts, not a card's. */
  chat?: boolean;
  count: number;
  allow(): void;
  /** Not now: not run, and not asked again until Fornello starts again (nothing kept). */
  notNow(): void;
  /** Don't ask again: kept, until the scripts change or the person allows them in the library. */
  decline(): void;
  show(): void;
}

/** A button a running script shows. */
export interface ScriptButtonView {
  /** The script's name (with its card's, or a number, when another running script has the same name). */
  script: string;
  label: string;
  press(): void;
}

/** A chat's own scripts, as a card's are asked about. */
export interface ChatScripts {
  chatId: string;
  hash: string;
  items: LibraryItem[];
  scripts: ScriptDef[];
}

/** The key the person's answer about a chat's scripts is kept under (trustedScripts). */
export const chatTrustKey = (chatId: string): string => `chat:${chatId}`;

/** What the settings show about the open chat's scripts. */
export interface ScriptStatus {
  cards: CardScripts[];
  chat: ChatScripts | null;
  running: Set<string>;
  errors: Map<string, string[]>;
  /** Asks (ScriptAsk.key) answered "Not now" since Fornello started. */
  notNow: ReadonlySet<string>;
}

interface Ask {
  key: string;
  name: string;
  chat?: boolean;
  count: number;
  answer(allow: boolean): Promise<void>;
}

export class ScriptHost {
  private readonly running = new Map<string, Running>();
  private readonly errors = new Map<string, string[]>();
  private readonly logs = new Map<string, LogLine[]>();
  private readonly watchers = new Set<() => void>();
  /** Asks answered "Not now": kept in memory only, so they come up again after a reload. */
  private readonly notNow = new Set<string>();
  private chatId: string | null = null;
  private cards: CardScripts[] = [];
  private chat: ChatScripts | null = null;
  private stops: (() => void)[] = [];
  /** Counts updates: one that finishes after a newer one started changes nothing. */
  private turn = 0;
  private readonly look = oncePerFrame(() => {
    if (currentChatId() !== this.chatId) void this.update();
  });

  constructor(
    private readonly settings: Settings,
    private readonly hooks: ScriptHostHooks,
  ) {}

  start(): void {
    this.stops.push(onScreenChange(this.look));
    void this.update();
  }

  stop(): void {
    this.turn++;
    for (const stop of this.stops.splice(0)) stop();
    this.stopAll();
    this.hooks.ask([]);
    this.hooks.buttons([]);
  }

  /** The settings changed: start and stop what that changes. */
  refresh(): void {
    void this.update();
  }

  /** Calls `fn` when what runs, or a log, changes (the library window redraws). */
  watch(fn: () => void): () => void {
    this.watchers.add(fn);
    return () => this.watchers.delete(fn);
  }

  private changed(): void {
    for (const fn of [...this.watchers]) fn();
  }

  /** A script's log: what it wrote to the console, and its errors. */
  logOf(key: string): LogLine[] {
    return [...(this.logs.get(key) ?? [])];
  }

  clearLog(key: string): void {
    this.logs.delete(key);
    this.errors.delete(key);
    this.changed();
  }

  private log(key: string, kind: LogLine["kind"], text: string): void {
    const list = this.logs.get(key) ?? [];
    list.push({ at: Date.now(), kind, text: text.slice(0, 2000) });
    this.logs.set(key, list.slice(-KEEP_LOG));
    this.changed();
  }

  /** The script's console: kept in its log, and passed on to the browser's. */
  private console(def: ScriptDef): Console {
    const real = window.console;
    const write = (kind: LogLine["kind"], method: "log" | "info" | "debug" | "warn" | "error") => (...args: unknown[]) => {
      this.log(def.key, kind, args.map(shown).join(" "));
      real[method](`[${def.name}]`, ...args);
    };
    return { ...real, log: write("log", "log"), info: write("log", "info"), debug: write("log", "debug"), warn: write("warn", "warn"), error: write("error", "error") };
  }

  /** The visible buttons of what runs now, by script id. */
  buttons(): Record<string, { button_id: string; button_name: string }[]> {
    const out: Record<string, { button_id: string; button_name: string }[]> = {};
    for (const r of this.running.values()) {
      if (r.failed) continue;
      const shown = r.buttons.filter((b) => b.visible).map((b) => ({ button_id: b.name, button_name: b.name }));
      if (shown.length) out[r.def.id] = shown;
    }
    return out;
  }

  status(): ScriptStatus {
    return { cards: this.cards, chat: this.chat, running: new Set([...this.running].filter(([, r]) => !r.failed).map(([key]) => key)), errors: this.errors, notNow: this.notNow };
  }

  /** The person answered about the chat's own scripts. */
  async answerChat(chat: ChatScripts, allow: boolean): Promise<void> {
    const trustedScripts = { ...this.settings.current.trustedScripts, [chatTrustKey(chat.chatId)]: allow ? chat.hash : `no:${chat.hash}` };
    await this.settings.set({ trustedScripts }).catch((e: unknown) => this.hooks.report(t("This chat", "이 채팅"), e instanceof Error ? e.message : String(e)));
  }

  /** The person answered a card's question. */
  async answer(card: CardScripts, allow: boolean): Promise<void> {
    const trustedScripts = { ...this.settings.current.trustedScripts, [card.characterId]: allow ? card.hash : `no:${card.hash}` };
    await this.settings.set({ trustedScripts }).catch((e: unknown) => this.hooks.report(card.characterName, e instanceof Error ? e.message : String(e)));
  }

  private stopAll(): void {
    for (const key of [...this.running.keys()]) this.stopOne(key);
  }

  private stopOne(key: string): void {
    const r = this.running.get(key);
    if (!r) return;
    r.stopped = true;
    r.run?.stop();
    r.api?.dispose();
    this.running.delete(key);
    this.changed();
  }

  /** Whether a script should run, given the card's word and the person's switch (a folder switched off runs none). */
  private isOn(def: ScriptDef): boolean {
    if (def.folderOff) return false;
    return this.settings.current.scriptSwitch[def.key] ?? def.enabled;
  }

  private async update(): Promise<void> {
    const turn = ++this.turn;
    const chatId = currentChatId();
    if (chatId !== this.chatId) {
      // every script belongs to the chat it started in (its commands act there)
      this.stopAll();
      this.errors.clear();
      this.cards = [];
      this.chat = null;
      this.chatId = chatId;
    }
    const s = this.settings.current;
    if (!chatId || s.mode === "off") {
      this.stopAll();
      this.publish([]);
      return;
    }
    const [cast, own] = await Promise.all([chatCharacters(chatId).catch(() => []), readChatData(chatId).then((d) => d.scripts ?? []).catch(() => [] as LibraryItem[])]);
    if (turn !== this.turn) return;
    this.cards = cast.map(scriptsOf).filter((c): c is CardScripts => !!c);
    this.chat = own.length ? { chatId, hash: libraryHash(own), items: own, scripts: libraryScripts(own).map(({ script, folder }) => globalDef(script, folder, chatId)) } : null;
    const wanted: ScriptDef[] = libraryScripts(s.scripts)
      .map(({ script, folder }) => globalDef(script, folder))
      .filter((d) => this.isOn(d));
    const asks: Ask[] = [];
    for (const card of this.cards) {
      const answer = s.trustedScripts[card.characterId];
      if (answer === card.hash) wanted.push(...card.scripts.filter((d) => this.isOn(d)));
      else if (answer !== `no:${card.hash}` && !this.notNow.has(`${card.characterId}:${card.hash}`)) asks.push({ key: `${card.characterId}:${card.hash}`, name: card.characterName, count: card.scripts.length, answer: (allow) => this.answer(card, allow) });
    }
    if (this.chat) {
      const chat = this.chat;
      const answer = s.trustedScripts[chatTrustKey(chatId)];
      if (answer === chat.hash) wanted.push(...chat.scripts.filter((d) => this.isOn(d)));
      else if (answer !== `no:${chat.hash}` && !this.notNow.has(`${chatTrustKey(chatId)}:${chat.hash}`)) asks.push({ key: `${chatTrustKey(chatId)}:${chat.hash}`, name: t("This chat", "이 채팅"), chat: true, count: chat.scripts.length, answer: (allow) => this.answerChat(chat, allow) });
    }
    const sigs = new Map(wanted.map((d) => [d.key, sha256(`${d.code}\n${JSON.stringify(d.buttons)}`)]));
    for (const [key, r] of this.running) if (sigs.get(key) !== r.sig) this.stopOne(key);
    for (const def of wanted) if (!this.running.has(def.key)) void this.startOne(def, sigs.get(def.key)!, chatId);
    this.publish(asks);
  }

  private report(def: ScriptDef, e: unknown): void {
    const message = e instanceof Error ? e.message : String(e);
    console.warn(`[Fornello] script "${def.name}":`, e);
    const list = this.errors.get(def.key) ?? [];
    list.push(message);
    this.errors.set(def.key, list.slice(-KEEP_ERRORS));
    this.log(def.key, "error", message);
    this.hooks.report(def.name, message);
  }

  /** Stops a script and starts it afresh (reloadIframe, the library's "Restart"). */
  restart(key: string): void {
    const r = this.running.get(key);
    const chatId = this.chatId;
    if (!r || !chatId) return;
    this.stopOne(key);
    void this.startOne(r.def, r.sig, chatId);
  }

  private async startOne(def: ScriptDef, sig: string, chatId: string): Promise<void> {
    const r: Running = { def, sig, buttons: def.buttons.map((b) => ({ ...b })), api: null, run: null, stopped: false, failed: false };
    this.running.set(def.key, r);
    const report = (e: unknown) => {
      if (!r.stopped) this.report(def, e);
    };
    try {
      const api = await pageApi({
        messageId: null,
        report,
        ui: screenUi,
        reload: () => this.restart(def.key),
        script: {
          def,
          buttons: () => r.buttons,
          setButtons: (list) => {
            r.buttons = list;
            this.publish();
          },
        },
      });
      if (r.stopped || currentChatId() !== chatId) return api.dispose();
      r.api = api;
      const run = await runScript(def.code, { ...api.globals, console: this.console(def) }, report, api.bindScope);
      if (r.stopped) return run.stop();
      r.run = run;
      if (run.failed) {
        r.failed = true;
        r.api = null;
        api.dispose();
      }
      this.publish();
      this.changed();
    } catch (e) {
      report(e);
    }
  }

  /** Hands on the asks and the running scripts' buttons (the asks again only when given). */
  private publish(asks?: Ask[]): void {
    if (asks) {
      this.hooks.ask(
        asks.map((ask) => ({
          key: ask.key,
          name: ask.name,
          chat: ask.chat,
          count: ask.count,
          allow: () => void ask.answer(true),
          notNow: () => {
            this.notNow.add(ask.key);
            this.changed();
          },
          decline: () => void ask.answer(false),
          show: () => this.hooks.openScripts(),
        })),
      );
    }
    const live = [...this.running.values()].filter((r) => !r.failed);
    const headings = scriptHeadings(live.map((r) => r.def));
    this.hooks.buttons(
      live.flatMap((r) =>
        r.buttons
          .filter((b) => b.visible)
          .map((b) => ({ script: headings.get(r.def.key) ?? r.def.name, label: b.name, press: () => void emitEvent(buttonEvent(r.def.key, b.name), [], (e) => this.report(r.def, e)) })),
      ),
    );
  }
}
