// Small notes on screen. (The chat's people are in people.ts.)

import type { ToastKind } from "../../ui/toast";
import { cmd } from "../command";
import type { PageSession } from "../session";

export const toast = (s: PageSession, text: unknown, kind: ToastKind = "info"): void => s.ui.toast(String(text ?? ""), kind);

export function chatCommands(s: PageSession) {
  return {
    showToast: cmd((text: unknown, kind?: ToastKind) => toast(s, text, kind)),
  };
}
