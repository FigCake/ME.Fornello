// Fornello: runs HTML pages with their scripts inside Marinara.

import { ChatPages } from "./chat";
import { ChatAssets } from "./assets/chat-assets";
import { removePictureRules } from "./assets/rule-sync";
import { removePictureRegex } from "./assets/picture-regex";
import { AssetManager } from "./ui/asset-manager";
import { getMarinara } from "./shared/marinara-global";
import { Settings } from "./settings";
import { PageBlock } from "./ui/block";
import { SettingsPanel } from "./ui/settings-panel";
import { removeToasts, showToast } from "./ui/toast";
import { ComponentHost } from "./components/host";
import { ScriptHost, type ScriptAsk } from "./scripts/host";
import { setLibraryStore } from "./scripts/library-store";
import { ScriptLibrary } from "./ui/script-library";
import type { GoToTab } from "./ui/window-tabs";
import { SettingsParts } from "./ui/settings-parts";
import { fillPageAssets, forgetPageAssets } from "./assets/page-assets";
import { addAssetCommands } from "./assets/dispensa-commands";
import { hookCharacterImport } from "./host/import-hook";
import { ScriptAskPopup } from "./ui/script-ask";
import { ScriptButtons } from "./ui/script-buttons";
import { MENU_ICONS, addMenuSource, keepTopMenu } from "./shared/top-menu";
import { onLangChange, t } from "./shared/i18n";
import { startServices } from "./services";
import { StoryState } from "./state/story";
import { TemplateService } from "./ejs/service";
import { currentChatId } from "./host/current-chat";
import { StoryValues } from "./ui/story-values";

/** What other extensions (Dispensa's 🌟 viewer) use to show a page through Fornello. */
export interface FornelloBridge {
  version: 1;
  /** Shows the page in the container; scripts run on a click, or at once when `run` is true. */
  /** `chatId`: the chat the page was made in, whose characters' pictures its names mean (the open chat otherwise). */
  mount(container: HTMLElement, code: string, options?: { run?: boolean; chatId?: string }): { dispose(): void };
  /** Opens Fornello's settings (Dispensa and Polyglot link to it). */
  openSettings?(): void;
  /** A page's code with its picture names ({{raw::name}}, [img:name]) filled in from a chat's character assets (the page's own chat, else the open one). */
  fillAssets?(code: string, chatId?: string): Promise<string>;
}

declare global {
  interface Window {
    __fornello?: FornelloBridge;
  }
}

export async function start(): Promise<() => void> {
  const marinara = getMarinara();
  const stopServices = startServices();
  const settings = new Settings();
  if (!(await settings.loadOrSafe())) {
    marinara.log.warn("settings not loaded: pages wait for a click until a reload");
    showToast(t("Settings could not be read: until a reload, pages run only on a click.", "설정을 읽지 못해서, 다시 불러올 때까지 페이지는 눌러야 실행돼요."), "warning");
  }
  const panel = new SettingsPanel(settings);
  // into the window on the components tab (go: below), on one component when given
  // `gear`: with ⚙ open (a page's ⚙ is about how pages run)
  const openSettings = (componentId?: string, gear = false) => {
    go("components", { gear });
    if (componentId) panel.open(componentId);
  };
  const chat = new ChatPages(settings, { openSettings: () => openSettings(undefined, true) });
  chat.start();
  const assets = new ChatAssets(settings);
  assets.start();
  const storyAsk = new ScriptAskPopup();
  const storyValues = new StoryValues();
  // cards' code asks come one at a time, each once a session
  const storyAsks: ScriptAsk[] = [];
  const story = new StoryState(settings, {
    ask: (ask) => {
      storyAsks.push(ask);
      storyAsk.show([...storyAsks]);
    },
    showCode: () => go("status"),
  });
  story.start();
  // after Pesto, so a reply's hold runs its listener first (they run side by side either way)
  const templates = new TemplateService(settings);
  templates.start();
  const parts = new SettingsParts(settings);
  parts.templates = templates;
  const assetManager = new AssetManager(() => (assets.reset(), forgetPageAssets()));
  const components = new ComponentHost(settings, {
    openSettings,
    report: (name, message) => showToast(`${name}: ${message}`, "warning"),
  });
  components.start();
  panel.onChatComponents = () => components.reset();
  const askPopup = new ScriptAskPopup();
  const scriptButtons = new ScriptButtons(settings);
  scriptButtons.start();
  const scripts = new ScriptHost(settings, {
    openScripts: () => go("scripts"),
    report: (name, message) => showToast(`${name}: ${message}`, "warning"),
    ask: (asks) => askPopup.show(asks),
    buttons: (list) => scriptButtons.set(list),
  });
  const library = new ScriptLibrary(settings, scripts);
  // one window, four tabs: a tab press swaps one view for the next
  const views = { components: panel, scripts: library, assets: assetManager, status: storyValues };
  const go: GoToTab = (tab, options) => {
    for (const [name, view] of Object.entries(views)) if (name !== tab) view.close();
    if (tab === "components") {
      panel.open();
      if (options?.gear) panel.openGear();
    } else void views[tab].open();
  };
  panel.tabs = library.tabs = assetManager.tabs = storyValues.tabs = go;
  assetManager.settingsPart = () => parts.assetsSection();
  storyValues.settingsPart = () => [parts.storySection(), parts.templatesSection()];
  storyValues.buttons = () => scriptButtons.onStatus();
  scriptButtons.onChange = () => storyValues.refresh();
  // a setting changed in those parts: their tab draws it again
  parts.redraw = () => {
    assetManager.refresh();
    storyValues.refresh();
  };
  scripts.start();
  setLibraryStore({
    global: () => settings.current.scripts,
    setGlobal: (items) => settings.set({ scripts: items }),
    refresh: () => scripts.refresh(),
    buttons: () => scripts.buttons(),
  });
  // Fornello's entries in the top-bar menu (Polyglot's, or the one this or Dispensa puts up)
  const removeMenu = addMenuSource({
    id: "fornello",
    name: "Fornello",
    order: 20,
    items: () => [{ icon: MENU_ICONS.flame, label: "Fornello", run: () => go("components") }],
  });
  const stopTopMenu = keepTopMenu();
  // pages other extensions put up: they go when Fornello does
  const mounted = new Set<PageBlock>();
  let last = settings.current;
  const unsubscribe = settings.subscribe((s) => {
    if (s.mode !== last.mode) chat.reset();
    else if (s.autoRun !== last.autoRun) chat.rerank();
    if (s.assets !== last.assets) {
      // tags off, or telling the AI moved or stopped: Fornello's rule entries everywhere go (the open chat's come back as needed)
      if (last.assets.tags && !s.assets.tags) void removePictureRegex().catch((e) => console.warn("[Fornello] picture regex", e));
      if ((last.assets.tags && !s.assets.tags) || (last.assets.tags && last.assets.tell !== s.assets.tell)) void removePictureRules().catch((e) => console.warn("[Fornello] picture rules", e)).finally(() => assets.reset());
      else assets.reset();
    }
    // the values leave Marinara's tracker of the open chat when either is turned off, and come in when it is turned on
    const openChat = currentChatId();
    const trackerWas = last.story.on && last.story.tracker;
    const trackerIs = s.story.on && s.story.tracker;
    if (openChat && trackerWas && !trackerIs) void story.mirror(openChat, true).catch((e) => console.warn("[Fornello] Pesto tracker", e));
    if (openChat && !trackerWas && trackerIs) void story.mirror(openChat).catch((e) => console.warn("[Fornello] Pesto tracker", e));
    // the values leave the open chat's variables when that is turned off (other chats' go at their next reply)
    if (openChat && last.story.on && last.story.vars && !(s.story.on && s.story.vars)) void story.writeVars(openChat).catch((e) => console.warn("[Fornello] Pesto variables", e));
    if (last.story.on && !s.story.on) void story.turnedOff();
    if (s.mode === "off") for (const block of mounted) block.stop();
    if (s.mode !== last.mode || s.components !== last.components || s.display !== last.display || s.trustedCards !== last.trustedCards) components.reset();
    if (s.scriptPlaces !== last.scriptPlaces) scriptButtons.refresh();
    if (s.mode !== last.mode || s.scripts !== last.scripts || s.trustedScripts !== last.trustedScripts || s.scriptSwitch !== last.scriptSwitch) scripts.refresh();
    last = s;
  });
  const bridge: FornelloBridge = {
    version: 1,
    mount: (container, code, options = {}) => {
      const block = new PageBlock(code, { settings, autoRun: options.run === true, openSettings: () => openSettings(undefined, true), fillAssets: (c) => fillPageAssets(c, options.chatId || currentChatId()) });
      container.append(block.element);
      mounted.add(block);
      return {
        dispose: () => {
          mounted.delete(block);
          block.dispose();
        },
      };
    },
    openSettings: () => openSettings(),
    fillAssets: (code, chatId) => fillPageAssets(code, chatId || currentChatId()),
  };
  window.__fornello = bridge;
  const removeAssetCommands = addAssetCommands();
  const unhookImport = hookCharacterImport(settings);
  // Theme switches: <html> attributes and theme CSS in <head>
  let themeTimer: ReturnType<typeof setTimeout> | null = null;
  const themeObserver = new MutationObserver(() => {
    if (themeTimer) clearTimeout(themeTimer);
    themeTimer = setTimeout(() => PageBlock.refreshLooks(), 150);
  });
  themeObserver.observe(document.documentElement, { attributes: true, attributeFilter: ["data-theme", "class", "style"] });
  themeObserver.observe(document.head, { childList: true, subtree: true, characterData: true });
  // the screen height pages measure against (100vh) follows the window
  const onResize = () => {
    if (themeTimer) clearTimeout(themeTimer);
    themeTimer = setTimeout(() => PageBlock.refreshLooks(), 150);
  };
  window.addEventListener("resize", onResize);
  // a language switch (here, in Dispensa, or Marinara's own): the words again, running pages untouched
  const unwatchLang = onLangChange(() => {
    panel.refresh();
    library.refresh();
    assetManager.refresh();
    storyValues.refresh();
    PageBlock.relabelAll();
    scripts.refresh();
    components.reset();
  });
  window.dispatchEvent(new CustomEvent("fornello:ready"));
  const cleanup = () => {
    if (themeTimer) clearTimeout(themeTimer);
    themeObserver.disconnect();
    window.removeEventListener("resize", onResize);
    unwatchLang();
    removeAssetCommands();
    unhookImport();
    stopTopMenu();
    removeMenu();
    unsubscribe();
    chat.stop();
    assets.stop();
    story.stop();
    templates.stop();
    components.stop();
    scripts.stop();
    panel.close();
    library.close();
    assetManager.close();
    storyValues.close();
    askPopup.close();
    storyAsk.close();
    scriptButtons.stop();
    for (const block of mounted) block.dispose();
    mounted.clear();
    removeToasts();
    // after the pages: their last saves are written, then the modules stop listening and forget
    stopServices();
    setLibraryStore(null);
    if (window.__fornello === bridge) delete window.__fornello;
  };
  marinara.onCleanup(cleanup);
  marinara.log.info("Fornello ready");
  return cleanup;
}
