// Page commands for Marinara's regex scripts: read, change (asked once per
// page), delete (always asked), and apply them to a text.

import { t } from "../../shared/i18n";
import { cmd } from "../command";
import { type RegexScript, applyRegexScripts } from "../../regex";
import { createRegex, deleteRegex, patchRegex } from "../library";
import type { PageSession } from "../session";
import { findChar } from "./people";

export interface RegexItem {
  id: string;
  name: string;
  enabled: boolean;
  find: string;
  replace: string;
  flags: string;
  /** Taken out of each capture ($1…) before it goes in. */
  trim: string[];
  /** What it changes: the AI's replies ("ai_output") and / or your messages ("user_input"). */
  on: string[];
  /** On screen ("display"), in what goes to the AI ("prompt"), or "both". */
  mode: "display" | "prompt" | "both";
  /** Only in chats with these characters / with these prompt presets (empty: everywhere). */
  chars: string[];
  presets: string[];
  /** Only for messages this far back (0 = the latest); null: any. */
  minDepth: number | null;
  maxDepth: number | null;
}

export interface RegexScope {
  /** A character's ("current": the chat's first). */
  char?: string;
  /** A prompt preset's ("in_use": the chat's). */
  preset?: string;
  /** Those for every chat (no character or preset). */
  global?: boolean;
}

function regexItem(s: PageSession, r: RegexScript): RegexItem {
  const charName = (id: string) => s.world.chars.find((c) => c.id === id)?.name ?? id;
  const presetName = (id: string) => s.world.presets.find((p) => p.id === id)?.name ?? id;
  return {
    id: r.id,
    name: r.name,
    enabled: r.enabled,
    find: r.findRegex,
    replace: r.replaceString,
    flags: r.flags,
    trim: [...r.trimStrings],
    on: [...r.placement],
    mode: r.display && r.prompt ? "both" : r.prompt ? "prompt" : "display",
    chars: r.targetCharacterIds.map(charName),
    presets: r.targetPromptPresetIds.map(presetName),
    minDepth: r.minDepth,
    maxDepth: r.maxDepth,
  };
}

function presetId(s: PageSession, name: string): string {
  if (name === "in_use") {
    if (!s.world.presetId) throw new Error(t("This chat has no preset.", "이 채팅에 프리셋 없음."));
    return s.world.presetId;
  }
  const p = s.world.presets.find((x) => x.name === name || x.id === name);
  if (!p) throw new Error(t(`No preset: ${name}`, `프리셋 없음: ${name}`));
  return p.id;
}

/** Whether a script belongs to a scope (no scope: every script). */
function inScope(s: PageSession, scope: RegexScope): (r: RegexScript) => boolean {
  if (scope.char !== undefined) {
    const id = findChar(s, scope.char).id;
    return (r) => r.targetCharacterIds.includes(id);
  }
  if (scope.preset !== undefined) {
    const id = presetId(s, scope.preset);
    return (r) => r.targetPromptPresetIds.includes(id);
  }
  if (scope.global) return (r) => !r.targetCharacterIds.length && !r.targetPromptPresetIds.length;
  return () => true;
}

function getRegex(s: PageSession, scope: RegexScope = {}): RegexItem[] {
  return s.world.regex.filter(inScope(s, scope ?? {})).map((r) => regexItem(s, r));
}

/** What a page passed as Marinara's fields (only those given). */
function regexPatch(s: PageSession, input: Record<string, unknown>): Record<string, unknown> {
  const out: Record<string, unknown> = {};
  const list = (v: unknown) => (Array.isArray(v) ? v.map(String) : v === undefined || v === null || v === "" ? [] : [String(v)]);
  if (input.name !== undefined) out.name = String(input.name).slice(0, 200) || "Regex";
  if (input.enabled !== undefined) out.enabled = input.enabled !== false;
  if (input.find !== undefined) out.findRegex = String(input.find);
  if (input.replace !== undefined) out.replaceString = String(input.replace ?? "");
  if (input.flags !== undefined) out.flags = String(input.flags ?? "");
  if (input.trim !== undefined) out.trimStrings = list(input.trim);
  if (input.on !== undefined) out.placement = list(input.on).filter((p) => p === "ai_output" || p === "user_input");
  if (input.mode !== undefined) {
    const mode = ["display", "prompt", "both"].includes(String(input.mode)) ? String(input.mode) : "display";
    out.applyMode = mode;
    out.promptOnly = mode === "prompt";
  }
  if (input.chars !== undefined) out.targetCharacterIds = list(input.chars).map((n) => findChar(s, n).id);
  if (input.presets !== undefined) out.targetPromptPresetIds = list(input.presets).map((n) => presetId(s, n));
  for (const k of ["minDepth", "maxDepth"] as const) {
    if (input[k] !== undefined) out[k] = input[k] === null || input[k] === "" ? null : Math.trunc(Number(input[k])) || 0;
  }
  return out;
}

function confirmDelete(s: PageSession, names: string[]): boolean {
  return s.ui.confirm(t(`This page wants to delete ${names.length} regex script(s): ${names.join(", ")}. Delete?`, `이 페이지가 정규식 ${names.length}개를 지우려고 해요: ${names.join(", ")}. 지울까요?`));
}

/** Adds scripts or changes the one with the same id or name; new ones belong to the scope. `replace`: the scope holds just these. */
export async function setRegex(s: PageSession, items: unknown, options: RegexScope & { replace?: boolean } = {}): Promise<number> {
  if (!s.allowOnce("regex", t("This page wants to change regex scripts (they apply to every chat). Allow?", "이 페이지가 정규식을 고치려고 해요(모든 채팅에 적용). 허락할까요?"))) return 0;
  const scope = options ?? {};
  const fits = inScope(s, scope);
  const all = s.world.regex;
  const kept = new Set<string>();
  let count = 0;
  for (const input of (Array.isArray(items) ? items : [items]) as Record<string, unknown>[]) {
    if (!input || typeof input !== "object") continue;
    const patch = regexPatch(s, input);
    const same = (input.id !== undefined ? all.find((r) => r.id === String(input.id)) : undefined) ?? (patch.name ? all.find((r) => r.name === patch.name && !kept.has(r.id)) : undefined);
    if (same) {
      await patchRegex(same.id, patch);
      kept.add(same.id);
    } else {
      if (!patch.findRegex) throw new Error(t("A regex needs find.", "정규식에 find가 필요함."));
      if (scope.char !== undefined && patch.targetCharacterIds === undefined) patch.targetCharacterIds = [findChar(s, scope.char).id];
      if (scope.preset !== undefined && patch.targetPromptPresetIds === undefined) patch.targetPromptPresetIds = [presetId(s, scope.preset)];
      kept.add(await createRegex({ name: "Regex", placement: ["ai_output"], ...patch }));
    }
    count++;
  }
  if (options.replace) {
    const gone = all.filter((r) => fits(r) && !kept.has(r.id));
    if (gone.length) {
      if (!confirmDelete(s, gone.map((r) => r.name))) throw new Error(t("Not replaced: deleting was refused.", "바꾸지 않음: 지우기를 거절함."));
      for (const r of gone) await deleteRegex(r.id);
    }
  }
  await s.freshWorld();
  return count;
}

/** Deletes scripts by name (or names), or those a function picks (always asked). */
async function delRegex(s: PageSession, which: unknown): Promise<number> {
  const names = typeof which === "function" ? null : (Array.isArray(which) ? which : [which]).map(String);
  const gone = s.world.regex.filter((r) => (names ? names.includes(r.name) || names.includes(r.id) : (which as (r: RegexItem) => unknown)(regexItem(s, r))));
  if (!gone.length || !confirmDelete(s, gone.map((r) => r.name))) return 0;
  for (const r of gone) await deleteRegex(r.id);
  await s.freshWorld();
  return gone.length;
}

export interface ApplyRegexOptions {
  /** Whose text it is: "ai_output" (default) or "user_input". */
  on?: string;
  /** "display" (default) or "prompt". */
  mode?: string;
  /** How far back the message is (0 = the latest, the default). */
  depth?: number;
}

/** The text as this chat's regex scripts turn it. */
export function applyRegex(s: PageSession, text: unknown, options: ApplyRegexOptions = {}): string {
  return applyRegexScripts(String(text ?? ""), s.world.regex, {
    role: options.on === "user_input" ? "user" : "char",
    depth: Math.max(0, Number(options.depth ?? 0) || 0),
    chatCharacters: s.cast.map((c) => c.id),
    names: { user: s.me.name, char: s.cast[0]?.name ?? "" },
    mode: options.mode === "prompt" ? "prompt" : "display",
    presetId: s.world.presetId,
  });
}

export function regexCommands(s: PageSession) {
  return {
    getRegex: cmd((scope?: RegexScope) => getRegex(s, scope)),
    setRegex: cmd({ writes: true }, (items: unknown, options?: RegexScope & { replace?: boolean }) => setRegex(s, items, options)),
    delRegex: cmd({ writes: true }, (which: unknown) => delRegex(s, which)),
    applyRegex: cmd((text: unknown, options?: ApplyRegexOptions) => applyRegex(s, text, options)),
  };
}
