// ES modules and libraries for pages and scripts. The interpreter runs plain
// scripts only, so a module is turned into CommonJS with sucrase, everything
// it imports is fetched first (all the way down), and the modules run in order
// in the page's (or script's) scope. A plain script imported for its side
// effect runs as a plain script; imported by name, with `module` / `exports`
// as a UMD build expects. Tavern Helper's libraries ($, _, z, YAML) load the
// same way, only when the code uses them.

import { transform } from "sucrase";
import { t } from "../shared/i18n";
import { guardLoops } from "./guard";

/** Where a bare name (`import _ from "lodash"`) is fetched from. */
const bareUrl = (name: string): string => `https://cdn.jsdelivr.net/npm/${name}/+esm`;

// ── Tavern Helper's libraries ──

export interface Builtin {
  /** The names it goes by in the scope. */
  names: string[];
  /** Code that uses it. */
  used: RegExp;
  /** A page's own copy (a <script src> of it): then it is left to the page. */
  own: RegExp;
  url: string;
  pick(exports: Record<string, unknown>): unknown;
}

const BUILTINS: Builtin[] = [
  { names: ["$", "jQuery"], used: /(?:^|[^\w$.])(?:\$|jQuery)\s*[(.]/, own: /jquery/i, url: "https://cdn.jsdelivr.net/npm/jquery@3.7.1/dist/jquery.min.js", pick: (e) => e },
  { names: ["_"], used: /(?:^|[^\w$.])_\s*[.(]/, own: /lodash|underscore/i, url: "https://cdn.jsdelivr.net/npm/lodash@4.17.21/lodash.min.js", pick: (e) => e },
  { names: ["z"], used: /(?:^|[^\w$.])z\s*\.\s*[a-z]/, own: /\bzod\b/i, url: "https://cdn.jsdelivr.net/npm/zod@3.23.8/+esm", pick: (e) => e.z ?? e },
  { names: ["YAML"], used: /(?:^|[^\w$.])YAML\s*\./, own: /\byaml\b/i, url: "https://cdn.jsdelivr.net/npm/yaml@2.5.0/+esm", pick: (e) => e.default ?? e },
];

declare global {
  interface RegExpConstructor {
    escape?(text: string): string;
  }
}

const escape = (text: string) => RegExp.escape?.(text) ?? text.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");

/** Code that makes the name itself (`const $ = …`, `function _(…)`, `window.$ = …`). */
const declares = (code: string, name: string): boolean =>
  new RegExp(`\\b(?:const|let|var|function|class)\\s+${escape(name)}(?![\\w$])`).test(code) || new RegExp(`^\\s*(?:window\\.)?${escape(name)}\\s*=(?!=)`, "m").test(code);

/** The libraries `code` uses that it does not bring or make itself (`sources`: addresses of its own scripts). */
export const builtinsFor = (code: string, sources: string[] = []): Builtin[] =>
  BUILTINS.filter((b) => b.used.test(code) && !sources.some((src) => b.own.test(src)) && !b.names.some((n) => declares(code, n)));

/** Libraries known not to run here, and the name a note shows. */
const KNOWN: { test: RegExp; name: string }[] = [{ test: /MagVarUpdate/i, name: "MVU (MagVarUpdate)" }];

/** Code that is an ES module (import or export at the start of a line). */
export const isModuleCode = (code: string): boolean => /^[ \t]*(?:import\s*[\w*{'"]|export\s)/m.test(code);

export interface ImportRef {
  spec: string;
  /** Imported by name (default, named, namespace or dynamic), not just for its side effect. */
  named: boolean;
}

const IMPORT_FROM = /^[ \t]*(?:import|export)\s+([^'";]*?)\s*from\s*['"]([^'"]+)['"]/gm;
const IMPORT_BARE = /^[ \t]*import\s*['"]([^'"]+)['"]/gm;
const DYNAMIC = /\bimport\s*\(\s*['"]([^'"]+)['"]\s*\)/g;

/** What a module imports, by the specifiers it writes. */
export function importsOf(code: string): ImportRef[] {
  const out = new Map<string, boolean>();
  for (const m of code.matchAll(IMPORT_FROM)) out.set(m[2], true);
  for (const m of code.matchAll(DYNAMIC)) out.set(m[1], true);
  for (const m of code.matchAll(IMPORT_BARE)) if (!out.has(m[1])) out.set(m[1], false);
  return [...out].map(([spec, named]) => ({ spec, named }));
}

/** The address a specifier names, from the module that writes it (`base`: its address, or null for code with none). */
export function resolveSpec(spec: string, base: string | null): string {
  if (/^https:\/\//i.test(spec)) return spec;
  if (/^(?:\.{0,2}\/)/.test(spec)) {
    if (!base) throw new Error(t(`Use a full address: ${spec}`, `전체 주소를 쓰세요: ${spec}`));
    return new URL(spec, base).href;
  }
  if (/^[a-z][\w+.-]*:/i.test(spec)) throw new Error(t(`Not supported: ${spec}`, `지원 안 함: ${spec}`));
  return bareUrl(spec);
}

/** A module as CommonJS (require / module / exports); `import()` becomes a require of what was fetched. */
export function toCommonJs(code: string): string {
  // without the "use strict" sucrase adds: cards' code is written for a browser's plain scripts
  return transform(code, { transforms: ["imports"], production: true }).code.replace(/^\s*"use strict";/, "");
}

/** A library Fornello knows will not run (its note says just that). */
class Unsupported extends Error {}

// Fetched sources, shared by every page and script (each still runs its own copy)
const sources = new Map<string, Promise<string>>();

/** Forgets the fetched sources (Fornello stops). */
export function forgetModules(): void {
  sources.clear();
}

function fetchSource(url: string): Promise<string> {
  let text = sources.get(url);
  if (!text) {
    text = (async () => {
      const known = KNOWN.find((k) => k.test.test(url));
      if (known) throw new Unsupported(t(`Not supported: ${known.name}`, `지원 안 함: ${known.name}`));
      const href = new URL(url);
      if (href.protocol !== "https:") throw new Error(t("only https libraries are loaded", "https 라이브러리만 불러와요"));
      const res = await fetch(href.href, { credentials: "omit", referrerPolicy: "no-referrer" });
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      return res.text();
    })();
    sources.set(url, text);
    // a failed fetch is tried again next time
    text.catch(() => sources.delete(url));
  }
  return text;
}

interface Loaded {
  url: string;
  kind: "module" | "script";
  code: string;
  /** Specifier → address, for what it imports. */
  deps: Map<string, string>;
  /** The specifiers it imports by name (the converted code does not say which). */
  named: Set<string>;
}

interface Evaluated {
  module: { exports: Record<string, unknown> };
}

/**
 * The modules of one interpreter. `run(source)` runs code there in the
 * page's (or script's) scope; a module hands its body over through
 * `__fornelloDefine`, which the caller gives the interpreter as `define`.
 */
export class ModuleSystem {
  private readonly loaded = new Map<string, Promise<Loaded>>();
  private readonly done = new Map<string, Evaluated>();
  private readonly factories = new Map<string, (...a: unknown[]) => unknown>();
  private next = 0;

  /** Imports that could not be had: reported once, and they import as empty. */
  private readonly failed = new Set<string>();

  constructor(
    private readonly run: (source: string) => void,
    private readonly report: (e: unknown) => void,
  ) {}

  /** For the interpreter: `__fornelloDefine(id, fn)` hands a module's body over. */
  readonly define = (id: string, fn: (...a: unknown[]) => unknown): void => {
    this.factories.set(id, fn);
  };

  /** Fetches a module and everything under it (once per address). */
  private load(url: string): Promise<Loaded> {
    let found = this.loaded.get(url);
    if (!found) {
      found = fetchSource(url).then((text) => (isModuleCode(text) ? this.parse(text, url) : { url, kind: "script" as const, code: text, deps: new Map(), named: new Set<string>() }));
      this.loaded.set(url, found);
    }
    return found;
  }

  /** A module's own parse: what it imports is named, not fetched yet. */
  private parse(text: string, url: string | null): Loaded {
    const refs = importsOf(text);
    const deps = new Map<string, string>();
    for (const r of refs) deps.set(r.spec, resolveSpec(r.spec, url));
    return { url: url ?? `inline:${this.next++}`, kind: "module", code: toCommonJs(text), deps, named: new Set(refs.filter((r) => r.named).map((r) => r.spec)) };
  }

  /** Fetches everything under a module, each address once (a cycle is fine); one that fails is reported and imports as empty. */
  private async fetchAll(item: Loaded, seen = new Set<string>()): Promise<void> {
    await Promise.all(
      [...new Set(item.deps.values())].map(async (u) => {
        if (seen.has(u)) return;
        seen.add(u);
        try {
          await this.fetchAll(await this.load(u), seen);
        } catch (e) {
          if (!this.failed.has(u)) this.report(e instanceof Unsupported ? e.message : t(`Could not load ${u}: ${e instanceof Error ? e.message : e}`, `${u}을(를) 불러오지 못했어요: ${e instanceof Error ? e.message : e}`));
          this.failed.add(u);
        }
      }),
    );
  }

  /** Runs a module once, what it imports first. */
  private async evaluate(item: Loaded, named: boolean): Promise<Record<string, unknown>> {
    const key = `${item.kind === "script" && !named ? "side" : "named"}:${item.url}`;
    // imported again, or in a cycle: its exports, filled or still filling
    const known = this.done.get(key);
    if (known) return known.module.exports;
    const module = { exports: {} as Record<string, unknown> };
    this.done.set(key, { module });
    if (item.kind === "script" && !named) {
      this.run(guardLoops(item.code));
    } else if (item.kind === "script") {
      await this.call(item.code, false, module, () => {
        throw new Error(t("Not supported: require in a library", "지원 안 함: 라이브러리 안의 require"));
      });
    } else {
      const exportsOf = new Map<string, Record<string, unknown>>();
      for (const [spec, url] of item.deps) exportsOf.set(spec, this.failed.has(url) ? {} : await this.evaluate(await this.load(url), item.named.has(spec)));
      const require = (spec: string) => {
        const found = exportsOf.get(spec);
        if (!found) throw new Error(t(`Not loaded: ${spec}`, `불러오지 않음: ${spec}`));
        return found;
      };
      await this.call(item.code, true, module, require);
    }
    return module.exports;
  }

  /** Runs a body with require / module / exports (a module's in an async function, so `await` works at its top). */
  private async call(code: string, isModule: boolean, module: { exports: Record<string, unknown> }, require: (spec: string) => unknown): Promise<void> {
    const id = `m${this.next++}`;
    this.run(guardLoops(`__fornelloDefine(${JSON.stringify(id)}, ${isModule ? "async function" : "function"} (require, module, exports, define) {\n${code}\n});`));
    const fn = this.factories.get(id);
    this.factories.delete(id);
    if (!fn) throw new Error("module did not load");
    await fn.call(module.exports, require, module, module.exports, undefined);
  }

  /** Runs code that is a module (a page's module script, a script with import / export). Relative imports need `base`. */
  async runModule(code: string, base: string | null = null): Promise<Record<string, unknown>> {
    const item = this.parse(code, base);
    await this.fetchAll(item);
    return this.evaluate(item, true);
  }

  /** A library by address, as its exports (a plain script runs with module / exports). */
  async library(url: string): Promise<Record<string, unknown>> {
    const item = await this.load(url);
    await this.fetchAll(item);
    return this.evaluate(item, true);
  }

  /** Puts the Tavern Helper libraries `code` uses into the scope (`define`); one that fails to load is reported. */
  async builtins(code: string, sources: string[], define: (name: string, value: unknown) => void, report: (e: unknown) => void): Promise<void> {
    await Promise.all(
      builtinsFor(code, sources).map(async (b) => {
        try {
          const value = b.pick(await this.library(b.url));
          for (const name of b.names) define(name, value);
        } catch (e) {
          report(t(`Could not load ${b.names[0]}: ${e instanceof Error ? e.message : e}`, `${b.names[0]}을(를) 불러오지 못했어요: ${e instanceof Error ? e.message : e}`));
        }
      }),
    );
  }
}
