// How components look beyond their own CSS: icon fonts loaded when the code
// uses their classes, and theme colours and classes that follow Marinara's theme.

import { stylesheetUrls } from "../runtime/stylesheets";

export const FONT_AWESOME = "https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css";
const MATERIAL_SYMBOLS = (style: string) => `https://fonts.googleapis.com/css2?family=Material+Symbols+${style}`;
const MATERIAL_ICONS = "https://fonts.googleapis.com/icon?family=Material+Icons";

/** The icon stylesheets the code's classes ask for: Font Awesome (fa-…), Material Symbols, Material Icons. */
export function iconSheets(code: string): string[] {
  const out: string[] = [];
  // fa-solid / fa-regular / fa-brands …, or "fa fa-heart" / "fas fa-heart"
  if (/\bfa-(?:solid|regular|brands|light|thin|duotone|sharp)\b|\bfa[srbld]?\s+fa-[\w-]+/.test(code)) out.push(FONT_AWESOME);
  for (const m of code.matchAll(/\bmaterial-symbols-(outlined|rounded|sharp)\b/g)) {
    const url = MATERIAL_SYMBOLS(m[1][0].toUpperCase() + m[1].slice(1));
    if (!out.includes(url)) out.push(url);
  }
  if (/\bmaterial-icons\b/.test(code)) out.push(MATERIAL_ICONS);
  return out;
}

/** Every stylesheet a component needs: its own <link> and @import ones, then the icons it uses. */
export function componentSheets(code: string): string[] {
  return [...new Set([...stylesheetUrls(code), ...iconSheets(code)])];
}

/** Theme colours for a component's CSS (var(--fc-accent)), from shared/theme.ts's --d-… tokens, and a few ready classes. */
export const THEME_CSS = `
:host {
  --fc-text: var(--d-text); --fc-muted: var(--d-muted); --fc-title: var(--d-title);
  --fc-card: var(--card, var(--background, #111)); --fc-field: var(--d-field); --fc-line: var(--d-line);
  --fc-accent: var(--d-accent); --fc-accent-text: var(--d-accent-text);
  --fc-danger: var(--d-danger); --fc-radius: var(--d-radius); --fc-font: var(--d-font);
}
.fc-card { background: var(--d-panel-solid); color: var(--fc-text); border: 1px solid var(--fc-line); border-radius: var(--fc-radius); padding: 10px 12px; }
.fc-title { color: var(--fc-title); font-weight: 700; }
.fc-muted { color: var(--fc-muted); }
.fc-accent { color: var(--fc-accent); }
.fc-line { border-color: var(--fc-line); }
.fc-badge { display: inline-block; padding: 1px 8px; border-radius: 999px; font-size: .85em; background: var(--d-accent-fill); color: var(--fc-accent-text); }
.fc-btn { font: inherit; padding: 5px 12px; border-radius: 999px; border: 1px solid var(--fc-accent); background: transparent; color: var(--fc-accent); cursor: pointer; }
.fc-btn:hover { background: var(--d-accent-fill); color: var(--fc-accent-text); }
.fc-bar { height: 6px; border-radius: 999px; background: var(--fc-field); overflow: hidden; }
.fc-bar > i { display: block; height: 100%; width: var(--value, 50%); background: var(--fc-accent); border-radius: inherit; }
`;
