// What Fornello reads from Marinara, in the shapes the rest of the code uses.

export interface ChatDetail {
  id: string;
  name?: string;
  /** "roleplay", "conversation", "game"… */
  mode?: string;
  metadata?: unknown;
  characterIds?: unknown;
  personaId?: string | null;
  connectionId?: string | null;
  promptPresetId?: string | null;
}

export type MessageRole = "user" | "char" | "narrator" | "system";

export interface Message {
  /** Marinara's message id. */
  id: string;
  /** Position in the chat, counting from 1 (as Marinara numbers messages). */
  num: number;
  role: MessageRole;
  name: string;
  text: string;
  hidden: boolean;
  /** The character who wrote it (character messages). */
  characterId: string | null;
  /** The swipe on screen (from 0), and how many there are. */
  swipe?: number;
  swipes?: number;
  /** Data pages and scripts keep with the message (its swipe on screen): setMsgData. */
  data?: Record<string, unknown>;
  /** When it was written (Marinara orders a chat's messages by it). */
  at?: string;
  /** The sprite expression Marinara's Expression agent chose for it, by character id. */
  expressions?: Record<string, string>;
  /** What Pesto kept with its swipe (the dice rolled before it). */
  story?: Record<string, unknown>;
}

export interface CharacterInfo {
  id: string;
  name: string;
  description: string;
  personality: string;
  scenario: string;
  firstMessage: string;
  data: Record<string, unknown>;
}

export interface PersonaInfo {
  id: string | null;
  name: string;
  description: string;
}

export interface LoreBook {
  id: string;
  name: string;
  /** Characters the book belongs to (a card's own book). */
  characterIds?: string[];
  personaIds?: string[];
  /** The chat it is that chat's own book of. */
  chatId?: string | null;
  /** On in every chat. */
  isGlobal?: boolean;
  enabled?: boolean;
  /** "character" for a book Marinara made from a card. */
  category?: string;
}

export interface RawLoreEntry {
  id: string;
  name?: string;
  content?: string;
  keys?: string[];
  secondaryKeys?: string[];
  enabled?: boolean;
  constant?: boolean;
  selective?: boolean;
  position?: number;
  depth?: number;
  order?: number;
  role?: string;
  probability?: number | null;
  scanDepth?: number | null;
  [key: string]: unknown;
}

/** A lorebook entry that goes with every reply. */
export interface LoreNote {
  name: string;
  content: string;
}
