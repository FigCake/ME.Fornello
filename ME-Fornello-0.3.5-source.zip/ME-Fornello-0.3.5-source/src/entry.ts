import { start } from "./main";

void start().catch((e) => {
  console.error("[Fornello] failed to start", e);
});
