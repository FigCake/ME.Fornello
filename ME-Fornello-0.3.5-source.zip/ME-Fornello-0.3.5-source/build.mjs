// Builds Fornello, the page runner for Marinara Engine:
//
//   dist/manifest.json                Marinara personal-extension manifest (v1)
//   dist/extension.js                 the whole extension, one readable file (esbuild, no minify)
//   dist/README-ko.txt                the Korean README, for people who open the zip
//   dist/SHA256SUMS.txt               file hashes + the content hash Marinara will show
//   dist/ME-Fornello-<version>.zip    what you import in Settings → Addons → External Extensions
//   dist/ME-Fornello-<version>-source.zip   the Corresponding Source (AGPL-3.0 §6): what it takes to rebuild extension.js
//   dist/public/                      exactly what the public repository (FigCake/ME.Fornello) carries
//
// Deterministic: same sources → same bytes (fixed zip timestamps, store-only
// entries, sorted names, no source maps).

import { build } from 'esbuild';
import { createHash } from 'node:crypto';
import { mkdir, readFile, readdir, rm, writeFile } from 'node:fs/promises';
import { join, relative } from 'node:path';
import { fileURLToPath } from 'node:url';
import { patchSval, svalFile } from './patch-sval.mjs';

const CRC_TABLE = new Uint32Array(256).map((_, n) => {
    let c = n;
    for (let k = 0; k < 8; k++) c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1;
    return c >>> 0;
});

const root = fileURLToPath(new URL('.', import.meta.url));
const at = (...parts) => join(root, ...parts);
const sha256 = bytes => createHash('sha256').update(bytes).digest('hex');

const pkg = JSON.parse(await readFile(at('package.json'), 'utf8'));
const version = pkg.version;
const name = 'Fornello';
const description =
    'Runs HTML pages with their scripts inside Marinara: HTML code blocks in chat messages, and pages from other extensions '
    + '(Dispensa\'s 🌟 viewer). Marinara\'s security policy blocks inline scripts, so Fornello runs them in a JavaScript '
    + 'interpreter (sval). Pages can call the AI, send messages, and read and write chat variables and lorebooks (short commands, plus JS-Slash-Runner names, so SillyTavern card pages run too). '
    + 'By default the newest pages on screen run on their own; settings switch this to click to run, or off. '
    + '채팅 속 HTML 페이지를 스크립트까지 실행합니다. 마리나라가 막는 스크립트를 내장 해석기로 돌리며, 페이지에서 AI 호출과 채팅 변수 읽기·쓰기를 할 수 있어요. 기본은 화면의 최근 페이지가 바로 실행되고, 설정에서 눌러서 실행·끄기로 바꿀 수 있어요.';

await rm(at('dist'), { recursive: true, force: true });
await mkdir(at('dist'), { recursive: true });

// 1. Bundle. Marinara runs this as the body of `async (marinara) => { … }`, so:
//    IIFE, no imports/exports, `marinara` left as a free identifier.
const banner = `/*! ${name} ${version} — page runner for Marinara Engine 2.5.x (External Extension).
 * Runs HTML pages and their scripts in Marinara with a JavaScript interpreter.
 * Copyright (C) 2026 FigCake. Works with Marinara Engine (AGPL-3.0); includes sval, acorn, sucrase and html-to-image (MIT) and Lucide icons (ISC).
 * License: AGPL-3.0. Source: https://github.com/FigCake/ME.Fornello (ME-Fornello-${version}-source.zip) */`;
// Bundled third-party code (MIT, and Lucide's icon paths: ISC): its notices travel inside extension.js and next to it.
const notices = (await Promise.all(['sval', 'acorn', 'sucrase', 'lines-and-columns', 'html-to-image'].map(async dep => {
    const meta = JSON.parse(await readFile(at('node_modules', dep, 'package.json'), 'utf8'));
    const license = (await readFile(at('node_modules', dep, 'LICENSE'), 'utf8')).trim();
    return `${dep} ${meta.version} (${meta.license})\n\n${license}`;
}))).concat([`Lucide icons (ISC; some icons from Feather, MIT), drawn as SVG paths\n\n${(await readFile(at('third-party', 'lucide-LICENSE.txt'), 'utf8')).trim()}`]).join('\n\n-----\n\n');
const footer = `/*! Third-party notices (bundled code):\n\n${notices.replace(/\*\//g, '* /')}\n*/`;

// Sucrase's source maps and option checking are never used (they would pull in
// @jridgewell/* and ts-interface-checker): stand-ins keep them out of the bundle.
const trimSucrase = {
    name: 'trim-sucrase',
    setup(b) {
        b.onResolve({ filter: /^\.\/(computeSourceMap|Options)$/ }, args =>
            /[\\/]node_modules[\\/]sucrase[\\/]/.test(args.importer) ? { path: args.path.slice(2), namespace: 'sucrase-stub' } : undefined);
        b.onLoad({ filter: /.*/, namespace: 'sucrase-stub' }, args => ({
            loader: 'js',
            contents: args.path === 'Options'
                ? 'export function validateOptions() {}'
                : 'export default function computeSourceMap() { throw new Error("source maps are not bundled"); }',
        }));
    },
};

// sval's fixes (patch-sval.mjs)
const fixSval = {
    name: 'fix-sval',
    setup(b) {
        b.onLoad({ filter: svalFile }, async args => ({ loader: 'js', contents: patchSval(await readFile(args.path, 'utf8')) }));
    },
};

await build({
    entryPoints: [at('src/entry.ts')],
    plugins: [trimSucrase, fixSval],
    outfile: at('dist/extension.js'),
    bundle: true,
    format: 'iife',
    platform: 'browser',
    target: 'es2022',
    minify: false,
    sourcemap: false,
    legalComments: 'inline',
    logLevel: 'warning',
    charset: 'utf8',
    banner: { js: banner },
    footer: { js: footer },
});
const js = await readFile(at('dist/extension.js'));
const jsText = js.toString('utf8');
// (top level only: bundled libraries carry the words inside strings, e.g. Sucrase's import helpers)
if (/^(import|export)\s/m.test(jsText)) throw new Error('bundle must not contain import/export statements');

// 2. Manifest (packages/shared/src/schemas/personal-extension.schema.ts limits: name ≤ 200, version ≤ 64, description ≤ 2000)
const manifest = {
    kind: 'marinara.personal-extension',
    version: 1,
    config: {
        name,
        version,
        description,
        runtime: 'client',
        capabilities: ['full_page_access'],
        jsPath: 'extension.js',
    },
};
if (description.length > 2000) throw new Error('description exceeds 2000 characters');
const manifestText = `${JSON.stringify(manifest, null, 2)}\n`;
await writeFile(at('dist/manifest.json'), manifestText);

await writeFile(at('dist/THIRD_PARTY_NOTICES.txt'), `${notices}\n`);

// 3. README for the zip
const readmeKo = await readFile(at('README-ko.md'), 'utf8');
await writeFile(at('dist/README-ko.txt'), readmeKo);

// 4. Source archive: the code and everything the build reads (sorted, fixed timestamps).
//    Tests, e2e and CI stay in the development repository.
const SOURCE_FILES = ['build.mjs', 'patch-sval.mjs', 'package.json', 'package-lock.json', 'tsconfig.json', 'README.md', 'README-ko.md', 'third-party/lucide-LICENSE.txt', 'LICENSE'];
const SOURCE_DIRS = ['src', 'scripts'];
const listFiles = async dir => {
    const out = [];
    for (const entry of await readdir(at(dir), { withFileTypes: true })) {
        const path = join(dir, entry.name);
        if (entry.isDirectory()) out.push(...(await listFiles(path)));
        else if (!entry.name.startsWith('.')) out.push(path);
    }
    return out;
};
const sourcePaths = [...SOURCE_FILES];
for (const dir of SOURCE_DIRS) sourcePaths.push(...(await listFiles(dir)));
const sourceZipName = `ME-Fornello-${version}-source.zip`;
const sourceZip = createZip(
    (await Promise.all(sourcePaths.map(async f => ({ name: `ME-Fornello-${version}-source/${relative(root, at(f)).split('\\').join('/')}`, data: await readFile(at(f)) }))))
        .sort((a, b) => (a.name < b.name ? -1 : 1)),
);
await writeFile(at('dist', sourceZipName), sourceZip);

// 5. Hashes: per file, and the content hash Marinara computes for this exact package
//    (personal-extension-hash.ts: sha256 of JSON.stringify([runtime, css, js, serverJs, capabilities]))
const contentHash = `sha256:${sha256(JSON.stringify(['client', '', jsText, '', ['full_page_access']]))}`;
const sums = [
    `${sha256(js)}  extension.js`,
    `${sha256(Buffer.from(manifestText))}  manifest.json`,
    `${sha256(Buffer.from(readmeKo))}  README-ko.txt`,
    `${sha256(Buffer.from(`${notices}\n`))}  THIRD_PARTY_NOTICES.txt`,
    `${sha256(sourceZip)}  ${sourceZipName}`,
    '',
    `Marinara content hash (shown in "Review and Run"): ${contentHash}`,
    '',
].join('\n');
await writeFile(at('dist/SHA256SUMS.txt'), sums);

// 6. Zip
const entries = [
    { name: 'manifest.json', data: Buffer.from(manifestText) },
    { name: 'extension.js', data: js },
    { name: 'README-ko.txt', data: Buffer.from(readmeKo) },
    { name: 'SHA256SUMS.txt', data: Buffer.from(sums) },
    { name: 'THIRD_PARTY_NOTICES.txt', data: Buffer.from(`${notices}\n`) },
].sort((a, b) => (a.name < b.name ? -1 : 1));
const zipName = `ME-Fornello-${version}.zip`;
const zip = createZip(entries);
await writeFile(at('dist', zipName), zip);

// 7. The public set: what FigCake/ME.Fornello publishes (the build, plus the source archive).
//    The READMEs lose their Development section; everything else is identical.
const stripDevelopment = text => text.replace(/\n## (Development|개발)\n[\s\S]*?(?=\n## |$)/, '\n').trimEnd() + '\n';
await mkdir(at('dist/public'), { recursive: true });
// its checksums list only what it carries (README-ko.txt lives in the zip)
await writeFile(at('dist/public/SHA256SUMS.txt'), sums.split('\n').filter(line => !/  README-ko\.txt$/.test(line)).join('\n'));
for (const file of ['manifest.json', 'extension.js', 'THIRD_PARTY_NOTICES.txt', zipName, sourceZipName]) {
    await writeFile(at('dist/public', file), await readFile(at('dist', file)));
}
await writeFile(at('dist/public/README.md'), stripDevelopment(await readFile(at('README.md'), 'utf8')));
await writeFile(at('dist/public/README-ko.md'), stripDevelopment(readmeKo));
await writeFile(at('dist/public/LICENSE'), await readFile(at('LICENSE')));

console.log(`${name} ${version}`);
console.log(`  dist/extension.js   ${js.byteLength} bytes  sha256 ${sha256(js)}`);
console.log(`  dist/${zipName}  ${zip.byteLength} bytes  sha256 ${sha256(zip)}`);
console.log(`  Marinara content hash: ${contentHash}`);

// ── deterministic store-only zip writer (fixed timestamp, no directory entries) ──
function createZip(files) {
    const DOS_DATE = ((2000 - 1980) << 9) | (1 << 5) | 1; // 2000-01-01
    const locals = [], centrals = [];
    let offset = 0;
    for (const { name, data } of files) {
        const nameBytes = Buffer.from(name, 'utf8');
        const checksum = crc32(data);
        const local = Buffer.alloc(30);
        local.writeUInt32LE(0x04034b50, 0);
        local.writeUInt16LE(20, 4);
        local.writeUInt16LE(0x0800, 6);
        local.writeUInt16LE(0, 8);
        local.writeUInt16LE(0, 10);
        local.writeUInt16LE(DOS_DATE, 12);
        local.writeUInt32LE(checksum, 14);
        local.writeUInt32LE(data.length, 18);
        local.writeUInt32LE(data.length, 22);
        local.writeUInt16LE(nameBytes.length, 26);
        local.writeUInt16LE(0, 28);
        locals.push(local, nameBytes, data);

        const central = Buffer.alloc(46);
        central.writeUInt32LE(0x02014b50, 0);
        central.writeUInt16LE((3 << 8) | 20, 4);
        central.writeUInt16LE(20, 6);
        central.writeUInt16LE(0x0800, 8);
        central.writeUInt16LE(0, 10);
        central.writeUInt16LE(0, 12);
        central.writeUInt16LE(DOS_DATE, 14);
        central.writeUInt32LE(checksum, 16);
        central.writeUInt32LE(data.length, 20);
        central.writeUInt32LE(data.length, 24);
        central.writeUInt16LE(nameBytes.length, 28);
        central.writeUInt16LE(0, 30);
        central.writeUInt16LE(0, 32);
        central.writeUInt16LE(0, 34);
        central.writeUInt16LE(0, 36);
        central.writeUInt32LE(0o644 << 16, 38);
        central.writeUInt32LE(offset, 42);
        centrals.push(central, nameBytes);
        offset += local.length + nameBytes.length + data.length;
    }
    const centralSize = centrals.reduce((n, b) => n + b.length, 0);
    const end = Buffer.alloc(22);
    end.writeUInt32LE(0x06054b50, 0);
    end.writeUInt16LE(files.length, 8);
    end.writeUInt16LE(files.length, 10);
    end.writeUInt32LE(centralSize, 12);
    end.writeUInt32LE(offset, 16);
    return Buffer.concat([...locals, ...centrals, end]);
}

function crc32(bytes) {
    let crc = 0xffffffff;
    for (const b of bytes) crc = CRC_TABLE[(crc ^ b) & 0xff] ^ (crc >>> 8);
    return (crc ^ 0xffffffff) >>> 0;
}
