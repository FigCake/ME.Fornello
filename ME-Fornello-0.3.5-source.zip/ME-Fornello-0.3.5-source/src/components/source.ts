// Reading a component's source without running it (its name, values and
// defaults), and the <Name …/> tags the AI writes in a reply.


/** Drops import lines and export keywords, so React examples from elsewhere paste as they are. */
export function cleanSource(code: string): string {
  return code
    .replace(/^[ \t]*import\s+[\s\S]*?\sfrom\s+['"][^'"]+['"];?[ \t]*$/gm, "")
    .replace(/^[ \t]*import\s+['"][^'"]+['"];?[ \t]*$/gm, "")
    .replace(/^[ \t]*export\s+default\s+([A-Za-z_$][\w$]*)\s*;?[ \t]*$/gm, "")
    .replace(/^([ \t]*)export\s+default\s+(?=(async\s+)?function\b|class\b)/gm, "$1")
    .replace(/^([ \t]*)export\s+(?=(const|let|var|function|class|async)\b)/gm, "$1");
}

/** The component: the first top-level `function Name(` or `const Name = (…) =>` with a capital letter. */
export function componentName(code: string): string | null {
  const src = cleanSource(code);
  const m =
    /^[ \t]*(?:async\s+)?function\s+([A-Z][\w$]*)\s*\(/m.exec(src) ??
    /^[ \t]*(?:const|let|var)\s+([A-Z][\w$]*)\s*=\s*(?:React\.memo\(\s*)?(?:async\s+)?(?:function\b|\(|[A-Za-z_$][\w$]*\s*=>)/m.exec(src);
  return m ? m[1] : null;
}

/** Index of the bracket closing the one at `open`, skipping strings, templates and comments. */
function closing(src: string, open: number): number {
  const pairs: Record<string, string> = { "(": ")", "{": "}", "[": "]" };
  const stack: string[] = [];
  for (let i = open; i < src.length; i++) {
    const c = src[i];
    if (c === "'" || c === '"' || c === "`") {
      for (i++; i < src.length && src[i] !== c; i++) if (src[i] === "\\") i++;
      continue;
    }
    if (c === "/" && src[i + 1] === "/") {
      i = src.indexOf("\n", i);
      if (i < 0) return -1;
      continue;
    }
    if (c === "/" && src[i + 1] === "*") {
      i = src.indexOf("*/", i + 2) + 1;
      if (i <= 0) return -1;
      continue;
    }
    if (pairs[c]) stack.push(pairs[c]);
    else if (c === ")" || c === "}" || c === "]") {
      if (stack.pop() !== c) return -1;
      if (!stack.length) return i;
    }
  }
  return -1;
}

/** Splits at commas that are not inside brackets or strings. */
function topLevelSplit(text: string): string[] {
  const out: string[] = [];
  let depth = 0;
  let cur = "";
  for (let i = 0; i < text.length; i++) {
    const c = text[i];
    if (c === "'" || c === '"' || c === "`") {
      let j = i + 1;
      for (; j < text.length && text[j] !== c; j++) if (text[j] === "\\") j++;
      cur += text.slice(i, j + 1);
      i = j;
      continue;
    }
    if ("([{".includes(c)) depth++;
    if (")]}".includes(c)) depth--;
    if (c === "," && depth === 0) {
      out.push(cur);
      cur = "";
      continue;
    }
    cur += c;
  }
  if (cur.trim()) out.push(cur);
  return out;
}

export interface PropInfo {
  name: string;
  /** The default as written in the source ("" when none). */
  fallback: string;
}

/** The values a component takes: `function Name({ a = 1, b })`, or `const { a = 1 } = props` right inside it. */
export function componentProps(code: string, name: string): PropInfo[] {
  const at = propsPattern(code, name);
  if (!at) return [];
  const out: PropInfo[] = [];
  for (const part of topLevelSplit(code.slice(at.start + 1, at.end))) {
    const m = propPart(part);
    if (m) out.push({ name: m.name, fallback: m.fallback });
  }
  return out;
}

/** One `name`, `name = default` or `name: Type = default` of the pattern (a `...rest` is not one). */
function propPart(part: string): { name: string; fallback: string } | null {
  const p = part.trim();
  if (!p || p.startsWith("...")) return null;
  const m = /^([A-Za-z_$][\w$]*)\s*(?::\s*[A-Za-z_$][\w$]*)?\s*(?:=\s*([\s\S]+))?$/.exec(p);
  return m ? { name: m[1], fallback: (m[2] ?? "").trim() } : null;
}

/** Where the `{ … }` the component takes its values from is (see componentProps). */
function propsPattern(code: string, name: string): { start: number; end: number } | null {
  // import lines are blanked, not removed, so places in `src` are places in `code`
  const src = code.replace(/^[ \t]*import\s[^\n]*$/gm, (line) => " ".repeat(line.length));
  const head = new RegExp(`(?:function\\s+${name}\\s*|(?:const|let|var)\\s+${name}\\s*=\\s*(?:React\\.memo\\(\\s*)?(?:function\\s*)?)\\(`).exec(src);
  if (!head) return null;
  const open = head.index + head[0].length - 1;
  const close = closing(src, open);
  if (close < 0) return null;
  const param = src.slice(open + 1, close);
  const brace = param.search(/\S/);
  if (brace >= 0 && param[brace] === "{") {
    const start = open + 1 + brace;
    const end = closing(src, start);
    return end < 0 ? null : { start, end };
  }
  // function Name(props = {}) { const { … } = props;
  const word = /^\s*([A-Za-z_$][\w$]*)/.exec(param)?.[1];
  if (!word) return null;
  const body = new RegExp(`(?:const|let|var)\\s*(\\{)[\\s\\S]*?\\}\\s*=\\s*${word}\\b`).exec(src.slice(close));
  if (!body) return null;
  const start = close + body.index + body[0].indexOf("{");
  const end = closing(src, start);
  return end < 0 ? null : { start, end };
}

/** The code with a variable renamed: not in strings or comments, after a dot, or as an object key. */
function renameIdentifier(code: string, from: string, to: string): string {
  let out = "";
  let i = 0;
  const word = /[\w$]/;
  // `}` ends a ${…} back into its template
  const templates: number[] = [];
  let depth = 0;
  // the brackets open around the place: `{ hp, mp }` is an object only right inside a `{`
  const brackets: string[] = [];
  const template = () => {
    // inside a template's text: up to its end, or to a ${ that opens code
    while (i < code.length) {
      const c = code[i];
      if (c === "\\") {
        out += code.slice(i, i + 2);
        i += 2;
        continue;
      }
      if (c === "`") {
        out += c;
        i++;
        return;
      }
      if (c === "$" && code[i + 1] === "{") {
        out += "${";
        i += 2;
        templates.push(depth);
        depth++;
        brackets.push("{");
        return;
      }
      out += c;
      i++;
    }
  };
  while (i < code.length) {
    const c = code[i];
    if (c === "'" || c === '"') {
      let j = i + 1;
      for (; j < code.length && code[j] !== c && code[j] !== "\n"; j++) if (code[j] === "\\") j++;
      out += code.slice(i, j + 1);
      i = j + 1;
    } else if (c === "`") {
      out += c;
      i++;
      template();
    } else if (c === "/" && code[i + 1] === "/") {
      const end = code.indexOf("\n", i);
      out += code.slice(i, end < 0 ? code.length : end);
      i = end < 0 ? code.length : end;
    } else if (c === "/" && code[i + 1] === "*") {
      const end = code.indexOf("*/", i + 2);
      out += code.slice(i, end < 0 ? code.length : end + 2);
      i = end < 0 ? code.length : end + 2;
    } else if (c === "{") {
      depth++;
      brackets.push(c);
      out += c;
      i++;
    } else if (c === "}") {
      depth--;
      brackets.pop();
      out += c;
      i++;
      if (templates.length && templates[templates.length - 1] === depth) {
        templates.pop();
        template();
      }
    } else if (word.test(c)) {
      let j = i;
      while (j < code.length && word.test(code[j])) j++;
      const w = code.slice(i, j);
      const before = out.replace(/\s+$/, "").slice(-1);
      const after = code.slice(j).match(/^\s*(.)/)?.[1];
      const key = after === ":" && /[{,]/.test(before);
      // a JSX attribute (<Bar hp={…} />) names the other component's value
      const attr = /^\s*=\s*[{"']/.test(code.slice(j)) && /[\w"'}]/.test(before);
      // words in a tag's text (<b>hp left</b>) are text, not code
      const text = /<\/?[A-Za-z][\w.:-]*(?:\s[^<>]*)?\/?>[^<>{}();=]*$/.test(out.slice(-300));
      // `{ hp, mp }`: the key stays, the value is the new name (a lone `{hp}` is JSX's {…})
      const shorthand = brackets[brackets.length - 1] === "{" && (before === "," || (before === "{" && after === ",")) && (after === "," || after === "}" || after === "=");
      if (w !== from || before === "." || key || attr || text) out += w;
      else out += shorthand ? `${w}: ${to}` : to;
      i = j;
    } else {
      if (c === "(" || c === "[") brackets.push(c);
      else if (c === ")" || c === "]") brackets.pop();
      out += c;
      i++;
    }
  }
  return out;
}

/** Where the component's own code ends: its `{ … }` body, or the expression its arrow returns. */
function componentEnd(code: string, name: string): number {
  const src = code.replace(/^[ \t]*import\s[^\n]*$/gm, (line) => " ".repeat(line.length));
  const head = new RegExp(`(?:function\\s+${name}\\s*|(?:const|let|var)\\s+${name}\\s*=\\s*(?:React\\.memo\\(\\s*)?(?:function\\s*)?)\\(`).exec(src);
  if (!head) return code.length;
  const close = closing(src, head.index + head[0].length - 1);
  if (close < 0) return code.length;
  const at = /^\s*(?:=>\s*)?/.exec(src.slice(close + 1))![0].length + close + 1;
  if (src[at] === "{" || src[at] === "(") {
    const end = closing(src, at);
    return end < 0 ? code.length : end + 1;
  }
  // an arrow returning a bare expression: up to the end of the statement
  const end = src.slice(at).search(/;|\n\s*\n/);
  return end < 0 ? code.length : at + end;
}

/** The code with a value renamed where it is taken and where the component uses it (in its own code only). */
export function renameProp(code: string, name: string, from: string, to: string): string {
  const props = componentProps(code, name);
  const renamed = rewriteProps(code, name, props.map((p) => ({ name: p.name === from ? to : p.name, from: p.name })));
  const at = propsPattern(renamed, name);
  if (!at) return renamed;
  const end = Math.max(at.end + 1, componentEnd(renamed, name));
  return renamed.slice(0, at.end + 1) + renameIdentifier(renamed.slice(at.end + 1, end), from, to) + renamed.slice(end);
}

/** The code taking `entries` in order: existing values (`from`) kept as written or renamed, new ones as `name = fallback`. */
export function rewriteProps(code: string, name: string, entries: { name: string; from?: string; fallback?: string }[]): string {
  const at = propsPattern(code, name);
  if (!at) return code;
  const inner = code.slice(at.start + 1, at.end);
  const parts = topLevelSplit(inner).map((p) => p.trim()).filter(Boolean);
  const byName = new Map<string, string>();
  for (const p of parts) {
    const m = propPart(p);
    if (m) byName.set(m.name, p);
  }
  const rest = parts.filter((p) => p.startsWith("..."));
  const out = entries.map((e) => {
    const kept = e.from ? byName.get(e.from) : undefined;
    if (kept) return e.name === e.from ? kept : e.name + kept.slice(e.from!.length);
    return e.fallback ? `${e.name} = ${e.fallback}` : e.name;
  });
  const list = [...out, ...rest];
  // a pattern written over several lines stays that way
  const indent = /\n([ \t]*)\S/.exec(inner)?.[1];
  const body = indent === undefined ? (list.length ? ` ${list.join(", ")} ` : "") : `\n${list.map((p) => indent + p).join(",\n")}${/,\s*$/.test(inner) ? "," : ""}\n${/\n([ \t]*)$/.exec(inner)?.[1] ?? ""}`;
  return `${code.slice(0, at.start)}{${body}}${code.slice(at.end + 1)}`;
}

// ── tags in replies ──

export interface FoundTag {
  name: string;
  props: Record<string, unknown>;
  /** The text between <Name> and </Name>, when the tag has one. */
  body?: string;
  start: number;
  end: number;
  raw: string;
}

/** Values written as {…}, read as data only (they come from the AI), never run; anything else stays plain text. */
function evaluate(expr: string): unknown {
  const t = expr.trim();
  try {
    return JSON.parse(t);
  } catch {
    // unquoted keys, single quotes, trailing commas: the literal reader below
  }
  return parseLiteral(t);
}

/** A JavaScript data literal (JSON plus unquoted keys, '…' and `…` strings, trailing commas, undefined). Throws on anything else. */
export function parseLiteral(text: string): unknown {
  let i = 0;
  const fail = (): never => {
    throw new SyntaxError(`not a plain value at ${i}`);
  };
  const space = () => {
    while (i < text.length && /\s/.test(text[i])) i++;
  };
  const string = (): string => {
    const q = text[i++];
    let out = "";
    while (i < text.length && text[i] !== q) {
      let c = text[i++];
      if (q === "`" && c === "$" && text[i] === "{") fail();
      if (c === "\\") {
        c = text[i++] ?? "";
        const esc: Record<string, string> = { n: "\n", t: "\t", r: "\r", b: "\b", f: "\f", v: "\v", "0": "\0" };
        if (c === "u" && /^[0-9a-fA-F]{4}/.test(text.slice(i))) {
          c = String.fromCharCode(parseInt(text.slice(i, i + 4), 16));
          i += 4;
        } else if (c === "x" && /^[0-9a-fA-F]{2}/.test(text.slice(i))) {
          c = String.fromCharCode(parseInt(text.slice(i, i + 2), 16));
          i += 2;
        } else c = esc[c] ?? c;
      }
      out += c;
    }
    if (text[i] !== q) fail();
    i++;
    return out;
  };
  const value = (depth: number): unknown => {
    if (depth > 64) fail();
    space();
    const c = text[i];
    if (c === "{") {
      i++;
      const obj: Record<string, unknown> = {};
      for (;;) {
        space();
        if (text[i] === "}") {
          i++;
          return obj;
        }
        let key: string;
        if (text[i] === '"' || text[i] === "'") key = string();
        else {
          const m = /^[A-Za-z_$][\w$]*|^\d+/.exec(text.slice(i));
          if (!m) fail();
          key = m![0];
          i += key.length;
        }
        space();
        if (text[i++] !== ":") fail();
        // never let a key reach the object's prototype
        Object.defineProperty(obj, key, { value: value(depth + 1), enumerable: true, writable: true, configurable: true });
        space();
        if (text[i] === ",") i++;
        else if (text[i] !== "}") fail();
      }
    }
    if (c === "[") {
      i++;
      const arr: unknown[] = [];
      for (;;) {
        space();
        if (text[i] === "]") {
          i++;
          return arr;
        }
        arr.push(value(depth + 1));
        space();
        if (text[i] === ",") i++;
        else if (text[i] !== "]") fail();
      }
    }
    if (c === '"' || c === "'" || c === "`") return string();
    const num = /^[+-]?(?:0[xX][0-9a-fA-F]+|(?:\d+\.?\d*|\.\d+)(?:[eE][+-]?\d+)?|Infinity)/.exec(text.slice(i));
    if (num) {
      i += num[0].length;
      return Number(num[0]);
    }
    for (const [word, v] of [["true", true], ["false", false], ["null", null], ["undefined", undefined]] as const) {
      if (text.startsWith(word, i) && !/[\w$]/.test(text[i + word.length] ?? "")) {
        i += word.length;
        return v;
      }
    }
    return fail();
  };
  const out = value(0);
  space();
  if (i < text.length) fail();
  return out;
}

function readString(text: string, i: number): [string, number] {
  const q = text[i];
  let out = "";
  for (let j = i + 1; j < text.length; j++) {
    const c = text[j];
    if (c === "\\" && j + 1 < text.length) {
      // \n and \t as JSON has them; any other escaped character stands for itself
      const e = text[++j];
      out += e === "n" ? "\n" : e === "t" ? "\t" : e;
      continue;
    }
    if (c === q) return [out, j + 1];
    out += c;
  }
  return [out, text.length];
}

/** Every <Name …/> (or <Name …></Name>) of the given names, with its values. */
export function findTags(text: string, names: Iterable<string>): FoundTag[] {
  const wanted = new Set(names);
  if (!wanted.size) return [];
  const out: FoundTag[] = [];
  const re = /<([A-Z][\w$]*)(?=[\s/>])/g;
  let m: RegExpExecArray | null;
  while ((m = re.exec(text))) {
    const name = m[1];
    if (!wanted.has(name)) continue;
    const props: Record<string, unknown> = {};
    let body: string | undefined;
    let i = m.index + m[0].length;
    let ok = false;
    while (i < text.length) {
      while (i < text.length && /\s/.test(text[i])) i++;
      if (text.startsWith("/>", i)) {
        i += 2;
        ok = true;
        break;
      }
      if (text[i] === ">") {
        i++;
        const end = text.indexOf(`</${name}>`, i);
        if (end >= 0) {
          body = text.slice(i, end);
          i = end + name.length + 3;
        }
        ok = true;
        break;
      }
      const attr = /^[A-Za-z_$][\w$:-]*/.exec(text.slice(i));
      if (!attr) break;
      i += attr[0].length;
      while (i < text.length && /\s/.test(text[i])) i++;
      if (text[i] !== "=") {
        props[attr[0]] = true;
        continue;
      }
      i++;
      while (i < text.length && /\s/.test(text[i])) i++;
      const c = text[i];
      if (c === '"' || c === "'") {
        const [value, next] = readString(text, i);
        props[attr[0]] = value;
        i = next;
      } else if (c === "{") {
        const end = closing(text, i);
        if (end < 0) break;
        try {
          props[attr[0]] = evaluate(text.slice(i + 1, end));
        } catch {
          props[attr[0]] = text.slice(i + 1, end).trim();
        }
        i = end + 1;
      } else {
        const bare = /^[^\s/>]+/.exec(text.slice(i))?.[0] ?? "";
        props[attr[0]] = bare;
        i += bare.length;
      }
    }
    if (!ok) continue;
    out.push({ name, props, ...(body !== undefined ? { body } : {}), start: m.index, end: i, raw: text.slice(m.index, i) });
    re.lastIndex = i;
  }
  return out;
}
