// Which chat is on screen. Marinara's chat input carries the chat's id; the
// last chat it opened is also in its localStorage.

import { t } from "../shared/i18n";

/** The chat on screen. */
export function currentChatId(): string | null {
  const composer = document.querySelector<HTMLTextAreaElement>("textarea[data-chat-composer]");
  const id = composer?.dataset.chatId;
  if (id) return id;
  try {
    return localStorage.getItem("marinara-active-chat-id");
  } catch {
    return null;
  }
}

/** The chat on screen, or an error saying none is open. */
export function requireChat(): string {
  const id = currentChatId();
  if (!id) throw new Error(t("No chat is open.", "열려 있는 채팅이 없어요."));
  return id;
}
