// Shared by chat pages (chat.ts) and components (components/host.ts): look
// over the messages on screen when it changes (at most once a frame), against
// the chat's saved messages, and start over when another chat opens.

import { listMessages } from "./api/chat-store";
import type { Message } from "./api/types";
import { currentChatId } from "./host/current-chat";
import { onGenerationComplete } from "./host/events";
import { oncePerFrame, onScreenChange } from "./host/screen-watch";
import type { Settings } from "./settings";

/** The message list is read again at most this often (ms): the screen changes many times while a reply arrives. */
const LOAD_GAP = 800;
/** A look that wanted a read too soon after the last one looks again this much later (ms). */
const RETRY_AFTER = 900;

export abstract class MessageScanner {
  /** The chat looked at last. */
  protected chatId: string | null = null;
  /** Its messages by id, as last read. */
  protected messages = new Map<string, Message>();
  protected stopped = true;
  private loading: { chatId: string; done: Promise<void> } | null = null;
  private lastLoad = 0;
  private readonly stops: (() => void)[] = [];

  /** Looks again on the next frame. */
  protected readonly schedule = oncePerFrame(() => {
    if (!this.stopped) void this.look();
  });

  constructor(protected readonly settings: Settings) {}

  start(): void {
    this.stopped = false;
    this.stops.push(
      onScreenChange(() => this.schedule()),
      onGenerationComplete(() => this.replyDone()),
    );
    this.started();
    this.schedule();
  }

  stop(): void {
    this.stopped = true;
    for (const stop of this.stops.splice(0)) stop();
    this.stopping();
    this.clear();
  }

  /** Draws everything again (settings changed). */
  reset(): void {
    this.clear();
    this.schedule();
  }

  /** Takes everything this scanner put on screen away. */
  protected abstract clear(): void;

  /** One look at the screen; `chatId` is the chat on it. */
  protected abstract scan(chatId: string | null): Promise<void>;

  /** More to start and stop with the scanner. */
  protected started(): void {}
  protected stopping(): void {}

  /** Marinara finished a reply. */
  protected replyDone(): void {
    this.schedule();
  }

  /** Another chat opened: what was kept about the last one goes (the messages and the screen are cleared already). */
  protected chatChanged(): void {}

  /** Reads what a look needs; the returned function puts it in place (skipped when another chat opened meanwhile). */
  protected async read(chatId: string): Promise<() => void> {
    const list = await listMessages(chatId, { fresh: true });
    return () => {
      this.messages = new Map(list.map((m) => [m.id, m]));
    };
  }

  /** The messages may be read again now; otherwise another look is booked for a moment later. */
  protected loadAllowed(): boolean {
    if (Date.now() - this.lastLoad > LOAD_GAP) return true;
    setTimeout(() => this.schedule(), RETRY_AFTER);
    return false;
  }

  /** Reads the chat's messages (one read at a time; a look meanwhile waits for it). */
  protected async load(chatId: string): Promise<void> {
    if (this.loading?.chatId !== chatId) {
      const loading = {
        chatId,
        done: this.read(chatId)
          .then((apply) => {
            // another chat opened meanwhile
            if (this.chatId === chatId) apply();
          })
          .catch(() => undefined)
          .finally(() => {
            if (this.loading === loading) this.loading = null;
            this.lastLoad = Date.now();
          }),
      };
      this.loading = loading;
    }
    await this.loading.done;
  }

  private async look(): Promise<void> {
    const chatId = currentChatId();
    if (chatId !== this.chatId) {
      this.chatId = chatId;
      this.messages.clear();
      this.chatChanged();
      this.clear();
    }
    await this.scan(chatId);
  }
}
