// Pesto in the open chats: before each reply, reads the card's entries (`pesto:schema`,
// `pesto:start`, `pesto:rules`, in the chat's character books or the chat's own book;
// the chat's win), works the values out from the messages, rolls the reply's dice, and puts the
// two texts of prompt.ts and the triggers that hold in the chat's lorebook. A regenerated or
// continued reply sees the values from before it. The dice are kept on the reply's swipe once it
// is saved, so the rules read the same dice whenever the reply is counted again.
//
// A reply that forgot its block can have one filled in by a helper model (fill.ts), kept on its
// swipe; and the values can be shown in Marinara's tracker too (mirror.ts), on the last reply's
// snapshot, after each reply and each change the person makes.
//
// The blocks the AI writes are taken out of what the AI is sent again and of what the screen
// shows by one Marinara regex script, "Fornello: Pesto blocks", made when Pesto
// first runs and removed when it is turned off (turned off by the person, it stays off).

import { characterLore, chatCharacters, chatDetail, isSaved, listMessages, storyExtra } from "../api/chat-store";
import { abortRun, chatLoreBookIfAny, generate, loreEntries, ownTrackerState, patchMessageExtra, patchTracker } from "../api/marinara";
import { parseObject } from "../api/parse";
import { inject, uninject, type Injection } from "../api/injections";
import type { Message, RawLoreEntry } from "../api/types";
import { holdTrackerReads, onGenerationEnd, onGenerationStart, type GenStart } from "../host/generation-hold";
import { canShowTracker, showTracker } from "../host/tracker-view";
import { forgetRegexScripts, regexScripts } from "../regex";
import { api } from "../shared/api";
import { t } from "../shared/i18n";
import type { Settings } from "../settings";
import { showToast } from "../ui/toast";
import { evaluate } from "./expr";
import { CodeRunner } from "./code";
import { sha256 } from "../hash";
import { currentChatId } from "../host/current-chat";
import { pageApi } from "../api/page-api";
import { screenUi } from "../ui/page-ui";
import type { ScriptAsk } from "../scripts/host";
import { loadDefinition, rollAll, runMessage, scopeFor, StoryEngine, type CodeHook, type Definition, type Effect, type DefinitionProblem, type StoryMessage } from "./engine";
import type { Trigger } from "./rules";
import { setStoryAccess, storyChanged, type StoryAccess, type StoryView } from "./access";
import { howToText, nowText } from "./prompt";
import { fromData, initVarData, startTagData, withoutFence, writeYaml } from "./convert";
import { scriptSchema } from "./script-schema";
import { scriptsOf } from "../scripts/model";
import { fillable, fillMessages, hasBlock, readFill, withFilled } from "./fill";
import { mergeFields, sameFields } from "./mirror";
import { macroVariables, patchMacroVariables, readChatData, updateChatData } from "../api/chat-data";
import { storyVars, varChanges } from "./vars";

// the card's Pesto entries: "pesto:" and one of these names
const ENTRY_NAMES = { schema: ["schema"], start: ["start", "init"], rules: ["rules"], code: ["code"] } as const;
type EntryKind = keyof typeof ENTRY_NAMES;

/** The injection ids (injections.ts names the entries "Fornello inject: " + id). */
const HOW_TO = "story-state-rules";
const NOW = "story-state-now";

export const REGEX_NAME = "Fornello: Pesto blocks";
// the blank lines before a block go with it; Marinara refuses patterns it finds risky (no \s* in front)
export const BLOCK_PATTERN = "\\n*```[ \\t]*pesto(?![\\w-])[^\\n]*\\n[\\s\\S]*?(?:```|$)";

/** An entry's text, without a ```yaml fence around it. */
const entryText = (e: RawLoreEntry) => withoutFence(String(e.content ?? ""));

/** A card's Pesto entries: texts as written, or (for a card with its own variable data) the schema and start values read from its data. */
export interface StoryTexts {
  schema?: unknown;
  start?: unknown;
  rules?: string;
  code?: string;
  /** read from another system's data, not written for Fornello */
  from?: "initvar" | "tags";
  /** the schema read from the card's script (its zod schema), not from the values */
  schemaFrom?: "script";
}

/**
 * Every entry of the chat's character books and its own book (the chat's last), and the card's
 * Pesto texts among them (each found last wins). With `others`, a card without a schema but
 * with "[InitVar]" entries, or starting tags in its first message, is read from those (and its schema
 * from a card script that describes one, see script-schema.ts).
 */
export async function storyLore(chatId: string, others = false): Promise<{ texts: StoryTexts; entries: RawLoreEntry[] }> {
  const cast = await chatCharacters(chatId);
  const lists: RawLoreEntry[][] = await Promise.all(cast.map((c) => characterLore(c.id).catch(() => [])));
  const book = await chatLoreBookIfAny(chatId).catch(() => null);
  if (book) lists.push(await loreEntries(book.id).catch(() => []));
  const entries = lists.flat();
  const texts: StoryTexts = {};
  for (const entry of entries) {
    const label = String(entry.name ?? "").trim();
    if (!label.toLowerCase().startsWith("pesto:")) continue;
    const name = label.slice("pesto:".length).trim().toLowerCase();
    for (const kind of Object.keys(ENTRY_NAMES) as EntryKind[]) if ((ENTRY_NAMES[kind] as readonly string[]).includes(name)) texts[kind] = entryText(entry);
  }
  if (!texts.schema && others) {
    let from: StoryTexts["from"] = "initvar";
    let data = initVarData(entries);
    if (data === null) {
      const first = (await listMessages(chatId).catch(() => [])).find((m) => m.role === "char" || m.role === "narrator");
      data = first ? startTagData(first.text) : null;
      from = "tags";
    }
    const read = fromData(data);
    if (read) Object.assign(texts, { schema: read.schema, start: read.start, from });
    // a schema in the card's script says more than the values do: kinds, ranges, defaults
    const fromScript = scriptSchema(cast.flatMap((c) => scriptsOf(c)?.scripts.map((s) => s.code) ?? []));
    if (fromScript) Object.assign(texts, { schema: fromScript, schemaFrom: "script" });
  }
  return { texts, entries };
}

/** A chat's message as the engine reads it: the narrator's are the AI's too. */
export const storyMessage = (m: Message): StoryMessage => {
  const dice = m.story?.dice;
  const edits = personEdits(m);
  return {
    id: m.id,
    text: withFilled(m.text, m.story?.filled),
    fromAI: m.role === "char" || m.role === "narrator",
    ...(dice && typeof dice === "object" && !Array.isArray(dice) ? { dice: dice as Record<string, unknown> } : {}),
    ...(edits.length ? { edits: edits.map((e) => ({ kind: "set" as const, path: e.path, value: e.value })) } : {}),
  };
};

/** The values the person set at a message (kept on its swipe as `edits: [{ path, value }]`). */
export function personEdits(m: Message): { path: string; value: unknown }[] {
  const raw = m.story?.edits;
  if (!Array.isArray(raw)) return [];
  return raw.filter((e): e is { path: string; value: unknown } => !!e && typeof e === "object" && typeof (e as { path?: unknown }).path === "string");
}

/** The messages a reply's values come from: all of them, or those before the one written again or continued. */
export function messagesBefore(messages: Message[], gen: Pick<GenStart, "kind" | "messageId">): Message[] {
  if ((gen.kind === "regenerate" || gen.kind === "continue") && gen.messageId) {
    const at = messages.findIndex((m) => m.id === gen.messageId);
    if (at >= 0) return messages.slice(0, at);
  }
  return messages;
}

async function ensureRegex(): Promise<void> {
  const scripts = await regexScripts();
  const mine = scripts.find((s) => s.name === REGEX_NAME);
  if (mine) {
    // an older Fornello's pattern is brought up to date (one the person turned off stays off)
    if (mine.enabled && mine.findRegex !== BLOCK_PATTERN) {
      await api(`/regex-scripts/${encodeURIComponent(mine.id)}`, { method: "PATCH", body: { findRegex: BLOCK_PATTERN } });
      forgetRegexScripts();
    }
    return;
  }
  await api("/regex-scripts", {
    method: "POST",
    body: { name: REGEX_NAME, enabled: true, findRegex: BLOCK_PATTERN, replaceString: "", placement: ["ai_output"], flags: "gi", applyMode: "both" },
  });
  forgetRegexScripts();
}

async function removeRegex(): Promise<void> {
  forgetRegexScripts();
  for (const s of await regexScripts()) if (s.name === REGEX_NAME) await api(`/regex-scripts/${encodeURIComponent(s.id)}`, { method: "DELETE" });
  forgetRegexScripts();
}

const POSITION_OF: Record<number, "before" | "after" | "depth"> = { 0: "before", 1: "after", 2: "depth" };

/**
 * Whether the message read is the reply written: a message written again has a new swipe on
 * screen, a continued one a longer text (a read from before the reply, still shared, is not it;
 * the dice and a filled-in block would go on the swipe before).
 */
export function isNewReply(gen: Pick<GenStart, "kind">, reply: Pick<Message, "swipe" | "swipes" | "text">, target: Pick<Message, "swipe" | "swipes" | "text"> | undefined): boolean {
  if (!target || gen.kind === "send") return true;
  if (gen.kind === "regenerate") return reply.swipe !== target.swipe || (reply.swipes ?? 0) > (target.swipes ?? 0);
  return reply.text !== target.text;
}

const effectKey = (e: Effect) => JSON.stringify([e.cmd, e.args]);

/**
 * The effects of a reply that haven't run yet: a continued reply counted again asks for the ones it
 * had and maybe more, and only the new ones run (as many times as they are new). A reply marked
 * `effectsDone` (an earlier Fornello's mark) has run them all.
 */
export function effectsToRun(effects: Effect[], story: Record<string, unknown> | undefined): Effect[] {
  if (story?.effectsDone === true) return [];
  const ran = new Map<string, number>();
  for (const k of Array.isArray(story?.effectsRun) ? story.effectsRun : []) if (typeof k === "string") ran.set(k, (ran.get(k) ?? 0) + 1);
  return effects.filter((e) => {
    const k = effectKey(e);
    const left = ran.get(k) ?? 0;
    if (left > 0) ran.set(k, left - 1);
    return left === 0;
  });
}

/** What a trigger puts in the prompt while its condition holds: its text, or a lorebook entry's (with that entry's place). */
export function triggerText(trigger: Trigger, entries: RawLoreEntry[]): Injection | null {
  const entry = trigger.entry !== undefined ? entries.findLast((e) => String(e.name ?? "").trim() === trigger.entry) : undefined;
  const content = trigger.text ?? (entry ? String(entry.content ?? "") : "");
  if (!content.trim()) return null;
  const position = trigger.position ?? (entry && typeof entry.position === "number" ? POSITION_OF[entry.position] : undefined) ?? "depth";
  const depth = trigger.depth ?? (entry && typeof entry.depth === "number" ? entry.depth : 2);
  const role = entry && (entry.role === "user" || entry.role === "assistant" || entry.role === "system") ? entry.role : "system";
  return { id: "", content, position, depth, role };
}

/** The injection ids of a chat's triggers: "story-trigger-" + the trigger's name. */
const TRIGGER = "story-trigger-";

interface Pending {
  gen: GenStart;
  /** the reply's dice, when the card rolls any */
  dice?: Record<string, unknown>;
  /** the messages before the reply (a sent reply is the AI's message after them) */
  before: Set<string>;
  /** the message written again or continued, as it was before: the reply is that message once it differs */
  target?: Pick<Message, "swipe" | "swipes" | "text">;
}

interface Loaded {
  def: Definition;
  engine: StoryEngine;
  messages: Message[];
}

/** How long the next reply waits for a helper still filling in the last reply's block (ms; a reply waits at most 5 s for Fornello in all). */
const FILL_WAIT = 2000;

/** The longest the helper model may take to fill in a block (ms): then it is stopped and the reply counted without one. */
const FILL_TIME = 30_000;

/** How long a chat's worked-out values are reused by the components and windows reading them (ms). */
const KEEP_LOADED = 1500;

export interface StoryHooks {
  /** Asks the person whether a card's code may run (the scripts' popup). */
  ask(ask: ScriptAsk): void;
  /** Shows the Pesto window (the code, and the answer given). */
  showCode(): void;
}

export class StoryState implements StoryAccess {
  /** The card code running, by its hash. */
  private runners = new Map<string, CodeRunner>();
  /** Code asked about in this session (a "not now" is not asked again until Fornello starts again). */
  private asked = new Set<string>();
  /** One engine a chat, for the card's entries as they were read. */
  private engines = new Map<string, StoryEngine>();
  /** What each chat's engine was made for: the code's hash and whether it runs. */
  private engineKeys = new Map<string, string>();
  private definitions = new Map<string, { def: Definition; problems: DefinitionProblem[] }>();
  /** Chats whose lorebook holds entries of Pesto now, with their injection ids. */
  private placed = new Map<string, Map<string, string>>();
  /** Card entries whose problems were shown already. */
  private told = new Set<string>();
  /** The dice rolled for a reply being written, by chat: kept on the reply once it is saved. */
  private pending = new Map<string, Pending>();
  private loads = new Map<string, { at: number; value: Promise<Loaded | null> }>();
  private stops: (() => void)[] = [];
  /** A helper model filling in a reply's block, by chat: the next reply waits for it (a while). */
  private filling = new Map<string, Promise<void>>();
  /** Marinara's reads of a chat's tracker, held while a reply is written and its values put in: let go after the reply. */
  private readHolds = new Map<string, () => void>();
  /** The card's entries as read a moment ago, by chat (a reply, the window and the templates all read them at once). */
  private lores = new Map<string, { at: number; others: boolean; value: ReturnType<typeof storyLore> }>();

  /** The chat's card entries (storyLore), read once for a moment. */
  private lore(chatId: string): ReturnType<typeof storyLore> {
    const others = this.settings.current.story.others;
    const hit = this.lores.get(chatId);
    if (hit && hit.others === others && Date.now() - hit.at < KEEP_LOADED) return hit.value;
    const value = storyLore(chatId, others);
    this.lores.set(chatId, { at: Date.now(), others, value });
    value.catch(() => this.lores.delete(chatId));
    return value;
  }

  /** Problems told once a session, by what they are. */
  private toldOnce = new Set<string>();
  private tellOnce(key: string, text: string): void {
    if (this.toldOnce.has(key)) return;
    this.toldOnce.add(key);
    showToast(t(`Pesto: ${text}`, `Pesto: ${text}`), "warning");
  }
  /** A fill that failed was told once a session. */
  private fillTold = false;

  constructor(
    private settings: Settings,
    private hooks?: StoryHooks,
  ) {}

  start(): void {
    setStoryAccess(this);
    this.stops.push(() => setStoryAccess(null));
    this.stops.push(
      onGenerationStart((gen) => this.beforeReply(gen)),
      onGenerationEnd((gen, ok) => void this.afterReply(gen, ok).catch((e) => console.warn("[Fornello] Pesto dice", e))),
    );
  }

  stop(): void {
    for (const stop of this.stops.splice(0)) stop();
    this.engines.clear();
    this.definitions.clear();
    this.placed.clear();
    this.pending.clear();
    this.loads.clear();
    this.filling.clear();
    this.lores.clear();
    this.owned.clear();
    for (const release of this.readHolds.values()) release();
    this.readHolds.clear();
    for (const r of this.runners.values()) r.dispose();
    this.runners.clear();
  }

  /** A card's code as the engine calls it, once the person allowed it; asked about otherwise. */
  private codeHook(def: Definition, cardName: string): { hook?: CodeHook; key: string } {
    if (!def.code) return { key: "" };
    const hash = sha256(def.code);
    const answer = this.settings.current.story.code[hash];
    if (answer === undefined && !this.asked.has(hash) && this.hooks) {
      this.asked.add(hash);
      const answerWith = (allow: boolean) => void this.answerCode(hash, allow).catch((e) => console.warn("[Fornello] Pesto code", e));
      this.hooks.ask({
        key: `story:${hash}`,
        name: cardName,
        count: 1,
        title: t(`“${cardName}” has Pesto code`, `“${cardName}” 카드에 Pesto 코드가 있어요`),
        note: t(
          "It works out the story's values after each reply, in a Worker cut off from the network, and may ask for page commands (with their usual checks). Let it run?",
          "답변마다 이야기의 값을 계산하는 코드예요. 네트워크가 막힌 Worker에서 돌고, 페이지 명령을 부탁할 수 있어요(평소처럼 확인을 거쳐요). 실행할까요?",
        ),
        allow: () => answerWith(true),
        notNow: () => undefined,
        decline: () => answerWith(false),
        show: () => this.hooks?.showCode(),
      });
    }
    if (answer !== true) return { key: `${hash}:off` };
    let runner = this.runners.get(hash);
    if (!runner) this.runners.set(hash, (runner = new CodeRunner(def.code)));
    const r = runner;
    return { hook: (input) => r.call(input), key: `${hash}:on` };
  }

  async answerCode(hash: string, allow: boolean | null): Promise<void> {
    const code = { ...this.settings.current.story.code };
    if (allow === null) {
      delete code[hash];
      this.asked.delete(hash);
    } else code[hash] = allow;
    await this.settings.set({ story: { ...this.settings.current.story, code } });
    this.codeAnswered();
  }

  /** The person answered about a card's code: values are counted again, with it or without. */
  codeAnswered(): void {
    this.engines.clear();
    this.loads.clear();
    const chatId = currentChatId();
    if (chatId) storyChanged(chatId);
  }

  /** The chat's engine for the card's entries and the answer about its code (a new one when either changed). */
  private async engineFor(chatId: string, def: Definition): Promise<StoryEngine> {
    const cardName = def.code ? ((await chatCharacters(chatId).catch(() => []))[0]?.name ?? t("This card", "이 카드")) : "";
    const { hook, key } = this.codeHook(def, cardName);
    let engine = this.engines.get(chatId);
    if (!engine || engine.def !== def || this.engineKeys.get(chatId) !== key) {
      this.engines.set(chatId, (engine = new StoryEngine(def, 25, hook)));
      this.engineKeys.set(chatId, key);
    }
    return engine;
  }

  /** What the card's code is and the person's answer about it (for the Pesto window). */
  async codeOf(chatId: string): Promise<{ code: string; allowed: boolean | undefined; hash: string } | null> {
    const { texts } = await this.lore(chatId);
    if (!texts.code?.trim()) return null;
    const hash = sha256(texts.code);
    return { code: texts.code, allowed: this.settings.current.story.code[hash], hash };
  }

  /** The chat's engine brought up to its messages as they are now (shared for a moment), or null without Pesto. */
  private load(chatId: string): Promise<Loaded | null> {
    const hit = this.loads.get(chatId);
    if (hit && Date.now() - hit.at < KEEP_LOADED) return hit.value;
    const value = (async (): Promise<Loaded | null> => {
      if (!this.settings.current.story.on) return null;
      const { texts } = await this.lore(chatId);
      if (!texts.schema) return null;
      const { def, problems } = this.definition(texts);
      this.tell(def, problems);
      const engine = await this.engineFor(chatId, def);
      const messages = await listMessages(chatId);
      await engine.update(messages.map(storyMessage));
      return { def, engine, messages };
    })();
    this.loads.set(chatId, { at: Date.now(), value });
    value.catch(() => this.loads.delete(chatId));
    return value;
  }

  async has(chatId: string): Promise<boolean> {
    return !!(await this.load(chatId).catch(() => null));
  }

  async at(chatId: string, messageId: string | null): Promise<StoryView | null> {
    let loaded = await this.load(chatId);
    // a message newer than what was read: read the chat again
    if (loaded && messageId !== null && !loaded.messages.some((m) => m.id === messageId)) {
      this.loads.delete(chatId);
      loaded = await this.load(chatId);
    }
    if (!loaded) return null;
    const { def, engine, messages } = loaded;
    const index = messageId === null ? messages.length - 1 : messages.findIndex((m) => m.id === messageId);
    if (messageId !== null && index < 0) return null;
    const view = engine.view(await engine.valuesAt(index));
    const filled = index >= 0 ? messages[index].story?.filled : undefined;
    return {
      def,
      ...view,
      turn: index >= 0 ? engine.turn(index) : undefined,
      edits: index >= 0 ? personEdits(messages[index]) : [],
      ...(typeof filled === "string" && !hasBlock(messages[index].text) ? { filled } : {}),
    };
  }

  async tryReply(chatId: string, messageId: string | null, text: string) {
    const loaded = await this.load(chatId);
    if (!loaded) return null;
    const { def, engine, messages } = loaded;
    const index = messageId === null ? messages.length - 1 : messages.findIndex((m) => m.id === messageId);
    const values = await engine.valuesAt(index);
    // the card's code counts too, when it may run (its effects don't run: nothing here happens)
    const cardName = def.code ? ((await chatCharacters(chatId).catch(() => []))[0]?.name ?? "") : "";
    const turn = await runMessage(def, values, { id: `fornello-try-${index}`, text, fromAI: true }, this.codeHook(def, cardName).hook);
    return { turn, ...engine.view(values) };
  }

  async history(chatId: string) {
    const loaded = await this.load(chatId);
    if (!loaded) return null;
    const { from, series } = await loaded.engine.numbersOverTime();
    const shown = loaded.messages.slice(from);
    return { ids: shown.map((m) => m.id), nums: shown.map((m) => m.num), series };
  }

  async cardOf(chatId: string) {
    const { texts } = await this.lore(chatId);
    if (!texts.schema) return null;
    const { problems } = this.definition(texts);
    if (!texts.from && !texts.schemaFrom) return { problems };
    const isObj = (v: unknown): v is Record<string, unknown> => !!v && typeof v === "object" && !Array.isArray(v);
    return {
      problems,
      ...(texts.from ? { from: texts.from } : {}),
      ...(texts.schemaFrom ? { schemaFrom: texts.schemaFrom } : {}),
      ...(isObj(texts.schema) ? { schema: writeYaml(texts.schema) } : {}),
      ...(isObj(texts.start) ? { start: writeYaml(texts.start) } : {}),
    };
  }

  async edit(chatId: string, messageId: string, changes: { path: string; value: unknown }[]): Promise<void> {
    const message = (await listMessages(chatId, { fresh: true })).find((m) => m.id === messageId);
    if (!message) throw new Error(t("That message is gone.", "그 메시지가 없어요."));
    const edits = personEdits(message).filter((e) => !changes.some((c) => c.path === e.path));
    for (const c of changes) if (c.value !== null) edits.push({ path: c.path, value: c.value });
    await patchMessageExtra(chatId, messageId, storyExtra("edits", edits), message.swipe);
    this.loads.delete(chatId);
    storyChanged(chatId);
    await this.mirror(chatId).catch((e) => console.warn("[Fornello] Pesto tracker", e));
  }

  /** Turned off: the entries go from every chat, and the regex script with them. */
  async turnedOff(): Promise<void> {
    for (const [chatId, ids] of [...this.placed]) await uninject(chatId, [...ids.keys()]).catch(() => undefined);
    this.placed.clear();
    this.engines.clear();
    this.pending.clear();
    this.loads.clear();
    await removeRegex().catch((e) => console.warn("[Fornello] Pesto regex", e));
  }

  private definition(texts: StoryTexts) {
    const key = JSON.stringify(texts);
    let loaded = this.definitions.get(key);
    if (!loaded) {
      loaded = loadDefinition(texts);
      if (this.definitions.size > 20) this.definitions.clear();
      this.definitions.set(key, loaded);
    }
    return loaded;
  }

  /** Puts these injections in the chat's lorebook and takes out the chat's others. */
  private async place(chatId: string, wanted: Injection[]): Promise<void> {
    const had = this.placed.get(chatId) ?? new Map<string, string>();
    const now = new Map(wanted.map((i) => [i.id, JSON.stringify(i)]));
    const gone = [...had.keys()].filter((id) => !now.has(id));
    if (gone.length) await uninject(chatId, gone);
    // an entry already there as wanted isn't written again (the "how to" stays the same reply after reply)
    for (const i of wanted) if (had.get(i.id) !== now.get(i.id)) await inject(chatId, i);
    if (now.size) this.placed.set(chatId, now);
    else this.placed.delete(chatId);
  }

  private tell(def: Definition, problems: DefinitionProblem[]) {
    if (!problems.length || this.told.has(def.sig)) return;
    this.told.add(def.sig);
    console.warn("[Fornello] Pesto entries:", problems);
    const first = problems[0];
    showToast(
      t(
        `Pesto: pesto:${first.entry} has a problem at ${first.path || "the top"}: ${first.why}${problems.length > 1 ? ` (and ${problems.length - 1} more, in the console)` : ""}`,
        `Pesto: pesto:${first.entry}의 ${first.path || "맨 위"}에 문제가 있어요: ${first.why}${problems.length > 1 ? ` (외 ${problems.length - 1}개, 콘솔에 있어요)` : ""}`,
      ),
      "warning",
    );
  }

  /** The values the coming reply starts from, its dice and the triggers that hold, put where the AI reads them. */
  async beforeReply(gen: GenStart): Promise<void> {
    const { on, depth } = this.settings.current.story;
    if (!on) return;
    const chatId = gen.chatId;
    this.pending.delete(chatId);
    // Marinara reads the tracker again as the reply ends (in a game, or a roleplay with agents):
    // that read waits for the values this reply leads to. Held first, before anything is awaited.
    if (this.settings.current.story.tracker && gen.kind !== "impersonate") {
      this.letReadsGo(chatId);
      const until = new Promise<void>((resolve) => this.readHolds.set(chatId, resolve));
      const detail = await chatDetail(chatId).catch(() => null);
      const agents = (parseObject(detail?.metadata) as { enableAgents?: unknown }).enableAgents;
      if (detail?.mode === "game" || (detail?.mode === "roleplay" && (agents === true || agents === "true"))) holdTrackerReads(chatId, until);
    }
    // the last reply's block, still being filled in, counts for this one
    const filling = this.filling.get(chatId);
    if (filling) await Promise.race([filling, new Promise((r) => setTimeout(r, FILL_WAIT))]);
    const { texts, entries } = await this.lore(chatId);
    if (!texts.schema) {
      this.letReadsGo(chatId);
      await this.place(chatId, []);
      this.engines.delete(chatId);
      return;
    }
    const { def, problems } = this.definition(texts);
    this.tell(def, problems);
    await ensureRegex().catch((e) => console.warn("[Fornello] Pesto regex", e));
    const all = await listMessages(chatId, { fresh: true });
    const messages = messagesBefore(all, gen);
    const engine = await this.engineFor(chatId, def);
    const story = messages.map(storyMessage);
    // the engine keeps the whole chat (the window and components read it too); the reply starts from the values before it
    await engine.update(all.map(storyMessage));
    const values = await engine.valuesAt(messages.length - 1);

    // the dice of this reply: a continued reply keeps the ones it had
    let dice: Record<string, unknown> | undefined;
    if (Object.keys(def.rules.dice).length && gen.kind !== "impersonate") {
      const continued = gen.kind === "continue" ? all.find((m) => m.id === gen.messageId) : undefined;
      dice = (continued && storyMessage(continued).dice) || rollAll(def, values, Math.random);
    }
    if (gen.kind !== "impersonate") {
      const was = gen.messageId ? all.find((m) => m.id === gen.messageId) : undefined;
      this.pending.set(chatId, { gen, ...(dice ? { dice } : {}), before: new Set(all.map((m) => m.id)), ...(was ? { target: { swipe: was.swipe, swipes: was.swipes, text: was.text } } : {}) });
    }

    const lastAI = story.findLastIndex((m) => m.fromAI);
    const wanted: Injection[] = [];
    // with the helper model writing the changes, the AI isn't asked for blocks (a card's own instructions may still ask)
    const helperWrites = this.settings.current.story.writer === "helper";
    const howTo = helperWrites ? "" : howToText(def);
    if (howTo) wanted.push({ id: HOW_TO, content: howTo, position: "after" });
    // what a filled-in block got wrong is the helper's, not for the AI to put right
    const lastTurn = lastAI >= 0 && !helperWrites && !messages[lastAI].story?.filled ? engine.turn(lastAI) : undefined;
    const now = nowText(def, values, lastTurn, dice);
    if (now) wanted.push({ id: NOW, content: now, position: "depth", depth, role: "system" });
    const scope = scopeFor(def, values);
    for (const [name, trigger] of Object.entries(def.rules.triggers)) {
      let holds = false;
      try {
        holds = !!evaluate(trigger.when, scope);
      } catch (e) {
        console.warn(`[Fornello] Pesto trigger ${name}:`, e);
      }
      const text = holds ? triggerText(trigger, entries) : null;
      if (text) wanted.push({ ...text, id: `${TRIGGER}${name}` });
    }
    await this.place(chatId, wanted);
    // turned off since: what is left of them goes (nothing is written when there is nothing)
    await this.writeVars(chatId, this.settings.current.story.vars ? storyVars(def, values) : {}).catch((e) => {
      console.warn("[Fornello] Pesto variables", e);
      this.tellOnce(`vars:${chatId}`, e instanceof Error ? e.message : String(e));
    });
    // turned off while this ran: what was just put in goes again
    if (!this.settings.current.story.on) await this.place(chatId, []);
    // the reply went on before these were in: the AI didn't see these dice, so they aren't kept (the rules roll from the reply's id instead)
    const pending = this.pending.get(chatId);
    if (gen.late && pending?.gen === gen && pending.dice) {
      console.warn("[Fornello] Pesto: the reply started before its dice were in; they are not kept");
      delete pending.dice;
    }
  }

  /** A finished reply keeps the dice it was written with, on its swipe, so counting it again gives the same; then the card's code's effects for it run, once. */
  async afterReply(gen: GenStart, ok: boolean): Promise<void> {
    try {
      await this.afterReplyWork(gen, ok);
    } finally {
      this.letReadsGo(gen.chatId);
    }
  }

  /** Marinara's held reads of the chat's tracker go on. */
  private letReadsGo(chatId: string): void {
    const release = this.readHolds.get(chatId);
    this.readHolds.delete(chatId);
    release?.();
  }

  private async afterReplyWork(gen: GenStart, ok: boolean): Promise<void> {
    this.loads.delete(gen.chatId);
    const pending = this.pending.get(gen.chatId);
    if (!pending || pending.gen !== gen) {
      if (this.settings.current.story.on) storyChanged(gen.chatId);
      return;
    }
    this.pending.delete(gen.chatId);
    if (!ok) return;
    const reply = await this.savedReply(gen, pending);
    if (!reply) return;
    if (pending.dice && JSON.stringify(reply.story?.dice) !== JSON.stringify(pending.dice)) {
      await patchMessageExtra(gen.chatId, reply.id, storyExtra("dice", pending.dice), reply.swipe);
      this.loads.delete(gen.chatId);
    }
    // a continued reply's block, filled in for its first part, is filled in again for the whole
    const refill = gen.kind === "continue" && pending.target !== undefined && reply.text !== pending.target.text;
    if (this.settings.current.story.writer !== "ai" && (reply.story?.filled === undefined || refill) && !hasBlock(reply.text)) {
      const fill = this.fill(gen.chatId, reply).finally(() => this.filling.get(gen.chatId) === fill && this.filling.delete(gen.chatId));
      this.filling.set(gen.chatId, fill);
      await fill;
    }
    storyChanged(gen.chatId);
    await this.mirror(gen.chatId).catch((e) => console.warn("[Fornello] Pesto tracker", e));
    // the tracker holds the reply's values: Marinara may read it now (and the effects' page commands with it)
    this.letReadsGo(gen.chatId);
    await this.runEffects(gen.chatId, reply.id);
  }

  /**
   * The names Pesto wrote in a chat (its variables, its tracker fields), as read once: only
   * Fornello writes them. (Written from another tab meanwhile, a name not known here is only left
   * alone, never taken out.)
   */
  private owned = new Map<string, { vars?: Set<string>; tracker?: Set<string> }>();

  private async ownedNames(chatId: string, kind: "vars" | "tracker"): Promise<Set<string>> {
    const kept = this.owned.get(chatId)?.[kind];
    if (kept) return new Set(kept);
    const data = await readChatData(chatId);
    const names = new Set(kind === "vars" ? data.storyVars : data.storyTracker);
    this.owned.set(chatId, { ...this.owned.get(chatId), [kind]: names });
    return new Set(names);
  }

  private async keepOwned(chatId: string, kind: "vars" | "tracker", names: Iterable<string>): Promise<void> {
    const list = [...new Set(names)];
    await updateChatData(chatId, (d) => ({ ...d, [kind === "vars" ? "storyVars" : "storyTracker"]: list }));
    this.owned.set(chatId, { ...this.owned.get(chatId), [kind]: new Set(list) });
  }

  /** The values as Marinara chat variables ("story_…"): only those that changed are written; old ones go. With nothing, all of Pesto's go. */
  async writeVars(chatId: string, now: Record<string, string> = {}): Promise<void> {
    const owned = await this.ownedNames(chatId, "vars");
    const names = Object.keys(now);
    const same = names.length === owned.size && names.every((n) => owned.has(n));
    // nothing written and nothing to take out: not even a read
    if (same && !names.length) return;
    // the names first: a variable written but not recorded would be taken for the card's
    if (!same && names.some((n) => !owned.has(n))) await this.keepOwned(chatId, "vars", [...owned, ...names]);
    await patchMacroVariables(chatId, varChanges(await macroVariables(chatId), now, owned));
    if (!same) await this.keepOwned(chatId, "vars", names);
  }

  /** A helper model writes the block a reply forgot; kept on the reply's swipe ("" when it found no change), counted from then on. */
  private async fill(chatId: string, reply: Message): Promise<void> {
    try {
      const loaded = await this.load(chatId);
      if (!loaded || !fillable(loaded.def)) return;
      const index = loaded.messages.findIndex((m) => m.id === reply.id);
      if (index < 0) return;
      const before = await loaded.engine.valuesAt(index - 1);
      const { fillWith } = this.settings.current.story;
      const runId = `fornello-fill-${reply.id}-${Date.now()}`;
      let timer: ReturnType<typeof setTimeout> | undefined;
      const answer = await Promise.race([
        generate(fillMessages(loaded.def, before, reply.text), {
          chatId,
          runId,
          ...(fillWith ? { connectionId: fillWith } : {}),
          parameters: { temperature: 0, maxTokens: 600 },
        }),
        new Promise<never>((_, reject) => {
          timer = setTimeout(() => {
            void abortRun(runId, "raw", chatId);
            reject(new Error(t(`no answer in ${FILL_TIME / 1000} s`, `${FILL_TIME / 1000}초 동안 답이 없어요`)));
          }, FILL_TIME);
        }),
      ]).finally(() => clearTimeout(timer));
      const filled = readFill(answer);
      // the swipe may have changed while the helper wrote: keep it only on the one it read
      const now = (await listMessages(chatId, { fresh: true })).find((m) => m.id === reply.id);
      if (!now || now.swipe !== reply.swipe || now.text !== reply.text) return;
      await patchMessageExtra(chatId, reply.id, storyExtra("filled", filled), now.swipe);
      this.loads.delete(chatId);
    } catch (e) {
      console.warn("[Fornello] Pesto fill", e);
      if (!this.fillTold) {
        this.fillTold = true;
        showToast(
          t(`Pesto: the helper model could not fill in a block: ${e instanceof Error ? e.message : String(e)}`, `Pesto: 보조 모델이 블록을 채우지 못했어요: ${e instanceof Error ? e.message : String(e)}`),
          "warning",
        );
      }
    }
  }

  /** The values shown in Marinara's tracker, on the last reply's snapshot (with `off`, Pesto's fields taken out of it). */
  async mirror(chatId: string, off = false): Promise<void> {
    if (!off && !this.settings.current.story.tracker) return;
    // taking the fields out needs only the card's entries (Pesto may be off by then)
    const loaded = off ? null : await this.load(chatId);
    const lore = off ? (await this.lore(chatId)).texts : null;
    const def = loaded?.def ?? (lore?.schema ? this.definition(lore).def : null);
    if (!def) return;
    const messages = loaded?.messages ?? (await listMessages(chatId));
    const reply = messages.findLast((m) => m.role === "char" || m.role === "narrator");
    if (!reply) return;
    // a reply without a snapshot of its own gets one made from the latest, so the latest's fields are the ones to keep
    const own = await ownTrackerState(reply.id, chatId);
    const base = own ?? (await ownTrackerState(undefined, chatId)) ?? {};
    const had = Array.isArray(base.worldCustomFields) ? base.worldCustomFields : [];
    const before = await this.ownedNames(chatId, "tracker");
    const { fields, owned } = mergeFields(had, def, loaded ? loaded.engine.values : null, before);
    const ownedChanged = owned.size !== before.size || [...owned].some((k) => !before.has(k));
    // the names first: a field written but not recorded would be taken for someone else's
    if (ownedChanged) await this.keepOwned(chatId, "tracker", [...before, ...owned]);
    if (!own || !sameFields(had, fields)) {
      await patchTracker({ ...base, worldCustomFields: fields, messageId: reply.id, swipeIndex: reply.swipe ?? 0 }, ["worldCustomFields"], chatId, false);
      // the screen is told too, where Marinara gives a way to (after a reply Marinara also reads it again, its read waiting for this)
      if (canShowTracker()) {
        const now = await ownTrackerState(undefined, chatId);
        if (now) showTracker(chatId, now);
      }
    }
    if (ownedChanged) await this.keepOwned(chatId, "tracker", owned);
  }

  /** The reply a generation wrote, once it is saved (a moment after its stream ends); null when it can't be told apart. */
  private async savedReply(gen: GenStart, { before, target }: Pending): Promise<Message | null> {
    for (let tries = 0; tries < 5; tries++) {
      const messages = await listMessages(gen.chatId, { fresh: true });
      const reply = gen.kind === "send" ? messages.findLast((m) => !before.has(m.id) && (m.role === "char" || m.role === "narrator")) : messages.find((m) => m.id === gen.messageId);
      if (reply && isSaved(reply.id) && isNewReply(gen, reply, target)) return reply;
      await new Promise((r) => setTimeout(r, 300 * (tries + 1)));
    }
    return null;
  }

  /** The effects the card's code asked for at a new reply: run once (marked on its swipe first), as page commands (or "toast"), while its chat is open. */
  private async runEffects(chatId: string, messageId: string): Promise<void> {
    const view = await this.at(chatId, messageId);
    const effects = view?.turn?.effects;
    if (!effects?.length || currentChatId() !== chatId) return;
    const message = (await listMessages(chatId, { fresh: true })).find((m) => m.id === messageId);
    if (!message) return;
    const todo = effectsToRun(effects, message.story);
    if (!todo.length) return;
    // marked first: whatever happens next, these don't run twice
    await patchMessageExtra(chatId, messageId, storyExtra("effectsRun", effects.map(effectKey)), message.swipe);
    this.loads.delete(chatId);
    const report = (m: string) => showToast(t(`Pesto code: ${m}`, `Pesto 코드: ${m}`), "warning");
    const api = await pageApi({ messageId, report, ui: screenUi });
    try {
      for (const e of todo) {
        // "toast" shows its text; "toastr.info" and the like reach into a page command's object
        if (e.cmd === "toast") {
          showToast(String(e.args[0] ?? ""), "info");
          continue;
        }
        const [head, ...rest] = e.cmd.split(".");
        let owner: unknown = undefined;
        let fn: unknown = api.globals[head];
        for (const part of rest) {
          owner = fn;
          fn = fn && typeof fn === "object" && Object.hasOwn(fn, part) ? (fn as Record<string, unknown>)[part] : undefined;
        }
        if (typeof fn !== "function") {
          report(t(`there is no page command "${e.cmd}"`, `"${e.cmd}"라는 페이지 명령이 없어요`));
          continue;
        }
        try {
          await (fn as (...args: unknown[]) => unknown).apply(owner, e.args);
        } catch (err) {
          report(`${e.cmd}: ${err instanceof Error ? err.message : String(err)}`);
        }
      }
    } finally {
      api.dispose();
    }
  }
}
