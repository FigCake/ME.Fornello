// What Fornello's windows share: the element builder they draw with (no
// innerHTML) and the dimmed backdrop they sit on.

/** The backdrop behind a window, centring it. */
export const BACKDROP_CSS = ".back { position: absolute; inset: 0; display: flex; align-items: center; justify-content: center; padding: 12px; background: rgb(0 0 0 / .45); }";

type Child = Node | string | null | undefined | false;

/**
 * An element: `on…` functions become listeners, a `style` string the
 * attribute, known properties (value, checked…) are set, the rest become
 * attributes; undefined, null and false are left out (children too).
 */
export function el<K extends keyof HTMLElementTagNameMap>(tag: K, attrs: Record<string, unknown> = {}, ...children: Child[]): HTMLElementTagNameMap[K] {
  const node = document.createElement(tag);
  for (const [k, v] of Object.entries(attrs)) {
    if (v === undefined || v === null || v === false) continue;
    if (k.startsWith("on") && typeof v === "function") node.addEventListener(k.slice(2), v as EventListener);
    else if (k === "style" && typeof v === "string") node.setAttribute("style", v);
    else if (k in node && k !== "list") (node as unknown as Record<string, unknown>)[k] = v;
    else node.setAttribute(k, v === true ? "" : String(v));
  }
  for (const c of children) if (c !== null && c !== undefined && c !== false) node.append(c);
  return node;
}
