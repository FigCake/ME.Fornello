// Events pages and scripts send each other by a name of their own
// (SillyTavern's own events are in st-compat.ts). Listeners run in order, each
// awaited, and share the same argument objects.

type Listener = (...args: unknown[]) => unknown;

const listeners = new Map<string, Listener[]>();

/** Listens to `event` (`first`: before the others); the returned function stops it. */
export function onEvent(event: string, fn: Listener, first = false): () => void {
  const list = listeners.get(event) ?? [];
  if (first) list.unshift(fn);
  else list.push(fn);
  listeners.set(event, list);
  return () => offEvent(event, fn);
}

function offEvent(event: string, fn: Listener): void {
  const list = listeners.get(event);
  if (!list) return;
  const i = list.indexOf(fn);
  if (i >= 0) list.splice(i, 1);
  if (!list.length) listeners.delete(event);
}

/** Sends `event` to its listeners in order; one that fails leaves the rest running (its error goes to `report`). */
export async function emitEvent(event: string, args: unknown[], report: (e: unknown) => void = (e) => console.warn("[Fornello]", e)): Promise<void> {
  for (const fn of [...(listeners.get(event) ?? [])]) {
    try {
      await fn(...args);
    } catch (e) {
      report(e);
    }
  }
}

/** Every listener goes (Fornello stopped). */
export function clearEvents(): void {
  listeners.clear();
}
