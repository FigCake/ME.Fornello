// Puts the picture rule (rule.ts) where the AI reads it: in each card's own
// lorebook (the default, so it travels with the card when exported), or in
// the chat's lorebook. A card gets one only when it lists assets; a card whose
// book slot holds a book Marinara didn't link can't take one, so its rule goes
// to the chat's book instead. Fornello remembers what it wrote: an entry the
// person changed is left as it is, and only Fornello's own are removed.

import { forgetPeople } from "../api/chat-store";
import { characterData } from "../api/library";
import { chatLoreBook, chatLoreBookIfAny, createLoreEntry, deleteLoreEntries, loreEntries, patchLoreEntry } from "../api/marinara";
import { parseObject } from "../api/parse";
import type { CharacterInfo, RawLoreEntry } from "../api/types";
import { quickHash } from "../hash";
import { api } from "../shared/api";
import { t } from "../shared/i18n";
import { getMarinara } from "../shared/marinara-global";
import { showToast } from "../ui/toast";
import type { AssetDisplay } from "./display";
import { cardAssets } from "./model";
import { RULE_ENTRY, pictureRule } from "./rule";

/** Storage key: entry id → the book it is in and a hash of the content Fornello wrote there. */
const WRITTEN = "assetRules";

interface Written {
  hash: string;
  /** Its book (none for entries remembered before books were). */
  book?: string;
}

let written: Record<string, Written> | null = null;

async function writtenHashes(): Promise<Record<string, Written>> {
  if (!written) {
    const raw = parseObject((await getMarinara().storage.get())[WRITTEN]);
    written = {};
    for (const [id, v] of Object.entries(raw)) {
      // an earlier shape kept the hash alone
      if (typeof v === "string") written[id] = { hash: v };
      else {
        const o = parseObject(v);
        if (typeof o.hash === "string") written[id] = { hash: o.hash, ...(typeof o.book === "string" ? { book: o.book } : {}) };
      }
    }
  }
  return written;
}

async function remember(entryId: string, content: string | null, book?: string): Promise<void> {
  const map = await writtenHashes();
  if (content === null) delete map[entryId];
  else map[entryId] = { hash: quickHash(content), ...(book ? { book } : {}) };
  await getMarinara().storage.patch({ [WRITTEN]: { ...map } });
}

/**
 * Takes away every rule entry Fornello wrote that is still as it wrote it, in
 * whichever book (picture tags or telling the AI turned off: other chats'
 * cards hold entries too). Entries the person changed stay.
 */
export async function removePictureRules(): Promise<void> {
  const map = await writtenHashes();
  const byBook = new Map<string, string[]>();
  for (const [id, w] of Object.entries(map)) if (w.book) byBook.set(w.book, [...(byBook.get(w.book) ?? []), id]);
  for (const [book, ids] of byBook) {
    const entries = await loreEntries(book).catch(() => null);
    // a book that is gone took its entries with it
    const ours = (entries ?? []).filter((e) => ids.includes(e.id) && map[e.id]?.hash === quickHash(e.content ?? "")).map((e) => e.id);
    if (ours.length) await deleteLoreEntries(book, ours);
    for (const id of ids) if (!entries || ours.includes(id) || !entries.some((e) => e.id === id)) delete map[id];
  }
  await getMarinara().storage.patch({ [WRITTEN]: { ...map } });
}

/** What was said already this session, so a notice isn't repeated. */
const told = new Set<string>();

/** Forgets what was read and said (Fornello stopped). */
export function forgetRuleHashes(): void {
  written = null;
  told.clear();
}
function tellOnce(key: string, text: string): void {
  if (told.has(key)) return;
  told.add(key);
  showToast(text, "info");
}

/** Whether Fornello wrote this entry as it is now (the person hasn't changed it). */
async function isOurs(entry: RawLoreEntry): Promise<boolean> {
  return (await writtenHashes())[entry.id]?.hash === quickHash(entry.content ?? "");
}

/** Puts `content` in the book's rule entry (none: takes Fornello's entry away). */
async function putRule(bookId: string, content: string, whose: string): Promise<void> {
  const entry = (await loreEntries(bookId)).find((e) => e.name === RULE_ENTRY);
  if (!content) {
    if (entry && (await isOurs(entry))) {
      await deleteLoreEntries(bookId, [entry.id]);
      await remember(entry.id, null);
    }
    return;
  }
  if (entry) {
    if (entry.content === content) return;
    if (!(await isOurs(entry))) {
      tellOnce(
        `edited:${entry.id}`,
        t(`"${RULE_ENTRY}" in ${whose} was changed by hand, so Fornello left it as it is.`, `${whose}의 "${RULE_ENTRY}" 항목을 직접 고치셔서 Fornello가 그대로 두었어요.`),
      );
      return;
    }
    await patchLoreEntry(bookId, entry.id, { content });
    await remember(entry.id, content, bookId);
    return;
  }
  const made = await createLoreEntry(bookId, { name: RULE_ENTRY, content, enabled: true, constant: true, position: 2, depth: 4, order: 900 });
  await remember(made.id, content, bookId);
}

/** The book a card carries (its linked, embedded book); `make`: one is made and put in the card when the slot is free. */
export async function cardBook(c: CharacterInfo, make: boolean): Promise<string | null> {
  const ext = parseObject(c.data.extensions);
  const linked = parseObject(parseObject(ext.importMetadata).embeddedLorebook).lorebookId;
  if (typeof linked === "string" && linked) {
    const book = await api<{ id?: string }>(`/lorebooks/${encodeURIComponent(linked)}`).catch(() => null);
    if (book?.id) return book.id;
  }
  if (!make) return null;
  // read again before making one: a sync queued behind another may hold the card as it was before that one put a book in
  const data = await characterData(c.id);
  const fresh = parseObject(parseObject(parseObject(data.extensions).importMetadata).embeddedLorebook).lorebookId;
  if (fresh !== linked) {
    forgetPeople();
    return cardBook({ ...c, data }, false);
  }
  // the card's book slot holds a book Marinara didn't link: nothing can be added to the card
  if (data.character_book !== null && data.character_book !== undefined) return null;
  const book = await api<{ id: string }>("/lorebooks", { method: "POST", body: { name: `${c.name} Fornello`.slice(0, 200), category: "character", characterIds: [c.id] } });
  try {
    await api(`/characters/${encodeURIComponent(c.id)}/embedded-lorebook/embed`, { method: "POST", body: { lorebookId: book.id } });
  } catch (e) {
    // not put in the card: the new, empty book doesn't stay in the library
    await api(`/lorebooks/${encodeURIComponent(book.id)}`, { method: "DELETE" }).catch(() => {});
    throw e;
  }
  forgetPeople();
  return book.id;
}

/** Brings the rule entries of this chat and its cards in line with the settings and the cards' assets. */
export async function syncPictureRules(chatId: string, cast: CharacterInfo[], look: AssetDisplay): Promise<void> {
  const where = look.tags ? look.tell : "off";
  const withAssets = cast.filter((c) => cardAssets(c.data).length);
  const toChat: CharacterInfo[] = [];
  for (const c of cast) {
    const assets = cardAssets(c.data);
    const want = where === "card" && assets.length ? pictureRule([{ name: c.name, assets }], look.perReply) : "";
    const book = await cardBook(c, !!want);
    if (book) await putRule(book, want, c.name);
    else if (want) {
      toChat.push(c);
      tellOnce(
        `slot:${c.id}`,
        t(`${c.name}'s card already holds a lorebook Marinara didn't link, so its picture names went to this chat's lorebook.`, `${c.name} 카드에는 마리나라가 연결하지 않은 로어북이 이미 있어서, 그림 이름은 이 채팅의 로어북에 넣었어요.`),
      );
    }
  }
  const chatPeople = where === "chat" ? withAssets : toChat;
  const chatRule = chatPeople.length ? pictureRule(chatPeople.map((c) => ({ name: c.name, assets: cardAssets(c.data) })), look.perReply) : "";
  const book = chatRule ? await chatLoreBook(chatId) : await chatLoreBookIfAny(chatId);
  if (book) await putRule(book.id, chatRule, t("this chat's lorebook", "이 채팅 로어북"));
}
