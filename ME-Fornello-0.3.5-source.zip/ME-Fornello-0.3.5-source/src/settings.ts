// Fornello settings in its Marinara extension storage.

import { getMarinara } from "./shared/marinara-global";
import { DEFAULT_DISPLAY, type ComponentDef, type ComponentDisplay, type ComponentSet, normalizeDisplay, normalizeComponent, normalizeSets } from "./components/model";
import { t } from "./shared/i18n";
import { type LibraryItem, normalizeLibrary } from "./scripts/model";

/** ask: show pages, run their scripts on a click. always: run the recent ones as they come on screen. off: leave the chat alone. */
export type RunMode = "ask" | "always" | "off";

export const RUN_MODES: Record<RunMode, string> = {
  get always() {
    return t("Run at once", "바로 실행");
  },
  get ask() {
    return t("Click to run", "눌러서 실행");
  },
  get off() {
    return t("Off", "끄기");
  },
};

export interface FornelloSettings {
  mode: RunMode;
  maxHeight: number;
  components: ComponentDef[];
  /** Named groups of the components. */
  componentSets: ComponentSet[];
  display: ComponentDisplay;
  /** "바로 실행": how many of the most recent pages start by themselves (older ones wait for ▶ 실행). */
  autoRun: number;
  /** Cards whose components the person allowed: character id → what the components were then (cards.ts). */
  trustedCards: Record<string, string>;
  /** Background scripts the person keeps here (every chat). */
  scripts: LibraryItem[];
  /** Cards whose scripts the person answered: character id → the scripts' hash (allowed) or "no:" + it (declined). */
  trustedScripts: Record<string, string>;
  /** Scripts the person switched on or off (by key), over what the card says. */
  scriptSwitch: Record<string, boolean>;
}

export const AUTO_RUN_MAX = 20;

function normalizeSwitches(raw: unknown): Record<string, boolean> {
  const out: Record<string, boolean> = {};
  if (raw && typeof raw === "object" && !Array.isArray(raw)) for (const [k, v] of Object.entries(raw)) if (typeof v === "boolean") out[k] = v;
  return out;
}

function normalizeTrusted(raw: unknown): Record<string, string> {
  const out: Record<string, string> = {};
  if (raw && typeof raw === "object" && !Array.isArray(raw)) for (const [k, v] of Object.entries(raw)) if (typeof v === "string") out[k] = v;
  return out;
}

const DEFAULTS: FornelloSettings = { mode: "always", maxHeight: 1600, components: [], componentSets: [], display: DEFAULT_DISPLAY, autoRun: 3, trustedCards: {}, scripts: [], trustedScripts: {}, scriptSwitch: {} };

export class Settings {
  private value: FornelloSettings = { ...DEFAULTS };
  /** Read from storage: until then nothing is written over what is there. */
  private loaded = false;
  private readonly listeners = new Set<(s: FornelloSettings) => void>();

  get current(): FornelloSettings {
    return this.value;
  }

  async load(): Promise<void> {
    const stored = (await getMarinara().storage.get()).settings as Partial<FornelloSettings> | undefined;
    const components = Array.isArray(stored?.components) ? stored.components.map(normalizeComponent).filter((w): w is ComponentDef => !!w) : [];
    this.value = {
      mode: stored?.mode && Object.hasOwn(RUN_MODES, stored.mode) ? stored.mode : DEFAULTS.mode,
      maxHeight: Number(stored?.maxHeight) >= 200 ? Number(stored?.maxHeight) : DEFAULTS.maxHeight,
      components,
      componentSets: normalizeSets(stored?.componentSets, components),
      display: normalizeDisplay(stored?.display),
      trustedCards: normalizeTrusted(stored?.trustedCards),
      scripts: normalizeLibrary(stored?.scripts),
      trustedScripts: normalizeTrusted(stored?.trustedScripts),
      scriptSwitch: normalizeSwitches(stored?.scriptSwitch),
      autoRun: Number.isFinite(Number(stored?.autoRun)) && stored?.autoRun !== undefined ? Math.max(0, Math.min(AUTO_RUN_MAX, Math.round(Number(stored.autoRun)))) : DEFAULTS.autoRun,
    };
    this.loaded = true;
  }

  /** Reads the settings, with retries; if they cannot be read, pages wait for a click (the person may have chosen that). */
  async loadOrSafe(tries = 3, pause = 1000): Promise<boolean> {
    for (let i = 0; i < tries; i++) {
      try {
        await this.load();
        return true;
      } catch {
        if (i < tries - 1) await new Promise((r) => setTimeout(r, pause));
      }
    }
    this.value = { ...DEFAULTS, mode: "ask" };
    return false;
  }

  async set(patch: Partial<FornelloSettings>): Promise<void> {
    if (!this.loaded) throw new Error(t("Settings could not be read, so nothing was saved. Try reloading.", "설정을 읽지 못해서 저장하지 않았어요. 새로고침해 보세요."));
    // saved first: a failed save leaves the settings as they were
    const next = { ...this.value, ...patch };
    await getMarinara().storage.patch({ settings: next });
    this.value = next;
    for (const fn of this.listeners) fn(this.value);
  }

  subscribe(fn: (s: FornelloSettings) => void): () => void {
    this.listeners.add(fn);
    return () => this.listeners.delete(fn);
  }
}
