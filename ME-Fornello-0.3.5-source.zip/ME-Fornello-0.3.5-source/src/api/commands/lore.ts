// Page commands for lorebooks, their entries and which books a chat uses.
// "@chat" stands for the chat's own lorebook.

import { t } from "../../shared/i18n";
import { cmd } from "../command";
import { currentChatId } from "../../host/current-chat";
import {
  chatLoreBook,
  createLoreBook,
  createLoreEntry,
  deleteLoreEntries,
  findLoreBook,
  loreBooks,
  loreEntries,
  patchLoreEntry,
} from "../marinara";
import { asText } from "../parse";
import type { PageSession } from "../session";
import type { LoreBook, RawLoreEntry } from "../types";
import { deleteBook, importBook, patchBook, setChatBookIds } from "../library";

export interface LoreItem {
  id: string;
  name: string;
  content: string;
  keys: string[];
  enabled: boolean;
  constant: boolean;
  position: "before" | "after" | "depth" | "outlet";
  depth: number;
  order: number;
  secondaryKeys: string[];
  /** How the secondary keys count: "and" (any of them too), "and_all", "not" (none of them), "not_all". */
  selectiveLogic: string;
  /** % chance it goes in when it matches (null: always). */
  probability: number | null;
  /** How many recent messages are searched for its keys (null: the book's setting). */
  scanDepth: number | null;
  role: "system" | "user" | "assistant";
  /** Stays in for this many messages after it went in / can't go in again for this many / not before this many messages. */
  sticky: number | null;
  cooldown: number | null;
  delay: number | null;
  group: string;
  /** The outlet it goes to (position "outlet"). */
  outletName: string;
  caseSensitive: boolean;
  matchWholeWords: boolean;
  /** Its keys are regular expressions. */
  useRegex: boolean;
  /** Its content does not set off other entries / other entries' content does not set it off / only set off by other entries. */
  preventRecursion: boolean;
  excludeRecursion: boolean;
  delayUntilRecursion: boolean;
}

const POSITION_NAME: Record<number, LoreItem["position"]> = { 0: "before", 1: "after", 2: "depth", 7: "outlet" };
const POSITION_NUM: Record<string, number> = { before: 0, after: 1, depth: 2, outlet: 7 };

/** An entry the way getLore(book) hands it to pages. */
function loreItem(e: RawLoreEntry): LoreItem {
  return {
    id: e.id,
    name: String(e.name ?? ""),
    content: String(e.content ?? ""),
    keys: Array.isArray(e.keys) ? e.keys.map(String) : [],
    enabled: e.enabled !== false,
    constant: e.constant === true,
    position: POSITION_NAME[Number(e.position ?? 0)] ?? "before",
    depth: Number(e.depth ?? 4),
    order: Number(e.order ?? 100),
    secondaryKeys: Array.isArray(e.secondaryKeys) ? e.secondaryKeys.map(String) : [],
    selectiveLogic: String(e.selectiveLogic ?? "and"),
    probability: numOrNull(e.probability),
    scanDepth: numOrNull(e.scanDepth),
    role: e.role === "user" || e.role === "assistant" ? e.role : "system",
    sticky: numOrNull(e.sticky),
    cooldown: numOrNull(e.cooldown),
    delay: numOrNull(e.delay),
    group: String(e.group ?? ""),
    outletName: String(e.outletName ?? ""),
    caseSensitive: e.caseSensitive === true,
    matchWholeWords: e.matchWholeWords === true,
    useRegex: e.useRegex === true,
    preventRecursion: e.preventRecursion !== false,
    excludeRecursion: e.excludeRecursion === true,
    delayUntilRecursion: e.delayUntilRecursion === true,
  };
}

const numOrNull = (v: unknown): number | null => (v === null || v === undefined || v === "" || !Number.isFinite(Number(v)) ? null : Number(v));
const LOGIC = new Set(["and", "and_all", "or", "not", "not_all"]);

/** Keys as a list, or as one comma-separated text. */
export const keyList = (v: unknown): string[] => (Array.isArray(v) ? v.map(String) : typeof v === "string" ? v.split(",").map((s) => s.trim()).filter(Boolean) : []);

/** What a page passed to setLore, as the fields Marinara takes (only those given). */
export function lorePatch(input: Record<string, unknown>): Record<string, unknown> {
  const out: Record<string, unknown> = {};
  if (input.name !== undefined) out.name = String(input.name).slice(0, 200) || "Entry";
  if (input.content !== undefined) out.content = asText(input.content);
  if (input.keys !== undefined) out.keys = keyList(input.keys);
  if (input.enabled !== undefined) out.enabled = input.enabled !== false;
  if (input.constant !== undefined) out.constant = input.constant === true;
  if (input.position !== undefined) out.position = typeof input.position === "number" ? input.position : (POSITION_NUM[String(input.position)] ?? 0);
  if (input.depth !== undefined) out.depth = Number(input.depth) || 0;
  if (input.order !== undefined) out.order = Number(input.order) || 0;
  if (input.secondaryKeys !== undefined) {
    out.secondaryKeys = keyList(input.secondaryKeys);
    out.selective = (out.secondaryKeys as string[]).length > 0;
  }
  if (input.selectiveLogic !== undefined && LOGIC.has(String(input.selectiveLogic))) out.selectiveLogic = String(input.selectiveLogic);
  for (const k of ["probability", "scanDepth", "sticky", "cooldown", "delay"] as const) if (input[k] !== undefined) out[k] = numOrNull(input[k]);
  if (input.role !== undefined && ["system", "user", "assistant"].includes(String(input.role))) out.role = String(input.role);
  if (input.group !== undefined) out.group = String(input.group ?? "");
  if (input.outletName !== undefined) out.outletName = String(input.outletName ?? "").slice(0, 200);
  for (const k of ["caseSensitive", "matchWholeWords", "useRegex", "preventRecursion", "excludeRecursion", "delayUntilRecursion"] as const) {
    if (input[k] !== undefined) out[k] = input[k] === true;
  }
  return out;
}

/** The name that stands for this chat's own lorebook (what is in it reaches only this chat's story). */
const CHAT_BOOK = "@chat";

/** The book a page names ("@chat", a name or an id); `create` makes a missing one. */
export async function bookFor(s: PageSession, name: string, create: boolean): Promise<{ id: string; name: string } | null> {
  if (name === CHAT_BOOK) return chatLoreBook(s.here());
  const found = await findLoreBook(String(name), s.chatId ?? currentChatId());
  if (found || !create) return found;
  return createLoreBook(String(name));
}

/** Books whose entries the person let this page delete (asked once per book). */
const allowedBooks = new WeakMap<PageSession, Set<string>>();

/** Deletes entries; from a shared lorebook (or several at once) it asks first, once per book. */
export async function removeLore(s: PageSession, asked: string, book: { id: string; name: string }, ids: string[]): Promise<number> {
  if (!ids.length) return 0;
  let allowed = allowedBooks.get(s);
  if (!allowed) allowedBooks.set(s, (allowed = new Set()));
  if ((asked !== CHAT_BOOK || ids.length > 1) && !allowed.has(book.id)) {
    const where = asked === CHAT_BOOK ? t("this chat's lorebook", "이 채팅의 로어북") : t(`lorebook "${book.name}"`, `로어북 "${book.name}"`);
    if (!s.ui.confirm(t(`This page wants to delete ${ids.length} entr${ids.length === 1 ? "y" : "ies"} from ${where}. Delete?`, `이 페이지가 ${where}에서 항목 ${ids.length}개를 지우려고 해요. 지울까요?`))) return 0;
    allowed.add(book.id);
  }
  return deleteLoreEntries(book.id, ids);
}

async function getLore(s: PageSession, book?: unknown): Promise<string[] | LoreItem[]> {
  if (book === undefined || book === null || book === "") return (s.bookNames = (await loreBooks()).map((b) => b.name));
  const found = await bookFor(s, String(book), false);
  return found ? (await loreEntries(found.id)).map(loreItem) : [];
}

/** Adds entries or updates the one with the same id or name; a missing book is made. `replace`: the book holds just these. */
export async function setLore(s: PageSession, book: unknown, entries: unknown, options: { replace?: boolean } = {}): Promise<number> {
  const target = await bookFor(s, String(book), true);
  if (!target) return 0;
  if (!s.bookNames.includes(target.name)) s.bookNames.push(target.name);
  const existing = await loreEntries(target.id);
  const kept = new Set<string>();
  let count = 0;
  for (const input of (Array.isArray(entries) ? entries : [entries]) as Record<string, unknown>[]) {
    if (!input || typeof input !== "object") continue;
    const patch = lorePatch(input);
    const same =
      (input.id !== undefined ? existing.find((e) => e.id === String(input.id) && !kept.has(e.id)) : undefined) ??
      (patch.name ? existing.find((e) => e.name === patch.name && !kept.has(e.id)) : undefined);
    if (same) {
      await patchLoreEntry(target.id, same.id, patch);
      kept.add(same.id);
    } else {
      const made = await createLoreEntry(target.id, patch);
      existing.push(made);
      kept.add(made.id);
    }
    count++;
  }
  if (options.replace) {
    const gone = existing.filter((e) => !kept.has(e.id)).map((e) => e.id);
    if (gone.length && !(await removeLore(s, String(book), target, gone))) throw new Error(t("Not replaced: deleting was refused.", "바꾸지 않음: 지우기를 거절함."));
  }
  return count;
}

/** Deletes entries by name (or names), or those a function picks. */
async function delLore(s: PageSession, book: unknown, which: unknown): Promise<number> {
  const target = await bookFor(s, String(book), false);
  if (!target) return 0;
  const entries = await loreEntries(target.id);
  const names = typeof which === "function" ? null : (Array.isArray(which) ? which : [which]).map(String);
  const ids = entries.filter((e) => (names ? names.includes(String(e.name ?? "")) : (which as (e: LoreItem) => unknown)(loreItem(e)))).map((e) => e.id);
  return removeLore(s, String(book), target, ids);
}

// ── which books a chat uses ──

export interface ChatBooks {
  /** On in every chat. */
  global: string[];
  /** Linked to the chat's characters (a card's own book comes first). */
  char: string[];
  /** Linked to the chat's persona. */
  persona: string[];
  /** The chat's own book and the books added to this chat. */
  chat: string[];
}

/** A card's own book (Marinara made it from the card) before the books linked to it later. */
export const ownFirst = (books: LoreBook[]): LoreBook[] => [...books].sort((a, b) => Number(b.category === "character") - Number(a.category === "character"));

function chatBooks(s: PageSession): ChatBooks {
  const { books, chatBooks: added } = s.world;
  const on = books.filter((b) => b.enabled !== false);
  const castIds = s.cast.map((c) => c.id);
  const me = s.me.id;
  return {
    global: on.filter((b) => b.isGlobal).map((b) => b.name),
    char: ownFirst(on.filter((b) => b.characterIds?.some((id) => castIds.includes(id)))).map((b) => b.name),
    persona: me ? on.filter((b) => b.personaIds?.includes(me)).map((b) => b.name) : [],
    chat: on.filter((b) => (s.chatId && b.chatId === s.chatId) || added.includes(b.id)).map((b) => b.name),
  };
}

type LinkTarget = { kind: "global" | "chat" } | { kind: "char" | "persona"; id: string; name: string };

/** Where linkBook puts a book: every chat, this chat, a character (the chat's first by default) or a persona (the chat's by default). */
function linkTarget(s: PageSession, to: unknown): LinkTarget {
  if (to === "global" || to === "chat") return { kind: to };
  const asked = (key: string) => (to === key ? undefined : to && typeof to === "object" && key in to ? String((to as Record<string, unknown>)[key]) : null);
  const charName = asked("char");
  if (charName !== null) {
    const c = charName === undefined ? s.cast[0] : s.world.chars.find((x) => x.name === charName || x.id === charName);
    if (!c) throw new Error(t(`No character: ${charName ?? ""}`, `캐릭터 없음: ${charName ?? ""}`));
    return { kind: "char", id: c.id, name: c.name };
  }
  const personaName = asked("persona");
  if (personaName !== null) {
    const p = personaName === undefined ? (s.me.id ? { id: s.me.id, name: s.me.name } : undefined) : s.world.personas.find((x) => x.name === personaName || x.id === personaName);
    if (!p) throw new Error(t(`No persona: ${personaName ?? ""}`, `페르소나 없음: ${personaName ?? ""}`));
    return { kind: "persona", id: p.id, name: p.name };
  }
  throw new Error(t('Use "global", "chat", "char" or "persona"', '"global", "chat", "char", "persona" 중 하나'));
}

/** Links a book (`on`) or unlinks it; a link outside this chat is asked about once per book. */
export async function linkBook(s: PageSession, book: unknown, to: unknown, on: boolean): Promise<boolean> {
  const found = await bookFor(s, String(book), false);
  if (!found) throw new Error(t(`No lorebook: ${String(book)}`, `로어북 없음: ${String(book)}`));
  const where = linkTarget(s, to);
  const full: LoreBook = s.world.books.find((b) => b.id === found.id) ?? found;
  if (where.kind === "chat") {
    const ids = s.world.chatBooks.filter((id) => id !== found.id);
    await setChatBookIds(s.here(), on ? [...ids, found.id] : ids);
  } else {
    const what = "name" in where ? where.name : t("every chat", "모든 채팅");
    const question = on
      ? t(`This page wants to turn lorebook "${found.name}" on for ${what}. Allow?`, `이 페이지가 로어북 "${found.name}"을(를) ${what}에 켜려고 해요. 허락할까요?`)
      : t(`This page wants to turn lorebook "${found.name}" off for ${what}. Allow?`, `이 페이지가 로어북 "${found.name}"을(를) ${what}에서 끄려고 해요. 허락할까요?`);
    if (!s.allowOnce(`book:${found.id}`, question)) return false;
    if (!("id" in where)) await patchBook(found.id, { isGlobal: on });
    else {
      const key = where.kind === "char" ? "characterIds" : "personaIds";
      const ids = (full[key] ?? []).filter((id) => id !== where.id);
      await patchBook(found.id, { [key]: on ? [...ids, where.id] : ids });
    }
  }
  await s.freshWorld();
  return true;
}

/** Deletes a whole book (always asked). */
export async function delBook(s: PageSession, book: unknown): Promise<boolean> {
  const found = await bookFor(s, String(book), false);
  if (!found) return false;
  if (!s.ui.confirm(t(`This page wants to delete lorebook "${found.name}" and all its entries. Delete?`, `이 페이지가 로어북 "${found.name}"과(와) 항목 전부를 지우려고 해요. 지울까요?`))) return false;
  await deleteBook(found.id);
  await s.freshWorld();
  return true;
}

/** Imports a SillyTavern lorebook (its JSON, as an object or text); its name comes back. */
export async function importLore(s: PageSession, file: unknown, name?: unknown): Promise<string> {
  const json = typeof file === "string" ? (JSON.parse(file) as unknown) : file;
  if (!json || typeof json !== "object") throw new Error(t("Not a lorebook file.", "로어북 파일이 아님."));
  const fallback = String(name ?? (json as { name?: unknown }).name ?? "Imported");
  const id = await importBook(json as Record<string, unknown>, fallback);
  const world = await s.freshWorld();
  return world.books.find((b) => b.id === id)?.name ?? fallback;
}

export function loreCommands(s: PageSession) {
  return {
    getLore: cmd((book?: unknown) => getLore(s, book)),
    setLore: cmd({ writes: true }, (book: unknown, entries: unknown, options?: { replace?: boolean }) => setLore(s, book, entries, options)),
    delLore: cmd({ writes: true }, (book: unknown, which: unknown) => delLore(s, book, which)),
    getBooks: cmd(() => chatBooks(s)),
    linkBook: cmd({ writes: true }, (book: unknown, to: unknown) => linkBook(s, book, to, true)),
    unlinkBook: cmd({ writes: true }, (book: unknown, from: unknown) => linkBook(s, book, from, false)),
    delBook: cmd({ writes: true }, (book: unknown) => delBook(s, book)),
    importBook: cmd({ writes: true }, (file: unknown, name?: unknown) => importLore(s, file, name)),
  };
}
