// Page commands that ask the AI (with the chat as context, or the prompt
// alone); nothing is saved to the chat. Each call is a run with an id, so a
// page can stop its own calls without stopping the person's reply.

import { cmd } from "../command";
import { currentChatId } from "../../host/current-chat";
import { randomPart } from "../../hash";
import { type AiInputMessage, abortRun, generate } from "../marinara";
import type { PageSession } from "../session";

interface Common {
  /** A saved connection, by name or id. */
  connection?: string;
  /** Called as the reply comes in: the text so far and the newest piece. */
  onToken?: (text: string, piece: string) => void;
  /** The run's id (for stopGen(id)); one is made when not given. */
  id?: string;
}

export interface GenChatOptions extends Common {
  /** Only the cards, the persona, always-on entries and the last `history` messages (cheaper; see lightContext). */
  history?: number;
  /** A note the AI takes into account for this reply only. */
  guide?: string;
  /** Another prompt preset, by name or id. */
  preset?: string;
}

export interface GenRawOptions extends Common {
  /** Images with the request (data URLs or links). */
  images?: string[];
  temperature?: number;
  maxTokens?: number;
  topP?: number;
  topK?: number;
  minP?: number;
  frequencyPenalty?: number;
  presencePenalty?: number;
  reasoningEffort?: string;
}

const PARAMETERS = ["temperature", "maxTokens", "topP", "topK", "minP", "frequencyPenalty", "presencePenalty", "reasoningEffort"] as const;

const newRunId = () => `fornello-${randomPart()}`;

/** Runs one AI call as the page's own run, so stopGen(id) / stopMyGens() can stop it. */
async function asRun(s: PageSession, kind: "raw" | "dryRun", id: string | undefined, call: (runId: string) => Promise<string>): Promise<string> {
  const runId = id ? String(id) : newRunId();
  s.runs.set(runId, kind);
  try {
    return await call(runId);
  } finally {
    s.runs.delete(runId);
  }
}

// a page outside any chat (Dispensa's viewer) asks about the chat on screen
export function genChat(s: PageSession, prompt: unknown, options: GenChatOptions = {}): Promise<string> {
  const light = options.history !== undefined;
  return asRun(s, light ? "raw" : "dryRun", options.id, (runId) =>
    generate(String(prompt ?? ""), {
      chatId: s.chatId ?? currentChatId(),
      connection: options.connection,
      history: options.history,
      guide: options.guide,
      preset: options.preset,
      onToken: typeof options.onToken === "function" ? options.onToken : undefined,
      runId,
    }),
  );
}

/** The prompt alone: a text, or the messages in order ({ role, content, images? }). */
export function genRaw(s: PageSession, input: unknown, options: GenRawOptions = {}): Promise<string> {
  const parameters: Record<string, unknown> = {};
  for (const key of PARAMETERS) if (options[key] !== undefined) parameters[key] = options[key];
  return asRun(s, "raw", options.id, (runId) =>
    generate(Array.isArray(input) ? (input as AiInputMessage[]) : String(input ?? ""), {
      raw: true,
      chatId: s.chatId ?? currentChatId(),
      connection: options.connection,
      images: Array.isArray(options.images) ? options.images.map(String) : undefined,
      parameters: Object.keys(parameters).length ? parameters : undefined,
      onToken: typeof options.onToken === "function" ? options.onToken : undefined,
      runId,
    }),
  );
}

/** Stops one of the page's runs; true when it was running. */
export async function stopRun(s: PageSession, id: string): Promise<boolean> {
  const kind = s.runs.get(id);
  if (!kind) return false;
  s.runs.delete(id);
  return abortRun(id, kind, s.chatId);
}

/** Stops every run the page started (never the person's reply). */
export async function stopMyGens(s: PageSession): Promise<boolean> {
  const ids = [...s.runs.keys()];
  const done = await Promise.all(ids.map((id) => stopRun(s, id)));
  return done.some(Boolean);
}

export function generateCommands(s: PageSession) {
  return {
    genChat: cmd({ costs: true }, (prompt: unknown, options?: GenChatOptions) => genChat(s, prompt, options)),
    genRaw: cmd({ costs: true }, (input: unknown, options?: GenRawOptions) => genRaw(s, input, options)),
    stopMyGens: cmd(() => stopMyGens(s)),
  };
}
