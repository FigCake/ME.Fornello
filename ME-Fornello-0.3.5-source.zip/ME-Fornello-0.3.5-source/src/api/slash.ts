// runSlash("/command"): all of STscript through Dispensa when installed,
// otherwise the commands pages use most.

import { submitThroughComposer } from "../shared/composer";
import { t } from "../shared/i18n";
import { cmd } from "./command";
import { genChat, genRaw } from "./commands/generate";
import { addMsg, sendMsg, sendRegen, setInput, stopGen, untilReplyDone, whileSending } from "./commands/messages";
import { currentChatId } from "../host/current-chat";
import { forgetChat } from "./chat-store";
import type { PageSession } from "./session";
import { refreshShared } from "./shared-vars";
import "../shared/dispensa-bridge";

/** A line of commands split at its pipes (|), leaving pipes inside quotes alone. */
export function splitPipes(line: string): string[] {
  const parts: string[] = [];
  let cur = "";
  let quote: string | null = null;
  for (const ch of line) {
    if (quote) {
      if (ch === quote) quote = null;
    } else if (ch === '"' || ch === "'") quote = ch;
    else if (ch === "|") {
      parts.push(cur.trim());
      cur = "";
      continue;
    }
    cur += ch;
  }
  if (cur.trim()) parts.push(cur.trim());
  return parts;
}

/** "/name key=value text" → name and the text after its named arguments. */
export function parseCommand(part: string): { name: string; text: string } {
  const m = /^\/(\S+)\s*([\s\S]*)$/.exec(part);
  if (!m) return { name: "", text: part };
  let rest = m[2];
  while (/^[\w-]+=("[^"]*"|\S+)\s*/.test(rest)) rest = rest.replace(/^[\w-]+=("[^"]*"|\S+)\s*/, "");
  return { name: m[1].toLowerCase(), text: rest.replace(/\{\{pipe\}\}/g, "") };
}

/** Commands that never call the AI: a line of only these is not counted as an AI call. */
const NO_AI = new Set([
  "setvar", "getvar", "addvar", "incvar", "decvar", "flushvar", "listvar",
  "setglobalvar", "getglobalvar", "addglobalvar", "incglobalvar", "decglobalvar", "flushglobalvar",
  "echo", "setinput", "send", "sendas", "sendchar", "sys", "narrate", "comment", "stop", "pass",
]);

/** Whether a line run through Dispensa may call the AI: yes unless every command in it never does (a closure may run anything). */
export function slashCallsAi(line: string): boolean {
  if (line.includes("{:")) return true;
  return splitPipes(line).some((part) => {
    const { name } = parseCommand(part);
    return name !== "" && !NO_AI.has(name);
  });
}

export async function runSlash(s: PageSession, line: unknown): Promise<string> {
  const text = String(line ?? "").trim();
  if (!text) return "";
  if (window.__dispensa) {
    // counted once: what Dispensa runs (a QR, a closure) is not followed here
    if (slashCallsAi(text)) s.budget("runSlash");
    try {
      return await window.__dispensa.runSlash(text);
    } finally {
      // the commands may have set variables (/setvar) behind the pages' back
      forgetChat(s.chatId ?? currentChatId());
      if (s.chatId) await refreshShared(s.chatId).catch(() => undefined);
    }
  }
  // without Dispensa
  const parts = splitPipes(text).map(parseCommand);
  let pipe = "";
  for (let i = 0; i < parts.length; i++) {
    const { name, text: arg } = parts[i];
    const value = arg || pipe;
    switch (name) {
      // each AI call is counted, as genChat and sendMsg are
      case "send":
        if (parts[i + 1]?.name === "trigger") {
          s.budget("runSlash");
          await sendMsg(s, value);
          i++;
        } else await addMsg(s, value, "user");
        pipe = "";
        break;
      case "trigger": {
        const who = s.cast[0]?.name;
        if (!who) throw new Error(t("No character to reply.", "답변할 캐릭터가 없어요."));
        s.budget("runSlash");
        await whileSending(async () => {
          await submitThroughComposer(`/as "${who.replace(/"/g, "")}"`, s.stillHere);
          await untilReplyDone();
        });
        pipe = "";
        break;
      }
      case "gen":
        s.budget("runSlash");
        pipe = await genChat(s, value);
        break;
      case "genraw":
        s.budget("runSlash");
        pipe = await genRaw(s, value);
        break;
      case "sendas":
      case "sendchar":
        await addMsg(s, value, "char");
        pipe = "";
        break;
      case "sys":
      case "narrate":
        await addMsg(s, value, "narrator");
        pipe = "";
        break;
      case "regen":
      case "regenerate":
        s.budget("runSlash");
        await sendRegen(s);
        pipe = "";
        break;
      case "stop":
        stopGen();
        break;
      case "echo":
        // shows it and passes it on, as in SillyTavern
        s.ui.toast(value);
        pipe = value;
        break;
      case "setinput":
        setInput(value);
        break;
      default:
        throw new Error(t(`Needs Dispensa: /${name}`, `Dispensa 필요: /${name}`));
    }
  }
  return pipe;
}

export function slashCommands(s: PageSession) {
  return {
    runSlash: cmd({ writes: true }, (line: unknown) => runSlash(s, line)),
  };
}
