// Asset tags in a reply. Fornello's own form is [img:name] or
// [img:person:name]; the forms other character cards use are read too:
// [img::name], {{img::name}}, {{img::person::name}}, {{image::…}},
// {{asset::…}}, {{emotion::…}}, and {{raw::name}} / {{path::name}}, which
// stand for the picture's address (in a card's HTML or CSS).

import { samePerson } from "./names";

export interface AssetTag {
  start: number;
  end: number;
  /** img: show the picture; raw: put its address there. */
  kind: "img" | "raw";
  name: string;
  person?: string;
}

const BRACKET = /\[img:{1,2}([^\]\n]+)\]/gi;
const CURLY = /\{\{(img|image|asset|emotion|raw|path)::([^{}\n]+)\}\}/gi;
/**
 * {{raw::name}} as Marinara shows it (Fornello's display regex, picture-regex.ts): an address the browser
 * doesn't fetch, so the page Marinara draws asks for nothing before Fornello fills the name in.
 */
export const SHOWN_PREFIX = "data:,fornello-pic::";
const SHOWN = /data:,fornello-pic::([^"'()<>\n]+)/g;

/**
 * Splits a tag's body into a person and a name. The first part names a
 * person only when it is one of `people`; otherwise the whole body is the
 * name (a name may hold the separator: "Re:Zero").
 */
function split(body: string, separator: string, people: string[]): { name: string; person?: string } {
  const parts = body.split(separator).map((p) => p.trim()).filter(Boolean);
  if (parts.length > 1 && people.some((p) => samePerson(parts[0], p))) return { person: parts[0], name: parts.slice(1).join(separator) };
  return { name: parts.join(separator) };
}

/** The tags in `text`, in order. `people`: who a tag may name (the chat's characters and a card's people). */
export function findTags(text: string, people: string[] = []): AssetTag[] {
  const out: AssetTag[] = [];
  for (const m of text.matchAll(BRACKET)) {
    const { name, person } = split(m[1], ":", people);
    if (name) out.push({ start: m.index, end: m.index + m[0].length, kind: "img", name, ...(person ? { person } : {}) });
  }
  for (const m of text.matchAll(CURLY)) {
    const kind = /^(raw|path)$/i.test(m[1]) ? "raw" : "img";
    const { name, person } = split(m[2], "::", people);
    if (name) out.push({ start: m.index, end: m.index + m[0].length, kind, name, ...(person ? { person } : {}) });
  }
  for (const m of text.matchAll(SHOWN)) {
    const { name, person } = split(m[1], "::", people);
    if (name) out.push({ start: m.index, end: m.index + m[0].length, kind: "raw", name, ...(person ? { person } : {}) });
  }
  return out.sort((a, b) => a.start - b.start);
}

/** Whether `text` may hold a tag (a quick look before the full one). */
export const mayHoldTags = (text: string) => /\[img:|\{\{(?:img|image|asset|emotion|raw|path)::|data:,fornello-pic::/i.test(text);
