// How a page command is declared, and the checks every call goes through:
//
//   setMsg: cmd({ writes: true }, (num, text) => setMsg(s, num, text)),

import { t } from "../shared/i18n";
import { currentChatId } from "../host/current-chat";
import type { PageSession } from "./session";

export interface CommandRules {
  /**
   * Changes the chat, its lorebooks or its metadata: a preview only says so,
   * and it does not run while another chat is open. Chat variables are not
   * marked (a preview has its own copy; they go to the page's own chat).
   */
  writes?: boolean;
  /** An AI call that answers with text: a preview answers "" without calling. Counts toward the AI calls a minute. */
  costs?: boolean;
  /** Makes the AI answer without being such a call (sendMsg, sendRegen): counts toward the AI calls a minute. */
  paid?: boolean;
}

// eslint-disable-next-line @typescript-eslint/no-explicit-any
type AnyFn = (...args: any[]) => unknown;

export interface Command<F extends AnyFn = AnyFn> {
  readonly rules: CommandRules;
  readonly run: F;
}

/** Something pages get that is not a command (tavern_events, SillyTavern, toastr): handed over as it is. */
export interface PlainValue {
  readonly value: unknown;
}

/** What pages see, by the names they call it. */
export type CommandTable = Record<string, Command | PlainValue>;

/** A command; without rules, one that only reads. */
export function cmd<F extends AnyFn>(run: F): Command<F>;
export function cmd<F extends AnyFn>(rules: CommandRules, run: F): Command<F>;
export function cmd<F extends AnyFn>(a: CommandRules | F, b?: F): Command<F> {
  return typeof a === "function" ? { rules: {}, run: a } : { rules: a, run: b! };
}

export const plain = (value: unknown): PlainValue => ({ value });

/** The command as pages call it, with the checks of its rules. */
export function guarded(name: string, command: Command, s: PageSession): AnyFn {
  const { writes, costs, paid } = command.rules;
  return (...args: unknown[]) => {
    if (s.disposed) throw new Error(t(`Page closed: ${name}`, `페이지 닫힘: ${name}`));
    if (s.preview && (writes || costs)) {
      s.ui.toast(t(`Preview, so this did not run: ${name}`, `미리보기라서 실행하지 않았어요: ${name}`));
      return Promise.resolve(costs ? "" : false);
    }
    if (writes && s.chatId && currentChatId() !== s.chatId) throw new Error(t(`Another chat is open: ${name}`, `다른 채팅이 열려 있음: ${name}`));
    if (costs || paid) {
      // these all answer with a promise: a stop is a rejection too (genChat(…).catch(…))
      try {
        s.budget(name);
      } catch (e) {
        return Promise.reject(e);
      }
    }
    return command.run(...args);
  };
}
