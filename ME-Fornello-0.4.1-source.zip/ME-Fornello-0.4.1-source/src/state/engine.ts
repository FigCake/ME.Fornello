// Pesto's engine: the story's values worked out from the chat's messages. The AI only says
// what happened (readUpdates); this checks each change against the schema (kind, range, who may
// write it), runs the card's events and each-reply rules, and keeps the result per message, so a
// swipe, an edit or a deleted message recomputes from there on. Nothing here touches the page or
// Marinara: it is plain work on values, the same every time for the same messages (the dice are
// seeded by the message's id).

import { quickHash } from "../hash";
import { pathParts } from "../api/var-ops";
import { ExprError, evaluate, rollDice, same, type Scope } from "./expr";
import { emptyValue, fieldAt, readSchema, type Field, type Schema, type Writer } from "./schema";
import { DICE, readRules, type Rules, type Step } from "./rules";
import { readChanges, readUpdates, type Op } from "./update";
import { readYaml, YamlError } from "./yaml";

type Obj = Record<string, unknown>;
type By = Writer | "start";

export interface Definition {
  schema: Schema;
  rules: Rules;
  /** the values before the first message */
  start: Obj;
  /** changes when any of the card's entries change */
  sig: string;
  /** the card's code (`pesto:code`), run only once the person allows it */
  code?: string;
}

export interface Change {
  path: string;
  from: unknown;
  to: unknown;
  by: By;
  /** brought inside its limits (then `from` may equal `to`: it was already at the limit) */
  clamped?: boolean;
  /** made by this event's rules */
  event?: string;
}

export type ProblemWhy =
  | "unknown-path"
  | "not-allowed"
  | "wrong-kind"
  | "computed"
  | "full"
  | "missing"
  | "unknown-event"
  | "refused"
  | "bad-rule"
  | "bad-block"
  | "bad-change"
  | "too-much"
  | "code";

export interface Problem {
  why: ProblemWhy;
  path?: string;
  event?: string;
  /** what was asked or what went wrong, for the person and for the AI's next turn */
  detail?: string;
  by?: By;
}

export interface DefinitionProblem {
  entry: "schema" | "start" | "rules";
  path: string;
  why: string;
}

export interface StoryMessage {
  id: string;
  /** the text of the swipe on screen */
  text: string;
  fromAI: boolean;
  /** changes the person made at this message (setState, the values window) */
  edits?: Op[];
  /** the dice rolled before this reply was written (the card's `dice:`) */
  dice?: Obj;
}

export interface Turn {
  id: string;
  changes: Change[];
  problems: Problem[];
  /** the dice this reply had */
  dice?: Obj;
  /** what the card's code asked Fornello to do for this reply (page commands; done once, for a new reply) */
  effects?: Effect[];
}

/** A page command the card's code asks for: `{ cmd: "toast", args: ["Down."] }`. */
export interface Effect {
  cmd: string;
  args: unknown[];
}

/** What the card's code is given for a reply, and what it answers (changes in any form a reply's block takes, and effects). */
export interface CodeInput {
  id: string;
  text: string;
  values: Obj;
  derived: Obj;
  /** this reply's changes so far (the AI's and its events') */
  changes: Change[];
  /** the events the AI named, and whether they ran */
  events: { name: string; args: Obj; ran: boolean }[];
  dice: Obj | null;
}

export interface CodeOutput {
  /** the changes as data (as a block's JSON or YAML would read), or null */
  changes: unknown;
  effects: Effect[];
  /** why the code gave nothing (its error, or it took too long) */
  error?: string;
}

/** Runs the card's code for one reply (in a Worker); null when the card has none or it may not run. */
export type CodeHook = (input: CodeInput) => Promise<CodeOutput | null>;

const isPlain = (v: unknown): v is Obj => !!v && typeof v === "object" && !Array.isArray(v);
const clone = <T>(v: T): T => (v !== null && typeof v === "object" ? structuredClone(v) : v);
const MAX_STEPS = 2000;
const MAX_DEPTH = 8;

/** Reads a card's three entries (YAML or JSON text, or values already read). */
export function loadDefinition(entries: { schema?: unknown; start?: unknown; rules?: unknown; code?: string }): { def: Definition; problems: DefinitionProblem[] } {
  const problems: DefinitionProblem[] = [];
  const read = (entry: DefinitionProblem["entry"], v: unknown) => {
    if (typeof v !== "string") return v ?? null;
    try {
      return readYaml(v);
    } catch (e) {
      problems.push({ entry, path: e instanceof YamlError ? `line ${e.line}` : "", why: e instanceof Error ? e.message : String(e) });
      return null;
    }
  };
  const s = readSchema(read("schema", entries.schema));
  for (const p of s.problems) problems.push({ entry: "schema", ...p });
  const r = readRules(read("rules", entries.rules));
  for (const p of r.problems) problems.push({ entry: "rules", ...p });
  const def: Definition = { schema: s.schema, rules: r.rules, start: {}, sig: quickHash(JSON.stringify([entries.schema, entries.start, entries.rules, entries.code ?? ""])), ...(entries.code?.trim() ? { code: entries.code } : {}) };
  // the starting values: each field's default, then the card's start values checked like any change
  const values = emptyValue(s.schema.root) as Obj;
  const startRaw = read("start", entries.start);
  if (startRaw !== null && !isPlain(startRaw)) problems.push({ entry: "start", path: "", why: "the start values must be a set of names" });
  else if (startRaw) {
    const work = new Work(def, values, () => 0);
    for (const [name, value] of Object.entries(startRaw)) work.apply({ kind: "set", path: name, value }, "start");
    for (const p of work.problems) problems.push({ entry: "start", path: p.path ?? "", why: [p.why, p.detail].filter(Boolean).join(": ") });
  }
  def.start = values;
  return { def, problems };
}

/** Seeded numbers in [0, 1): the same seed gives the same dice. */
function seeded(seed: string): () => number {
  let s = Number(quickHash(seed).split(":")[1]) || 1;
  return () => {
    s = (s + 0x6d2b79f5) | 0;
    let t = Math.imul(s ^ (s >>> 15), 1 | s);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

/** The computed values (`derive`) for some values; a computed value that fails is null. */
export function derived(def: Definition, values: Obj): Obj {
  const scope = makeScope(def, values, {}, () => 0);
  const out: Obj = {};
  for (const name of Object.keys(def.schema.derive)) {
    try {
      out[name] = clone(scope.name(name));
    } catch {
      out[name] = null;
    }
  }
  return out;
}

/** What names mean for expressions over some values (computed values included); no dice. */
export const scopeFor = (def: Definition, values: Obj): Scope => makeScope(def, values, {}, () => 0);

function makeScope(def: Definition, values: Obj, locals: Obj, random: () => number): Scope {
  const done = new Map<string, unknown>();
  const working = new Set<string>();
  const scope: Scope = {
    random,
    name(name) {
      if (Object.hasOwn(locals, name)) return locals[name];
      const expr = def.schema.derive[name];
      if (expr !== undefined && Object.hasOwn(def.schema.derive, name)) {
        if (done.has(name)) return done.get(name);
        if (working.has(name)) throw new ExprError(`"${name}" is computed from itself`);
        working.add(name);
        try {
          const v = evaluate(expr, scope);
          done.set(name, v);
          return v;
        } finally {
          working.delete(name);
        }
      }
      if (Object.hasOwn(values, name)) return values[name];
      throw new ExprError(`there is no value "${name}"`);
    },
  };
  return scope;
}

type Coerced = { ok: true; value: unknown; clamped?: boolean } | { ok: false; why: ProblemWhy; detail: string };

/** One message's work on the values: changes are checked, made and written down. */
class Work {
  changes: Change[] = [];
  problems: Problem[] = [];
  /** the events the AI named (for the card's code) */
  events: { name: string; args: Obj; ran: boolean }[] = [];
  private steps = 0;

  constructor(
    private def: Definition,
    private values: Obj,
    private random: () => number,
    /** names every expression of this message reads (`dice`) */
    private base: Obj = {},
  ) {}

  private scope(locals: Obj = {}) {
    return makeScope(this.def, this.values, { ...this.base, ...locals }, this.random);
  }

  /** A value brought to a field's kind, or why it can't be. `current` is the value now (groups merge into it). */
  private coerce(field: Field, value: unknown, current: unknown): Coerced {
    // [value, "what it means"] pairs, as some cards keep their values
    if (field.kind !== "list" && field.kind !== "any" && Array.isArray(value) && value.length === 2 && typeof value[1] === "string") value = value[0];
    const bad = (detail: string): Coerced => ({ ok: false, why: "wrong-kind", detail });
    switch (field.kind) {
      case "number":
      case "int": {
        let n = typeof value === "number" ? value : typeof value === "string" && value.trim() !== "" ? Number(value.trim().replace(/,/g, "")) : NaN;
        if (!Number.isFinite(n)) return bad(`needs a number, not ${JSON.stringify(value)}`);
        if (field.kind === "int") n = Math.round(n);
        const bound = (b: number | string | undefined) => {
          if (b === undefined) return undefined;
          if (typeof b === "number") return b;
          const v = evaluate(b, this.scope());
          return typeof v === "number" && Number.isFinite(v) ? v : undefined;
        };
        let clamped = false;
        try {
          const lo = bound(field.min);
          const hi = bound(field.max);
          if (lo !== undefined && n < lo) [n, clamped] = [lo, true];
          if (hi !== undefined && n > hi) [n, clamped] = [hi, true];
        } catch (e) {
          this.problems.push({ why: "bad-rule", detail: `a limit: ${e instanceof Error ? e.message : e}` });
        }
        return { ok: true, value: n, clamped };
      }
      case "text":
        if (typeof value === "string") return { ok: true, value };
        if (typeof value === "number" || typeof value === "boolean") return { ok: true, value: String(value) };
        return bad(`needs text, not ${JSON.stringify(value)}`);
      case "bool": {
        if (typeof value === "boolean") return { ok: true, value };
        const word = String(value).trim().toLowerCase();
        if (["true", "yes", "1", "on"].includes(word)) return { ok: true, value: true };
        if (["false", "no", "0", "off"].includes(word)) return { ok: true, value: false };
        return bad(`needs yes or no, not ${JSON.stringify(value)}`);
      }
      case "enum": {
        const word = String(value ?? "").trim().toLowerCase();
        const found = field.values?.find((v) => v.toLowerCase() === word);
        return found !== undefined ? { ok: true, value: found } : bad(`one of ${field.values?.join(", ")}, not ${JSON.stringify(value)}`);
      }
      case "list": {
        if (!Array.isArray(value)) return bad(`needs a list, not ${JSON.stringify(value)}`);
        const items: unknown[] = [];
        for (const item of value) {
          const c = field.item ? this.coerce(field.item, item, undefined) : { ok: true as const, value: clone(item) };
          if (c.ok) items.push(c.value);
          else return c;
        }
        if (field.maxItems !== undefined && items.length > field.maxItems) return { ok: true, value: items.slice(0, field.maxItems), clamped: true };
        return { ok: true, value: items };
      }
      case "map": {
        if (!isPlain(value)) return bad(`needs names and values, not ${JSON.stringify(value)}`);
        const out: Obj = {};
        for (const [k, v] of Object.entries(value)) {
          if (k === "__proto__") continue;
          const c = field.item ? this.coerce(field.item, v, isPlain(current) ? current[k] : undefined) : { ok: true as const, value: clone(v) };
          if (!c.ok) return { ...c, detail: `${k}: ${c.detail}` };
          out[k] = c.value;
        }
        return { ok: true, value: out };
      }
      case "object": {
        if (!isPlain(value)) return bad(`needs names and values, not ${JSON.stringify(value)}`);
        // a group given in part keeps what wasn't given
        const out: Obj = isPlain(current) ? clone(current) : (emptyValue(field) as Obj);
        let clamped = false;
        for (const [k, v] of Object.entries(value)) {
          const f = field.fields?.[k];
          if (!f || !Object.hasOwn(field.fields!, k)) return { ok: false, why: "unknown-path", detail: `there is no "${k}" here` };
          const c = this.coerce(f, v, out[k]);
          if (!c.ok) return { ...c, detail: `${k}: ${c.detail}` };
          out[k] = c.value;
          clamped ||= !!c.clamped;
        }
        return { ok: true, value: out, clamped };
      }
      default:
        return { ok: true, value: clone(value) };
    }
  }

  /** The container that holds the last part of a path, made where a map or group entry is still missing. */
  private parentOf(parts: string[]): Obj | unknown[] | undefined {
    let at: unknown = this.values;
    for (let i = 0; i < parts.length - 1; i++) {
      const part = parts[i];
      if (Array.isArray(at)) {
        const n = Number(part);
        if (!/^\d+$/.test(part) || n >= at.length) return undefined;
        at = at[n];
      } else if (isPlain(at)) {
        if (!Object.hasOwn(at, part) || at[part] === null || typeof at[part] !== "object") {
          const f = fieldAt(this.def.schema.root, parts.slice(0, i + 1))?.field;
          if (!f || (f.kind !== "object" && f.kind !== "map" && f.kind !== "list")) return undefined;
          at[part] = emptyValue(f);
        }
        at = at[part];
      } else return undefined;
    }
    return Array.isArray(at) || isPlain(at) ? at : undefined;
  }

  /** Makes one change, after checking it; problems and changes are written down. */
  apply(op: Op, by: By, event?: string): void {
    if (++this.steps > MAX_STEPS) {
      if (this.steps === MAX_STEPS + 1) this.problems.push({ why: "too-much", detail: `more than ${MAX_STEPS} changes in one message`, by });
      return;
    }
    if (op.kind === "do") {
      const before = this.problems.length;
      this.event(op.event ?? "", op.args ?? {}, by, 0);
      if (by === "ai") this.events.push({ name: op.event ?? "", args: clone(op.args ?? {}), ran: !this.problems.slice(before).some((p) => p.event === op.event && (p.why === "unknown-event" || p.why === "refused" || p.why === "too-much")) });
      return;
    }
    const pathText = op.path ?? "";
    const parts = pathParts(pathText);
    const path = parts.join(".");
    const problem = (why: ProblemWhy, detail?: string): void => void this.problems.push({ why, path, by, ...(event ? { event } : {}), ...(detail ? { detail } : {}) });
    if (!parts.length) return problem("unknown-path", "a change needs a path");
    if (Object.hasOwn(this.def.schema.derive, parts[0])) return problem("computed", "computed from other values; change those");
    const last = parts[parts.length - 1];
    // "bag/-" (JSON Patch's end of a list) is a push onto bag
    if (last === "-") {
      if (op.kind === "remove") return problem("missing", `"${path}" is no item`);
      this.steps--;
      return this.apply({ ...op, kind: "push", path: parts.slice(0, -1).join(".") }, by, event);
    }
    const found = fieldAt(this.def.schema.root, parts);
    if (!found) return problem("unknown-path", `there is no "${path}"`);
    if (by !== "start" && !found.write.includes(by)) return problem("not-allowed", `${by === "ai" ? "the AI" : by} may not change "${path}"`);
    const { field } = found;
    const parent = this.parentOf(parts);
    if (!parent) return problem("missing", `"${parts.slice(0, -1).join(".")}" is not there`);
    const has = Array.isArray(parent) ? /^\d+$/.test(last) && Number(last) < parent.length : Object.hasOwn(parent, last);
    const current = has ? (parent as Obj)[last] : undefined;

    let kind = op.kind;
    if (kind === "add") kind = field.kind === "number" || field.kind === "int" ? "delta" : field.kind === "list" ? "push" : "set";
    if (kind === "sub") {
      if (field.kind === "number" || field.kind === "int") kind = "delta";
      else if (field.kind === "list") kind = "pull";
      else return problem("wrong-kind", `"-=" needs a number or a list`);
      if (kind === "delta") op = { ...op, value: -toNumber(op.value) };
    }
    if (kind === "insert-missing") {
      if (!has || current === null) kind = "set";
      else if (field.kind === "list" && Array.isArray(op.value)) {
        for (const item of op.value) if (!(current as unknown[]).some((x) => same(x, item))) this.apply({ kind: "push", path, value: item }, by, event);
        return;
      } else return;
    }

    const write = (value: unknown, clamped?: boolean): void => {
      // unchanged is left out, unless a limit stopped it (the AI is told it hit the limit)
      if (same(current, value) && has && !clamped) return;
      if (Array.isArray(parent)) {
        if (/^\d+$/.test(last) && Number(last) <= parent.length) parent[Number(last)] = value;
        else return problem("missing", `the list has no item ${last}`);
      } else parent[last] = value;
      this.changes.push({ path, from: clone(current), to: clone(value), by, ...(clamped ? { clamped } : {}), ...(event ? { event } : {}) });
    };

    switch (kind) {
      case "set": {
        // null takes a map's entry or a list's item away, and puts a field back to its start
        if (op.value === null && field.kind !== "any") return this.remove(parent, last, has, current, field, path, by, event);
        const c = this.coerce(field, op.value, current);
        if (!c.ok) return problem(c.why, c.detail);
        return write(c.value, c.clamped);
      }
      case "delta": {
        if (field.kind !== "number" && field.kind !== "int") return problem("wrong-kind", `"${path}" is not a number`);
        const by_ = Number(typeof op.value === "string" ? op.value.replace(/,/g, "") : op.value);
        if (!Number.isFinite(by_)) return problem("wrong-kind", `needs a number, not ${JSON.stringify(op.value)}`);
        const base = typeof current === "number" ? current : toNumber(emptyValue(field));
        const c = this.coerce(field, base + by_, current);
        if (!c.ok) return problem(c.why, c.detail);
        return write(c.value, c.clamped);
      }
      case "push": {
        if (field.kind !== "list") return problem("wrong-kind", `"${path}" is not a list`);
        const list = Array.isArray(current) ? current : [];
        if (field.maxItems !== undefined && list.length >= field.maxItems) return problem("full", `"${path}" holds ${field.maxItems} at most`);
        const c = field.item ? this.coerce(field.item, op.value, undefined) : { ok: true as const, value: clone(op.value) };
        if (!c.ok) return problem(c.why, c.detail);
        const at = op.index === undefined || op.index < 0 || op.index > list.length ? list.length : op.index;
        const next = [...list.slice(0, at), c.value, ...list.slice(at)];
        return write(next);
      }
      case "pull": {
        if (field.kind !== "list") return problem("wrong-kind", `"${path}" is not a list`);
        const list = Array.isArray(current) ? current : [];
        const i = list.findIndex((x) => same(x, op.value));
        if (i < 0) return problem("missing", `${JSON.stringify(op.value)} is not in "${path}"`);
        return write([...list.slice(0, i), ...list.slice(i + 1)]);
      }
      case "remove": {
        if (op.value === undefined) return this.remove(parent, last, has, current, field, path, by, event);
        // remove with a value: that item from a list (or the item at that place), that entry from a map or group
        if (field.kind === "list") {
          const list = Array.isArray(current) ? current : [];
          if (list.some((x) => same(x, op.value))) return this.apply({ kind: "pull", path, value: op.value }, by, event);
          if (typeof op.value === "number") return this.apply({ kind: "remove", path: `${path}.${op.value}` }, by, event);
          return problem("missing", `${JSON.stringify(op.value)} is not in "${path}"`);
        }
        return this.apply({ kind: "remove", path: `${path}.${op.value}` }, by, event);
      }
    }
  }

  private remove(parent: Obj | unknown[], last: string, has: boolean, current: unknown, field: Field, path: string, by: By, event?: string): void {
    if (!has) return;
    const holder = fieldAt(this.def.schema.root, pathParts(path).slice(0, -1))?.field;
    let to: unknown;
    if (Array.isArray(parent)) parent.splice(Number(last), 1);
    else if (holder?.kind === "map" || holder?.kind === "any") delete parent[last];
    else {
      // a field the schema names stays, back at its start
      to = emptyValue(field);
      if (same(current, to)) return;
      parent[last] = to;
    }
    this.changes.push({ path, from: clone(current), to: clone(to ?? null), by, ...(event ? { event } : {}) });
  }

  /** Runs an event the AI (or another event) named. */
  event(name: string, args: Obj, by: By, depth: number) {
    const rule = Object.hasOwn(this.def.rules.events, name) ? this.def.rules.events[name] : undefined;
    if (!rule) {
      this.problems.push({ why: "unknown-event", event: name, by, detail: `there is no event "${name}"` });
      return;
    }
    if (depth >= MAX_DEPTH) {
      this.problems.push({ why: "too-much", event: name, by, detail: `events call each other more than ${MAX_DEPTH} deep` });
      return;
    }
    const locals: Obj = { ...clone(rule.params) };
    for (const [k, v] of Object.entries(args)) if (k !== "__proto__") locals[k] = clone(v);
    if (rule.when) {
      let ok: unknown;
      try {
        ok = evaluate(rule.when, this.scope(locals));
      } catch (e) {
        this.problems.push({ why: "bad-rule", event: name, by, detail: `when: ${e instanceof Error ? e.message : e}` });
        return;
      }
      if (!ok) {
        this.problems.push({ why: "refused", event: name, by, detail: `not now (${rule.when})` });
        return;
      }
    }
    this.steps_(rule.steps, locals, name, depth);
  }

  /** A rule's steps, run with the rules' right to write. */
  steps_(steps: Step[], locals: Obj, event: string | undefined, depth: number) {
    for (const step of steps) {
      try {
        if (step.kind === "if") {
          this.steps_(evaluate(step.test, this.scope(locals)) ? step.then : step.else, locals, event, depth);
        } else if (step.kind === "do") {
          const given: Obj = {};
          for (const [k, v] of Object.entries(step.with)) given[k] = this.valueOf(v, locals);
          this.event(step.event, given, "rules", depth + 1);
        } else {
          const path = step.path.replace(/\{([^}]*)\}/g, (_, expr: string) => {
            const v = evaluate(expr, this.scope(locals));
            return /[.[\]]/.test(String(v)) ? `["${String(v).replace(/"/g, "")}"]` : String(v);
          });
          const value = step.kind === "remove" ? undefined : this.valueOf(step.value, locals);
          this.apply({ kind: step.kind, path, ...(value !== undefined ? { value } : {}) } as Op, "rules", event);
        }
      } catch (e) {
        if (!(e instanceof ExprError)) throw e;
        this.problems.push({ why: "bad-rule", by: "rules", ...(event ? { event } : {}), detail: e.message });
      }
    }
  }

  private valueOf(v: unknown, locals: Obj): unknown {
    return typeof v === "string" ? clone(evaluate(v, this.scope(locals))) : clone(v);
  }
}

const toNumber = (v: unknown) => {
  const n = Number(v);
  return Number.isFinite(n) ? n : 0;
};

/** One message's effect on the values (which it changes in place). */
/**
 * The card's dice, rolled: `dice: { check: 1d20, loot: "roll('1d6') + luck" }` → { check: 14, loot: 5 }.
 * A die that can't be rolled is null (expressions read the values given).
 */
export function rollAll(def: Definition, values: Obj, random: () => number): Obj {
  const out: Obj = {};
  const scope = makeScope(def, values, {}, random);
  for (const [name, spec] of Object.entries(def.rules.dice)) {
    try {
      out[name] = DICE.test(spec) ? rollDice(spec, random) : clone(evaluate(spec, scope));
    } catch {
      out[name] = null;
    }
  }
  return out;
}

export async function runMessage(def: Definition, values: Obj, message: StoryMessage, code?: CodeHook): Promise<Turn> {
  const random = seeded(`${def.sig}:${message.id}`);
  // the dice rolled before this reply (kept on the message), or rolled now from its id for a reply without them
  let dice: Obj | undefined;
  if (message.fromAI && Object.keys(def.rules.dice).length) dice = message.dice ?? rollAll(def, values, seeded(`${def.sig}:${message.id}:dice`));
  const work = new Work(def, values, random, dice ? { dice } : {});
  if (message.fromAI) {
    const read = readUpdates(message.text);
    for (const p of read.problems) work.problems.push({ why: p.why, by: "ai", detail: p.detail });
    for (const op of read.ops) work.apply(op, "ai");
    // the card's code, after the AI's changes: its changes are the rules' (checked the same way), its effects kept on the turn
    let effects: Effect[] = [];
    if (code) {
      const out = await code({ id: message.id, text: message.text, values: clone(values), derived: derived(def, values), changes: clone(work.changes), events: work.events, dice: dice ?? null });
      if (out?.error) work.problems.push({ why: "code", by: "rules", detail: out.error });
      if (out) {
        const read = readChanges(out.changes);
        for (const p of read.problems) work.problems.push({ why: "code", by: "rules", detail: p.detail });
        for (const op of read.ops) work.apply(op, "rules");
        effects = out.effects;
      }
    }
    work.steps_(def.rules.eachReply, {}, undefined, 0);
    for (const op of message.edits ?? []) work.apply(op, "user");
    return { id: message.id, changes: work.changes, problems: work.problems, ...(dice ? { dice } : {}), ...(effects.length ? { effects } : {}) };
  }
  for (const op of message.edits ?? []) work.apply(op, "user");
  return { id: message.id, changes: work.changes, problems: work.problems };
}

const messageSig = (m: StoryMessage) =>
  quickHash(`${m.id}\u0000${m.fromAI ? 1 : 0}\u0000${m.text}\u0000${m.edits ? JSON.stringify(m.edits) : ""}\u0000${m.dice ? JSON.stringify(m.dice) : ""}`);

/**
 * The values over a whole chat, kept between calls: `update` with the messages as they are now
 * recomputes from the first message that is new or different, starting at the last checkpoint
 * before it (one every `every` messages), so a new reply or a swipe costs one message's work.
 */
export class StoryEngine {
  private messages: StoryMessage[] = [];
  private chain: string[] = [];
  private turns: Turn[] = [];
  /** values after message i, every `every` messages and after the last */
  private checkpoints = new Map<number, Obj>();
  private last: Obj;

  constructor(
    readonly def: Definition,
    private every = 25,
    /** the card's code, when it may run */
    private code?: CodeHook,
  ) {
    this.last = clone(def.start);
  }

  /** Brings the values up to date with the chat's messages; returns how many messages were worked out. */
  /** One update or read at a time: the card's code is awaited between messages. */
  private turnTaking: Promise<unknown> = Promise.resolve();

  private inTurn<T>(fn: () => Promise<T>): Promise<T> {
    const next = this.turnTaking.then(fn, fn);
    this.turnTaking = next.catch(() => undefined);
    return next;
  }

  update(messages: StoryMessage[]): Promise<number> {
    return this.inTurn(() => this.recompute(messages));
  }

  private async recompute(messages: StoryMessage[]): Promise<number> {
    const chain: string[] = [];
    let prev = this.def.sig;
    for (const m of messages) chain.push((prev = quickHash(`${prev}|${messageSig(m)}`)));
    let first = 0;
    while (first < chain.length && first < this.chain.length && chain[first] === this.chain[first]) first++;
    if (first === chain.length && first === this.chain.length) return 0;
    // forget what came after the change
    for (const i of [...this.checkpoints.keys()]) if (i >= first) this.checkpoints.delete(i);
    this.turns.length = first;
    let from = -1;
    for (const i of this.checkpoints.keys()) if (i > from) from = i;
    const values = clone(from >= 0 ? this.checkpoints.get(from)! : this.def.start);
    for (let i = from + 1; i < messages.length; i++) {
      const turn = await runMessage(this.def, values, messages[i], this.code);
      if (i >= first) this.turns[i] = turn;
      if ((i + 1) % this.every === 0 || i === messages.length - 1) this.checkpoints.set(i, clone(values));
    }
    this.messages = messages;
    this.chain = chain;
    this.last = values;
    return messages.length - (from + 1);
  }

  /** The values after the last message. */
  get values(): Obj {
    return clone(this.last);
  }

  /** The values after message `index` (-1: before the first). */
  valuesAt(index: number): Promise<Obj> {
    return this.inTurn(() => this.replayTo(index));
  }

  private async replayTo(index: number): Promise<Obj> {
    if (index >= this.messages.length - 1) return this.values;
    if (index < 0) return clone(this.def.start);
    let from = -1;
    for (const i of this.checkpoints.keys()) if (i <= index && i > from) from = i;
    const values = clone(from >= 0 ? this.checkpoints.get(from)! : this.def.start);
    for (let i = from + 1; i <= index; i++) await runMessage(this.def, values, this.messages[i], this.code);
    return values;
  }

  /**
   * The number values after each of the last `last` messages, by path (computed ones too), for a
   * graph: one pass from the checkpoint before them (the card's code answers from what it kept).
   */
  numbersOverTime(last = 200): Promise<{ from: number; series: Record<string, (number | null)[]> }> {
    return this.inTurn(async () => {
      const count = this.messages.length;
      const from = Math.max(0, count - last);
      let at = -1;
      for (const i of this.checkpoints.keys()) if (i < from && i > at) at = i;
      const values = clone(at >= 0 ? this.checkpoints.get(at)! : this.def.start);
      const series: Record<string, (number | null)[]> = {};
      const record = (step: number) => {
        const walk = (v: unknown, path: string) => {
          if (typeof v === "number" && Number.isFinite(v) && path) {
            (series[path] ??= Array(count - from).fill(null))[step] = v;
          } else if (isPlain(v)) for (const [k, x] of Object.entries(v)) walk(x, path ? `${path}.${k}` : k);
        };
        walk(values, "");
        walk(derived(this.def, values), "");
      };
      for (let i = at + 1; i < count; i++) {
        await runMessage(this.def, values, this.messages[i], this.code);
        if (i >= from) record(i - from);
      }
      return { from, series };
    });
  }

  /** What message `index` changed and which of its changes were refused. */
  turn(index: number): Turn | undefined {
    return this.turns[index];
  }

  /** The values with the computed ones beside them. */
  view(values: Obj = this.last): { values: Obj; derived: Obj } {
    return { values: clone(values), derived: derived(this.def, values) };
  }
}
