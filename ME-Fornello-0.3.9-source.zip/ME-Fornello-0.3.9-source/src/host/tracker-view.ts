// Marinara's tracker on screen reads a store in the page, filled when Marinara reads the tracker
// (opening a chat, the end of a reply). After Fornello writes the tracker at another time (a value
// set in the Pesto window), the store is given the new state through the host Marinara
// publishes for its packages (globalThis.__MARINARA_HOST__, version 1), when there is one; without
// it the screen catches up the next time Marinara reads the tracker.

interface StoreLike<S> {
  getState(): S;
}

interface HostLike {
  version?: number;
  stores?: {
    chat?: StoreLike<{ activeChatId?: string | null }>;
    gameState?: StoreLike<{ setGameState?: (state: unknown) => void }>;
  };
}

/** Whether there is a host to tell the screen through (without one, a read of the tracker for it is wasted). */
export function canShowTracker(): boolean {
  return (globalThis as { __MARINARA_HOST__?: HostLike }).__MARINARA_HOST__?.version === 1;
}

/** Shows this tracker state on screen, if its chat is the open one. */
export function showTracker(chatId: string, state: unknown): boolean {
  const host = (globalThis as { __MARINARA_HOST__?: HostLike }).__MARINARA_HOST__;
  if (host?.version !== 1) return false;
  try {
    if (host.stores?.chat?.getState().activeChatId !== chatId) return false;
    const set = host.stores?.gameState?.getState().setGameState;
    if (typeof set !== "function") return false;
    set(state);
    return true;
  } catch (e) {
    console.warn("[Fornello] tracker on screen", e);
    return false;
  }
}
