// The commands of one running page (or component): every module's table put
// together, each call guarded (command.ts), plus the page's storages.

import { type CommandTable, guarded } from "./command";
import { chatCommands } from "./commands/chat";
import { generateCommands } from "./commands/generate";
import { loreCommands } from "./commands/lore";
import { peopleCommands } from "./commands/people";
import { regexCommands } from "./commands/regex";
import { agentCommands } from "./commands/agents";
import { mediaCommands } from "./commands/media";
import { summaryCommands } from "./commands/summary";
import { scriptLibraryCommands } from "./commands/script-library";
import { listenCommands, messageCommands } from "./commands/messages";
import { trackerCommands } from "./commands/tracker";
import { variableCommands } from "./commands/variables";
import { type PageContext, openSession } from "./session";
import { slashCommands } from "./slash";
import { stCommands } from "./st-compat";
import { scriptCommands } from "./commands/script";
import { eventCommands } from "./commands/events";
import { toolCommands } from "./commands/tools";
import { replyCommands } from "./commands/replies";
import { msgDataCommands } from "./commands/msg-data";
import { loadExtraVars } from "./extra-vars";

export type { PageContext, PageUi } from "./session";
export { plainTracker } from "./commands/tracker";

export interface PageApi {
  globals: Record<string, unknown>;
  /** The runtime hands over how to add a name its scripts see (for waitGlobalInitialized). */
  bindScope(define: (name: string, value: unknown) => void): void;
  dispose(): void;
}

export async function pageApi(ctx: PageContext): Promise<PageApi> {
  const [s] = await Promise.all([openSession(ctx), loadExtraVars()]);
  const guard = (name: string, command: Parameters<typeof guarded>[1]) => guarded(name, command, s);
  const table: CommandTable = {
    ...messageCommands(s),
    ...generateCommands(s),
    ...variableCommands(s),
    ...chatCommands(s),
    ...trackerCommands(s),
    ...loreCommands(s),
    ...peopleCommands(s),
    ...regexCommands(s),
    ...agentCommands(s),
    ...mediaCommands(s),
    ...summaryCommands(s),
    ...scriptLibraryCommands(s),
    ...slashCommands(s),
    ...listenCommands(s),
    ...eventCommands(s),
    ...toolCommands(s),
    ...replyCommands(s),
    ...msgDataCommands(s),
    ...stCommands(s, guard),
    ...scriptCommands(s),
  };
  const globals: Record<string, unknown> = {};
  for (const [name, entry] of Object.entries(table)) globals[name] = "run" in entry ? guard(name, entry) : entry.value;
  globals.localStorage = s.storages.local;
  globals.sessionStorage = s.storages.session;
  return {
    globals,
    bindScope: (define) => {
      s.define = define;
    },
    dispose: () => s.dispose(),
  };
}
