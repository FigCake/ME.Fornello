// Finding an asset by the name a reply wrote. Models seldom copy a name
// exactly, so names are compared loosely: case, width, a picture extension
// and the marks between words (space _ - .) don't count, and when nothing
// matches so, the nearest name within a few letters is taken.

import type { Asset } from "./model";

const PICTURE_EXT = /\.(png|jpe?g|gif|webp|avif|svg|mp4|webm)$/i;

/** A name as compared: no picture extension, no case, no marks between words. */
export function nameKey(name: string): string {
  return name.normalize("NFKC").trim().replace(PICTURE_EXT, "").toLowerCase().replace(/[\s_\-.]+/g, "");
}

/** Letters to add, drop or change to turn `a` into `b`. */
export function distance(a: string, b: string): number {
  if (a === b) return 0;
  const x = [...a];
  const y = [...b];
  let row = Array.from({ length: y.length + 1 }, (_, i) => i);
  for (let i = 1; i <= x.length; i++) {
    const next = [i];
    for (let j = 1; j <= y.length; j++) next[j] = Math.min(row[j] + 1, next[j - 1] + 1, row[j - 1] + (x[i - 1] === y[j - 1] ? 0 : 1));
    row = next;
  }
  return row[y.length];
}

/** How far a written name may be from an asset's and still mean it: one letter in four, at most three. */
const nearEnough = (key: string) => Math.min(3, Math.floor([...key].length / 4));

/** Whether a written name means this person (the whole name or its first word). */
export function samePerson(written: string, person: string): boolean {
  const w = nameKey(written);
  if (!w) return false;
  const words = person.normalize("NFKC").trim().split(/[\s_]+/);
  return w === nameKey(person) || w === nameKey(words[0] ?? "");
}

export interface Wanted {
  name: string;
  /** Whose asset (a card with several people); none: the speaker's own. */
  person?: string;
}

/** The extension a name ends with, the two ways of writing JPEG as one. */
const extOf = (name: string) => PICTURE_EXT.exec(name.trim())?.[0].toLowerCase().replace(".jpeg", ".jpg") ?? "";

/**
 * As findLoose; a written name with an extension keeps to the pictures of that type when there are
 * any, so two pictures of one name in two types can be told apart.
 */
export function findAssets(assets: Asset[], wanted: Wanted): Asset[] {
  const found = findLoose(assets, wanted);
  const ext = extOf(wanted.name);
  if (!ext || found.length < 2) return found;
  const same = found.filter((a) => extOf(a.name) === ext || (!extOf(a.name) && extOf(a.file) === ext));
  return same.length ? same : found;
}

/**
 * The assets a written name means, best match first: the exact name (the person may be part of it),
 * then the name among the person's assets, then a name that ends with it, then the nearest name.
 * Several assets sharing a name all come back; pickOne chooses between them.
 */
function findLoose(assets: Asset[], wanted: Wanted): Asset[] {
  const name = nameKey(wanted.name);
  if (!name) return [];
  const person = wanted.person ? nameKey(wanted.person) : "";
  const full = person + name;
  // an asset is the person's when its person is them, named in full or by first name (as tags may name them)
  const keyed = assets.map((a) => ({ a, key: nameKey(a.name), owner: a.person && wanted.person && samePerson(wanted.person, a.person) ? person : a.person ? nameKey(a.person) : "" }));
  const exact = keyed.filter((k) => k.key === full || (!person && k.key === name));
  if (exact.length) return exact.map((k) => k.a);
  if (person) {
    const theirs = keyed.filter((k) => k.owner === person && k.key === name);
    if (theirs.length) return theirs.map((k) => k.a);
  } else {
    // a name that ends with what was written, whatever comes before it: someone's, when the reply didn't say whose
    const someone = keyed.filter((k) => k.key.length > name.length && k.key.endsWith(name));
    if (someone.length) return someone.map((k) => k.a);
  }
  // nearest: the whole written name, or the name after the person
  let best = Infinity;
  let found: Asset[] = [];
  for (const k of keyed) {
    const target = person && k.owner === person ? name : full;
    const d = distance(k.key, target);
    if (d > nearEnough(target)) continue;
    if (d < best) [best, found] = [d, [k.a]];
    else if (d === best) found.push(k.a);
  }
  return found;
}

/** One of several assets, always the same one for the same `seed` (a message), so a picture doesn't change when the chat redraws. */
export function pickOne<T>(list: T[], seed: string): T | undefined {
  if (list.length < 2) return list[0];
  let h = 2166136261;
  for (let i = 0; i < seed.length; i++) h = Math.imul(h ^ seed.charCodeAt(i), 16777619);
  return list[(h >>> 0) % list.length];
}
