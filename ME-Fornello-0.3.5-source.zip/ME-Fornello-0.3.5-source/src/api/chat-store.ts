// Shared reads of Marinara's chats: chat pages, components, onMsg and page
// commands read the same chat at the same moments, so a read is reused while
// fresh and forgotten when what it read may have changed:
//
//   forgetChat(id)   a write to the chat; with no id, every chat (a reply finished)
//   forgetDetail(id) the chat's metadata changed
//   forgetLore()     a lorebook changed
//   forgetPeople()   a card or persona may have been edited (and the card's lorebook entries)

import { api } from "../shared/api";
import { onGenerationComplete } from "../host/events";
import { parseList, parseObject } from "./parse";
import type { CharacterInfo, ChatDetail, LoreNote, Message, MessageRole, PersonaInfo, RawLoreEntry } from "./types";

const enc = encodeURIComponent;

/** How long each read is reused (ms). */
const KEEP = {
  detail: 2000,
  messages: 700,
  /** "Fresh" still shares a read started this recently (the same change seen by several readers). */
  sameMoment: 150,
  alwaysLore: 10_000,
  people: 30_000,
  /** What a page reads before it starts: pages opening together share it. */
  pageSnapshot: 3000,
};

interface Remembered<T> {
  at: number;
  value: Promise<T>;
}

const details = new Map<string, Remembered<ChatDetail>>();
const messageLists = new Map<string, Remembered<Message[]>>();
const alwaysLore = new Map<string, Remembered<LoreNote[]>>();
const personas = new Map<string, Remembered<PersonaInfo>>();
const characters = new Map<string, Remembered<CharacterInfo>>();
const snapshots = new Map<string, Remembered<unknown>>();
const cardLore = new Map<string, Remembered<RawLoreEntry[]>>();

function remembered<T>(map: Map<string, Remembered<T>>, key: string, keep: number, load: () => Promise<T>): Promise<T> {
  const hit = map.get(key);
  if (hit && Date.now() - hit.at < keep) return hit.value;
  const value = load();
  map.set(key, { at: Date.now(), value });
  // a failed read is not kept
  value.catch(() => {
    if (map.get(key)?.value === value) map.delete(key);
  });
  return value;
}

/** Reads of the chat are stale (a write, a finished reply): the next one asks Marinara again. */
export function forgetChat(chatId?: string | null): void {
  for (const map of [details, messageLists, alwaysLore, snapshots] as Map<string, unknown>[]) {
    if (chatId) map.delete(chatId);
    else map.clear();
  }
}

/** The chat's metadata was just written: its details, and what pages read before they start (variables, chat_metadata). */
export function forgetDetail(chatId: string): void {
  details.delete(chatId);
  snapshots.delete(chatId);
}

/** A lorebook changed: what genChat sends as always-on entries, and the books pages see, are read again. */
export function forgetLore(): void {
  alwaysLore.clear();
  cardLore.clear();
  snapshots.clear();
}

/** A card or persona may have been edited. */
export function forgetPeople(): void {
  characters.clear();
  cardLore.clear();
  personas.clear();
}

/** Forgets every read after a reply; the returned stop forgets everything. */
export function startChatStore(): () => void {
  const stopListening = onGenerationComplete(() => {
    forgetChat();
    forgetPeople();
  });
  return () => {
    stopListening();
    forgetChat();
    forgetPeople();
    readListeners.clear();
  };
}

export function chatDetail(chatId: string): Promise<ChatDetail> {
  return remembered(details, chatId, KEEP.detail, () => api<ChatDetail>(`/chats/${enc(chatId)}`));
}

// ── persona and characters ──

function character(id: string): Promise<CharacterInfo> {
  return remembered(characters, id, KEEP.people, async () => {
    const raw = await api<{ id: string; data?: unknown; name?: string }>(`/characters/${enc(id)}`);
    const data = parseObject(raw.data);
    return {
      id,
      name: String(data.name ?? raw.name ?? "Character"),
      description: String(data.description ?? ""),
      personality: String(data.personality ?? ""),
      scenario: String(data.scenario ?? ""),
      firstMessage: String(data.first_mes ?? ""),
      data,
    };
  });
}

export async function chatCharacters(chatId: string): Promise<CharacterInfo[]> {
  const ids = parseList((await chatDetail(chatId)).characterIds);
  return Promise.all(ids.map((id) => character(id).catch(() => ({ id, name: "Character", description: "", personality: "", scenario: "", firstMessage: "", data: {} }))));
}

export async function persona(chatId: string): Promise<PersonaInfo> {
  const detail = await chatDetail(chatId);
  const id = detail.personaId;
  if (!id) return { id: null, name: "User", description: "" };
  return remembered(personas, id, KEEP.people, async () => {
    const p = await api<{ name?: string; description?: string }>(`/characters/personas/${enc(id)}`).catch(() => null);
    return { id, name: p?.name || "User", description: String(p?.description ?? "") };
  });
}

// ── messages ──

/** The key in a message's `extra` (one per swipe in Marinara) that holds what pages keep there (setMsgData). */
export const MESSAGE_DATA = "fornelloData";

interface RawMessage {
  id: string;
  role: string;
  content: string;
  characterId?: string | null;
  extra?: unknown;
  hidden?: boolean;
  activeSwipeIndex?: number;
  swipeCount?: number;
  createdAt?: string;
}

/** A message Marinara saved (one still streaming or just sent has a made-up id: __streaming__, __optimistic_…). */
export const isSaved = (id: string | undefined): id is string => !!id && !id.startsWith("__");

/** The chat's messages (copies). `fresh`: the screen just changed, so an older read will not do. */
export async function listMessages(chatId: string, { fresh = false } = {}): Promise<Message[]> {
  const list = await remembered(messageLists, chatId, fresh ? KEEP.sameMoment : KEEP.messages, () => readMessages(chatId));
  return list.map((m) => ({ ...m }));
}

const readListeners = new Set<(chatId: string, list: Message[]) => void>();

/** Hears every message list Fornello reads (onMsg looks at them instead of reading its own). */
export function onMessagesRead(fn: (chatId: string, list: Message[]) => void): () => void {
  readListeners.add(fn);
  return () => readListeners.delete(fn);
}

async function readMessages(chatId: string): Promise<Message[]> {
  const list = await readMessageList(chatId);
  for (const fn of [...readListeners]) {
    try {
      fn(chatId, list.map((m) => ({ ...m })));
    } catch (e) {
      console.warn("[Fornello]", e);
    }
  }
  return list;
}

async function readMessageList(chatId: string): Promise<Message[]> {
  const [raw, cast, me] = await Promise.all([
    api<RawMessage[]>(`/chats/${enc(chatId)}/messages`),
    chatCharacters(chatId).catch(() => [] as CharacterInfo[]),
    persona(chatId).catch(() => ({ id: null, name: "User", description: "" })),
  ]);
  const names = new Map(cast.map((c) => [c.id, c.name]));
  return raw.map((m, i) => {
    const extra = parseObject(m.extra);
    const role: MessageRole = m.role === "assistant" ? "char" : m.role === "user" ? "user" : m.role === "narrator" ? "narrator" : "system";
    const name =
      role === "char"
        ? (m.characterId && names.get(m.characterId)) || cast[0]?.name || "Character"
        : role === "user"
          ? String(parseObject(extra.personaSnapshot).name || me.name)
          : role === "narrator"
            ? "Narrator"
            : "System";
    return { id: m.id, num: i + 1, role, name, text: m.content ?? "", hidden: m.hidden === true || extra.hidden === true || extra.hiddenFromAI === true, characterId: m.characterId ?? null, swipe: Number(m.activeSwipeIndex ?? 0), swipes: Number(m.swipeCount ?? 1), data: parseObject(extra[MESSAGE_DATA]), at: m.createdAt };
  });
}

// ── lorebooks ──

/** The chat's always-on lorebook entries, as Marinara picks them for this chat. */
export function alwaysOnLore(chatId: string): Promise<LoreNote[]> {
  return remembered(alwaysLore, chatId, KEEP.alwaysLore, async () => {
    const res = await api<{ entries?: { name?: string; content?: string; constant?: unknown }[] }>(`/lorebooks/scan/${enc(chatId)}`);
    return (res?.entries ?? [])
      .filter((e) => e.constant === true && String(e.content ?? "").trim())
      .map((e) => ({ name: String(e.name ?? ""), content: String(e.content).trim() }));
  });
}

/** The entries of a character's own lorebooks (the books Marinara made of its card). */
export function characterLore(characterId: string): Promise<RawLoreEntry[]> {
  return remembered(cardLore, characterId, KEEP.people, async () => {
    const res = await api<unknown>("/lorebooks");
    const books = (Array.isArray(res) ? res : ((res as { items?: unknown[] }).items ?? [])) as { id: string; characterIds?: unknown }[];
    const own = books.filter((b) => parseList(b.characterIds).includes(characterId));
    return (await Promise.all(own.map((b) => api<RawLoreEntry[]>(`/lorebooks/${enc(b.id)}/entries`).catch(() => [] as RawLoreEntry[])))).flat();
  });
}

// ── what a page reads before it starts ──

/** Shared by the pages of a chat opening together (components under many messages); forgotten with the chat's other reads. */
export function pageSnapshot<T>(chatId: string | null, load: () => Promise<T>): Promise<T> {
  return remembered(snapshots, chatId ?? "", KEEP.pageSnapshot, load) as Promise<T>;
}
