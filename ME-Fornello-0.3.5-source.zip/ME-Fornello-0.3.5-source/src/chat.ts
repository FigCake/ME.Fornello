// HTML pages in chat messages:
// - ```html blocks in the reply: the code block on screen is swapped for the
//   page (its source is read from the saved message);
// - pages a card's display regex makes of the reply: they go under the reply,
//   whose text hides when nothing else is left of it.

import { chatCharacters, isSaved, listMessages, persona } from "./api/chat-store";
import type { Message } from "./api/types";
import { currentChatId } from "./host/current-chat";
import { MessageScanner } from "./message-scanner";
import { clearQuietEdit, isQuietEdit } from "./api/quiet-edits";
import { applyDisplayRegex, regexScripts } from "./regex";
import { quickHash } from "./hash";
import { type Fence, codeFences, fenceRulesFor } from "./runtime/fences";
import type { Settings } from "./settings";
import { blankText, findLoose } from "./ui/blank-text";
import { PageBlock } from "./ui/block";
import { standApart } from "./ui/stand-apart";

const isHtmlBlock = (pre: HTMLPreElement) => /^html?$/i.test(pre.querySelector(".mari-md-codeblock-lang")?.textContent?.trim() ?? "");
const OURS = ".fornello-pages, .fornello-components, .fornello-block";

interface Shown {
  key: string;
  block: PageBlock;
  /** The code block it stands in for (```html in the reply). */
  pre?: HTMLPreElement;
  /** Or the opening ``` Marinara left as text (a fence never closed): the page sits after it. */
  marker?: Text;
}

/** Takes an element of Marinara's off the screen, marked so unhideWithin puts it back. */
function hide(el: HTMLElement): void {
  if (el.style.display === "none") return;
  el.style.display = "none";
  el.dataset.fornelloHidden = "1";
}

/** Puts back what hide() took off the screen inside `root`. */
function unhideWithin(root: ParentNode): void {
  for (const el of root.querySelectorAll<HTMLElement>("[data-fornello-hidden]")) {
    el.style.removeProperty("display");
    delete el.dataset.fornelloHidden;
  }
}

export interface ChatPagesHooks {
  /** Opens Fornello's settings (the ⚙ on each page). */
  openSettings(): void;
}

export class ChatPages extends MessageScanner {
  /** By message id and page index. */
  private readonly shown = new Map<string, Shown>();
  private readonly containers = new Map<string, HTMLElement>();
  private recent = new Set<string>();
  private cast: string[] = [];
  private names = { user: "User", char: "" };
  private readonly regexed = new Map<string, { sig: string; text: string; sources: string[] }>();
  private readonly textSig = new Map<string, string>();
  /** A reply finished: the message list is read again before the next look. */
  private reload = false;

  constructor(
    settings: Settings,
    private readonly hooks: ChatPagesHooks,
  ) {
    super(settings);
  }

  /** The number of pages that run by themselves changed: running pages keep running. */
  rerank(): void {
    this.rankRecent();
    for (const key of this.recent) this.shown.get(key)?.block.wake();
  }

  protected clear(): void {
    for (const id of [...this.shown.keys()]) this.drop(id);
    for (const c of this.containers.values()) c.remove();
    this.containers.clear();
    unhideWithin(document);
  }

  protected override replyDone(): void {
    this.reload = true;
    this.schedule();
  }

  protected override chatChanged(): void {
    this.reload = false;
    this.regexed.clear();
    this.textSig.clear();
  }

  protected override async read(chatId: string): Promise<() => void> {
    const [list, cast, me] = await Promise.all([listMessages(chatId, { fresh: true }), chatCharacters(chatId).catch(() => []), persona(chatId).catch(() => null)]);
    return () => {
      this.messages = new Map(list.map((m) => [m.id, m]));
      this.cast = cast.map((c) => c.id);
      this.names = { user: me?.name ?? "User", char: cast[0]?.name ?? "" };
    };
  }

  private drop(key: string): void {
    const s = this.shown.get(key);
    if (!s) return;
    s.block.dispose();
    if (s.pre) {
      s.pre.style.removeProperty("display");
      delete s.pre.dataset.fornello;
    }
    if (s.marker?.parentElement) unhideWithin(s.marker.parentElement);
    this.shown.delete(key);
    clearQuietEdit(key.slice(0, key.lastIndexOf(":")));
  }

  /** A page for one fence; it starts by itself when it is among the recent ones. */
  private newBlock(code: string, messageId: string, key: string): PageBlock {
    return new PageBlock(code, { settings: this.settings, messageId, startOnScreen: () => this.recent.has(key), openSettings: () => this.hooks.openSettings() });
  }

  protected async scan(chatId: string | null): Promise<void> {
    if (!chatId || this.settings.current.mode === "off") {
      if (this.shown.size) this.clear();
      return;
    }
    const elements = [...document.querySelectorAll<HTMLElement>("[data-message-id]")].filter((el) => !el.parentElement?.closest(OURS));
    if (!elements.length) return;
    // a new message, or one whose text changed (a swipe, an edit); one still streaming has no saved id yet
    const sigs = new Map(elements.filter((el) => isSaved(el.dataset.messageId)).map((el) => [el.dataset.messageId!, quickHash(el.textContent ?? "")]));
    const stale = [...sigs].some(([id, sig]) => !this.messages.has(id) || this.textSig.get(id) !== sig);
    if ((stale || this.reload) && this.loadAllowed()) {
      this.reload = false;
      await this.load(chatId);
      for (const [id, sig] of sigs) this.textSig.set(id, sig);
    }
    const scripts = await regexScripts();
    // turned off, or another chat opened, while it read
    if (this.stopped || currentChatId() !== chatId) return;
    const last = Math.max(0, ...[...this.messages.values()].map((m) => m.num));
    const live = new Set<string>();
    for (const el of elements) {
      const id = el.dataset.messageId ?? "";
      const message = this.messages.get(id);
      if (!message) {
        // still streaming, or not saved yet: what it shows stays as it is
        for (const key of this.shown.keys()) if (key.startsWith(`${id}:`)) live.add(key);
        continue;
      }
      const own = codeFences(message.text, fenceRulesFor(el, message.text)).filter((f) => /^html?$/i.test(f.lang));
      if (own.length) {
        this.swapCodeBlocks(el, message, own, live);
        continue;
      }
      const sig = `${quickHash(message.text)}|${last - message.num}|${scripts.length}`;
      let cached = this.regexed.get(id);
      if (!cached || cached.sig !== sig) {
        const sources: string[] = [];
        const text = scripts.length ? applyDisplayRegex(message.text, scripts, { role: message.role, depth: last - message.num, chatCharacters: this.cast, names: this.names }, sources) : message.text;
        cached = { sig, text, sources };
        this.regexed.set(id, cached);
      }
      if (cached.text === message.text || !this.showRegexPages(el, message, cached.text, cached.sources, live)) unhideWithin(el);
    }
    for (const key of [...this.shown.keys()]) if (!live.has(key)) this.drop(key);
    this.rankRecent();
    for (const [id, c] of this.containers) {
      if (![...live].some((k) => k.startsWith(`${id}:`))) {
        c.remove();
        this.containers.delete(id);
      }
    }
  }

  /** "바로 실행": the most recent pages (by message, then by place in it) may start by themselves. */
  private rankRecent(): void {
    const order = (key: string) => {
      const at = key.lastIndexOf(":");
      return [this.messages.get(key.slice(0, at))?.num ?? 0, Number(key.slice(at + 1))] as const;
    };
    // pages without scripts take no place
    const keys = [...this.shown].filter(([, s]) => s.block.hasScripts).map(([key]) => key).sort((a, b) => {
      const [na, ia] = order(a);
      const [nb, ib] = order(b);
      return nb - na || ib - ia;
    });
    this.recent = new Set(keys.slice(0, this.settings.current.autoRun));
  }

  /** Puts (or keeps) a page; true when it is already the page for that code. */
  private keep(key: string, code: string, message: Message): Shown | null {
    const existing = this.shown.get(key);
    if (!existing || !existing.block.element.isConnected) return null;
    const k = quickHash(code);
    if (existing.key === k) return existing;
    // the page rewrote its own message without a redraw: keep it running (for that text only)
    if (isQuietEdit(message.id, message.text)) {
      existing.key = k;
      return existing;
    }
    return null;
  }

  private swapCodeBlocks(el: HTMLElement, message: Message, fences: Fence[], live: Set<string>): void {
    const id = message.id;
    const pres = [...el.querySelectorAll<HTMLPreElement>("pre.mari-md-codeblock")].filter((p) => !p.closest(OURS) && isHtmlBlock(p));
    // match a block by its source text (Marinara may split a reply on screen), else by its place
    const used = new Set<Fence>();
    const flat = (s: string) => s.replace(/\s+/g, " ").trim();
    pres.forEach((pre, i) => {
      const shown = flat(pre.querySelector("code")?.textContent ?? "");
      const fence = fences.find((f) => !used.has(f) && flat(f.code) === shown) ?? (used.has(fences[i]) ? undefined : fences[i]);
      if (!fence || !fence.complete) return;
      used.add(fence);
      const key = `${id}:${i}`;
      live.add(key);
      const kept = this.keep(key, fence.code, message);
      if (kept && kept.pre === pre) return;
      this.drop(key);
      const block = this.newBlock(fence.code, id, key);
      pre.dataset.fornello = quickHash(fence.code);
      pre.style.display = "none";
      pre.after(block.element);
      this.shown.set(key, { key: quickHash(fence.code), block, pre });
    });
    const tail = fences.find((f) => !used.has(f) && f.complete && !f.closed);
    if (tail) this.placeAfterMarker(el, message, tail, `${id}:${pres.length}`, live);
    this.muteStyles(el, message.text, fences);
  }

  /** A fence left open at the end: Marinara shows the ``` as text and draws the HTML after it; the page replaces that. */
  private placeAfterMarker(el: HTMLElement, message: Message, fence: Fence, key: string, live: Set<string>): void {
    let shown = this.keep(key, fence.code, message) ?? undefined;
    let marker = shown?.marker?.isConnected ? shown.marker : undefined;
    if (!marker) {
      for (const c of el.querySelectorAll<HTMLElement>(".mari-message-content")) {
        if (c.closest(OURS)) continue;
        const walker = document.createTreeWalker(c, NodeFilter.SHOW_TEXT);
        for (let n = walker.nextNode(); n; n = walker.nextNode()) {
          if (/^`{3,}/.test(n.nodeValue?.trim() ?? "") && !n.parentElement?.closest("pre, code")) marker = n as Text;
        }
      }
    }
    if (!marker?.parentNode) return;
    live.add(key);
    if (!shown || shown.marker !== marker) {
      this.drop(key);
      const block = this.newBlock(fence.code, message.id, key);
      shown = { key: quickHash(fence.code), block, marker };
      this.shown.set(key, shown);
    }
    if (shown.block.element.previousSibling !== marker) marker.after(shown.block.element);
    marker.nodeValue = "";
    for (let n = shown.block.element.nextSibling; n; n = n.nextSibling) {
      if (n instanceof HTMLElement) hide(n);
      else if (n.nodeType === Node.TEXT_NODE && n.nodeValue) n.nodeValue = "";
    }
  }

  /** Marinara applies a reply's <style> to the whole message; when every <style> is inside the pages, that copy is turned off. */
  private muteStyles(el: HTMLElement, text: string, fences: Fence[]): void {
    let rest = text;
    for (const f of [...fences].reverse()) if (f.complete) rest = rest.slice(0, f.start) + rest.slice(f.end);
    const mute = !/<style[\s>]/i.test(rest);
    for (const style of el.querySelectorAll<HTMLStyleElement>(".mari-message-content style")) {
      if (style.closest(OURS) || style.closest("pre, code") || !style.sheet) continue;
      style.sheet.disabled = mute;
    }
  }

  private showRegexPages(el: HTMLElement, message: Message, text: string, sources: string[], live: Set<string>): boolean {
    const id = message.id;
    const fences = codeFences(text).filter((f) => f.html && f.complete);
    if (!fences.length) return false;
    const contents = [...el.querySelectorAll<HTMLElement>(".mari-message-content")].filter((c) => !c.closest(OURS));
    const anchor = contents[contents.length - 1];
    let container = this.containers.get(id);
    if (!container) {
      container = document.createElement("div");
      container.className = "fornello-pages";
      standApart(container);
      this.containers.set(id, container);
    }
    if (anchor) {
      if (anchor.nextElementSibling !== container) anchor.after(container);
    } else if (container.parentElement !== el) el.append(container);
    // only the pages are left of the reply: its text (or Marinara's own rendering) goes
    let rest = text;
    for (const f of [...fences].reverse()) rest = rest.slice(0, f.start) + rest.slice(f.end);
    if (!rest.trim()) for (const c of contents) hide(c);
    fences.forEach((fence, i) => {
      const key = `${id}:${i}`;
      live.add(key);
      const kept = this.keep(key, fence.code, message);
      if (kept) {
        if (kept.block.element.parentElement !== container) container!.append(kept.block.element);
        return;
      }
      this.drop(key);
      const block = this.newBlock(fence.code, id, key);
      container!.append(block.element);
      this.shown.set(key, { key: quickHash(fence.code), block });
    });
    if (rest.trim()) {
      unhideWithin(el);
      // the reply keeps its text, without the part that became the page
      if (sources.length) for (const c of contents) blankText(c, (full) => findLoose(full, sources));
      // Marinara runs the display regex too: the ```html blocks it drew of it are the pages below
      for (const c of contents) {
        for (const pre of c.querySelectorAll<HTMLPreElement>("pre.mari-md-codeblock")) if (isHtmlBlock(pre) && !pre.closest(OURS)) hide(pre);
      }
    }
    return true;
  }
}
