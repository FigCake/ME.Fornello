// Components to and from files: Fornello's JSON file, a .jsx or .html file, or
// a character card (PNG or JSON) carrying components. No DOM here.

import { pngCardJson } from "../scripts/files";
import { componentsOf } from "./cards";
import { type ComponentDef, DEFAULT_BODY, newComponentId, normalizeComponent } from "./model";
import { componentName } from "./source";
import { fieldsFromCode, fieldsFromTemplate } from "./fields";

/** What the file says it is. */
const FILE_TYPE = "fornello.components";

/** Components as a file: what is the person's own (no ids, no card), with the set's name if any. */
export function exportComponents(defs: ComponentDef[], name = ""): string {
  const components = defs.map((d) => {
    const rest: Partial<ComponentDef> = { ...d };
    delete rest.id;
    delete rest.card;
    return rest;
  });
  return JSON.stringify({ type: FILE_TYPE, version: 1, ...(name ? { name } : {}), components }, null, 2);
}

export interface FoundComponents {
  items: ComponentDef[];
  /** The set's name, a card's name, or the file's. */
  name: string;
}

/** A new component from code, named after an HTML file (status-board.html → StatusBoard) or the JSX function. */
export function newComponentFrom(code: string, html: boolean, fileName = ""): ComponentDef {
  const tag = fileName.replace(/\.[^.]+$/, "").split(/[^A-Za-z0-9]+/).filter(Boolean).map((w) => w[0].toUpperCase() + w.slice(1)).join("");
  const name = html ? (/^[A-Z][\w$]*$/.test(tag) ? tag : "MyTemplate") : (componentName(code) ?? "MyComponent");
  return {
    id: newComponentId(),
    kind: html ? "html" : "jsx",
    name,
    label: "",
    code,
    font: "",
    enabled: true,
    everyChat: true,
    source: "tag",
    body: { ...DEFAULT_BODY },
    map: {},
    fields: html ? fieldsFromTemplate(code, []) : fieldsFromCode(code, name, []),
    use: "status",
    when: "",
  };
}

/** A component from a bare .jsx or .html file (none when the file has no component). */
function fromCode(fileName: string, code: string, html: boolean): ComponentDef | null {
  if (!code.trim() || (!html && !componentName(code))) return null;
  return newComponentFrom(code, html, fileName);
}

/** The components a card's JSON carries (V2 / V3, or its data alone). */
function fromCard(json: Record<string, unknown>): FoundComponents | null {
  const data = (json.data && typeof json.data === "object" ? json.data : json) as Record<string, unknown>;
  const book = data.character_book as { entries?: Record<string, unknown>[] } | undefined;
  const entries = (book?.entries ?? []).map((e) => ({ name: String(e.name ?? e.comment ?? ""), content: String(e.content ?? "") }));
  const name = typeof data.name === "string" ? data.name : "";
  const found = componentsOf({ id: "file", name, data: data as Record<string, unknown> }, entries);
  return found ? { items: found.defs.map((d) => ({ ...d, card: undefined, id: newComponentId() })), name } : null;
}

/** The components in a file (fresh ids: they are matched by name when brought in). */
export async function componentsFromFile(fileName: string, bytes: Uint8Array): Promise<FoundComponents> {
  const base = fileName.replace(/\.[^.]+$/, "");
  if (/\.png$/i.test(fileName)) {
    const json = pngCardJson(bytes);
    try {
      return (json && fromCard(JSON.parse(json))) || { items: [], name: base };
    } catch {
      return { items: [], name: base };
    }
  }
  const text = new TextDecoder().decode(bytes);
  if (/\.html?$/i.test(fileName) || /\.(jsx|tsx|js)$/i.test(fileName)) {
    const one = fromCode(fileName, text, /\.html?$/i.test(fileName));
    return { items: one ? [one] : [], name: base };
  }
  let json: unknown;
  try {
    json = JSON.parse(text);
  } catch {
    return { items: [], name: base };
  }
  const o = json && typeof json === "object" ? (json as Record<string, unknown>) : {};
  if (Array.isArray(o.components) || Array.isArray(json)) {
    const list = (Array.isArray(json) ? json : o.components) as unknown[];
    const items = list.map((c) => normalizeComponent({ ...(c as object), id: newComponentId() })).filter((d): d is ComponentDef => !!d);
    return { items, name: typeof o.name === "string" && o.name ? o.name : base };
  }
  if (typeof o.code === "string") {
    const one = normalizeComponent({ ...o, id: newComponentId() });
    return { items: one ? [one] : [], name: base };
  }
  return fromCard(o) ?? { items: [], name: base };
}

/** Brings components in: one with an existing name takes its place and id (chats keep their choice); the rest are added. */
export function bringIn(list: ComponentDef[], found: ComponentDef[]): { list: ComponentDef[]; ids: string[] } {
  const next = [...list];
  const ids: string[] = [];
  for (const d of found) {
    const at = next.findIndex((c) => c.name === d.name);
    if (at >= 0) {
      next[at] = { ...d, id: next[at].id };
      // two of one name in the file: the later one wins, listed once
      if (!ids.includes(next[at].id)) ids.push(next[at].id);
    } else {
      next.push(d);
      ids.push(d.id);
    }
  }
  return { list: next, ids };
}
