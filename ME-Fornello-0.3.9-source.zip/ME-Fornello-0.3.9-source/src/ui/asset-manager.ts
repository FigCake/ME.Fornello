// The character assets window: one character's pictures, named for replies.
// Its Gallery pictures are listed under a name (and a person, and words that
// show them), new ones are uploaded named after their files, and its sprites
// can get words too. Every change is saved to the card at once. A card file
// (.charx, a JPEG or PNG card) brings its pictures in under the card's names:
// what it holds is shown first, then they are uploaded one at a time.

import { chatCharacters } from "../api/chat-store";
import { type CharacterName, characterNames } from "../api/library";
import { cardImportMessage, importCardFile } from "../assets/card-import";
import { currentChatId } from "../host/current-chat";
import { type CardFile, type LeftOutReason, picturesToImport, readCardFile } from "../assets/card-file";
import { editAsset, listFile, nameFromFile, parseWords, setSpriteWords, unlistFile } from "../assets/edit";
import { type Asset, assetUrl } from "../assets/model";
import { type GalleryPicture, deleteFromGallery, galleryOf, readAssets, saveAssets, spriteListOf, uploadToGallery } from "../assets/store";
import { t } from "../shared/i18n";
import { type GoToTab, TABS_CSS, tabHeader } from "./window-tabs";
import { FORM_CSS, section } from "../shared/form";
import { CONTROLS, THEME_TOKENS } from "../shared/theme";
import { BACKDROP_CSS, el, pickFile } from "./dom";
import { showToast } from "./toast";

const STYLE = `
${THEME_TOKENS}
:host { position: fixed; inset: 0; z-index: 2147482700; }
* { box-sizing: border-box; }
${CONTROLS}
${FORM_CSS}
${BACKDROP_CSS}
${TABS_CSS}
details.part { border: 1px solid var(--d-line); border-radius: var(--d-radius-sm); padding: 6px 10px; margin-bottom: 10px; }
details.part > summary { cursor: pointer; color: var(--d-muted); font-size: 12px; }
details.part[open] > summary { margin-bottom: 6px; }
.win { width: min(980px, 100%); height: min(860px, 100%); display: flex; flex-direction: column; overflow: hidden;
  font: 13px/1.45 var(--d-font); color: var(--d-text); background: var(--d-panel-solid); border: 1px solid var(--d-line); border-radius: var(--d-radius); box-shadow: var(--d-shadow); }
header { display: flex; align-items: center; gap: 8px; padding: 10px 14px; border-bottom: 1px solid var(--d-divider); flex-wrap: wrap; }
header h2 { margin: 0; font-size: 15px; color: var(--d-title); flex: 1; }
header select { width: auto; max-width: 16em; }
main { flex: 1; min-height: 0; overflow: auto; padding: 8px 14px 18px; }
.note { color: var(--d-muted); font-size: 12px; }
.grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(190px, 1fr)); gap: 10px; }
.grid.small { grid-template-columns: repeat(auto-fill, minmax(120px, 1fr)); }
.tile { display: flex; flex-direction: column; gap: 4px; padding: 6px; border: 1px solid var(--d-line); border-radius: var(--d-radius-sm); background: var(--d-field); min-width: 0; }
.tile img { width: 100%; aspect-ratio: 1; object-fit: contain; border-radius: 6px; background: var(--d-panel-solid); }
.tile input { font-size: 12px; padding: 3px 6px; }
.tile .row { display: flex; gap: 4px; align-items: center; }
.tile .row input { flex: 1; min-width: 0; }
.tile .name { font-size: 12px; font-weight: 600; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
button.mini { padding: 2px 7px; font-size: 12px; min-width: 0; }
.badge { font-size: 11px; padding: 0 6px; border-radius: 999px; border: 1px solid var(--d-line); color: var(--d-muted); }
.card-file { display: flex; flex-direction: column; gap: 6px; }
.card-file ul { margin: 0; padding-left: 18px; }
.card-file .row { display: flex; gap: 8px; align-items: center; flex-wrap: wrap; }
`;

/** A card file read and waiting to be imported (what it holds is shown first). */
interface CardImport {
  file: File;
  found: CardFile;
  /** Make a new character from the card and put the pictures there. */
  asNew: boolean;
}
/** What a card file's import did. */
interface ImportReport {
  /** The card's name. */
  name: string;
  done: number;
  skipped: number;
  failed: string[];
}

/** Why a part of a card file stays out, as the summary says it. */
function leftOutText(reason: LeftOutReason): string {
  switch (reason) {
    case "portrait":
      return t("the portrait (the character's own picture)", "대표 그림 (캐릭터 자신의 그림)");
    case "user-icon":
      return t("the user's picture", "사용자 그림");
    case "default":
      return t("a default picture", "기본 그림");
    case "remote":
      return t("on the web (not downloaded)", "웹 주소 (내려받지 않음)");
    case "missing":
      return t("not in the file", "파일 안에 없음");
    case "not-picture":
      return t("not a picture", "그림이 아님");
    case "app-data":
      return t("data of the app that made the card", "카드를 만든 앱의 데이터");
    case "not-listed":
      return t("not listed in the card", "카드 목록에 없음");
    case "unknown-uri":
      return t("an address Fornello can't read", "읽을 수 없는 주소");
    case "same-emotion":
      return t("an emotion given twice (the first is kept)", "같은 표정이 또 있음 (첫 장만)");
  }
}

export class AssetManager {
  private element: HTMLElement | null = null;
  private root: ShadowRoot | null = null;
  private returnFocus: HTMLElement | null = null;
  private people: CharacterName[] = [];
  private others: CharacterName[] | null = null;
  private characterId: string | null = null;
  private assets: Asset[] = [];
  private gallery: GalleryPicture[] = [];
  private sprites: Asset[] = [];
  private busy = "";
  private cardImport: CardImport | null = null;
  private report: ImportReport | null = null;
  /** A card file is being imported (the character can't be changed meanwhile). */
  private importing = false;
  /** Pictures are being uploaded: the character can't be changed until they are listed. */
  private uploading = false;

  /** The tabs of Fornello's window (main.ts sets it). */
  tabs: GoToTab | null = null;
  /** How assets show (the settings), at the top of the tab. */
  settingsPart: (() => HTMLElement) | null = null;
  private partOpen = false;

  /** `changed`: the asset list of a card was saved (the chat draws again). */
  constructor(private readonly changed: () => void) {}

  async open(characterId?: string): Promise<void> {
    if (!this.element) {
      this.element = document.createElement("div");
      this.element.id = "fornello-assets";
      this.root = this.element.attachShadow({ mode: "open" });
      this.returnFocus = document.activeElement instanceof HTMLElement ? document.activeElement : null;
      document.addEventListener("keydown", this.onKey, true);
      document.body.append(this.element);
    }
    const chatId = currentChatId();
    this.people = chatId ? (await chatCharacters(chatId).catch(() => [])).map((c) => ({ id: c.id, name: c.name })) : [];
    this.render();
    const first = characterId ?? this.characterId ?? this.people[0]?.id;
    if (first) await this.pick(first);
    else await this.loadOthers();
  }

  close(): void {
    document.removeEventListener("keydown", this.onKey, true);
    const wasOpen = !!this.element;
    this.element?.remove();
    this.element = null;
    this.root = null;
    if (wasOpen && this.returnFocus?.isConnected) this.returnFocus.focus();
  }

  /** Redraws when open (the language changed). */
  refresh(): void {
    if (this.element) this.render();
  }

  private readonly onKey = (e: KeyboardEvent) => {
    if (e.key === "Escape" && this.element) {
      e.stopPropagation();
      this.close();
    }
  };

  private async loadOthers(): Promise<void> {
    if (this.others) return;
    this.others = await characterNames().catch(() => []);
    this.render();
  }

  private async pick(id: string): Promise<void> {
    if (id !== this.characterId) this.report = null;
    this.characterId = id;
    // nothing of the character shown before stays under this one's name (a save would write it to this card)
    this.assets = [];
    this.gallery = [];
    this.sprites = [];
    this.busy = t("Loading…", "불러오는 중…");
    this.render();
    let read: [Asset[], GalleryPicture[], Asset[]] | null = null;
    try {
      read = await Promise.all([readAssets(id), galleryOf(id), spriteListOf(id)]);
    } catch (e) {
      showToast(e instanceof Error ? e.message : String(e), "warning");
    }
    // another character was picked meanwhile: its own read fills the window
    if (this.characterId !== id) return;
    if (read) [this.assets, this.gallery, this.sprites] = read;
    // a card whose list couldn't be read isn't saved over: the window waits for another pick
    else this.characterId = null;
    this.busy = "";
    this.render();
  }

  /**
   * Saves a changed list to character `id` (the one shown when the change
   * began); on failure the window shows what is saved, if it still shows that character.
   */
  private async save(next: Asset[], id = this.characterId): Promise<void> {
    if (!id) return;
    const shown = () => this.characterId === id;
    const before = this.assets;
    if (shown()) {
      this.assets = next;
      this.render();
    }
    try {
      await saveAssets(id, next);
      this.changed();
    } catch (e) {
      if (shown()) {
        this.assets = before;
        this.render();
      }
      showToast(t(`Not saved: ${e instanceof Error ? e.message : e}`, `저장하지 못했어요: ${e instanceof Error ? e.message : e}`), "warning");
    }
  }

  private async upload(files: File[]): Promise<void> {
    const id = this.characterId;
    if (!id || !files.length) return;
    this.uploading = true;
    const added: { file: string; name: string }[] = [];
    for (const [i, file] of files.entries()) {
      this.busy = t(`Uploading ${i + 1} of ${files.length}…`, `${files.length}장 중 ${i + 1}장 올리는 중…`);
      this.render();
      try {
        const pic = await uploadToGallery(id, file, file.name);
        if (this.characterId === id) this.gallery = [...this.gallery, pic];
        added.push({ file: pic.file, name: nameFromFile(file.name) });
      } catch (e) {
        showToast(`${file.name}: ${e instanceof Error ? e.message : e}`, "warning");
      }
    }
    this.uploading = false;
    this.busy = "";
    if (!added.length) return this.render();
    // onto the list as it is now (a name may have been changed meanwhile)
    let now: Asset[];
    try {
      now = await readAssets(id);
    } catch (e) {
      this.render();
      showToast(t(`The names were not saved (the pictures are in the Gallery): ${e instanceof Error ? e.message : e}`, `이름을 저장하지 못했어요 (그림은 갤러리에 있어요): ${e instanceof Error ? e.message : e}`), "warning");
      return;
    }
    await this.save(added.reduce((list, a) => listFile(list, "gallery", a.file, a.name), now), id);
  }

  /** Picks a card file and shows what it holds (nothing is uploaded yet). */
  private pickCard(): void {
    pickFile(async (file) => {
      let found: CardFile;
      try {
        found = await readCardFile(file.name, new Uint8Array(await file.arrayBuffer()));
      } catch (e) {
        showToast(t(`Could not read that file: ${e instanceof Error ? e.message : e}`, `그 파일을 읽지 못했어요: ${e instanceof Error ? e.message : e}`), "error");
        return;
      }
      if (found.form === "none" || !found.card) {
        showToast(t("No character card found in that file.", "그 파일에서 캐릭터 카드를 찾지 못했어요."), "warning");
        return;
      }
      this.cardImport = { file, found, asNew: false };
      this.report = null;
      this.render();
    }, ".charx,.zip,.png,.jpg,.jpeg,image/png,image/jpeg");
  }

  /** Brings the card file in (card-import.ts) and shows what came in. */
  private async importCard(imp: CardImport): Promise<void> {
    if (!imp.asNew && !this.characterId) return;
    this.importing = true;
    let result;
    try {
      result = await importCardFile(imp.found, imp.file, imp.asNew ? null : { id: this.characterId!, assets: this.assets }, (what) => {
        this.busy = what;
        this.render();
      });
    } catch (e) {
      this.importing = false;
      this.busy = "";
      this.render();
      showToast(t(`Not imported: ${e instanceof Error ? e.message : e}`, `가져오지 못했어요: ${e instanceof Error ? e.message : e}`), "warning");
      return;
    }
    if (result.changed) this.changed();
    this.importing = false;
    this.cardImport = null;
    if (imp.asNew) {
      // the new character joins the choices before the window turns to it
      this.others = null;
      await this.loadOthers();
    }
    await this.pick(result.characterId);
    this.report = { name: imp.found.name, done: result.done, skipped: result.skipped, failed: result.failed };
    this.render();
    showToast(cardImportMessage(imp.found.name, result), result.failed.length ? "warning" : "success");
  }

  private async deletePicture(pic: GalleryPicture): Promise<void> {
    const id = this.characterId;
    if (!id || !window.confirm(t("Delete this picture from the character's Gallery?", "이 그림을 캐릭터 갤러리에서 지울까요?"))) return;
    try {
      await deleteFromGallery(id, pic.id);
    } catch (e) {
      showToast(e instanceof Error ? e.message : String(e), "warning");
      return;
    }
    // another character was picked meanwhile: its window is left as it is, the name comes off the saved list
    if (this.characterId !== id) {
      const saved = await readAssets(id).catch(() => null);
      if (saved?.some((a) => a.place === "gallery" && a.file === pic.file)) await this.save(unlistFile(saved, "gallery", pic.file), id);
      return;
    }
    this.gallery = this.gallery.filter((p) => p !== pic);
    if (this.assets.some((a) => a.place === "gallery" && a.file === pic.file)) await this.save(unlistFile(this.assets, "gallery", pic.file), id);
    else this.render();
  }

  private render(): void {
    if (!this.root) return;
    const scroll = this.root.querySelector("main")?.scrollTop ?? 0;
    const style = el("style", {}, STYLE);
    const choices = [...this.people, ...(this.others ?? []).filter((o) => !this.people.some((p) => p.id === o.id))];
    const select = el(
      "select",
      {
        "aria-label": t("Character", "캐릭터"),
        "data-key": "asset-character",
        disabled: this.importing || this.uploading,
        onfocus: () => void this.loadOthers(),
        onchange: (e: Event) => void this.pick((e.target as HTMLSelectElement).value),
      },
      ...(this.characterId ? [] : [el("option", { value: "", selected: true }, t("Pick a character", "캐릭터 고르기"))]),
      ...choices.map((c) => el("option", { value: c.id, selected: c.id === this.characterId }, c.name || c.id)),
    );
    const head = el(
      "header",
      {},
      ...(this.tabs ? tabHeader("assets", this.tabs) : [el("h2", {}, t("🖼 Character assets", "🖼 캐릭터 에셋"))]),
      el("button", { className: "ghost", "aria-label": t("Close", "닫기"), onclick: () => this.close() }, "✕"),
    );
    const part = this.settingsPart ? el("details", { className: "part", open: this.partOpen, ontoggle: (e: Event) => (this.partOpen = (e.target as HTMLDetailsElement).open) }, el("summary", {}, t("How they show", "보이는 방식")), this.settingsPart()) : null;
    const main = el("main", {}, part, el("div", { className: "row", style: "margin-bottom:8px" }, select), ...(this.characterId ? this.sections(this.characterId) : [el("div", { className: "note" }, t("Pick a character above.", "위에서 캐릭터를 고르세요."))]));
    const win = el("div", { className: `win${this.tabs ? " tabbed" : ""}`, role: "dialog", "aria-modal": "true", "aria-label": t("Character assets", "캐릭터 에셋"), tabIndex: -1 }, head, main);
    const back = el("div", { className: "back", onclick: (e: Event) => e.target === back && this.close() }, win);
    this.root.replaceChildren(style, back);
    const newMain = this.root.querySelector("main");
    if (newMain) newMain.scrollTop = scroll;
  }

  private sections(id: string): HTMLElement[] {
    const file = el("input", { type: "file", accept: "image/png,image/jpeg,image/gif,image/webp,image/avif", multiple: true, hidden: true }) as HTMLInputElement;
    file.addEventListener("change", () => void this.upload([...(file.files ?? [])]));
    const listed = this.assets.filter((a) => a.place === "gallery");
    const loose = this.gallery.filter((p) => !listed.some((a) => a.file === p.file));
    const named = section(
      t(`Named pictures (${listed.length})`, `이름 붙인 그림 (${listed.length})`),
      t(
        "A reply shows one with [img:name]. Several pictures may share a name (one is picked per reply). Person: who it shows, for a card with several people. Words: it shows when a reply uses one",
        "답변에 [img:이름]이 나오면 보여요. 여러 장이 같은 이름이어도 돼요(답변마다 한 장). 인물: 카드에 여러 사람이 있을 때 누구 그림인지. 단어: 답변에 그 단어가 나오면 보여요",
      ),
      [
        file,
        el("button", { className: "mini", disabled: !!this.busy, onclick: () => file.click() }, t("+ Upload pictures", "+ 그림 올리기")),
        el(
          "button",
          { className: "mini", disabled: !!this.busy, title: t("Pictures from a .charx, JPEG or PNG character card (or a .zip holding one)", ".charx·JPEG·PNG 캐릭터 카드(또는 그걸 담은 .zip)의 그림"), onclick: () => this.pickCard() },
          t("Import from a card file", "카드 파일에서 가져오기"),
        ),
      ],
      this.busy ? el("div", { className: "note" }, this.busy) : null,
      listed.length ? el("div", { className: "grid" }, ...listed.map((a) => this.namedTile(id, a))) : el("div", { className: "note" }, t("No named pictures yet. Upload some (named after their files), or name one below.", "아직 이름 붙인 그림이 없어요. 올리면 파일 이름이 이름이 돼요. 아래 그림에 이름을 붙여도 돼요.")),
    );
    const unnamed = loose.length
      ? section(
          t(`Gallery pictures without a name (${loose.length})`, `이름 없는 갤러리 그림 (${loose.length})`),
          undefined,
          [],
          el("div", { className: "grid small" }, ...loose.map((p) => this.looseTile(p))),
        )
      : null;
    const sprites = this.sprites.length
      ? section(
          t(`Sprites (${this.sprites.length})`, `스프라이트 (${this.sprites.length})`),
          t("Found by their expression name without a list; words make them show by words too", "표정 이름으로 바로 찾아져요. 단어를 달면 단어로도 보여요"),
          [],
          el("div", { className: "grid small" }, ...this.sprites.map((s) => this.spriteTile(id, s))),
        )
      : null;
    const card = this.cardImport ? this.cardSummary(this.cardImport) : this.report ? this.reportSection(this.report) : null;
    return [card, named, unnamed, sprites].filter((s): s is HTMLElement => !!s);
  }

  /** What a card file holds and what stays out, before anything is uploaded. */
  private cardSummary(imp: CardImport): HTMLElement {
    const { found } = imp;
    const count = (kind: string) => found.pictures.filter((p) => p.kind === kind).length;
    const todo = picturesToImport(found.pictures, imp.asNew ? [] : this.assets);
    const skipped = found.pictures.length - todo.length;
    const reasons = new Map<LeftOutReason, string[]>();
    for (const l of found.leftOut) reasons.set(l.reason, [...(reasons.get(l.reason) ?? []), l.what]);
    const leftOut = [...reasons].map(([reason, names]) =>
      el("li", {}, `${leftOutText(reason)} (${names.length}): ${names.slice(0, 4).join(", ")}${names.length > 4 ? ", …" : ""}`),
    );
    const into = this.characterName(this.characterId);
    const asNew = found.card
      ? el(
          "label",
          { className: "row", style: "cursor:pointer" },
          el("input", { type: "checkbox", checked: imp.asNew, disabled: !!this.busy, onchange: (e: Event) => ((imp.asNew = (e.target as HTMLInputElement).checked), this.render()) }),
          t(`As a new character (made from the card: ${found.name})`, `새 캐릭터로 (카드로 만들기: ${found.name})`),
        )
      : null;
    return section(
      t(`From the card file: ${found.name}`, `카드 파일에서: ${found.name}`),
      t(
        "Emotions become sprites (a sprite of the same expression is replaced). The rest go to the Gallery with their prompts and are named as the card names them. A picture imported before (same name, same file) is skipped",
        "표정은 스프라이트가 돼요 (같은 표정의 스프라이트는 바뀌어요). 나머지는 프롬프트와 함께 갤러리로 가고, 카드에 적힌 이름이 붙어요. 전에 가져온 그림(같은 이름, 같은 파일)은 건너뛰어요",
      ),
      [el("button", { className: "mini ghost", disabled: !!this.busy, onclick: () => ((this.cardImport = null), this.render()) }, t("Cancel", "취소"))],
      el(
        "div",
        { className: "card-file", "data-key": "card-file" },
        el("div", {}, t(`Found: ${count("icon")} other ${count("icon") === 1 ? "portrait" : "portraits"}, ${count("emotion")} ${count("emotion") === 1 ? "emotion" : "emotions"}, ${count("picture")} ${count("picture") === 1 ? "picture" : "pictures"}`, `찾은 것: 다른 대표 그림 ${count("icon")}장, 표정 ${count("emotion")}장, 그림 ${count("picture")}장`)),
        skipped ? el("div", { className: "note" }, t(`Already imported, skipped: ${skipped}`, `이미 가져와서 건너뜀: ${skipped}장`)) : null,
        found.lorebooks?.length ? el("div", {}, t(`Lorebook (linked to the character): ${found.lorebooks.map((b) => b.name).join(", ")}`, `로어북 (캐릭터에 연결): ${found.lorebooks.map((b) => b.name).join(", ")}`)) : null,
        found.qrSets?.length
          ? el("div", {}, t(`QR sets (to Dispensa's Library): ${found.qrSets.map((q) => q.name).join(", ")}`, `QR 세트 (Dispensa 보관함으로): ${found.qrSets.map((q) => q.name).join(", ")}`), typeof window.__dispensa?.importQrs === "function" ? null : el("span", { className: "note" }, t(" · needs Dispensa", " · Dispensa가 있어야 해요")))
          : null,
        leftOut.length ? el("div", {}, t("Left out:", "빠지는 것:"), el("ul", {}, ...leftOut)) : null,
        el(
          "div",
          { className: "row" },
          el("span", {}, imp.asNew ? t("Into: a new character", "넣을 곳: 새 캐릭터") : t(`Into: ${into}`, `넣을 곳: ${into}`)),
          asNew,
        ),
        el(
          "div",
          { className: "row" },
          el("button", { disabled: !!this.busy || !(todo.length || found.lorebooks?.length || found.qrSets?.length), onclick: () => void this.importCard(imp) }, (found.lorebooks?.length || found.qrSets?.length ? t(`Import (${todo.length} ${todo.length === 1 ? "picture" : "pictures"} and the rest)`, `가져오기 (그림 ${todo.length}장과 나머지)`) : t(`Import ${todo.length} ${todo.length === 1 ? "picture" : "pictures"}`, `그림 ${todo.length}장 가져오기`))),
        ),
      ),
    );
  }

  /** What the last card import did: counts, and each picture that failed. */
  private reportSection(r: ImportReport): HTMLElement {
    return section(
      t(`Imported from ${r.name}`, `${r.name}에서 가져옴`),
      undefined,
      [el("button", { className: "mini ghost", "aria-label": t("Close", "닫기"), onclick: () => ((this.report = null), this.render()) }, "✕")],
      el(
        "div",
        { className: "card-file", "data-key": "card-report" },
        el("div", {}, t(`${r.done} imported, ${r.skipped} already there, ${r.failed.length} failed`, `${r.done}장 가져옴, ${r.skipped}장 이미 있음, ${r.failed.length}장 실패`)),
        r.failed.length ? el("ul", {}, ...r.failed.map((f) => el("li", {}, f))) : null,
      ),
    );
  }

  private characterName(id: string | null): string {
    const c = [...this.people, ...(this.others ?? [])].find((p) => p.id === id);
    return c?.name || id || "";
  }

  private namedTile(id: string, a: Asset): HTMLElement {
    const pic = this.gallery.find((p) => p.file === a.file);
    const field = (value: string, label: string, placeholder: string, onchange: (v: string) => void) =>
      el("input", { type: "text", value, placeholder, "aria-label": label, title: label, onchange: (e: Event) => onchange((e.target as HTMLInputElement).value) });
    return el(
      "div",
      { className: "tile", "data-file": a.file },
      el("img", { src: assetUrl(id, a), alt: a.name, loading: "lazy" }),
      field(a.name, t("Name", "이름"), t("Name", "이름"), (v) => v.trim() && void this.save(editAsset(this.assets, "gallery", a.file, { name: v }))),
      field(a.person ?? "", t("Person (optional)", "인물 (선택)"), t("Person (optional)", "인물 (선택)"), (v) => void this.save(editAsset(this.assets, "gallery", a.file, { person: v }))),
      field((a.words ?? []).join(", "), t("Words, with commas", "단어 (쉼표로)"), t("Words, with commas", "단어 (쉼표로)"), (v) => void this.save(editAsset(this.assets, "gallery", a.file, { words: parseWords(v) }))),
      el(
        "div",
        { className: "row" },
        el("button", { className: "mini ghost", title: t("Take the name off (the picture stays)", "이름 떼기 (그림은 남아요)"), onclick: () => void this.save(unlistFile(this.assets, "gallery", a.file)) }, t("Unname", "이름 떼기")),
        pic ? el("button", { className: "mini ghost danger", title: t("Delete from the Gallery", "갤러리에서 지우기"), onclick: () => void this.deletePicture(pic) }, "🗑") : el("span", { className: "badge" }, t("missing", "파일 없음")),
      ),
    );
  }

  private looseTile(p: GalleryPicture): HTMLElement {
    const input = el("input", { type: "text", placeholder: t("Name", "이름"), "aria-label": t("Name for this picture", "이 그림의 이름"), value: "" }) as HTMLInputElement;
    const add = () => input.value.trim() && void this.save(listFile(this.assets, "gallery", p.file, input.value));
    input.addEventListener("keydown", (e) => e.key === "Enter" && add());
    return el(
      "div",
      { className: "tile", "data-file": p.file },
      el("img", { src: p.url, alt: p.prompt || p.file, loading: "lazy" }),
      el("div", { className: "row" }, input, el("button", { className: "mini", title: t("Name it", "이름 붙이기"), onclick: add }, "＋")),
    );
  }

  private spriteTile(id: string, s: Asset): HTMLElement {
    const words = this.assets.find((a) => a.place === "sprite" && a.file === s.file)?.words ?? [];
    return el(
      "div",
      { className: "tile", "data-file": s.file },
      el("img", { src: assetUrl(id, s), alt: s.name, loading: "lazy" }),
      el("div", { className: "name", title: s.name }, s.name),
      el("input", {
        type: "text",
        value: words.join(", "),
        placeholder: t("Words, with commas", "단어 (쉼표로)"),
        "aria-label": t(`Words for ${s.name}`, `${s.name}의 단어`),
        onchange: (e: Event) => void this.save(setSpriteWords(this.assets, s, parseWords((e.target as HTMLInputElement).value))),
      }),
    );
  }
}
