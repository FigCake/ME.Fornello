// Text in the prompt of the chat's next replies (inject / injectPrompts): each
// is an always-on entry of the chat's own lorebook. "once" ones go after the
// next reply; the others when removed or when their page or script goes.

import { onGenerationEnd } from "../host/generation-hold";
import { currentChatId } from "../host/current-chat";
import { oncePerFrame, onScreenChange } from "../host/screen-watch";
import { chatLoreBook, chatLoreBookIfAny, createLoreEntry, deleteLoreEntries, loreEntries, patchLoreEntry } from "./marinara";

/** The name every entry made here starts with (left-over ones are found again by it). */
const INJECTION_PREFIX = "Fornello inject: ";

export type InjectPosition = "before" | "after" | "depth";

export interface Injection {
  id: string;
  content: string;
  /** Where: before or after the character definitions, or in the chat at `depth` (0 = after the last message). */
  position?: InjectPosition;
  depth?: number;
  role?: "system" | "user" | "assistant";
  /** Only for the next reply. */
  once?: boolean;
}

interface Placed {
  bookId: string;
  entryId: string;
  once: boolean;
}

/** By chat, then by injection id. */
const placed = new Map<string, Map<string, Placed>>();
const cleaned = new Set<string>();
const POSITIONS: Record<InjectPosition, number> = { before: 0, after: 1, depth: 2 };

/** Entries a stopped Fornello left behind in this chat's book go before the first new one. */
async function cleanLeftovers(chatId: string, bookId: string): Promise<void> {
  if (cleaned.has(chatId)) return;
  cleaned.add(chatId);
  const mine = new Set([...(placed.get(chatId)?.values() ?? [])].map((p) => p.entryId));
  const stale = (await loreEntries(bookId).catch(() => [])).filter((e) => String(e.name ?? "").startsWith(INJECTION_PREFIX) && !mine.has(e.id));
  if (stale.length) await deleteLoreEntries(bookId, stale.map((e) => e.id)).catch(() => undefined);
}

export async function inject(chatId: string, injection: Injection): Promise<void> {
  const book = await chatLoreBook(chatId);
  await cleanLeftovers(chatId, book.id);
  const fields = {
    name: `${INJECTION_PREFIX}${injection.id}`.slice(0, 200),
    content: injection.content,
    enabled: true,
    constant: true,
    keys: [],
    position: POSITIONS[injection.position ?? "depth"] ?? 2,
    depth: Math.max(0, Math.floor(Number(injection.depth ?? 1)) || 0),
    role: injection.role ?? "system",
    order: 1000,
  };
  const forChat = placed.get(chatId) ?? new Map<string, Placed>();
  placed.set(chatId, forChat);
  const there = forChat.get(injection.id);
  if (there) await patchLoreEntry(there.bookId, there.entryId, fields);
  else {
    const entry = await createLoreEntry(book.id, fields);
    forChat.set(injection.id, { bookId: book.id, entryId: entry.id, once: injection.once === true });
    return;
  }
  there.once = injection.once === true;
}

export async function uninject(chatId: string, ids: string[]): Promise<void> {
  const forChat = placed.get(chatId);
  if (!forChat) return;
  const gone = ids.map((id) => [id, forChat.get(id)] as const).filter((x): x is readonly [string, Placed] => !!x[1]);
  for (const [id] of gone) forChat.delete(id);
  const byBook = new Map<string, string[]>();
  for (const [, p] of gone) byBook.set(p.bookId, [...(byBook.get(p.bookId) ?? []), p.entryId]);
  for (const [bookId, entryIds] of byBook) await deleteLoreEntries(bookId, entryIds).catch(() => undefined);
}

/** The "once" injections of a chat whose reply is done. */
function afterReply(chatId: string | null): void {
  for (const [id, forChat] of placed) {
    if (chatId && id !== chatId) continue;
    const once = [...forChat].filter(([, p]) => p.once).map(([key]) => key);
    if (once.length) void uninject(id, once);
  }
}

/** Removes "once" injections after each reply and leftovers when a chat opens; the returned stop removes every injection. */
export function startInjections(): () => void {
  let lastChat: string | null = null;
  const look = oncePerFrame(() => {
    const chatId = currentChatId();
    if (!chatId || chatId === lastChat) return;
    lastChat = chatId;
    if (cleaned.has(chatId)) return;
    void chatLoreBookIfAny(chatId)
      .then((book) => (book ? cleanLeftovers(chatId, book.id) : undefined))
      .catch(() => undefined);
  });
  const stops = [onGenerationEnd((gen) => afterReply(gen.chatId)), onScreenChange(look)];
  look();
  return () => {
    for (const stop of stops) stop();
    for (const [chatId, forChat] of [...placed]) void uninject(chatId, [...forChat.keys()]);
    placed.clear();
    cleaned.clear();
  };
}
