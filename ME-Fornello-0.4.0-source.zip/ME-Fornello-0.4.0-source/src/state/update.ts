// Reading what a reply says changed. The AI ends its reply with a ```pesto block, in
// one of these shapes (all lenient: trailing commas, comments, quotes or none):
//
//   hp -= 12                         lines: = sets, += adds (a number, or an item to a list),
//   bag += "rope"                    -= takes away, `remove path`, `do event name=value …`
//   do rest hours=8
//
//   [{"op": "replace", "path": "/hp", "value": 88}, {"op": "delta", "path": "gold", "value": -5},
//    {"op": "add", "path": "/bag/-", "value": "rope"}, {"do": "rest", "hours": 8}]
//
//   set: { hp: 88 }                  YAML (or JSON) by kind of change
//   add: { gold: -5 }
//
// Other ways cards ask for changes are read too: `_.set('path', old, new)` lines in an
// <UpdateVariable> block, a <JSONPatch> list, and <VariableEdit> / <VariableInsert> /
// <VariableDelete> blocks holding values by name. Nothing here checks the changes; the engine
// does that against the schema.

import { readYaml } from "./yaml";

export type OpKind = "set" | "add" | "sub" | "delta" | "push" | "remove" | "pull" | "insert-missing" | "do";

export interface Op {
  kind: OpKind;
  path?: string;
  value?: unknown;
  /** push: where in the list (the end when not given) */
  index?: number;
  event?: string;
  args?: Record<string, unknown>;
}

export interface ReadProblem {
  why: "bad-block" | "bad-change";
  detail: string;
}

export interface ReadResult {
  ops: Op[];
  problems: ReadProblem[];
  /** where the blocks are in the text ([start, end)), so the screen can hide them */
  spans: [number, number][];
}

const isPlain = (v: unknown): v is Record<string, unknown> => !!v && typeof v === "object" && !Array.isArray(v);

const BLOCK = /```[ \t]*pesto(?![\w-])[^\n]*\n([\s\S]*?)(?:```|$(?![\s\S]))/gi;
const TAG = /<(UpdateVariable|JSONPatch|VariableEdit|VariableInsert|VariableDelete)>([\s\S]*?)<\/\1>/gi;

/** The longest block read (characters): a longer one is refused, as reading it could hold up the page. */
export const MAX_BLOCK = 16_000;

/** Reads a block's text unless it is too long. */
function capped(body: string, out: ReadResult, read: () => void) {
  if (body.length > MAX_BLOCK) out.problems.push({ why: "bad-block", detail: `the block is longer than ${MAX_BLOCK} characters` });
  else read();
}

/** The changes a reply asks for, in the order written. */
export function readUpdates(text: string): ReadResult {
  const result: ReadResult = { ops: [], problems: [], spans: [] };
  const found: { at: number; end: number; read: () => void }[] = [];
  for (const m of text.matchAll(BLOCK)) {
    found.push({ at: m.index!, end: m.index! + m[0].length, read: () => capped(m[1], result, () => readBlock(m[1], result)) });
  }
  for (const m of text.matchAll(TAG)) {
    if (found.some((f) => m.index! >= f.at && m.index! < f.end)) continue;
    const tag = m[1].toLowerCase();
    found.push({
      at: m.index!,
      end: m.index! + m[0].length,
      read: () =>
        capped(m[2], result, () => {
        if (tag === "updatevariable") readUpdateVariable(m[2], result);
        else if (tag === "jsonpatch") readBlock(m[2], result);
        else readByName(m[2], tag === "variableedit" ? "set" : tag === "variableinsert" ? "insert-missing" : "remove", result);
        }),
    });
  }
  found.sort((a, b) => a.at - b.at);
  for (const f of found) {
    result.spans.push([f.at, f.end]);
    f.read();
  }
  return result;
}

/** Changes given as data rather than text (what the card's code answers): a list of changes, one change, or changes by kind; lines in a string. */
export function readChanges(data: unknown): ReadResult {
  const result: ReadResult = { ops: [], problems: [], spans: [] };
  if (data === null || data === undefined) return result;
  if (typeof data === "string") readBlock(data, result);
  else for (const item of Array.isArray(data) ? data : [data]) readItem(item, result);
  return result;
}

const LINE_SET = /^(\S+?)\s*(\+=|-=|=)\s*(.*)$/;
const LINE_WORD = /^(do|remove|delete|unset)\s+(\S+)\s*(.*)$/i;

function readBlock(body: string, out: ReadResult) {
  const lines = body
    .split("\n")
    .map((l) => l.trim())
    .filter((l) => l && !l.startsWith("#") && !l.startsWith("//"));
  if (!lines.length) return;
  // lines like `hp = 80`, `do rest` or `_.set(...)`; otherwise JSON or YAML
  if (lines.every((l) => l.startsWith("_.") || LINE_WORD.test(l) || (LINE_SET.test(l) && !/^[-[{]/.test(l) && !/^[^=]*:\s/.test(l)))) {
    for (const line of lines) readLine(line, out);
    return;
  }
  let data: unknown;
  try {
    data = readYaml(body);
  } catch (e) {
    out.problems.push({ why: "bad-block", detail: e instanceof Error ? e.message : String(e) });
    return;
  }
  for (const item of Array.isArray(data) ? data : [data]) readItem(item, out);
}

/** A value written after `=`: JSON, a quoted text, a number, a list, or plain words. */
function lineValue(text: string): unknown {
  const clean = text.replace(/\s+\/\/.*$/, "").replace(/;\s*$/, "").trim();
  try {
    return readYaml(clean);
  } catch {
    return clean;
  }
}

function readLine(line: string, out: ReadResult) {
  if (line.startsWith("_.")) {
    readSetCalls(line, out);
    return;
  }
  const word = LINE_WORD.exec(line);
  if (word) {
    if (word[1].toLowerCase() === "do") out.ops.push({ kind: "do", event: word[2], args: readArgs(word[3]) });
    else out.ops.push({ kind: "remove", path: word[2], ...(word[3].trim() ? { value: lineValue(word[3]) } : {}) });
    return;
  }
  const m = LINE_SET.exec(line);
  if (!m) {
    out.problems.push({ why: "bad-change", detail: line });
    return;
  }
  out.ops.push({ kind: m[2] === "=" ? "set" : m[2] === "+=" ? "add" : "sub", path: m[1], value: lineValue(m[3]) });
}

/** `hours=8 place="the inn"` or `{hours: 8}` → { hours: 8, place: "the inn" } */
function readArgs(text: string): Record<string, unknown> {
  const t = text.trim();
  if (!t) return {};
  if (t.startsWith("{")) {
    const v = lineValue(t);
    if (isPlain(v)) return v;
  }
  const args: Record<string, unknown> = {};
  const re = /([\p{L}\p{N}_$]+)\s*[=:]\s*("(?:[^"\\]|\\.)*"|'(?:[^']|'')*'|\[[^\]]*\]|\{[^}]*\}|[^\s,]+)/gu;
  for (const m of t.matchAll(re)) if (m[1] !== "__proto__") args[m[1]] = lineValue(m[2]);
  return args;
}

const OP_NAMES: Record<string, OpKind> = {
  replace: "set",
  set: "set",
  update: "set",
  add: "add",
  delta: "delta",
  inc: "delta",
  increment: "delta",
  plus: "delta",
  dec: "sub",
  decrement: "sub",
  minus: "sub",
  push: "push",
  insert: "push",
  append: "push",
  remove: "remove",
  delete: "remove",
  del: "remove",
  unset: "remove",
  pull: "pull",
  do: "do",
  event: "do",
};

function readItem(item: unknown, out: ReadResult) {
  if (typeof item === "string") {
    readLine(item.trim(), out);
    return;
  }
  if (!isPlain(item)) {
    out.problems.push({ why: "bad-change", detail: JSON.stringify(item) });
    return;
  }
  if (typeof item.op === "string") {
    const kind = OP_NAMES[item.op.toLowerCase()];
    if (!kind) {
      out.problems.push({ why: "bad-change", detail: `unknown op "${item.op}"` });
      return;
    }
    if (kind === "do") {
      const { event, name, args, ...rest } = item;
      delete rest.op;
      out.ops.push({ kind, event: String(event ?? name ?? ""), args: { ...rest, ...(isPlain(args) ? args : {}) } });
      return;
    }
    const path = item.path ?? item.key;
    if (typeof path !== "string") {
      out.problems.push({ why: "bad-change", detail: `"${item.op}" needs a path` });
      return;
    }
    const value = "value" in item ? item.value : item.to;
    out.ops.push({ kind, path, ...(value !== undefined ? { value } : {}), ...(typeof item.index === "number" ? { index: item.index } : {}) });
    return;
  }
  // { set: {path: value}, add: {...}, remove: [paths], do: event } — or just { path: value }
  const byKind = Object.keys(item).every((k) => OP_NAMES[k.toLowerCase()]);
  if (!byKind && typeof item.do === "string") {
    const { do: event, args, ...rest } = item;
    out.ops.push({ kind: "do", event, args: { ...rest, ...(isPlain(args) ? args : {}) } });
    return;
  }
  if (!byKind) {
    for (const [path, value] of Object.entries(item)) out.ops.push({ kind: "set", path, value });
    return;
  }
  for (const [name, body] of Object.entries(item)) {
    const kind = OP_NAMES[name.toLowerCase()];
    if (kind === "do") {
      for (const e of Array.isArray(body) ? body : [body]) {
        if (typeof e === "string") out.ops.push({ kind, event: e, args: {} });
        else if (isPlain(e)) readItem({ do: e.event ?? e.name, ...e }, out);
      }
    } else if (kind === "remove" && (typeof body === "string" || Array.isArray(body))) {
      for (const path of Array.isArray(body) ? body : [body]) out.ops.push({ kind, path: String(path) });
    } else if (isPlain(body)) {
      for (const [path, value] of Object.entries(body)) out.ops.push({ kind, path, value });
    } else out.problems.push({ why: "bad-change", detail: `"${name}" needs names and values` });
  }
}

/** Values by name, all the way down (lists are values): one change for each. */
function readByName(body: string, kind: OpKind, out: ReadResult) {
  let data: unknown;
  try {
    data = readYaml(body);
  } catch (e) {
    out.problems.push({ why: "bad-block", detail: e instanceof Error ? e.message : String(e) });
    return;
  }
  const walk = (v: unknown, path: string[]) => {
    if (isPlain(v) && Object.keys(v).length) for (const [k, x] of Object.entries(v)) walk(x, [...path, k]);
    else if (path.length) out.ops.push({ kind, path: path.map((p) => (/[.[\]]/.test(p) ? `["${p}"]` : p)).join("."), ...(kind === "remove" ? {} : { value: v }) });
  };
  if (Array.isArray(data) && kind === "remove") for (const p of data) out.ops.push({ kind, path: String(p) });
  else walk(data, []);
}

/**
 * An <UpdateVariable> block: `_.set(...)` calls, or (newer cards) a JSON Patch list, bare or in a
 * <JSONPatch> tag, the model's own <Analysis> before it left out.
 */
function readUpdateVariable(body: string, out: ReadResult) {
  let rest = body.replace(/<Analysis>[\s\S]*?<\/Analysis>/gi, "");
  rest = rest.replace(/<JSONPatch>([\s\S]*?)<\/JSONPatch>/gi, (_all, inner: string) => {
    readBlock(inner, out);
    return "";
  });
  if (/_\.(set|add|insert|assign|remove|delete|unset)\s*\(/.test(rest)) readSetCalls(rest, out);
  else if (/^\s*\[/.test(rest)) readBlock(rest.trim(), out);
}

/** `_.set('a.b', old, new)`, `_.add(...)`, `_.insert(...)`, `_.remove(...)` calls, with `//` notes after them. */
function readSetCalls(body: string, out: ReadResult) {
  const re = /_\.(set|add|insert|assign|remove|delete|unset)\s*\(/g;
  for (let m = re.exec(body); m; m = re.exec(body)) {
    const start = m.index + m[0].length;
    const end = closingParen(body, start);
    if (end < 0) {
      out.problems.push({ why: "bad-change", detail: `"_.${m[1]}(" is not closed` });
      break;
    }
    re.lastIndex = end + 1;
    let args: unknown;
    try {
      args = readYaml(`[${body.slice(start, end)}]`);
    } catch (e) {
      out.problems.push({ why: "bad-change", detail: e instanceof Error ? e.message : String(e) });
      continue;
    }
    if (!Array.isArray(args) || typeof args[0] !== "string") {
      out.problems.push({ why: "bad-change", detail: `"_.${m[1]}" needs a path first` });
      continue;
    }
    // a value kept with its note as [value, note] may be named as `path[0]`
    const path = args[0].replace(/^stat_data\./, "").replace(/\[0\]$/, "");
    const call = m[1];
    if (call === "set") out.ops.push({ kind: "set", path, value: args.length >= 3 ? args[2] : args[1] });
    else if (call === "add") out.ops.push({ kind: "add", path, value: args[1] });
    else if (call === "insert" || call === "assign") {
      if (args.length >= 3 && typeof args[1] === "number") out.ops.push({ kind: "push", path, value: args[2], index: args[1] });
      else if (args.length >= 3) out.ops.push({ kind: "set", path: `${path}.${args[1]}`, value: args[2] });
      else out.ops.push({ kind: "push", path, value: args[1] });
    } else out.ops.push({ kind: "remove", path, ...(args.length >= 2 ? { value: args[1] } : {}) });
  }
}

/** Where the `)` closing a call is, quotes and nested brackets respected; -1 when it never closes. */
function closingParen(text: string, from: number): number {
  let depth = 0;
  let quote = "";
  for (let i = from; i < text.length; i++) {
    const c = text[i];
    if (quote) {
      if (c === "\\") i++;
      else if (c === quote) quote = "";
    } else if (c === '"' || c === "'" || c === "`") quote = c;
    else if (c === "(" || c === "[" || c === "{") depth++;
    else if (c === ")" || c === "]" || c === "}") {
      if (depth === 0) return c === ")" ? i : -1;
      depth--;
    }
  }
  return -1;
}
