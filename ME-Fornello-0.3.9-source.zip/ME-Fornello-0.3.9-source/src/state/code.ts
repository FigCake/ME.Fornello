// The card's Pesto code (`pesto:code`) runs in a Worker of its own: real JavaScript,
// quick, and away from the page. Before the card's code, the Worker loses every way out
// (fetch, XMLHttpRequest, WebSocket, importScripts, other Workers, storage, navigator), so it
// can only answer: it gets a reply's values and changes and gives back changes and effects
// (page commands Fornello runs with their usual checks). A call that takes too long stops the
// Worker; the next call starts a new one.
//
//   function onReply({ values, derived, changes, events, dice, text }) {
//     if (values.hp <= 0 && !values.dead) return { set: { dead: true }, effects: [{ cmd: "toast", args: ["Ari falls."] }] };
//   }

import type { CodeInput, CodeOutput, Effect } from "./engine";
import { quickHash } from "../hash";
import { codeProblem } from "../runtime/guard";
import { LockedWorker } from "./locked-worker";

/** How many answers a card's code keeps, by what it was given (the same message counted again asks again otherwise). */
const KEEP_ANSWERS = 2000;

/** The longest one reply's code may take (ms). */
export const CODE_TIME = 1000;

const SHUT = ["fetch", "XMLHttpRequest", "WebSocket", "EventSource", "importScripts", "Worker", "SharedWorker", "indexedDB", "caches", "BroadcastChannel", "WebTransport", "navigator", "FileReaderSync", "WebAssembly", "Notification", "WebSocketStream"];

/** The start of a Worker's script that runs a card's code: every way out of the Worker shut. */
export function lockSource(): string {
  return `(() => {
  const names = ${JSON.stringify(SHUT)};
  for (let p = self; p; p = Object.getPrototypeOf(p)) for (const n of names) { try { Object.defineProperty(p, n, { value: undefined, configurable: false, writable: false }); } catch (e) {} }
})();`;
}

/** The card's code as a script: an `export` before its functions taken off (a Worker's script is no module). */
const cardScript = (code: string) => code.replace(/^\s*export\s+(?=(?:async\s+)?function|const|let|var|class)/gm, "");

/** The Worker's whole script: the locks, the card's code, then the answering. */
export function workerSource(code: string): string {
  return `"use strict";
${lockSource()}
const __answer = self.postMessage.bind(self);
${cardScript(code)}
;self.onmessage = async (e) => {
  const { id, input } = e.data || {};
  try {
    const out = typeof onReply === "function" ? await onReply(input) : null;
    __answer({ id, out: out === undefined ? null : JSON.parse(JSON.stringify(out)) });
  } catch (err) {
    __answer({ id, error: String(err && err.message || err) });
  }
};`;
}

/** What the code answered, as the engine takes it: changes as data, effects that name a command. */
export function codeOutput(out: unknown): CodeOutput {
  if (!out || typeof out !== "object") return { changes: null, effects: [] };
  const { effects, ...changes } = out as Record<string, unknown>;
  const list: Effect[] = [];
  for (const e of Array.isArray(effects) ? effects : []) {
    if (e && typeof e === "object" && typeof (e as { cmd?: unknown }).cmd === "string") {
      const args = (e as { args?: unknown }).args;
      list.push({ cmd: (e as { cmd: string }).cmd, args: Array.isArray(args) ? args : args === undefined ? [] : [args] });
    }
  }
  // { set, add, … } or { ops: [...] } or { changes: ... }
  const data = "ops" in changes ? changes.ops : "changes" in changes ? changes.changes : Object.keys(changes).length ? changes : null;
  return { changes: data, effects: list };
}

/** Pesto's code in its locked Worker; its answers kept by what it was given. */
export class CodeRunner {
  private worker: LockedWorker;
  /** Answers by what the code was given: the same input gives the same answer, so a chat counted again doesn't wait on the code again. */
  private answers = new Map<string, CodeOutput>();
  /** Why the code can't run at all (it doesn't read, or it loads a module), found before a Worker starts. */
  private problem: string | null;

  constructor(code: string) {
    this.problem = codeProblem(cardScript(code));
    this.worker = new LockedWorker(() => workerSource(code));
  }

  async call(input: CodeInput): Promise<CodeOutput> {
    if (this.problem) return { changes: null, effects: [], error: this.problem };
    const key = quickHash(JSON.stringify(input));
    const kept = this.answers.get(key);
    if (kept) return structuredClone(kept);
    const a = await this.worker.request({ input }, CODE_TIME);
    const out: CodeOutput = a.ok ? (typeof a.data.error === "string" ? { changes: null, effects: [], error: a.data.error } : codeOutput(a.data.out)) : { changes: null, effects: [], error: a.error === `took longer than ${CODE_TIME} ms` ? `the code took longer than ${CODE_TIME} ms` : a.error };
    // an error (too slow, stopped) is asked again next time; an answer is kept, the oldest going first
    if (!out.error) {
      if (this.answers.size >= KEEP_ANSWERS) this.answers.delete(this.answers.keys().next().value!);
      this.answers.set(key, structuredClone(out));
    }
    return out;
  }

  dispose(): void {
    this.worker.dispose();
    this.answers.clear();
  }
}
