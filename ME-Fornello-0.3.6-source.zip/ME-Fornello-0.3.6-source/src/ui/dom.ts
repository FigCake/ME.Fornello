// What Fornello's windows share: the element builder they draw with (no
// innerHTML) and the dimmed backdrop they sit on.

/** The backdrop behind a window, centring it. */
export const BACKDROP_CSS = ".back { position: absolute; inset: 0; display: flex; align-items: center; justify-content: center; padding: 12px; background: rgb(0 0 0 / .45); }";

type Child = Node | string | null | undefined | false;

/**
 * An element: `on…` functions become listeners, a `style` string the
 * attribute, known properties (value, checked…) are set, the rest become
 * attributes; undefined, null and false are left out (children too).
 */
export function el<K extends keyof HTMLElementTagNameMap>(tag: K, attrs: Record<string, unknown> = {}, ...children: Child[]): HTMLElementTagNameMap[K] {
  const node = document.createElement(tag);
  for (const [k, v] of Object.entries(attrs)) {
    if (v === undefined || v === null || v === false) continue;
    if (k.startsWith("on") && typeof v === "function") node.addEventListener(k.slice(2), v as EventListener);
    else if (k === "style" && typeof v === "string") node.setAttribute("style", v);
    else if (k in node && k !== "list") (node as unknown as Record<string, unknown>)[k] = v;
    else node.setAttribute(k, v === true ? "" : String(v));
  }
  for (const c of children) if (c !== null && c !== undefined && c !== false) node.append(c);
  return node;
}

/** The file picker kept on the page until it answers (one at a time). */
let picking: HTMLInputElement | null = null;

/**
 * Opens the file picker and hands the chosen file to `onFile` (call it from a
 * click). On phones the picker sends the page to the background: the input
 * stays in the page until it answers, so the browser can't drop it meanwhile,
 * and a filter by file extension is left out, since Android's picker greys
 * out files whose type it doesn't know (.jsx, .json, .js…); what the file
 * holds is checked after. A filter by picture type stays.
 */
export function pickFile(onFile: (file: File) => void, accept: string): void {
  picking?.remove();
  const input = document.createElement("input");
  input.type = "file";
  const phone = window.matchMedia?.("(pointer: coarse)").matches ?? false;
  const picturesOnly = accept.split(",").every((a) => a.trim().startsWith("image/"));
  if (!phone || picturesOnly) input.accept = accept;
  input.style.display = "none";
  const done = () => {
    input.remove();
    if (picking === input) picking = null;
  };
  input.addEventListener("change", () => {
    const file = input.files?.[0];
    done();
    if (file) onFile(file);
  });
  input.addEventListener("cancel", done);
  document.body.append(input);
  picking = input;
  input.click();
}
