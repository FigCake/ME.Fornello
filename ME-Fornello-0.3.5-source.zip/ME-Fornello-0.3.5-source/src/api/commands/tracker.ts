// Page commands for Marinara's tracker (the Tracker Panel).

import { type TrackerState, setTrackerValue } from "../../shared/tracker";
import { t } from "../../shared/i18n";
import { cmd } from "../command";
import { onTrackerWrite, trackerWritten } from "../../host/generation-hold";
import { agentList, chatAgents, rerunAgents } from "../features";
import { patchTracker, trackerState } from "../marinara";
import { asText } from "../parse";
import type { PageSession } from "../session";

/** The tracker as plain values, the way getTracker() hands it to pages. */
export function plainTracker(s: TrackerState | null): Record<string, unknown> {
  if (!s) return {};
  const fields = (list: { name: string; value: string }[] | undefined) => Object.fromEntries((list ?? []).map((f) => [f.name, f.value]));
  const stats = (list: { name: string; value: number }[] | null | undefined) => Object.fromEntries((list ?? []).map((x) => [x.name, x.value]));
  return {
    date: s.date ?? "",
    time: s.time ?? "",
    location: s.location ?? "",
    weather: s.weather ?? "",
    temperature: s.temperature ?? "",
    status: s.playerStats?.status ?? "",
    custom: fields(s.playerStats?.customTrackerFields),
    world: fields(s.worldCustomFields),
    persona: stats(s.personaStats),
    characters: (s.presentCharacters ?? []).map((c) => ({
      name: c.name,
      emoji: c.emoji ?? "",
      mood: c.mood ?? "",
      action: c.action ?? "",
      appearance: c.appearance ?? "",
      outfit: c.outfit ?? "",
      thoughts: c.thoughts ?? "",
      stats: stats(c.stats),
      fields: { ...(c.customFields ?? {}) },
    })),
  };
}

/** Changes tracker values by path ({ location: "Library", "custom.mood": "happy" }). */
async function setTracker(s: PageSession, values: Record<string, unknown>): Promise<boolean> {
  const id = s.here();
  const state: TrackerState = (await trackerState(undefined, id)) ?? {};
  const fields = new Set<string>();
  for (const [path, value] of Object.entries(values ?? {})) for (const f of setTrackerValue(state, path, asText(value))) fields.add(f);
  if (fields.size) {
    await patchTracker(state, [...fields], id);
    trackerWritten(id);
  }
  return true;
}

// ── hearing changes ──
// after a possible write (host/generation-hold.ts) the tracker is read and compared with what the page saw last

export type TrackerListener = (tracker: Record<string, unknown>, changed: string[]) => unknown;

/** What changed between two plain trackers, as paths: "location", "custom.mood", "characters". */
export function trackerChanges(before: Record<string, unknown>, after: Record<string, unknown>): string[] {
  const out: string[] = [];
  for (const key of new Set([...Object.keys(before), ...Object.keys(after)])) {
    const a = before[key];
    const b = after[key];
    if (JSON.stringify(a) === JSON.stringify(b)) continue;
    // a group of named fields says which of them changed
    if (a && b && typeof a === "object" && typeof b === "object" && !Array.isArray(a) && !Array.isArray(b)) {
      const was = a as Record<string, unknown>;
      const now = b as Record<string, unknown>;
      for (const k of new Set([...Object.keys(was), ...Object.keys(now)])) if (JSON.stringify(was[k]) !== JSON.stringify(now[k])) out.push(`${key}.${k}`);
    } else out.push(key);
  }
  return out;
}

/** Calls `fn(tracker, changed)` whenever the page's chat's tracker changes; the returned function stops it. */
function onTracker(s: PageSession, fn: TrackerListener): () => void {
  const chatId = s.here();
  let last: Record<string, unknown> | null = null;
  let timer: ReturnType<typeof setTimeout> | null = null;
  // an empty tracker has every field, empty: the first values count as changes of those fields only
  const read = async () => plainTracker((await trackerState(undefined, chatId)) ?? {});
  // what the tracker was when the page started listening
  void read()
    .then((now) => (last ??= now))
    .catch(() => (last ??= {}));
  const check = async () => {
    const now = await read();
    if (s.disposed) return;
    const changed = trackerChanges(last ?? {}, now);
    last = now;
    if (changed.length) await fn(structuredClone(now), changed);
  };
  const stopWatch = onTrackerWrite((id) => {
    if (id !== chatId) return;
    // several writes in a row (a reply's agents) are read once
    if (timer) clearTimeout(timer);
    timer = setTimeout(() => void check().catch(s.report), 300);
  });
  const stop = () => {
    if (timer) clearTimeout(timer);
    stopWatch();
  };
  s.onDispose(stop);
  return stop;
}

/** Runs the chat's trackers again, as Marinara's "Re-run trackers" (the ones run by hand if any, else every tracker and custom agent on). */
export async function runTrackers(s: PageSession): Promise<boolean> {
  const chatId = s.here();
  const [{ on, manual }, agents] = await Promise.all([chatAgents(chatId), agentList()]);
  const known = new Map(agents.map((a) => [a.type, a.category]));
  const builtIn = (type: string) => known.has(type) && known.get(type) !== "custom";
  const types = manual.filter((type) => known.get(type) === "tracker");
  const run = types.length ? types : on.filter((type) => known.get(type) === "tracker" || !builtIn(type));
  if (!run.length) throw new Error(t("No trackers on in this chat.", "이 채팅에 켜진 트래커 없음."));
  const errors = await rerunAgents(chatId, run);
  if (errors.length) throw new Error(errors.join("; "));
  return true;
}

export function trackerCommands(s: PageSession) {
  return {
    getTracker: cmd(async () => plainTracker(await trackerState(undefined, s.here()))),
    setTracker: cmd({ writes: true }, (values: Record<string, unknown>) => setTracker(s, values)),
    onTracker: cmd((fn: TrackerListener) => onTracker(s, fn)),
    runTrackers: cmd({ writes: true, paid: true }, () => runTrackers(s)),
  };
}
