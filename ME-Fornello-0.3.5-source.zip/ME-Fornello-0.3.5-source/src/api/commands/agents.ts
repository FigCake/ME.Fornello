// Page commands for Marinara's agents: the list, running them again, their memory in this chat.

import { t } from "../../shared/i18n";
import { cmd } from "../command";
import { agentList, agentMemory, chatAgents, clearAgentMemory, patchAgentMemory, rerunAgents } from "../features";
import type { PageSession } from "../session";

export interface AgentItem {
  type: string;
  name: string;
  /** "tracker", "custom" (made by the person)… */
  category: string;
  /** On in this chat. */
  on: boolean;
}

async function getAgents(s: PageSession): Promise<AgentItem[]> {
  const [agents, { on }] = await Promise.all([agentList(), chatAgents(s.here())]);
  return agents.map((a) => ({ ...a, on: on.includes(a.type) }));
}

/** An agent by type or name. */
async function agentType(name: unknown): Promise<string> {
  const n = String(name ?? "");
  const found = (await agentList()).find((a) => a.type === n || a.name === n);
  if (!found) throw new Error(t(`No agent: ${n}`, `에이전트 없음: ${n}`));
  return found.type;
}

/** Runs agents again on the latest reply; their errors are one error. */
async function runAgents(s: PageSession, names: unknown): Promise<boolean> {
  const list = Array.isArray(names) ? names : [names];
  const types = await Promise.all(list.map(agentType));
  const errors = await rerunAgents(s.here(), types);
  if (errors.length) throw new Error(errors.join("; "));
  return true;
}

export function agentCommands(s: PageSession) {
  return {
    getAgents: cmd(() => getAgents(s)),
    runAgents: cmd({ writes: true, paid: true }, (names: unknown) => runAgents(s, names)),
    getAgentMemory: cmd(async (name: unknown) => agentMemory(await agentType(name), s.here())),
    // { key: value } merged into the memory (null deletes a key)
    setAgentMemory: cmd({ writes: true }, async (name: unknown, values: Record<string, unknown>) => patchAgentMemory(await agentType(name), s.here(), values ?? {})),
    clearAgentMemory: cmd({ writes: true }, async (name: unknown) => {
      const type = await agentType(name);
      if (!s.ui.confirm(t(`This page wants to clear what agent "${String(name)}" remembers in this chat. Clear?`, `이 페이지가 에이전트 "${String(name)}"의 이 채팅 기억을 지우려고 해요. 지울까요?`))) return false;
      await clearAgentMemory(type, s.here());
      return true;
    }),
  };
}
