// Reading a character card file for the pictures it carries: a .charx (a zip
// with card.json and the pictures), a JPEG with such a zip appended, or a PNG
// card (its JSON and pictures in tEXt chunks). Character Card V3 lists the
// pictures in data.assets; what a picture is comes from its bytes, since the
// name and ext a card gives may be wrong. No DOM, nothing sent anywhere.

import { bytesHash } from "../hash";
import { pngText, unzip, zipStart } from "../scripts/files";
import { alreadyListed } from "./edit";
import type { Asset } from "./model";

/** What a picture's bytes are (the subtype of its image/… type). */
export type PictureType = "png" | "jpeg" | "gif" | "webp" | "avif";

/** What a picture is for: another portrait or a picture of the card (both to the Gallery), or an emotion (a sprite). */
export type PictureKind = "icon" | "picture" | "emotion";

export interface CardPicture {
  kind: PictureKind;
  /** The card's name for it, kept as given (several may share one). */
  name: string;
  /** Where it is in the file. */
  path: string;
  type: PictureType;
  /** The file name to upload it as: its own, with the extension its bytes call for. */
  fileName: string;
  bytes: Uint8Array;
  /** A short hash of the bytes (the same picture imported again is skipped by it). */
  hash: string;
  /** Its image prompt, when the card keeps one beside it (x_meta). */
  prompt?: string;
}

/** Why something in the file is not imported. */
export type LeftOutReason = "portrait" | "user-icon" | "default" | "remote" | "missing" | "not-picture" | "app-data" | "not-listed" | "unknown-uri" | "same-emotion";

export interface LeftOut {
  /** Its name in the card, or its path in the file. */
  what: string;
  reason: LeftOutReason;
}

export interface CardFile {
  /** The card's JSON (null when the file holds none). */
  card: Record<string, unknown> | null;
  /** The character's name in the card (the file's name without one). */
  name: string;
  /** How the file holds the card: a zip (.charx, or appended to a JPEG), PNG chunks, or not at all. */
  form: "zip" | "png" | "none";
  pictures: CardPicture[];
  leftOut: LeftOut[];
  /** The character's own picture, for a character made from the card (none when the card has no readable one). */
  portrait?: { bytes: Uint8Array; type: PictureType };
  /** A bundle (a .zip of a card and what goes with it): the card's own file, to make the character from. */
  source?: { name: string; bytes: Uint8Array };
  /** A bundle's QR sets (SillyTavern's or Dispensa's), for Dispensa. */
  qrSets?: { name: string; json: unknown }[];
  /** A bundle's lorebooks (SillyTavern world info). */
  lorebooks?: { name: string; json: Record<string, unknown> }[];
}

const EXT: Record<PictureType, string> = { png: "png", jpeg: "jpg", gif: "gif", webp: "webp", avif: "avif" };
/** The tEXt keyword in front of a picture's path in a PNG card. */
const PNG_ASSET = "chara-ext-asset_:";
const PROMPT_MAX = 2000;

/** What the bytes are, by their first bytes; null for anything but the pictures Marinara's Gallery takes. */
export function pictureType(b: Uint8Array): PictureType | null {
  const has = (at: number, text: string) => [...text].every((c, i) => b[at + i] === c.charCodeAt(0));
  if (b[0] === 0x89 && has(1, "PNG")) return "png";
  if (b[0] === 0xff && b[1] === 0xd8 && b[2] === 0xff) return "jpeg";
  if (has(0, "GIF8")) return "gif";
  if (has(0, "RIFF") && has(8, "WEBP")) return "webp";
  if (has(4, "ftypavif") || has(4, "ftypavis")) return "avif";
  return null;
}

const fromBase64 = (text: string): Uint8Array | null => {
  try {
    return Uint8Array.from(atob(text.replace(/\s+/g, "")), (c) => c.charCodeAt(0));
  } catch {
    return null;
  }
};

const object = (v: unknown): Record<string, unknown> | null => (v && typeof v === "object" && !Array.isArray(v) ? (v as Record<string, unknown>) : null);

const parseJson = (bytes: Uint8Array | null | undefined): Record<string, unknown> | null => {
  if (!bytes) return null;
  try {
    return object(JSON.parse(new TextDecoder().decode(bytes)));
  } catch {
    return null;
  }
};

/** A path's last part without its extension ("assets/other/image/a_1.png" → "a_1"). */
const stem = (path: string) => path.replace(/^.*\//, "").replace(/\.[^.]*$/, "");

/** The pictures (and what is left out) of a card file; the file's name only names a card that has none. */
export async function readCardFile(fileName: string, bytes: Uint8Array): Promise<CardFile> {
  const files = new Map<string, Uint8Array>();
  let card: Record<string, unknown> | null;
  let form: CardFile["form"] = "none";
  const chunks = pngText(bytes);
  const pngJson = chunks ? (chunks.ccv3 ?? chunks.chara) : undefined;
  if (chunks && pngJson) {
    form = "png";
    card = parseJson(fromBase64(pngJson));
    for (const [key, value] of Object.entries(chunks)) {
      const data = key.startsWith(PNG_ASSET) ? fromBase64(value) : null;
      if (data) files.set(key.slice(PNG_ASSET.length), data);
    }
  } else {
    const entries = await unzip(bytes).catch(() => []);
    if (entries.length) form = "zip";
    for (const e of entries) files.set(e.path, e.data);
    card = parseJson(files.get("card.json"));
    // a card handed round zipped (a .zip holding the .charx, PNG or JPEG card): the card inside
    if (!card) {
      const bundle = await readBundle(entries);
      if (bundle) return bundle;
    }
  }
  const data = object(card?.data) ?? card ?? {};
  const name = (typeof data.name === "string" && data.name.trim()) || fileName.replace(/^.*[\\/]/, "").replace(/\.[^.]*$/, "");

  // prompts kept beside the pictures: x_meta/<picture's name>.json, its Description
  const prompts = new Map<string, string>();
  for (const [path, bytes] of files) {
    const m = /^x_meta\/([^/]+)\.json$/.exec(path);
    const meta = m ? parseJson(bytes) : null;
    if (m && typeof meta?.Description === "string" && meta.Description.trim()) prompts.set(m[1], meta.Description.trim().slice(0, PROMPT_MAX));
  }

  // without a list, a card has its own picture only (the spec's default)
  const list = card ? (Array.isArray(data.assets) ? data.assets : [{ type: "icon", uri: "ccdefault:", name: "main", ext: "png" }]) : [];
  const listed = list.map((raw) => {
    const r = object(raw) ?? {};
    return { type: String(r.type ?? "").trim(), uri: String(r.uri ?? "").trim(), name: String(r.name ?? "").trim() };
  });
  // the portrait is the icon named main (or the first icon when none is): the character's own picture, not an asset
  const icons = listed.filter((a) => a.type === "icon");
  const portrait = icons.find((a) => a.name === "main") ?? icons[0];

  // the portrait's bytes: its file in the card, or for ccdefault: the picture the card sits in (a JPEG before its zip, a PNG card itself)
  let portraitBytes: Uint8Array | null | undefined;
  if (portrait) {
    const at = /^(?:embeded|embedded):\/\/(.+)$/.exec(portrait.uri) ?? /^__asset:(.+)$/.exec(portrait.uri);
    if (at) portraitBytes = files.get(at[1]);
    else if (portrait.uri === "ccdefault:") portraitBytes = form === "png" ? bytes : form === "zip" ? bytes.subarray(0, Math.max(0, zipStart(bytes))) : null;
  }
  const portraitType = portraitBytes?.length ? pictureType(portraitBytes) : null;

  const pictures: CardPicture[] = [];
  const leftOut: LeftOut[] = [];
  const used = new Set(["card.json"]);
  const emotions = new Set<string>();
  for (const a of listed) {
    const inFile = /^(?:embeded|embedded):\/\/(.+)$/.exec(a.uri) ?? /^__asset:(.+)$/.exec(a.uri);
    const path = inFile?.[1] ?? "";
    if (path) used.add(path);
    const what = a.name || path || a.uri;
    const leave = (reason: LeftOutReason) => leftOut.push({ what, reason });
    if (a === portrait) leave("portrait");
    else if (a.type === "user_icon") leave("user-icon");
    else if (a.uri === "ccdefault:") leave("default");
    else if (/^https?:/i.test(a.uri)) leave("remote");
    else {
      let bytes: Uint8Array | null | undefined;
      if (path) bytes = files.get(path);
      else if (/^data:[^,]*;base64,/i.test(a.uri)) bytes = fromBase64(a.uri.slice(a.uri.indexOf(",") + 1));
      else {
        leave("unknown-uri");
        continue;
      }
      if (!bytes) {
        leave(path ? "missing" : "not-picture");
        continue;
      }
      const type = pictureType(bytes);
      if (!type) {
        leave("not-picture");
        continue;
      }
      const kind: PictureKind = a.type === "emotion" ? "emotion" : a.type === "icon" ? "icon" : "picture";
      const own = path ? stem(path) : "";
      const named = a.name || own;
      if (!named) {
        leave("unknown-uri");
        continue;
      }
      // a sprite is kept per expression: a second picture for one would only replace the first
      if (kind === "emotion") {
        if (emotions.has(named.toLowerCase())) {
          leave("same-emotion");
          continue;
        }
        emotions.add(named.toLowerCase());
      }
      const prompt = own ? prompts.get(own) : undefined;
      pictures.push({ kind, name: named, path, type, fileName: `${own || "picture"}.${EXT[type]}`, bytes, hash: bytesHash(bytes), ...(prompt ? { prompt } : {}) });
    }
  }
  // files the card doesn't list: at the root, what isn't a picture is the data of the app that made it
  for (const [path, bytes] of files) {
    if (used.has(path) || /^x_meta\/[^/]+\.json$/.test(path)) continue;
    leftOut.push({ what: path, reason: form === "zip" && !path.includes("/") && !pictureType(bytes) ? "app-data" : "not-listed" });
  }
  return { card, name, form, pictures, leftOut, ...(portraitBytes && portraitType ? { portrait: { bytes: portraitBytes, type: portraitType } } : {}) };
}

const PICTURE_FILE = /\.(png|jpe?g|gif|webp|avif)$/i;

/** What a JSON file in a bundle is: a character card, a QR set, a lorebook, or none of them. */
function jsonKind(json: Record<string, unknown> | null): "card" | "qr" | "lorebook" | null {
  if (!json) return null;
  if (Array.isArray(json.qrList) || (json.format === "dispensa-qr" && Array.isArray(json.sets))) return "qr";
  const data = object(json.data) ?? json;
  if (String(json.spec ?? "").startsWith("chara_card") || (typeof data.name === "string" && ("first_mes" in data || "description" in data))) return "card";
  if (json.entries && typeof json.entries === "object") return "lorebook";
  return null;
}

/**
 * A bundle: a .zip holding a card (.charx, PNG, JPEG, or JSON), pictures beside it (in folders, or in
 * .zips inside), a QR set and a lorebook. The pictures are named after their files. Null when no card is in it.
 */
async function readBundle(entries: { path: string; data: Uint8Array }[]): Promise<CardFile | null> {
  // pictures in a .zip inside count too
  const all = [...entries];
  for (const e of entries) if (/\.zip$/i.test(e.path)) for (const inner of await unzip(e.data).catch(() => [])) all.push({ path: `${e.path}/${inner.path}`, data: inner.data });
  let found: CardFile | null = null;
  let cardPath = "";
  for (const e of all.filter((x) => /\.(charx|png|jpe?g)$/i.test(x.path))) {
    const inner = await readCardFile(e.path, e.data).catch(() => null);
    if (inner?.card) {
      found = inner;
      cardPath = e.path;
      break;
    }
  }
  const qrSets: CardFile["qrSets"] = [];
  const lorebooks: CardFile["lorebooks"] = [];
  for (const e of all.filter((x) => /\.json$/i.test(x.path))) {
    const json = parseJson(e.data);
    const kind = jsonKind(json);
    const name = stem(e.path);
    if (kind === "card" && !found) {
      const data = object(json!.data) ?? json!;
      found = { card: json, name: (typeof data.name === "string" && data.name.trim()) || name, form: "none", pictures: [], leftOut: [] };
      cardPath = e.path;
      // a set is called what its file says inside, as Dispensa will call it
    } else if (kind === "qr") qrSets.push({ name: typeof json!.name === "string" && json!.name.trim() ? json!.name.trim() : name, json });
    else if (kind === "lorebook") lorebooks.push({ name, json: json! });
  }
  if (!found) return null;
  const pictures = [...found.pictures];
  for (const e of all) {
    if (e.path === cardPath || !PICTURE_FILE.test(e.path)) continue;
    const type = pictureType(e.data);
    if (!type) continue;
    const own = stem(e.path);
    // named as the file, extension and all (one name in two types stays two pictures)
    pictures.push({ kind: "picture", name: e.path.replace(/^.*\//, ""), path: e.path, type, fileName: `${own}.${EXT[type]}`, bytes: e.data, hash: bytesHash(e.data) });
  }
  const source = all.find((e) => e.path === cardPath);
  return { ...found, pictures, leftOut: found.leftOut, ...(source ? { source: { name: source.path.replace(/^.*\//, ""), bytes: source.data } } : {}), ...(qrSets.length ? { qrSets } : {}), ...(lorebooks.length ? { lorebooks } : {}) };
}

/**
 * The pictures still to import into a card whose list is `assets`: a Gallery
 * picture listed already under the same name with the same bytes (the card
 * imported before, or the same picture twice in it) is skipped. Emotions all
 * go: a sprite of the same expression is replaced, never doubled.
 */
export function picturesToImport(pictures: CardPicture[], assets: Asset[]): CardPicture[] {
  const seen = [...assets];
  return pictures.filter((p) => {
    if (p.kind === "emotion") return true;
    if (alreadyListed(seen, p.name, p.hash)) return false;
    seen.push({ name: p.name, file: p.path, place: "gallery", hash: p.hash });
    return true;
  });
}
