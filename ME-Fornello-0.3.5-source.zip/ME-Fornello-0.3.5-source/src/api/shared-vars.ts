// Chat variables (and SillyTavern's chat_metadata) shared by every page of a
// chat: what one sets, the others read at once.

import { currentChatId } from "../host/current-chat";
import { onGenerationComplete } from "../host/events";
import { readVariables } from "./chat-data";

export interface SharedChat {
  values: Record<string, unknown>;
  /** Writes still on their way: a fresh read could miss them. */
  writing: number;
  /** SillyTavern's chat_metadata: one object for every page, as there. */
  meta: Record<string, unknown>;
}

const byChat = new Map<string, SharedChat>();

/** A value the page can change without changing what is kept (or what other pages see). */
export function copyOf<T>(value: T): T {
  if (value === null || typeof value !== "object") return value;
  try {
    return structuredClone(value);
  } catch {
    return JSON.parse(JSON.stringify(value)) as T;
  }
}

/** What was read from the server becomes what every page reads, unless a write is still on its way. */
function takeFresh(shared: SharedChat, fresh: Record<string, unknown>): void {
  if (shared.writing) return;
  for (const k of Object.keys(shared.values)) delete shared.values[k];
  Object.assign(shared.values, fresh);
}

/** The chat's shared variables, brought up to date with what was just read. */
export function sharedChat(chatId: string, loaded: Record<string, unknown>, meta: Record<string, unknown>): SharedChat {
  let found = byChat.get(chatId);
  if (!found) {
    found = { values: { ...loaded }, writing: 0, meta: { ...meta } };
    byChat.set(chatId, found);
  } else {
    // set elsewhere meanwhile (STscript /setvar, Marinara itself, a reply)
    takeFresh(found, loaded);
  }
  return found;
}

/** A copy of its own for a preview: it changes nothing. */
export const privateChat = (loaded: Record<string, unknown>, meta: Record<string, unknown>): SharedChat => ({ values: { ...loaded }, writing: 0, meta: { ...meta } });

/** Variables read again (after a reply, or a slash command that may have set some). */
export async function refreshShared(chatId: string): Promise<void> {
  const shared = byChat.get(chatId);
  if (!shared || shared.writing) return;
  takeFresh(shared, await readVariables(chatId));
}

/** A reply can set variables too ({{setvar}}): they are read again once it is done. The returned stop forgets every chat's. */
export function startSharedVars(): () => void {
  const stopListening = onGenerationComplete((chatId) => {
    const id = chatId ?? currentChatId();
    if (id) void refreshShared(id).catch(() => undefined);
  });
  return () => {
    stopListening();
    byChat.clear();
  };
}
