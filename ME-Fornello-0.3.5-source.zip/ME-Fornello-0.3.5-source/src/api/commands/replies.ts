// Page commands around replies: onBeforeGen, onGenDone / onGenError, and
// inject (text in the prompt of the next replies).

import { type GenKind, onGenerationEnd, onGenerationStart } from "../../host/generation-hold";
import { cmd } from "../command";
import { type Injection, type InjectPosition, inject, uninject } from "../injections";
import type { PageSession } from "../session";

export interface InjectOptions {
  /** Same id: the earlier text is replaced. */
  id?: string;
  position?: InjectPosition;
  depth?: number;
  role?: "system" | "user" | "assistant";
  /** Only for the next reply. */
  once?: boolean;
}

/** What onBeforeGen's listener gets. */
export interface BeforeGen {
  kind: GenKind;
  /** The number of the message written again or continued (regenerate, continue). */
  num: number | null;
  /** What the person sent with it. */
  userMessage: string | null;
  /** Text in the prompt of this reply only. */
  inject(text: unknown, options?: Omit<InjectOptions, "once">): Promise<void>;
}

let counter = 0;

/** Puts text in the chat's next prompts for this page; it goes when taken out, after one reply (once), or with the page. */
export async function injectFor(s: PageSession, text: unknown, options: InjectOptions = {}): Promise<{ id: string; remove: () => Promise<void> }> {
  const chatId = s.here();
  const id = options.id ? String(options.id) : `${Date.now().toString(36)}-${++counter}`;
  const injection: Injection = { id, content: String(text ?? ""), position: options.position, depth: options.depth, role: options.role, once: options.once };
  await inject(chatId, injection);
  if (!options.once) s.onDispose(() => void uninject(chatId, [id]));
  return { id, remove: () => uninject(chatId, [id]) };
}

/** Listens for the moment before a reply in the page's chat; the reply waits for the listener (5 s at most). */
export function beforeGen(s: PageSession, fn: unknown, call: (fn: (...a: unknown[]) => unknown, gen: BeforeGen) => unknown): () => void {
  if (typeof fn !== "function") return () => {};
  const stop = onGenerationStart((start) => {
    if (s.disposed || start.chatId !== s.here()) return;
    const num = start.messageId ? (s.messages.find((m) => m.id === start.messageId)?.num ?? null) : null;
    const gen: BeforeGen = {
      kind: start.kind,
      num,
      userMessage: start.userMessage,
      inject: async (text, options = {}) => void (await injectFor(s, text, { ...options, once: true })),
    };
    return call(fn as (...a: unknown[]) => unknown, gen);
  });
  s.onDispose(stop);
  return stop;
}

/** Listens for the end of replies in the page's chat: those that went well (done) or not. */
function afterGen(s: PageSession, fn: unknown, wantOk: boolean): () => void {
  if (typeof fn !== "function") return () => {};
  const stop = onGenerationEnd((gen, ok) => {
    if (s.disposed || ok !== wantOk || gen.chatId !== s.here()) return;
    try {
      void Promise.resolve((fn as () => unknown)()).catch(s.report);
    } catch (e) {
      s.report(e);
    }
  });
  s.onDispose(stop);
  return stop;
}

export function replyCommands(s: PageSession) {
  return {
    onBeforeGen: cmd((fn: unknown) => beforeGen(s, fn, (f, gen) => f(gen))),
    onGenDone: cmd((fn: unknown) => afterGen(s, fn, true)),
    onGenError: cmd((fn: unknown) => afterGen(s, fn, false)),
    inject: cmd({ writes: true }, (text: unknown, options?: InjectOptions) => injectFor(s, text, options)),
  };
}
