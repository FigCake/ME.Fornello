// The rule that tells the AI to write a component's tag, and putting it in the
// chat's own lorebook. Two drafts:
//   - status: the tag at the end of every reply (drawn under the reply);
//   - scene: the tag only when the story calls for it, drawn where it is (with
//     attributes, in a ```fornello block so Markdown leaves them alone).
// Text for the AI is English whatever the screen language.

import { chatLoreBook, createLoreEntry, loreEntries, patchLoreEntry } from "../api/marinara";
import type { LoreBook } from "../api/types";
import type { ComponentField, FieldType } from "./fields";
import type { BodyFormat, ComponentUse } from "./model";

const VALUES = `Keep the tag name and the value names exactly as they are. Write lists and objects as {[...]} / {{...}} and text as "...".`;

/** The status rule's first lines; the example tag follows. */
export const RULE_HEAD = (name: string) =>
  `[Component: ${name}]\nAt the very end of every reply, write the tag below on one line. Fill in the values for the scene as it is now, and write every value again each time, even the ones that did not change. ${VALUES}`;

/** The fence a scene component's tag goes in (host.ts draws the component in its place). */
export const SCENE_FENCE = "fornello";

const KIND: Record<FieldType, string> = { text: "text", number: "number", bool: "true or false", list: "list", object: "object" };

/** One line per value: its kind and what to write in it. */
function valueLines(fields: ComponentField[], title = "Values"): string {
  if (!fields.length) return "";
  return `\n${title}:\n${fields.map((f) => `- ${f.name} (${KIND[f.type]})${f.instruction.trim() ? `: ${f.instruction.trim().replace(/\s*\n\s*/g, " ")}` : ""}`).join("\n")}`;
}

/** How to write the text inside the tag. */
function bodyLine(format: BodyFormat, fields: ComponentField[]): string {
  const parts = fields.map((f) => f.name).join(format.sep === ":" ? ": " : "|");
  const split = `Separate the parts with "${format.sep}"; only the last part may contain "${format.sep}" itself.`;
  return format.lines ? `Inside the tag, write one line per item: ${parts || "the text"}. ${split}` : `Inside the tag, write the values in this order: ${parts || "the text"}. ${split}`;
}

/** The rule for a component: `example` its filled tag, `when` (scene) when to use it, `body` values as text inside the tag. */
export function componentRule(name: string, use: ComponentUse, example: string, when = "", fields: ComponentField[] = [], body?: BodyFormat): string {
  if (body) {
    const values = valueLines(fields, body.lines ? "Parts of each line" : "Values");
    if (use === "status") return `[Component: ${name}]\nAt the very end of every reply, write the tag below. Fill it in for the scene as it is now. ${bodyLine(body, fields)}\n${example}${values}`;
    return [
      `[Component: ${name}]`,
      `Use it only when: ${when.trim() || "the story calls for it"}.`,
      `When the story reaches that moment, write the tag right there, on lines of its own between two paragraphs. ${bodyLine(body, fields)}`,
      example,
      `Fill it in from the scene. Leave it out when the moment does not call for it.`,
    ].join("\n") + values;
  }
  if (use === "status") return `${RULE_HEAD(name)}\n${example}${valueLines(fields)}`;
  return [
    `[Component: ${name}]`,
    `Use it only when: ${when.trim() || "the story calls for it"}.`,
    `When the story reaches that moment, put the tag right there, between two paragraphs, in a code block of its own:`,
    "```" + SCENE_FENCE,
    example,
    "```",
    `Fill in the values from the scene. Leave it out when the moment does not call for it, and do not write it again in the same reply unless the scene changes. ${VALUES}`,
  ].join("\n") + valueLines(fields);
}

/** Adds the rule to the chat's lorebook as an always-on entry, or updates the one already there. */
export async function ruleToChatBook(chatId: string, name: string, rule: string): Promise<LoreBook> {
  const book = await chatLoreBook(chatId);
  const entryName = `Fornello component rule: ${name}`;
  const same = (await loreEntries(book.id)).find((e) => e.name === entryName);
  if (same) await patchLoreEntry(book.id, same.id, { name: entryName, content: rule, enabled: true, constant: true });
  else await createLoreEntry(book.id, { name: entryName, content: rule, enabled: true, constant: true, position: 2, depth: 1, order: 900 });
  return book;
}
