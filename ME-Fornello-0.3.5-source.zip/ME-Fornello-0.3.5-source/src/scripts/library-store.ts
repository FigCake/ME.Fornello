// What page commands reach of the scripts outside any page: the person's own
// list and the scripts running now (set by main.ts; none in tests without it).

import type { LibraryItem } from "./model";

export interface LibraryStore {
  /** The person's own scripts and folders (every chat). */
  global(): LibraryItem[];
  setGlobal(items: LibraryItem[]): Promise<void>;
  /** A card's or a chat's scripts changed: start and stop what that changes. */
  refresh(): void;
  /** The visible buttons of the scripts running now, by script id (getAllEnabledScriptButtons). */
  buttons(): Record<string, { button_id: string; button_name: string }[]>;
}

let store: LibraryStore | null = null;

export function setLibraryStore(next: LibraryStore | null): void {
  store = next;
}

export const libraryStore = (): LibraryStore | null => store;
