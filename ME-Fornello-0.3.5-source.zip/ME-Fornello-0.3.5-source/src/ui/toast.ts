// showToast: a small note in the corner, in the theme's colors.

import { findComposer } from "../shared/composer";
import { THEME_TOKENS } from "../shared/theme";

const STYLE = `
${THEME_TOKENS}
:host { position: fixed; right: 16px; bottom: 16px; z-index: 2147483000; display: flex; flex-direction: column; gap: 8px; align-items: flex-end; pointer-events: none; }
.t { pointer-events: auto; max-width: min(360px, calc(100vw - 32px)); padding: 9px 13px; font: 13px/1.4 var(--d-font); color: var(--d-text);
  background: var(--d-panel-solid); border: 1px solid var(--d-line); border-left: 3px solid var(--d-accent); border-radius: var(--d-radius); box-shadow: var(--d-shadow);
  white-space: pre-wrap; word-break: break-word; animation: in .18s ease-out; }
.t.success { border-left-color: #3fb97a; }
.t.warning { border-left-color: #e6a23c; }
.t.error { border-left-color: var(--d-danger); }
@keyframes in { from { opacity: 0; transform: translateY(6px); } to { opacity: 1; transform: none; } }
`;

let root: ShadowRoot | null = null;

export type ToastKind = "info" | "success" | "warning" | "error";

export function showToast(text: string, kind: ToastKind = "info"): void {
  if (!root || !root.host.isConnected) {
    const host = document.createElement("div");
    host.id = "fornello-toasts";
    root = host.attachShadow({ mode: "open" });
    const style = document.createElement("style");
    style.textContent = STYLE;
    root.append(style);
    document.body.append(host);
  }
  // above the chat input, so a note never covers the Send button
  const box = findComposer()?.container.getBoundingClientRect();
  const bottom = box && box.height > 0 ? Math.max(16, Math.round(window.innerHeight - box.top + 8)) : 16;
  (root.host as HTMLElement).style.bottom = `${bottom}px`;
  const note = document.createElement("div");
  note.className = `t ${kind}`;
  note.setAttribute("role", "status");
  note.textContent = text;
  root.append(note);
  setTimeout(() => note.remove(), kind === "error" ? 6000 : 3500);
}

/** Takes the notes away (Fornello turned off). */
export function removeToasts(): void {
  root?.host.remove();
  root = null;
}
