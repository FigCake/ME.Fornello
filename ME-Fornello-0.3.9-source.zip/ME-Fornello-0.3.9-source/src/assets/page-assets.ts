// Picture names in a page's code (an HTML page in a reply, or one another extension shows):
// {{raw::name}} becomes the picture's address and [img:name] the picture, from the open chat's
// characters' assets, as in replies. A name no character has is left as written.

import { chatCharacters } from "../api/chat-store";
import { currentChatId } from "../host/current-chat";
import { type Asset, assetUrl, cardAssets, withSprites } from "./model";
import { findAssets, pickOne, samePerson } from "./names";
import { spriteListOf } from "./store";
import { findTags, mayHoldTags } from "./tags";

interface Owned {
  id: string;
  name: string;
  assets: Asset[];
}

/** The chat's characters' assets, read once a chat for a short while (pages come in groups). */
let cached: { chatId: string; at: number; people: Promise<Owned[]> } | null = null;

/** Read again next time (a card's assets were saved, or Fornello stops). */
export function forgetPageAssets(): void {
  cached = null;
}
const KEEP_MS = 30_000;

function chatAssets(chatId: string): Promise<Owned[]> {
  if (cached && cached.chatId === chatId && Date.now() - cached.at < KEEP_MS) return cached.people;
  const people = chatCharacters(chatId).then((cast) =>
    Promise.all(
      cast.map(async (c) => {
        return { id: c.id, name: c.name, assets: withSprites(cardAssets(c.data), await spriteListOf(c.id).catch(() => [])) };
      }),
    ),
  );
  cached = { chatId, at: Date.now(), people };
  people.catch(() => cached?.people === people && (cached = null));
  return people;
}

/** The picture a tag means among the chat's characters (the first that has it), or null. */
function pick(people: Owned[], name: string, person?: string): string | null {
  // a person named may be one of the characters (their own pictures), else someone in a card's assets
  const owner = person ? people.find((p) => samePerson(person, p.name)) : undefined;
  const order = owner ? [owner, ...people.filter((p) => p !== owner)] : people;
  for (const p of order) {
    const one = pickOne(findAssets(p.assets, { name, ...(person && p !== owner ? { person } : {}) }), name);
    if (one) return assetUrl(p.id, one);
  }
  return null;
}

const escapeAttr = (s: string) => s.replace(/&/g, "&amp;").replace(/"/g, "&quot;").replace(/</g, "&lt;");

/** The code with its picture tags filled in; the same code when it has none (or no chat is open). */
export async function fillPageAssets(code: string, chatId = currentChatId()): Promise<string> {
  if (!chatId || !mayHoldTags(code)) return code;
  const people = await chatAssets(chatId).catch(() => [] as Owned[]);
  if (!people.some((p) => p.assets.length)) return code;
  let out = code;
  for (const tag of findTags(code, people.map((p) => p.name)).reverse()) {
    const url = pick(people, tag.name, tag.person);
    if (!url) continue;
    const put = tag.kind === "raw" ? url : `<img src="${escapeAttr(url)}" alt="${escapeAttr(tag.name)}" style="max-width:100%">`;
    out = out.slice(0, tag.start) + put + out.slice(tag.end);
  }
  return out;
}

/** A character's assets by name and address, for another extension (Dispensa's /assets). */
export async function chatAssetList(chatId = currentChatId()): Promise<{ character: string; name: string; url: string; person?: string }[]> {
  if (!chatId) return [];
  const people = await chatAssets(chatId).catch(() => [] as Owned[]);
  return people.flatMap((p) => p.assets.map((a) => ({ character: p.name, name: a.name, url: assetUrl(p.id, a), ...(a.person ? { person: a.person } : {}) })));
}

/** The address of the picture a name means in the open chat, or "". */
export async function chatAssetUrl(name: string, person?: string, chatId = currentChatId()): Promise<string> {
  if (!chatId || !name.trim()) return "";
  return pick(await chatAssets(chatId).catch(() => [] as Owned[]), name.trim(), person) ?? "";
}
