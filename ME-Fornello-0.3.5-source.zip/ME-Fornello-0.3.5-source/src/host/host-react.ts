// Marinara's React (on window): components draw with it, and pages that load
// React from a CDN get it instead, running at full speed outside the interpreter.

import { t } from "../shared/i18n";

/* eslint-disable @typescript-eslint/no-explicit-any */
export type AnyReact = any;

export function hostReact(): { React: AnyReact; ReactDOM: AnyReact } {
  const g = globalThis as { React?: AnyReact; ReactDOM?: AnyReact };
  if (!g.React?.createElement || !g.ReactDOM?.createRoot) throw new Error(t("Could not find Marinara's React.", "마리나라의 React를 찾지 못했어요."));
  return { React: g.React, ReactDOM: g.ReactDOM };
}

/** React and ReactDOM for a page, with ReactDOM.render / unmountComponentAtNode (gone in React 19, still used by pages). */
export function pageReact(): { React: AnyReact; ReactDOM: AnyReact } {
  const { React, ReactDOM } = hostReact();
  const roots = new WeakMap<Element, AnyReact>();
  const dom: AnyReact = Object.create(ReactDOM);
  if (typeof ReactDOM.render !== "function") {
    dom.render = (element: unknown, container: Element, callback?: () => void) => {
      let root = roots.get(container);
      if (!root) roots.set(container, (root = ReactDOM.createRoot(container)));
      root.render(element);
      if (typeof callback === "function") queueMicrotask(callback);
    };
  }
  if (typeof ReactDOM.unmountComponentAtNode !== "function") {
    dom.unmountComponentAtNode = (container: Element) => {
      const root = roots.get(container);
      if (!root) return false;
      root.unmount();
      roots.delete(container);
      return true;
    };
  }
  return { React, ReactDOM: dom };
}
