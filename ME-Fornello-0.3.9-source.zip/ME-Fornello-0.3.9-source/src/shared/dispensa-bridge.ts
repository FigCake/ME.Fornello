// Same file in Dispensa and Fornello (src/shared/): after a change, run
// `npm run shared -- sync <path to the other repository>`.

// window.__dispensa: what Dispensa offers other extensions (Dispensa's
// src/bridge.ts puts it up). Fornello runs STscript through it (runSlash,
// triggerSlash) and shows its script buttons in the Dock; Polyglot adds its
// commands. Kept here so both sides read the same shape.

/** Dispensa says this on window each time it starts (an extension that started first registers then). */
export const DISPENSA_READY = "dispensa:ready";
/** Dispensa says this on window when its Dock is shown or hidden. */
export const DISPENSA_DOCK = "dispensa:dock";

/** Another extension's buttons (Fornello's scripts): one bubble in the Dock, its menu lists them. */
export interface DockGroup {
  name: string;
  /** An emoji. */
  icon: string;
  items: { label: string; title?: string; /** Items with the same group sit under one heading. */ group?: string; run(): void }[];
  /** Taken off in the Dock's settings: the extension stops putting it there (missing: it can't be taken off). */
  remove?(): void;
}

/** A command another extension adds to Dispensa's scripts and QRs (Polyglot's /pg-translate…). */
export interface ExternalCommand {
  name: string;
  aliases?: string[];
  /** One line for the editor's command list. */
  help: string;
  /** The extension's name, shown on the command in the editor. */
  from: string;
  /** Gets the unnamed argument and the named ones as text; what it returns goes down the pipe. */
  run(args: { text: string; named: Record<string, string> }): unknown;
}

export interface DispensaBridge {
  version: 1;
  /** Runs an STscript line (SillyTavern numbering) and returns its pipe. */
  runSlash(text: string): Promise<string>;
  /** Opens Dispensa's window (Fornello's settings link to it). */
  openSettings?(): void;
  /** Adds another extension's command; returns what takes it out. */
  registerCommand?(def: ExternalCommand): () => void;
  /**
   * Adds a QR file's sets (SillyTavern's or Dispensa's) to the Library, as its Import does; how many QRs
   * came in (0: not a QR file). `characterId`: the sets are on in that character's chats (a card's own QRs).
   */
  importQrs?(json: unknown, name: string, options?: { characterId?: string }): Promise<number>;
  /** Puts another extension's buttons in the Dock as one bubble; null takes it out. */
  setDockGroup?(id: string, group: DockGroup | null): void;
  /**
   * Whether the Dock is shown (its switch by the input box is on): when it is
   * not, Fornello lists its buttons in the top-bar menu instead. Missing:
   * counts as shown.
   */
  dockShown?(): boolean;
}

declare global {
  interface Window {
    __dispensa?: DispensaBridge;
  }
}
