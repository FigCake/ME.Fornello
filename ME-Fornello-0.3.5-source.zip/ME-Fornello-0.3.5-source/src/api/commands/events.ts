// on("name", fn) / emit("name", …values): events pages and scripts send each other.

import { cmd } from "../command";
import { emitEvent, onEvent } from "../event-bus";
import type { PageSession } from "../session";

/** Listens to one of the events pages and scripts send each other, until the page goes. */
export function listenTo(s: PageSession, name: string, fn: unknown): () => void {
  if (typeof fn !== "function") return () => {};
  const stop = onEvent(name, fn as (...a: unknown[]) => unknown);
  s.onDispose(stop);
  return stop;
}

export function eventCommands(s: PageSession) {
  return {
    on: cmd((name: unknown, fn: unknown) => listenTo(s, String(name), fn)),
    emit: cmd((name: unknown, ...values: unknown[]) => emitEvent(String(name), values, s.report)),
  };
}
