// Running one background script in the interpreter, in Marinara's own window.
// When it stops, its timers, window and document listeners, observers, and
// the elements it created and left right in <body> or <head> go with it
// (markup added through innerHTML or deeper in Marinara's elements stays).

import Sval from "sval";
import { TICK, guardLoops, settle, tick } from "../runtime/guard";
import { clearTracked, sandboxScope } from "../runtime/scope";
import { ModuleSystem, importsOf, isModuleCode, toCommonJs } from "../runtime/modules";

export interface RunningScript {
  stop(): void;
  /** It could not start (its code does not parse): nothing of it runs. */
  readonly failed: boolean;
}

type Tracked = [EventTarget, string, EventListenerOrEventListenerObject, boolean | AddEventListenerOptions | undefined];

/** `target`'s add/removeEventListener, remembering what was added so it can all go. */
function trackListeners(target: EventTarget, tracked: Tracked[]) {
  return {
    addEventListener: (type: string, fn: EventListenerOrEventListenerObject, opts?: boolean | AddEventListenerOptions) => {
      target.addEventListener(type, fn, opts);
      tracked.push([target, type, fn, opts]);
    },
    removeEventListener: (type: string, fn: EventListenerOrEventListenerObject, opts?: boolean | EventListenerOptions) => {
      target.removeEventListener(type, fn, opts);
      const i = tracked.findIndex(([t2, ty, f]) => t2 === target && ty === type && f === fn);
      if (i >= 0) tracked.splice(i, 1);
    },
  };
}

/** Marinara's document, with its listeners tracked and the elements made through it remembered (in `made`). */
function trackedDocument(tracked: Tracked[], made: WeakSet<Node>): Document {
  const own = trackListeners(document, tracked);
  const create = {
    createElement: (...a: Parameters<Document["createElement"]>) => remember(document.createElement(...a)),
    createElementNS: (ns: string | null, name: string, options?: string | ElementCreationOptions) => remember(document.createElementNS(ns, name, options)),
  };
  function remember<T extends Node>(node: T): T {
    made.add(node);
    return node;
  }
  const bound = new WeakMap<object, unknown>();
  return new Proxy(document, {
    get(target, prop) {
      if (prop === "addEventListener" || prop === "removeEventListener") return own[prop];
      if (prop === "createElement" || prop === "createElementNS") return create[prop];
      const value = Reflect.get(target, prop, target);
      if (typeof value === "function" && typeof prop === "string" && /^[a-z]/.test(prop)) {
        let fn = bound.get(value);
        if (!fn) bound.set(value, (fn = value.bind(target)));
        return fn;
      }
      return value;
    },
    set: (target, prop, value) => Reflect.set(target, prop, value, target),
  });
}

type Observer = { disconnect(): void };

/** The window's observer classes, each instance remembered in `live` until it disconnects. */
function trackedObservers(live: Set<Observer>): Record<string, unknown> {
  const out: Record<string, unknown> = {};
  for (const name of ["MutationObserver", "ResizeObserver", "IntersectionObserver"] as const) {
    const Real = window[name] as unknown as (new (...a: never[]) => Observer) | undefined;
    if (typeof Real !== "function") continue;
    out[name] = class extends Real {
      constructor(...a: never[]) {
        super(...a);
        live.add(this);
      }
      override disconnect(): void {
        super.disconnect();
        live.delete(this);
      }
    };
  }
  return out;
}

/** A script's first syntax error, with its line (from 1) when the parser gives one; null when it reads fine. */
export function checkScript(code: string): { message: string; line: number | null } | null {
  try {
    // as it will run: a module as CommonJS, all of it in an async function
    guardLoops(`(async () => {\n${isModuleCode(code) ? toCommonJs(code) : code}\n})`);
    return null;
  } catch (e) {
    const message = e instanceof Error ? e.message : String(e);
    const at = /\((\d+):(\d+)\)/.exec(message);
    // the first line is the async function's
    return { message: message.replace(/\s*\(\d+:\d+\)\s*$/, ""), line: at ? Math.max(1, Number(at[1]) - 1) : null };
  }
}

/** Starts a script with its page commands (`globals`); errors go to `report`. import / export makes it a module. */
export async function runScript(code: string, globals: Record<string, unknown>, report: (e: unknown) => void, onScope?: (define: (name: string, value: unknown) => void) => void): Promise<RunningScript> {
  const timers = new Set<number>();
  const tracked: Tracked[] = [];
  const observers = new Set<Observer>();
  const made = new WeakSet<Node>();
  const stop = () => {
    for (const id of timers) clearTracked(window, id);
    timers.clear();
    for (const [target, type, fn, opts] of tracked.splice(0)) target.removeEventListener(type, fn, opts);
    for (const o of [...observers]) o.disconnect();
    observers.clear();
    // what it made and left right in <body> or <head> (a style, a floating panel)
    for (const parent of [document.body, document.head]) {
      for (const child of parent ? [...parent.children] : []) if (made.has(child)) child.remove();
    }
  };
  // its code does not parse: nothing runs, and it says so
  const problem = isModuleCode(code) ? checkScript(code) : null;
  if (problem) {
    report(new SyntaxError(problem.line ? `${problem.message} (line ${problem.line})` : problem.message));
    return { stop, failed: true };
  }
  let failed = false;
  let define: (name: string, value: unknown) => void = () => {};
  const scope = sandboxScope(window as Window & typeof globalThis, trackedDocument(tracked, made), { ...trackedObservers(observers), ...globals, ...trackListeners(window, tracked) }, timers, {
    report,
    onScope: (d) => {
      define = d;
      onScope?.(d);
    },
  });
  const interp = new Sval({ ecmaVer: "latest", sandBox: true });
  const runIn = (source: string) => {
    settle();
    interp.run(`with (__fornelloScope) {\n${source}\n}`);
  };
  const modules = new ModuleSystem(runIn, report);
  interp.import({ __fornelloScope: scope, [TICK]: tick, __fornelloReport: report, __fornelloDefine: modules.define });
  try {
    await modules.builtins(code, importsOf(code).map((r) => r.spec), define, report);
    // a module runs on by itself (its top-level await may wait long), as a plain script does
    if (isModuleCode(code)) void modules.runModule(code).catch(report);
    // its own scope where `await` works at the top, as a module's; only a parse error throws here
    else if (code.trim()) runIn(guardLoops(`(async () => {\n${code}\n})().catch(__fornelloReport);`));
  } catch (e) {
    failed = true;
    report(e);
  }
  return { stop, failed };
}
