// Pesto's values shown in Marinara's own tracker, as the World panel's custom fields (one a
// value, named by its path). The names Pesto put there are kept in the chat's data; fields
// that are not Pesto's (the person's, an agent's) are kept as they are, even with a name of the
// card's; Pesto's are replaced with the values now, and one hidden now (or gone from the card,
// or all when turned off) is taken out.

import { shownValues } from "./prompt";
import type { Definition } from "./engine";

type Obj = Record<string, unknown>;

export interface TrackerField {
  name: string;
  value: string;
  icon?: string | null;
}

/** Marinara compares the fields' names this way (so "HP" and "hp" are one field). */
export const fieldKey = (name: string) => name.trim().normalize("NFKC").toLocaleLowerCase("en-US").replace(/\s+/gu, " ");

/** The tracker's custom fields with Pesto's values in them, and the names Pesto holds after that.
 *  Only fields Pesto put there (`owned`) are changed or taken out: a field of the same name that was
 *  already there (the person's, an agent's) stays as it is, and that value isn't shown. New ones go at the end. */
export function mergeFields(existing: readonly TrackerField[], def: Definition, values: Obj | null, owned: ReadonlySet<string>): { fields: TrackerField[]; owned: Set<string> } {
  const ours: TrackerField[] = values ? shownValues(def, values).map(([name, value]) => ({ name, value })) : [];
  const oursByKey = new Map(ours.map((f) => [fieldKey(f.name), f]));
  const fields: TrackerField[] = [];
  const now = new Set<string>();
  for (const f of existing) {
    const key = fieldKey(f.name);
    if (!owned.has(key)) {
      fields.push(f);
      oursByKey.delete(key);
      continue;
    }
    const mine = oursByKey.get(key);
    // ours from before: the value now, in its place (with the icon the person may have given it); gone when hidden or off
    if (mine) {
      fields.push({ ...f, value: mine.value });
      now.add(key);
      oursByKey.delete(key);
    }
  }
  for (const [key, f] of oursByKey) {
    fields.push(f);
    now.add(key);
  }
  return { fields, owned: now };
}

/** Whether two field lists show the same (no write needed). */
export const sameFields = (a: readonly TrackerField[], b: readonly TrackerField[]) =>
  a.length === b.length && a.every((f, i) => f.name === b[i].name && f.value === b[i].value && (f.icon ?? null) === (b[i].icon ?? null));
