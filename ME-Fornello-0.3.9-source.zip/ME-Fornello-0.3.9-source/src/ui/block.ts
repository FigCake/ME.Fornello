// One page on screen (chat code blocks, and Dispensa's viewer through
// window.__fornello): it sits on the message like its own text, with round
// buttons in its corner on hover.

import { type PageApi, pageApi } from "../api/page-api";
import { type PreparedPage, preparePage } from "../runtime/prepare";
import { mayHoldTags } from "../assets/tags";
import { type MountedPage, mountPage } from "../runtime/page";
import type { Settings } from "../settings";
import { capturePage, saveBlob } from "../shared/capture";
import { ICON_EXPAND, ICON_GEAR, ICON_IMAGE, ICON_RERUN, ICON_SHRINK } from "./icons";
import { HOVER_TOOLS, THEME_TOKENS } from "../shared/theme";
import { t } from "../shared/i18n";
import { standApart } from "./stand-apart";
import { toolButton } from "./tool-button";
import { screenUi } from "./page-ui";

const STYLE = `
${THEME_TOKENS}
:host { display: block; margin: 6px 0; }
* { box-sizing: border-box; }
.wrap { position: relative; }
${HOVER_TOOLS}
.tools button.run { width: auto; padding: 0 11px; white-space: pre; font-weight: 700; background: var(--d-accent-fill); color: var(--d-accent-text); border-color: transparent; }
.tools button.run:hover { filter: brightness(1.06); color: var(--d-accent-text); }
.wrap.full { position: fixed; inset: max(8px, env(safe-area-inset-top)) 8px max(8px, env(safe-area-inset-bottom)); z-index: 2147482600;
  width: auto; height: auto; max-width: none; max-height: none; margin: 0; overflow: hidden; color: inherit;
  display: flex; flex-direction: column; padding: 8px;
  background: var(--d-panel-solid); border: 1px solid var(--d-line); border-radius: var(--d-radius); box-shadow: 0 20px 60px rgb(0 0 0 / .45); }
.wrap.full::backdrop { background: rgb(0 0 0 / .45); }
.wrap.full .tools { top: 12px; right: 12px; }
/* big: the buttons always show, so it can always be made small again */
.wrap.full .tools > * { opacity: 1; }
.wrap.full .page { flex: 1; overflow: auto; }
.wrap.full iframe { height: 100% !important; }
.err { font: 12px/1.4 var(--d-font); color: var(--d-danger); padding: 4px 2px; white-space: pre-wrap; }
`;

export interface BlockOptions {
  settings: Settings;
  /** Start running even in "ask" mode (the person already asked). */
  autoRun?: boolean;
  /** "바로 실행" in the chat: asked when the page comes on screen; true starts it (one of the recent pages). */
  startOnScreen?: () => boolean;
  /** Marinara id of the message the page sits in. */
  messageId?: string;
  /** Opens Fornello's settings: the page gets a ⚙ button for it. */
  openSettings?: () => void;
  /** Fills in the page's picture names (character assets) before it shows. */
  fillAssets?: (code: string) => Promise<string>;
}

const canPopover = (el: Element | null): el is HTMLElement => typeof (el as HTMLElement | null)?.showPopover === "function";

/** Blocks on screen, so a theme switch can restyle them all. */
const live = new Set<PageBlock>();

export class PageBlock {
  /** The message's text style again, after a theme change. */
  static refreshLooks(): void {
    for (const block of live) block.mounted?.restyle();
  }

  /** The corner buttons again in the screen language. Pages keep running: nothing is mounted or run again. */
  static relabelAll(): void {
    for (const block of live) block.relabel();
  }

  readonly element: HTMLElement;
  private readonly root: ShadowRoot;
  private mounted: MountedPage | null = null;
  private api: PageApi | null = null;
  private renderToken: object = {};
  private running = false;
  private errors: string[] = [];
  private full = false;
  /** Shows the size button and the frame as `full` says (set up by render). */
  private applyFull: () => void = () => {};
  /** Styles of the message around the page, put back when it gets small again. */
  private lifted: { el: HTMLElement; prop: string; value: string; priority: string }[] = [];
  /** Shows a message under the page (set up by render). */
  private showError: (message: string) => void = () => {};
  private page: PreparedPage;
  /** Waits for the page to come on screen ("바로 실행"), until it runs. */
  private seen: IntersectionObserver | null = null;

  constructor(
    private code: string,
    private readonly options: BlockOptions,
  ) {
    this.page = preparePage(code);
    this.element = document.createElement("div");
    this.element.className = "fornello-block";
    standApart(this.element);
    this.element.style.setProperty("--d-font", getComputedStyle(document.body).fontFamily);
    this.root = this.element.attachShadow({ mode: "open" });
    live.add(this);
    const mode = options.settings.current.mode;
    this.running = this.page.hasBehavior && options.autoRun === true && mode !== "off";
    // picture names ({{raw::name}}, [img:name]): drawn once they are addresses, so the browser never asks for the names
    const fill = options.fillAssets && mayHoldTags(code) ? options.fillAssets : null;
    if (!fill) this.render();
    else
      void fill(code)
        .catch(() => code)
        .then((filled) => {
          if (!live.has(this)) return;
          this.code = filled;
          this.page = preparePage(filled);
          this.render();
        });
    if (this.page.hasBehavior && !this.running && options.startOnScreen) {
      // started once it is seen (pages scrolled far up never run unasked)
      this.seen = new IntersectionObserver((entries) => {
        if (!entries.some((e) => e.isIntersecting) || this.running) return;
        if (this.options.settings.current.mode === "always" && this.options.startOnScreen?.()) this.run();
      });
      this.seen.observe(this.element);
    }
  }

  /** The page has scripts to run. */
  get hasScripts(): boolean {
    return this.page.hasBehavior;
  }

  dispose(): void {
    if (this.full) this.setFull(false);
    this.seen?.disconnect();
    this.seen = null;
    live.delete(this);
    this.renderToken = {};
    this.api?.dispose();
    this.api = null;
    this.mounted?.dispose();
    this.element.remove();
  }

  /** "끄기" was chosen: the page stays, its scripts stop. */
  stop(): void {
    if (!this.running) return;
    this.running = false;
    this.render();
  }

  /** The recent pages changed: one now among them starts if it is on screen. */
  wake(): void {
    if (!this.seen) return;
    this.seen.unobserve(this.element);
    this.seen.observe(this.element);
  }

  run(): void {
    if (this.options.settings.current.mode === "off") return;
    this.seen?.disconnect();
    this.seen = null;
    this.running = true;
    this.errors = [];
    this.render();
  }

  private render(): void {
    this.api?.dispose();
    this.api = null;
    this.mounted?.dispose();
    this.mounted = null;
    const token = (this.renderToken = {});
    const style = document.createElement("style");
    style.textContent = STYLE;
    const wrap = document.createElement("div");
    wrap.className = `wrap${this.full ? " full" : ""}`;
    wrap.setAttribute("part", "fornello");
    const tools = this.tools(wrap);
    const pageBox = document.createElement("div");
    pageBox.className = "page";
    const errBox = document.createElement("div");
    errBox.className = "err";
    errBox.hidden = true;
    wrap.append(tools, pageBox, errBox);
    this.root.replaceChildren(style, wrap);
    // run again while big: the new frame is big too
    if (this.full) this.applyFull();

    const showError = (this.showError = (message: string) => {
      this.errors.push(message);
      errBox.hidden = false;
      errBox.textContent = this.errors.slice(-3).join("\n");
    });
    // the page takes the text style of the message it sits in: mount once on screen
    const mount = (globals?: Record<string, unknown>) =>
      this.whenOnScreen(token, () => {
        const mounted = (this.mounted = mountPage(pageBox, this.page, { run: this.running, globals, maxHeight: this.options.settings.current.maxHeight, onError: showError, onScope: this.api?.bindScope }));
        // run again while big: Esc inside the new page still makes it small
        void mounted.ready.then(() => {
          if (this.full && this.mounted === mounted) mounted.frame.contentDocument?.addEventListener("keydown", this.onKey, true);
        });
      });
    if (!this.running) {
      mount();
      return;
    }
    void pageApi({ messageId: this.options.messageId, report: showError, ui: screenUi, reload: () => this.run() }).then((api) => {
      // rendered again (or gone) while the commands were loading
      if (token !== this.renderToken || !live.has(this)) return api.dispose();
      this.api = api;
      mount(api.globals);
    }, (e) => showError(t(`Could not get the page commands ready: ${e instanceof Error ? e.message : String(e)}`, `페이지 명령을 준비하지 못했어요: ${e instanceof Error ? e.message : String(e)}`)));
  }

  /** Swaps in new corner buttons (the screen language changed); the page itself is left alone. */
  private relabel(): void {
    const wrap = this.root.querySelector<HTMLElement>(".wrap");
    const old = wrap?.querySelector(":scope > .tools");
    if (wrap && old) old.replaceWith(this.tools(wrap));
  }

  /** The round buttons in the page's corner, and `applyFull` for its size button. */
  private tools(wrap: HTMLElement): HTMLElement {
    const tools = document.createElement("div");
    tools.className = "tools";
    // "끄기": pages show, their scripts never run (Dispensa's viewer included)
    if (this.page.hasBehavior && !this.running && this.options.settings.current.mode !== "off") {
      const run = toolButton("", t("Run this page's scripts", "이 페이지의 스크립트 실행"), () => this.run());
      run.textContent = t("▶ Run", "▶ 실행");
      run.className = "run keep";
      tools.append(run);
    }
    if (this.page.hasBehavior && this.running) tools.append(toolButton(ICON_RERUN, t("Run again", "다시 실행"), () => this.run()));
    const image = toolButton(ICON_IMAGE, t("Save image", "이미지 저장"), () => void this.saveImage(image));
    image.setAttribute("part", "fornello-image");
    const sizeLabel = () => (this.full ? t("Smaller (Esc)", "작게 (Esc)") : t("Bigger", "크게"));
    const size = toolButton(this.full ? ICON_SHRINK : ICON_EXPAND, sizeLabel(), () => this.setFull(!this.full));
    this.applyFull = () => {
      wrap.classList.toggle("full", this.full);
      // big: in the browser's top layer, above every bar of Marinara whatever its stacking
      if (canPopover(wrap)) {
        try {
          if (this.full && !wrap.matches(":popover-open")) {
            wrap.popover = "manual";
            wrap.showPopover();
          } else if (!this.full && wrap.matches(":popover-open")) {
            wrap.hidePopover();
            wrap.removeAttribute("popover");
          }
        } catch {
          // not on screen yet: the class alone
        }
      }
      size.innerHTML = this.full ? ICON_SHRINK : ICON_EXPAND;
      size.title = sizeLabel();
      size.setAttribute("aria-label", size.title);
    };
    tools.append(image, size);
    const openSettings = this.options.openSettings;
    if (openSettings) tools.append(toolButton(ICON_GEAR, t("Fornello settings (run mode, components)", "Fornello 설정 (실행 방식, 컴포넌트)"), openSettings));
    return tools;
  }

  /** Fills the screen (in the browser's top layer, a popover) or goes back; only the frame moves, so the page keeps its state. */
  private setFull(on: boolean): void {
    if (on === this.full) return;
    this.full = on;
    // no top layer in this browser: what keeps a fixed frame inside the message is lifted
    if (on && !canPopover(this.root.querySelector(".wrap"))) {
      for (let el = this.element.parentElement; el && el !== document.body; el = el.parentElement) {
        const cs = getComputedStyle(el);
        const lift = (prop: string, needed: boolean, value: string) => {
          if (!needed) return;
          this.lifted.push({ el, prop, value: el.style.getPropertyValue(prop), priority: el.style.getPropertyPriority(prop) });
          el.style.setProperty(prop, value, "important");
        };
        lift("contain", !!cs.contain && cs.contain !== "none", "none");
        lift("content-visibility", cs.getPropertyValue("content-visibility") === "auto", "visible");
        lift("container-type", !!cs.containerType && cs.containerType !== "normal", "normal");
        lift("transform", cs.transform !== "none", "none");
        lift("perspective", cs.perspective !== "none", "none");
        lift("filter", cs.filter !== "none", "none");
        lift("backdrop-filter", !!cs.backdropFilter && cs.backdropFilter !== "none", "none");
        lift("will-change", cs.willChange !== "auto", "auto");
        // stacking: the page goes above Marinara's own bars
        lift("z-index", cs.zIndex !== "auto", "auto");
        lift("isolation", cs.isolation === "isolate", "auto");
      }
    }
    if (on) {
      document.addEventListener("keydown", this.onKey, true);
      this.mounted?.frame?.contentDocument?.addEventListener("keydown", this.onKey, true);
    } else {
      for (const l of this.lifted.reverse()) {
        if (l.value) l.el.style.setProperty(l.prop, l.value, l.priority);
        else l.el.style.removeProperty(l.prop);
      }
      this.lifted = [];
      document.removeEventListener("keydown", this.onKey, true);
      this.mounted?.frame?.contentDocument?.removeEventListener("keydown", this.onKey, true);
    }
    this.applyFull();
  }

  private readonly onKey = (e: KeyboardEvent) => {
    if (e.key === "Escape" && this.full) {
      e.preventDefault();
      e.stopPropagation();
      this.setFull(false);
    }
  };

  /** Runs `fn` once the block is in the page (a few frames at most), unless it was rendered again. */
  private whenOnScreen(token: object, fn: () => void, tries = 30): void {
    if (token !== this.renderToken) return;
    if (this.element.isConnected || tries <= 0) return fn();
    requestAnimationFrame(() => this.whenOnScreen(token, fn, tries - 1));
  }

  private async saveImage(button: HTMLButtonElement): Promise<void> {
    button.disabled = true;
    try {
      const title = /<title[^>]*>([^<]*)<\/title>/i.exec(this.code)?.[1]?.trim() || "fornello";
      const blob = await capturePage(this.mounted?.frame ?? null, this.code, this.mounted?.background());
      saveBlob(blob, `${title.replace(/[\\/:*?"<>|]+/g, " ").trim() || "fornello"}.png`);
    } catch (error) {
      this.showError(t(`Could not save as image: ${error instanceof Error ? error.message : String(error)}`, `이미지로 저장하지 못했어요: ${error instanceof Error ? error.message : String(error)}`));
    } finally {
      button.disabled = false;
    }
  }
}
