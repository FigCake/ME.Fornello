// Components in replies: those whose tag the AI wrote, tracker-mode ones
// drawn from the tracker as it was at that reply, and Pesto ones drawn
// from the story's values after that reply. Scene components are drawn
// where their tag is (in place of the ```fornello block, or in the text);
// the rest go under the reply. The latest replies show them open, older ones
// a one-line bar (or nothing); a component runs only while on screen. They
// come from the settings and from the chat's cards (once allowed).

import { isSaved, onMessagesRead } from "../api/chat-store";
import { readChatData } from "../api/chat-data";
import { trackerState } from "../api/marinara";
import type { Message } from "../api/types";
import { currentChatId } from "../host/current-chat";
import { MessageScanner } from "../message-scanner";
import { type PageApi, pageApi, plainTracker } from "../api/page-api";
import { getTrackerValue } from "../shared/tracker";
import { getPath } from "../api/var-ops";
import { onStoryChange, storyAccess } from "../state/access";
import { addFamily, applyStylesheets, loadFontsFor } from "../runtime/stylesheets";
import { serverFonts } from "../api/library";
import { THEME_CSS, componentSheets } from "./look";
import type { Settings } from "../settings";
import { captureElement, saveBlob } from "../shared/capture";
import { ICON_FOLD, ICON_GEAR, ICON_IMAGE } from "../ui/icons";
import { HOVER_TOOLS, THEME_TOKENS } from "../shared/theme";
import { type CardComponents, chatCardComponents } from "./cards";
import type { ComponentDef } from "./model";
import { type MountedComponent, compileComponent, mountComponent } from "./runtime";
import { findTags } from "./source";
import { mountTemplate } from "./template";
import { applySwaps, bodyValues } from "./body";
import { refillInstructions } from "./instructions";
import { onTrackerWrite } from "../host/generation-hold";
import { codeFences, fenceRulesFor } from "../runtime/fences";
import { SCENE_FENCE } from "./rules";
import { type Span, blankText, findLoose } from "../ui/blank-text";
import { t } from "../shared/i18n";
import { standApart } from "../ui/stand-apart";
import { screenUi } from "../ui/page-ui";
import { toolButton } from "../ui/tool-button";

const STYLE = `
${THEME_TOKENS}
${THEME_CSS}
:host { display: block; position: relative; margin: 8px 0 2px; white-space: normal; }
.wrap { position: relative; }
.body { overflow-wrap: anywhere; }
/* a template stays inside its own box: values the AI writes into a style can't lay it over the page */
.template { position: relative; contain: paint; }
${HOVER_TOOLS}
.bar { font: 12px/1 var(--d-font); color: var(--d-btn-text); background: var(--d-panel-solid); border: 1px solid var(--d-line); border-radius: 999px; cursor: pointer; }
.bar:hover { border-color: var(--d-btn-border-hover); color: var(--d-btn-text-hover); }
.bar { display: inline-flex; align-items: center; gap: 6px; padding: 6px 12px; color: var(--d-muted); }
.err, .fc-error { font: 12px/1.4 var(--d-font); color: var(--d-danger, #e5484d); padding: 6px 10px; border: 1px dashed currentColor; border-radius: 8px; white-space: pre-wrap; }
.wait { font: 12px var(--d-font); color: var(--d-muted); padding: 6px 2px; }
.ask { display: flex; flex-wrap: wrap; align-items: center; gap: 8px; font: 12px/1.4 var(--d-font); color: var(--d-muted); padding: 8px 12px; border: 1px dashed var(--d-line); border-radius: 10px; }
.ask button { font: 12px/1 var(--d-font); padding: 6px 12px; border-radius: 999px; border: 1px solid var(--d-btn-border-hover); background: var(--d-panel-solid); color: var(--d-btn-text-hover); cursor: pointer; }
`;

interface Instance {
  def: ComponentDef;
  /** Unique within the message. */
  key: string;
  /** Tag mode: the values the AI wrote. */
  props?: Record<string, unknown>;
  /** The tag was in this ```fornello block of the reply (counting from 0): drawn there. */
  fence?: number;
  /** A card's component the person has not allowed yet. */
  ask?: CardComponents;
}

/** Marks a code block a scene component stands in for (chat.ts's own hiding is separate). */
const SCENE_HIDDEN = "fornelloScene";

const isScene = (lang: string) => lang.trim().toLowerCase() === SCENE_FENCE;
const isSceneBlock = (pre: HTMLPreElement) => isScene(pre.querySelector(".mari-md-codeblock-lang")?.textContent ?? "");

function hideBlock(pre: HTMLPreElement): void {
  pre.style.display = "none";
  pre.dataset[SCENE_HIDDEN] = "1";
}

function showBlock(pre: HTMLPreElement | undefined): void {
  if (!pre || !pre.dataset[SCENE_HIDDEN]) return;
  pre.style.removeProperty("display");
  delete pre.dataset[SCENE_HIDDEN];
}

/** Values for a tracker-mode component, from the tracker as it was at the message. */
async function trackerProps(def: ComponentDef, chatId: string, messageId: string): Promise<Record<string, unknown> | null> {
  const state = await trackerState(messageId, chatId);
  if (!state) return null;
  // every field by its own name, then the paths the person mapped
  const plain = plainTracker(state) as Record<string, unknown> & { custom: Record<string, string>; world: Record<string, string> };
  const { custom, world, ...rest } = plain;
  const props: Record<string, unknown> = { ...rest, ...world, ...custom };
  for (const [prop, path] of Object.entries(def.map)) {
    try {
      props[prop] = getTrackerValue(state, path);
    } catch {
      // an unknown path leaves the value as it was
    }
  }
  return props;
}

/** Values for a Pesto component: the values after the message, the computed ones beside them, then the paths the person mapped. */
async function storyProps(def: ComponentDef, chatId: string, messageId: string): Promise<Record<string, unknown> | null> {
  const view = await storyAccess()?.at(chatId, messageId);
  if (!view) return null;
  const props: Record<string, unknown> = { ...view.values, ...view.derived };
  for (const [prop, path] of Object.entries(def.map)) props[prop] = getPath(props, path) ?? null;
  return props;
}

/** Whether a component's values come from a record of each reply (the tracker, Pesto) rather than a tag. */
const fromRecord = (d: ComponentDef) => d.source === "tracker" || d.source === "story";

/** The values a record component shows at a message; null when there is no record. */
const recordProps = (def: ComponentDef, chatId: string, messageId: string) => (def.source === "story" ? storyProps(def, chatId, messageId) : trackerProps(def, chatId, messageId));

/** Puts one of Marinara's own fonts on an element's text (none: the theme's). */
export async function useFont(el: HTMLElement, family: string): Promise<void> {
  if (!family) {
    el.style.removeProperty("font-family");
    return;
  }
  addFamily(document, (await serverFonts().catch(() => [])).filter((f) => f.family === family));
  el.style.fontFamily = `"${family.replace(/"/g, "")}", var(--d-font)`;
}

/** How long a reply found without a tracker record is left out (the tracker may still be writing one). */
const NO_RECORD_FOR = 20_000;

/** A place in a message's text: a text node and where in it. */
interface TextPlace {
  node: Text;
  offset: number;
}

/** A tag of the reply's source, to find on screen: `key` is `Name#n` (counted in the source's order). */
export interface SourceTag {
  key: string;
  name: string;
  raw: string;
}

/**
 * Where the source's tags show in a message's text on screen: as written, or
 * loosely (quotes drawn as emphasis, unknown HTML tags dropped). `skip`: code
 * shown as code; `rest`: tags not found.
 */
export function matchScreenTags(full: string, names: string[], wanted: SourceTag[], skip: Span[] = []): { found: (Span & { key: string })[]; rest: SourceTag[] } {
  const skipped = (a: number, b: number) => skip.some((s) => a < s.end && b > s.start);
  const screen = findTags(full, names).filter((t) => !skipped(t.start, t.end));
  const used = new Set<number>();
  const found: (Span & { key: string })[] = [];
  const rest: SourceTag[] = [];
  let cursor = 0;
  const loose = (piece: string, chars: RegExp): Span | null => {
    if (!piece.trim()) return null;
    const [span] = findLoose(full.slice(cursor), [piece], chars);
    return span && !skipped(span.start + cursor, span.end + cursor) ? { start: span.start + cursor, end: span.end + cursor } : null;
  };
  for (const w of wanted) {
    const i = screen.findIndex((t, j) => !used.has(j) && t.name === w.name && t.start >= cursor);
    let span: Span | null = i >= 0 ? screen[i] : loose(w.raw, /[\s"'“”‘’«»]/) ?? loose(w.raw.replace(/<[^<>]*>/g, " "), /\s/);
    if (i >= 0) used.add(i);
    if (!span) {
      rest.push(w);
      continue;
    }
    span = { start: span.start, end: span.end };
    found.push({ ...span, key: w.key });
    cursor = span.end;
  }
  return { found, rest };
}

/** Blanks the source's tags on screen in place (no nodes moved, so Marinara can redraw); returns where each was, by `Name#n`. */
function hideTags(contents: HTMLElement[], names: string[], wanted: SourceTag[]): Map<string, TextPlace> {
  const out = new Map<string, TextPlace>();
  if (!names.length) return out;
  let left = wanted;
  for (const content of contents) {
    if (!content.textContent?.includes("<") && !left.length) continue;
    const nodes: Text[] = [];
    const walker = document.createTreeWalker(content, NodeFilter.SHOW_TEXT);
    for (let n = walker.nextNode(); n; n = walker.nextNode()) nodes.push(n as Text);
    const starts: number[] = [];
    const skip: Span[] = [];
    let full = "";
    for (const n of nodes) {
      starts.push(full.length);
      // code shown as code (```text, `inline`) keeps its tags
      if (n.parentElement?.closest("code, pre")) skip.push({ start: full.length, end: full.length + n.length });
      full += n.nodeValue ?? "";
    }
    const { found, rest } = matchScreenTags(full, names, left, skip);
    left = rest;
    const spans = [...found];
    if (!spans.length) continue;
    for (const tag of found) {
      let i = starts.length - 1;
      while (i > 0 && starts[i] > tag.start) i--;
      if (!nodes[i]) continue;
      // as it will be once the tags are blanked: less what earlier tags take out of the same node
      let offset = tag.start - starts[i];
      for (const t of spans) if (t.start < tag.start) offset -= Math.max(0, Math.min(t.end, tag.start) - Math.max(t.start, starts[i]));
      out.set(tag.key, { node: nodes[i], offset });
    }
    blankText(content, () => spans);
  }
  return out;
}

class ComponentView {
  readonly element: HTMLElement;
  private readonly root: ShadowRoot;
  private readonly frame: HTMLElement;
  private body: HTMLElement | null = null;
  private mounted: MountedComponent | null = null;
  private api: PageApi | null = null;
  private loading = false;
  private visible = false;
  private hideTimer: ReturnType<typeof setTimeout> | null = null;
  private open = false;
  private checked = false;
  private lastProps = "";
  private token = {};

  constructor(
    private readonly host: ComponentHost,
    private readonly chatId: string,
    readonly messageId: string,
    public inst: Instance,
  ) {
    this.element = document.createElement("div");
    this.element.className = "fornello-component";
    standApart(this.element);
    this.element.dataset.jsx = inst.def.name;
    this.root = this.element.attachShadow({ mode: "open" });
    const style = document.createElement("style");
    style.textContent = STYLE;
    this.frame = document.createElement("div");
    this.frame.className = "wrap";
    this.frame.setAttribute("part", "component");
    this.root.append(style, this.frame);
  }

  setOpen(open: boolean): void {
    if (open === this.open && this.frame.childElementCount) return;
    this.open = open;
    this.unmount();
    this.frame.replaceChildren();
    const ask = this.inst.ask;
    if (ask) {
      const box = document.createElement("div");
      box.className = "ask";
      box.setAttribute("part", "component-ask");
      const note = document.createElement("span");
      note.textContent = t(`🔥 ${this.inst.def.name}: a component from the card “${ask.characterName}”`, `🔥 ${this.inst.def.name}: “${ask.characterName}” 카드의 컴포넌트`);
      const allow = document.createElement("button");
      allow.type = "button";
      allow.textContent = t("Allow this card's components", "이 카드의 컴포넌트 허락");
      allow.addEventListener("click", () => this.host.allowCard(ask));
      box.append(note, allow);
      this.frame.append(box);
      return;
    }
    if (!open) {
      // a tracker component shows its bar only once the reply turns out to have a record
      if (this.inst.def.source === "tracker") this.element.style.display = "none";
      const bar = document.createElement("button");
      bar.type = "button";
      bar.className = "bar";
      bar.setAttribute("part", "component-bar");
      bar.textContent = t(`🔥 ${this.inst.def.label || this.inst.def.name} · Expand`, `🔥 ${this.inst.def.label || this.inst.def.name} · 펼치기`);
      bar.addEventListener("click", () => this.host.expand(this.messageId));
      this.frame.append(bar);
      return;
    }
    const tools = document.createElement("div");
    tools.className = "tools";
    tools.append(
      toolButton(ICON_IMAGE, t("Save as image", "이미지로 저장"), () => void this.saveImage()),
      toolButton(ICON_GEAR, t("Fornello component settings", "Fornello 컴포넌트 설정"), () => this.host.openSettings(this.inst.def.id)),
      toolButton(ICON_FOLD, t("Collapse", "접기"), () => this.host.collapse(this.messageId)),
    );
    this.body = document.createElement("div");
    this.body.className = "body";
    this.frame.append(tools, this.body);
    if (this.visible) void this.mount();
  }

  /** Tracker or Pesto mode: read the record again and redraw if it changed. */
  refreshTracker(source: "tracker" | "story" = "tracker"): void {
    if (this.inst.def.source !== source || !this.mounted) return;
    void recordProps(this.inst.def, this.chatId, this.messageId).then((props) => {
      if (!props || !this.mounted) return;
      const text = JSON.stringify(props);
      if (text === this.lastProps) return;
      this.lastProps = text;
      this.mounted.update(applySwaps(props, this.inst.def.fields));
    });
  }

  /** Same component, new values (the reply was edited or regenerated). */
  update(inst: Instance): void {
    const asked = !!inst.ask !== !!this.inst.ask;
    const changed = inst.def.code !== this.inst.def.code || JSON.stringify(inst.props) !== JSON.stringify(this.inst.props) || JSON.stringify(inst.def.map) !== JSON.stringify(this.inst.def.map);
    this.inst = inst;
    if (asked) {
      // allowed (or asked again): drawn anew with the next setOpen
      this.frame.replaceChildren();
      return;
    }
    if (!changed || !this.open) return;
    this.unmount();
    if (this.visible) void this.mount();
  }

  setVisible(visible: boolean): void {
    this.visible = visible;
    if (visible) {
      if (this.hideTimer) clearTimeout(this.hideTimer);
      this.hideTimer = null;
      if (this.open && !this.mounted && !this.loading) void this.mount();
      if (!this.open && this.inst.def.source === "tracker" && this.element.style.display === "none" && !this.checked) {
        this.checked = true;
        void trackerState(this.messageId, this.chatId).then((s) => {
          if (s) this.element.style.removeProperty("display");
          else this.host.noRecord(this.messageId);
        });
      }
      return;
    }
    // off screen for a while: stop it, keep its place
    if (this.mounted && !this.hideTimer) {
      this.hideTimer = setTimeout(() => {
        this.hideTimer = null;
        if (!this.visible) this.unmount(true);
      }, 4000);
    }
  }

  private showError(message: string): void {
    if (!this.body) return;
    const box = document.createElement("div");
    box.className = "err";
    box.textContent = message;
    this.body.replaceChildren(box);
  }

  private async mount(): Promise<void> {
    const body = this.body;
    if (!body || this.mounted || this.loading) return;
    this.loading = true;
    const token = (this.token = {});
    const report = (e: unknown) => this.host.report(this.inst.def.name, e);
    try {
      if (!body.childElementCount) {
        const wait = document.createElement("div");
        wait.className = "wait";
        wait.textContent = t(`Loading ${this.inst.def.name}…`, `${this.inst.def.name} 불러오는 중…`);
        body.append(wait);
      }
      const raw = fromRecord(this.inst.def) ? await recordProps(this.inst.def, this.chatId, this.messageId) : (this.inst.props ?? {});
      if (token !== this.token) return;
      if (!raw) {
        if (this.inst.def.source === "tracker") this.host.noRecord(this.messageId);
        else body.replaceChildren();
        return;
      }
      const props = applySwaps(raw, this.inst.def.fields);
      const sheets = componentSheets(this.inst.def.code);
      await useFont(body, this.inst.def.font);
      if (token !== this.token) return;
      if (this.inst.def.kind === "html") {
        // a template runs no code: drawn in a shadow root of its own, so its <style> leaves the buttons around it alone
        const holder = document.createElement("div");
        holder.className = "template";
        const target = document.createElement("div");
        const theme = document.createElement("style");
        theme.textContent = THEME_CSS;
        holder.attachShadow({ mode: "open" }).append(theme, target);
        if (sheets.length) await applyStylesheets(sheets, document, holder.shadowRoot!);
        if (token !== this.token) return;
        body.replaceChildren(holder);
        this.mounted = mountTemplate(target, this.inst.def.code, props);
        this.lastProps = JSON.stringify(raw);
        body.style.removeProperty("min-height");
        if (sheets.length) setTimeout(() => void loadFontsFor(document, target.textContent ?? ""), 50);
        return;
      }
      if (sheets.length) await applyStylesheets(sheets, document, this.root);
      const api = await pageApi({ messageId: this.messageId, report: (m) => report(m), ui: screenUi, reload: () => this.reload() });
      if (token !== this.token) return api.dispose();
      this.api = api;
      const compiled = compileComponent(this.inst.def.name, this.inst.def.code, api.globals, api.bindScope);
      const target = document.createElement("div");
      body.replaceChildren(target);
      this.mounted = mountComponent(target, compiled, props, report);
      this.lastProps = JSON.stringify(raw);
      body.style.removeProperty("min-height");
      if (sheets.length) setTimeout(() => void loadFontsFor(document, body.textContent ?? ""), 50);
    } catch (e) {
      if (token === this.token) this.showError(t(`Could not draw the component: ${e instanceof Error ? e.message : String(e)}`, `컴포넌트를 그리지 못했어요: ${e instanceof Error ? e.message : String(e)}`));
    } finally {
      if (token === this.token) this.loading = false;
    }
  }

  /** Draws it again from the start (reloadIframe). */
  private reload(): void {
    this.unmount();
    if (this.open && this.visible) void this.mount();
  }

  private unmount(keepPlace = false): void {
    this.token = {};
    this.loading = false;
    if (keepPlace && this.body) this.body.style.minHeight = `${this.body.offsetHeight}px`;
    this.mounted?.unmount();
    this.mounted = null;
    this.api?.dispose();
    this.api = null;
  }

  private async saveImage(): Promise<void> {
    if (!this.body) return;
    try {
      saveBlob(await captureElement(this.body), `${this.inst.def.name}.png`);
    } catch (e) {
      this.host.report(this.inst.def.name, t(`Could not save as image: ${e instanceof Error ? e.message : String(e)}`, `이미지로 저장하지 못했어요: ${e instanceof Error ? e.message : String(e)}`));
    }
  }

  dispose(): void {
    if (this.hideTimer) clearTimeout(this.hideTimer);
    this.unmount();
    this.element.remove();
  }
}

interface Slot {
  messageId: string;
  container: HTMLElement;
  views: Map<string, ComponentView>;
  /** The ```fornello code block it stands in for (a scene component); none: under the reply. */
  pre?: HTMLPreElement;
  /** Put where its tag was in the text (a scene component without a code block). */
  inText?: boolean;
}

/** A tag of a reply's source, as found once for its text. */
type CachedTag = ReturnType<typeof findTags>[number] & { key: string; fence?: number };

/** Where a scene component's tag is on screen, by message, then by `Name#n`. */
type Anchors = Map<string, Map<string, TextPlace>>;

export interface ComponentHostHooks {
  /** Opens Fornello's settings at a component (its ⚙ button). */
  openSettings(componentId?: string): void;
  /** A component's own error, shown as a note. */
  report(name: string, message: string): void;
}

export class ComponentHost extends MessageScanner {
  private readonly slots = new Map<string, Slot>();
  private io: IntersectionObserver | null = null;
  private unread: (() => void) | null = null;
  private unwatchTracker: (() => void) | null = null;
  private unwatchStory: (() => void) | null = null;
  /** Older replies the person opened, and recent ones they folded. */
  private readonly opened = new Set<string>();
  private readonly folded = new Set<string>();
  /** Replies found without a tracker record, and when. */
  private readonly noTracker = new Map<string, number>();
  private readonly anchors: Anchors = new Map();
  /** Names of the tag-mode components, whose tags are hidden in the replies' text. */
  private tagNames: string[] = [];
  /** Each reply's text on screen as the last look left it: a swipe or an edit changes it, and the list is read again. */
  private readonly screenText = new Map<string, string>();
  /** Reads again of a reply whose text on screen is not yet the one saved (another swipe shown). */
  private readonly retries = new Map<string, number>();
  /** Tags found in each reply, until its text (or the component list) changes: scans run on every change on screen. */
  private readonly tagCache = new Map<string, { text: string; names: string; tags: CachedTag[] }>();

  constructor(
    settings: Settings,
    private readonly hooks: ComponentHostHooks,
  ) {
    super(settings);
  }

  protected override started(): void {
    this.io = new IntersectionObserver(
      (entries) => {
        for (const e of entries) {
          for (const slot of this.slots.values()) for (const v of slot.views.values()) if (v.element === e.target) v.setVisible(e.isIntersecting);
        }
      },
      { rootMargin: "300px 0px" },
    );
    // an edit or a swipe: the chat pages read the list again, the components follow it
    this.unread = onMessagesRead((chatId, list) => {
      if (chatId !== this.chatId || this.stopped) return;
      const changed = list.length !== this.messages.size || list.some((m) => this.messages.get(m.id)?.text !== m.text);
      this.messages = new Map(list.map((m) => [m.id, m]));
      if (changed) this.schedule();
    });
    // the story's values changed (a reply counted, the person's edit): Pesto components read them again
    this.unwatchStory = onStoryChange((chatId) => {
      if (chatId !== this.chatId || this.stopped) return;
      this.refreshTrackers("story");
      this.schedule();
    });
    // the tracker was written (a reply's agents, a re-run, by hand): tracker components read it again, lost instructions go back
    this.unwatchTracker = onTrackerWrite((chatId) => {
      if (chatId !== this.chatId || this.stopped) return;
      this.refreshTrackers();
      void this.components(chatId)
        .then(({ shown }) => refillInstructions(chatId, shown))
        .catch((e: unknown) => console.warn("[Fornello] tracker instructions not put back", e));
    });
  }

  protected override stopping(): void {
    this.io?.disconnect();
    this.unread?.();
    this.unread = null;
    this.unwatchTracker?.();
    this.unwatchTracker = null;
    this.unwatchStory?.();
    this.unwatchStory = null;
    this.noTracker.clear();
  }

  openSettings(componentId?: string): void {
    this.hooks.openSettings(componentId);
  }

  report(name: string, e: unknown): void {
    this.hooks.report(name, e instanceof Error ? e.message : String(e));
  }

  /** A tracker component found no record at this reply: leave it out from now on. */
  noRecord(messageId: string): void {
    this.noTracker.set(messageId, Date.now());
    this.schedule();
    setTimeout(() => this.schedule(), NO_RECORD_FOR + 100);
  }

  expand(messageId: string): void {
    this.opened.add(messageId);
    this.folded.delete(messageId);
    this.schedule();
  }

  collapse(messageId: string): void {
    this.folded.add(messageId);
    this.opened.delete(messageId);
    this.schedule();
  }

  /** The person allowed a card's components (as they are now: a change asks again). */
  allowCard(card: CardComponents): void {
    const trustedCards = { ...this.settings.current.trustedCards, [card.characterId]: card.hash };
    this.settings.set({ trustedCards }).catch((e: unknown) => this.report(card.characterName, e));
  }

  protected clear(): void {
    for (const key of [...this.slots.keys()]) this.dropSlot(key);
  }

  protected override replyDone(): void {
    this.messages.clear();
    this.schedule();
    // the tracker writes its record after the reply: look again a little later
    for (const ms of [6000, 15000, 30000]) setTimeout(() => this.refreshTrackers(), ms);
  }

  protected override chatChanged(): void {
    this.tagCache.clear();
    this.screenText.clear();
    this.retries.clear();
    this.anchors.clear();
    this.opened.clear();
    this.folded.clear();
  }

  private lacksRecord(id: string): boolean {
    return Date.now() - (this.noTracker.get(id) ?? 0) < NO_RECORD_FOR;
  }

  private refreshTrackers(source: "tracker" | "story" = "tracker"): void {
    for (const slot of this.slots.values()) for (const v of slot.views.values()) v.refreshTracker(source);
  }

  /** The tags of tag-mode components in a reply's source, keyed `Name#n`, with their ```fornello block; tags in other code stay text. */
  private sourceTags(message: Message, el: HTMLElement): CachedTag[] {
    const names = this.tagNames.join("\n");
    let found = this.tagCache.get(message.id);
    if (!found || found.text !== message.text || found.names !== names) {
      const fences = codeFences(message.text, fenceRulesFor(el, message.text));
      const scenes = fences.filter((f) => isScene(f.lang));
      const code = fences.filter((f) => !isScene(f.lang)).map((f) => ({ start: f.start, end: f.end }));
      // `inline code` outside the blocks
      for (const m of message.text.matchAll(/`[^`\n]+`/g)) if (!fences.some((f) => m.index >= f.start && m.index < f.end)) code.push({ start: m.index, end: m.index + m[0].length });
      const counts = new Map<string, number>();
      const tags: CachedTag[] = [];
      for (const tag of findTags(message.text, this.tagNames)) {
        if (code.some((c) => tag.start >= c.start && tag.end <= c.end)) continue;
        const n = (counts.get(tag.name) ?? 0) + 1;
        counts.set(tag.name, n);
        const fence = scenes.findIndex((f) => tag.start >= f.start && tag.end <= f.end);
        tags.push({ ...tag, key: `${tag.name}#${n}`, ...(fence < 0 ? {} : { fence }) });
      }
      found = { text: message.text, names, tags };
      this.tagCache.set(message.id, found);
    }
    return found.tags;
  }

  private instances(message: Message, defs: ComponentDef[], asks: Map<string, CardComponents>, el: HTMLElement): Instance[] {
    if (message.role !== "char" && message.role !== "narrator") return [];
    const out: Instance[] = [];
    const byName = new Map(defs.filter((d) => !fromRecord(d)).map((d) => [d.name, d]));
    if (byName.size) {
      for (const tag of this.sourceTags(message, el)) {
        const def = byName.get(tag.name);
        if (!def) continue;
        const props = def.source === "body" ? bodyValues(tag.body ?? "", def.body, def.fields) : tag.props;
        out.push({ def, key: tag.key, props, fence: tag.fence, ask: asks.get(def.id) });
      }
    }
    if (message.role === "char" && !this.lacksRecord(message.id)) for (const d of defs.filter((x) => x.source === "tracker")) out.push({ def: d, key: `${d.name}@tracker`, ask: asks.get(d.id) });
    if (isSaved(message.id)) for (const d of defs.filter((x) => x.source === "story")) out.push({ def: d, key: `${d.name}@story`, ask: asks.get(d.id) });
    return out;
  }

  /**
   * The components to look for: the person's own, then the cards' (an own one
   * of the same name wins). `shown`: those on in this chat (the rest still hide
   * their tags); `asks`: card components not allowed yet.
   */
  private async components(chatId: string): Promise<{ defs: ComponentDef[]; shown: ComponentDef[]; asks: Map<string, CardComponents> }> {
    const defs = this.settings.current.components.filter((w) => w.enabled);
    const asks = new Map<string, CardComponents>();
    const cards = await chatCardComponents(chatId).catch(() => [] as CardComponents[]);
    const trusted = this.settings.current.trustedCards;
    for (const card of cards) {
      for (const d of card.defs) {
        if (defs.some((x) => x.name === d.name)) continue;
        defs.push(d);
        if (trusted[card.characterId] !== card.hash) asks.set(d.id, card);
      }
    }
    const chosen = (await readChatData(chatId).catch(() => null))?.components ?? {};
    // Pesto components only in a chat that has Pesto
    const story = defs.some((d) => d.source === "story") && (await storyAccess()?.has(chatId).catch(() => false));
    const usable = story ? defs : defs.filter((d) => d.source !== "story");
    return { defs: usable, shown: usable.filter((d) => chosen[d.id] ?? d.everyChat), asks };
  }

  protected async scan(chatId: string | null): Promise<void> {
    const { defs, shown, asks } = chatId && this.settings.current.mode !== "off" ? await this.components(chatId) : { defs: [], shown: [], asks: new Map<string, CardComponents>() };
    if (this.stopped || currentChatId() !== chatId) return;
    if (!chatId || !defs.length) {
      if (this.slots.size) this.clear();
      return;
    }
    this.tagNames = defs.filter((d) => !fromRecord(d)).map((d) => d.name);
    const elements = [...document.querySelectorAll<HTMLElement>("[data-message-id]")].filter((el) => !el.closest(".fornello-components"));
    if (!elements.length) return;
    // a reply still streaming has no saved id; one not read yet or changed on screen reads the list again
    const textOf = (el: HTMLElement) => [...el.querySelectorAll(".mari-message-content")].map((c) => c.textContent ?? "").join("\n");
    let behind = false;
    const changed = elements.filter((el) => isSaved(el.dataset.messageId) && this.screenText.get(el.dataset.messageId ?? "") !== textOf(el)).map((el) => el.dataset.messageId!);
    // where the tags were in a text Marinara has written again is not where they are now
    for (const id of changed) this.anchors.delete(id);
    if (elements.some((el) => isSaved(el.dataset.messageId) && !this.messages.has(el.dataset.messageId ?? "")) || changed.length) {
      // too soon after the last read: look again later, without counting the change as seen
      if (this.loadAllowed()) await this.load(chatId);
      else behind = true;
      if (this.stopped || currentChatId() !== chatId) return;
      // another swipe is on screen before Marinara has saved which one: read again a moment later
      if (!behind && elements.some((el) => changed.includes(el.dataset.messageId!) && !this.screenMatches(el, textOf(el)))) {
        behind = true;
        setTimeout(() => this.schedule(), 900);
      }
    }
    // which replies have components, newest last
    const withComponents: { el: HTMLElement; id: string; list: Instance[] }[] = [];
    for (const el of elements) {
      const id = el.dataset.messageId ?? "";
      const message = this.messages.get(id);
      if (!message) continue;
      // every component's tag leaves the text on screen (also when off in this chat); where each was is kept for scene components
      if (message.role === "char" || message.role === "narrator") {
        const kept = this.anchors.get(id) ?? new Map<string, TextPlace>();
        for (const [k, v] of kept) if (!v.node.isConnected) kept.delete(k);
        const wanted = this.sourceTags(message, el).filter((t) => t.fence === undefined && !kept.has(t.key));
        for (const [k, v] of hideTags([...el.querySelectorAll<HTMLElement>(".mari-message-content")], this.tagNames, wanted)) kept.set(k, v);
        this.anchors.set(id, kept);
      }
      const list = this.instances(message, shown, asks, el);
      if (list.length) withComponents.push({ el, id, list });
    }
    const { recent, older } = this.settings.current.display;
    /** The boxes still wanted. */
    const live = new Set<string>();
    withComponents.forEach(({ el, id, list }, index) => {
      const isRecent = index >= withComponents.length - recent;
      const open = this.opened.has(id) || (isRecent && !this.folded.has(id));
      if (!open && older === "hidden" && !isRecent) {
        this.drop(id);
        return;
      }
      // scene components where their ```fornello block is; the rest (and any whose block is not on screen) under the reply
      const blocks = [...el.querySelectorAll<HTMLPreElement>("pre.mari-md-codeblock")].filter((p) => !p.closest(".fornello-components, .fornello-pages, .fornello-block") && isSceneBlock(p));
      const kept = this.anchors.get(id) ?? new Map<string, TextPlace>();
      const groups = new Map<string, { pre?: HTMLPreElement; at?: TextPlace; list: Instance[] }>();
      for (const inst of list) {
        const pre = inst.fence === undefined ? undefined : blocks[inst.fence];
        // a scene component's tag outside a code block: where the tag was in the text
        const inText = !pre && inst.def.use === "scene" && !fromRecord(inst.def);
        const at = inText ? kept.get(inst.key) : undefined;
        const key = pre ? `${id}:${inst.fence}` : inText && (at || this.slots.get(`${id}@${inst.key}`)?.inText) ? `${id}@${inst.key}` : id;
        const group = groups.get(key) ?? { pre, at, list: [] };
        group.list.push(inst);
        groups.set(key, group);
      }
      for (const [key, group] of groups) {
        live.add(key);
        this.fill(this.place(el, id, key, group.pre, group.at), chatId, group.list, open);
      }
      // the blank lines the tags sat between (text shown with its line breaks): each box stands on its own line anyway
      for (const slot of this.slots.values()) {
        if (!slot.inText || slot.messageId !== id) continue;
        const before = slot.container.previousSibling;
        const after = slot.container.nextSibling;
        if (before instanceof Text && /\s$/.test(before.nodeValue ?? "")) before.nodeValue = (before.nodeValue ?? "").replace(/\s+$/, "");
        if (after instanceof Text && /^\s/.test(after.nodeValue ?? "")) after.nodeValue = (after.nodeValue ?? "").replace(/^\s+/, "");
      }
    });
    for (const key of [...this.slots.keys()]) if (!live.has(key)) this.dropSlot(key);
    // as this look left them (tags blanked): only a change Marinara makes reads the list again
    if (!behind) for (const el of elements) if (isSaved(el.dataset.messageId)) this.screenText.set(el.dataset.messageId!, textOf(el));
  }

  /** Whether the reply as read matches the screen (markup and tags left out); after a few tries it is taken as it is. */
  private screenMatches(el: HTMLElement, screen: string): boolean {
    const id = el.dataset.messageId ?? "";
    // a component's tag (and what it holds) is not shown as text
    const words = (s: string) => s.replace(/<([A-Z][\w$]*)\b[^<>]*>[\s\S]*?<\/\1\s*>/g, "").replace(/<[^<>]*>/g, "").replace(/[^\p{L}\p{N}]+/gu, "");
    const text = words(this.messages.get(id)?.text ?? "").slice(0, 40);
    if (!text || words(screen).includes(text)) {
      this.retries.delete(id);
      return true;
    }
    const n = (this.retries.get(id) ?? 0) + 1;
    this.retries.set(id, n);
    return n > 6;
  }

  /** Brings a box's components in line with `list`. */
  private fill(slot: Slot, chatId: string, list: Instance[], open: boolean): void {
    const keys = new Set(list.map((i) => i.key));
    for (const [key, view] of slot.views) {
      if (!keys.has(key)) {
        this.disposeView(view);
        slot.views.delete(key);
      }
    }
    for (const inst of list) {
      let view = slot.views.get(inst.key);
      if (!view) {
        view = new ComponentView(this, chatId, slot.messageId, inst);
        slot.views.set(inst.key, view);
        slot.container.append(view.element);
        this.io?.observe(view.element);
      } else view.update(inst);
      view.setOpen(open);
    }
  }

  /** A box of components: in place of its ```fornello block, where its tag was, or under the reply; put back after a redraw. */
  private place(el: HTMLElement, id: string, key: string, pre?: HTMLPreElement, at?: TextPlace): Slot {
    let slot = this.slots.get(key);
    if (!slot) {
      const container = document.createElement("div");
      container.className = "fornello-components";
      standApart(container);
      container.dataset.fornelloFor = id;
      slot = { messageId: id, container, views: new Map() };
      this.slots.set(key, slot);
    }
    if (pre) {
      if (slot.pre !== pre) showBlock(slot.pre);
      slot.pre = pre;
      hideBlock(pre);
      if (pre.nextElementSibling !== slot.container) pre.after(slot.container);
      return slot;
    }
    if (slot.inText && slot.container.isConnected) return slot;
    if (at?.node.isConnected && at.node.parentNode) {
      // the text is split where the tag was (React writes the whole text again when the message changes)
      // an earlier split may have moved the rest of this text into the nodes after it
      let node = at.node;
      let offset = at.offset;
      for (let next = node.nextSibling; offset > node.length && next; next = next.nextSibling) {
        if (next instanceof Text) {
          offset -= node.length;
          node = next;
        } else if (!(next instanceof HTMLElement && next.classList.contains("fornello-components"))) break;
      }
      const rest = node.splitText(Math.min(offset, node.length));
      rest.parentNode!.insertBefore(slot.container, rest);
      slot.inText = true;
      return slot;
    }
    const contents = el.querySelectorAll<HTMLElement>(".mari-message-content");
    const anchor = contents[contents.length - 1];
    if (anchor) {
      if (anchor.nextElementSibling !== slot.container) anchor.after(slot.container);
    } else if (slot.container.parentElement !== el) el.append(slot.container);
    return slot;
  }

  private disposeView(view: ComponentView): void {
    this.io?.unobserve(view.element);
    view.dispose();
  }

  /** Takes away a reply's components (every box of it). */
  private drop(id: string): void {
    for (const [key, slot] of [...this.slots]) if (slot.messageId === id) this.dropSlot(key);
  }

  private dropSlot(key: string): void {
    const slot = this.slots.get(key);
    if (!slot) return;
    for (const v of slot.views.values()) this.disposeView(v);
    const parent = slot.container.parentNode;
    slot.container.remove();
    // the text split for it is one again
    if (slot.inText) parent?.normalize();
    showBlock(slot.pre);
    this.slots.delete(key);
  }
}
