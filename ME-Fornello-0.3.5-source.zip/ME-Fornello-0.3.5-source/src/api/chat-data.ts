// Fornello's part of a chat's metadata, and the chat's variables. Marinara
// keeps variables in metadata.macroVariables, with limits on names and size;
// the rest (and which hold numbers or objects) go under Fornello's own key in
// the same metadata, so a branch takes them along.

import { api } from "../shared/api";
import { chatDetail, forgetChat, forgetDetail } from "./chat-store";
import { asText, parseObject } from "./parse";
import type { ChatDetail } from "./types";
import { type LibraryItem, normalizeLibrary } from "../scripts/model";

const enc = encodeURIComponent;

const MARINARA_NAME = /^[A-Za-z_]\w{0,63}$/;
const MARINARA_MAX = 10_000;

/** Fornello's part of a chat's metadata. */
export interface ChatData {
  /** Variables Marinara does not take (other names, longer values). */
  vars: Record<string, string>;
  /** Names of variables that hold numbers, objects and the like (kept as JSON text). */
  json: string[];
  /** SillyTavern's chatMetadata of the pages (saveMetadata). */
  meta: Record<string, unknown>;
  /** Scripts that run in this chat only (setScripts(…, "chat")). */
  scripts: LibraryItem[];
  /** Instructions for this chat's custom tracker fields, by field name (put back when a write drops them). */
  instructions: Record<string, string>;
  /** Components turned on or off in this chat, by id (the others follow their "new chats" choice). */
  components: Record<string, boolean>;
}

const CHAT_KEY = "fornello";

function chatDataOf(detail: ChatDetail): ChatData {
  const own = parseObject(parseObject(detail.metadata)[CHAT_KEY]);
  return {
    vars: { ...(parseObject(own.vars) as Record<string, string>) },
    json: Array.isArray(own.json) ? own.json.map(String) : [],
    meta: { ...parseObject(own.meta) },
    scripts: normalizeLibrary(own.scripts),
    instructions: Object.fromEntries(Object.entries(parseObject(own.instructions)).filter((e): e is [string, string] => typeof e[1] === "string" && !!e[1].trim())),
    components: Object.fromEntries(Object.entries(parseObject(own.components)).filter((e): e is [string, boolean] => typeof e[1] === "boolean")),
  };
}

export async function readChatData(chatId: string): Promise<ChatData> {
  return chatDataOf(await chatDetail(chatId));
}

const chatQueues = new Map<string, Promise<unknown>>();

/** Read-change-write of Fornello's part of a chat, one at a time per chat so writes never lose each other's changes. */
export function updateChatData(chatId: string, change: (data: ChatData) => ChatData): Promise<void> {
  const run = (chatQueues.get(chatId) ?? Promise.resolve()).then(async () => {
      forgetDetail(chatId);
    const next = change(chatDataOf(await chatDetail(chatId)));
    await api(`/chats/${enc(chatId)}/metadata`, { method: "PATCH", body: { [CHAT_KEY]: next } });
    forgetDetail(chatId);
  });
  chatQueues.set(chatId, run.catch(() => undefined));
  return run;
}

/** The chat's variables, numbers and objects as they were set (JS-Slash-Runner keeps their types too). */
export async function readVariables(chatId: string): Promise<Record<string, unknown>> {
  const detail = await chatDetail(chatId);
  const own = chatDataOf(detail);
  const out: Record<string, unknown> = { ...(parseObject(parseObject(detail.metadata).macroVariables) as Record<string, string>), ...own.vars };
  for (const name of own.json) {
    if (typeof out[name] !== "string") continue;
    try {
      out[name] = JSON.parse(out[name] as string);
    } catch {
      // changed to plain text elsewhere ({{setvar}}): it stays text
    }
  }
  return out;
}

export async function writeVariables(values: Record<string, unknown>, { replace = false } = {}, chatId: string): Promise<void> {
  const toMarinara: Record<string, string | null> = {};
  const setLocal: Record<string, string> = {};
  const dropLocal = new Set<string>();
  if (replace) {
    const meta = parseObject((await chatDetail(chatId)).metadata);
    for (const k of Object.keys(parseObject(meta.macroVariables))) toMarinara[k] = null;
  }
  for (const [k, v] of Object.entries(values)) {
    if (v === null || v === undefined) {
      toMarinara[k] = null;
      dropLocal.add(k);
      continue;
    }
    const text = asText(v);
    if (MARINARA_NAME.test(k) && text.length <= MARINARA_MAX) {
      toMarinara[k] = text;
      dropLocal.add(k);
    } else {
      setLocal[k] = text;
      if (MARINARA_NAME.test(k)) toMarinara[k] = null;
    }
  }
  // names Marinara refuses (its macro names) or past its 500-variable limit go to Fornello's part
  for (let tries = 0; Object.keys(toMarinara).length && tries < 50; tries++) {
    try {
      await api(`/chats/${enc(chatId)}/metadata`, { method: "PATCH", body: { macroVariables: toMarinara } });
      forgetChat(chatId);
      break;
    } catch (e) {
      const message = e instanceof Error ? e.message : String(e);
      const refused = /Invalid chat variable name: (.+)$/.exec(message)?.[1]?.trim();
      const moved = refused !== undefined && Object.hasOwn(toMarinara, refused) ? [refused] : /cannot hold more than/i.test(message) ? Object.keys(toMarinara) : [];
      if (!moved.length) throw e;
      for (const k of moved) {
        const v = toMarinara[k];
        delete toMarinara[k];
        if (v === null) continue;
        setLocal[k] = v;
        dropLocal.delete(k);
      }
    }
  }
  const json = Object.entries(values).map(([k, v]) => [k, v !== null && v !== undefined && typeof v !== "string"] as const);
  // nothing of Fornello's part changes (plain variables Marinara took): no second write
  if (!replace && !Object.keys(setLocal).length && !json.some(([, j]) => j)) {
    const before = (await readChatData(chatId).catch(() => null)) ?? { vars: {}, json: [] as string[] };
    if (![...dropLocal].some((k) => Object.hasOwn(before.vars, k)) && !json.some(([k]) => before.json.includes(k))) return;
  }
  await updateChatData(chatId, (data) => {
    const vars = replace ? {} : data.vars;
    for (const k of dropLocal) delete vars[k];
    Object.assign(vars, setLocal);
    const names = new Set(replace ? [] : data.json);
    for (const [k, isJson] of json) {
      if (isJson) names.add(k);
      else names.delete(k);
    }
    return { ...data, vars, json: [...names] };
  });
}

/** Fornello is turned off: writes still queued finish, nothing else is kept. */
export function clearChatData(): void {
  chatQueues.clear();
}
