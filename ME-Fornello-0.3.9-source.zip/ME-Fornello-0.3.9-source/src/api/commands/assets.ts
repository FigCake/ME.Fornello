// Page commands for a character's assets: the pictures its card names (the
// Character assets window) and its sprites, so a page can show them by name
// (a status panel's portrait, a scene's background).

import { type Asset, assetUrl, cardAssets, withSprites } from "../../assets/model";
import { findAssets, pickOne } from "../../assets/names";
import { spriteListOf } from "../../assets/store";
import { cmd } from "../command";
import { characterData } from "../library";
import type { PageSession } from "../session";
import { findChar } from "./people";

export interface AssetItem {
  name: string;
  /** The picture's address (for <img src> or a CSS url()). */
  url: string;
  /** A picture of the card's Gallery, or a sprite (named by its expression). */
  kind: "picture" | "sprite";
  person?: string;
  words?: string[];
}

/** A page's reads, by character id: each character's assets are read once a page. */
const read = new WeakMap<PageSession, Map<string, Promise<{ id: string; assets: Asset[] }>>>();

/** A character's assets: its card's list, then its sprites not listed there. */
function assetsOf(s: PageSession, who?: unknown): Promise<{ id: string; assets: Asset[] }> {
  const c = findChar(s, who);
  let mine = read.get(s);
  if (!mine) read.set(s, (mine = new Map()));
  let p = mine.get(c.id);
  if (!p) {
    p = (async () => {
      const inChat = s.cast.find((x) => x.id === c.id);
      const listed = cardAssets(inChat ? inChat.data : await characterData(c.id));
      return { id: c.id, assets: withSprites(listed, await spriteListOf(c.id)) };
    })();
    mine.set(c.id, p);
    // a read that failed is tried again on the next call
    const tried = p;
    p.catch(() => mine.get(c.id) === tried && mine.delete(c.id));
  }
  return p;
}

/** Every asset of a character (the chat's first when none is named). */
async function getAssets(s: PageSession, who?: unknown): Promise<AssetItem[]> {
  const { id, assets } = await assetsOf(s, who);
  return assets.map((a) => ({
    name: a.name,
    url: assetUrl(id, a),
    kind: a.place === "sprite" ? "sprite" : "picture",
    ...(a.person ? { person: a.person } : {}),
    ...(a.words?.length ? { words: [...a.words] } : {}),
  }));
}

/**
 * The address of the asset a name means, compared as tags are (case, marks
 * and a picture extension don't count; a near name is found), or "" when none.
 * Several of one name: always the same one for the same name.
 */
async function getAsset(s: PageSession, name: unknown, options: { char?: string; person?: string } = {}): Promise<string> {
  const wanted = String(name ?? "").trim();
  if (!wanted) return "";
  const { id, assets } = await assetsOf(s, options.char);
  const found = findAssets(assets, { name: wanted, ...(options.person ? { person: String(options.person) } : {}) });
  const one = pickOne(found, wanted);
  return one ? assetUrl(id, one) : "";
}

export function assetCommands(s: PageSession) {
  return {
    getAssets: cmd((who?: unknown) => getAssets(s, who)),
    getAsset: cmd((name: unknown, options?: { char?: string; person?: string }) => getAsset(s, name, options)),
  };
}
