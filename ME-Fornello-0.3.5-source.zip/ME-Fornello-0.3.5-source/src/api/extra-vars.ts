// Variables kept in Fornello's extension storage: global, a script's own and
// a character's. Read once, then answered without await (as JS-Slash-Runner's
// getVariables); writes are saved a moment later.

import { getMarinara } from "../shared/marinara-global";

export type ExtraScope = "global" | "script" | "character";

interface ExtraVars {
  global: Record<string, unknown>;
  script: Record<string, Record<string, unknown>>;
  character: Record<string, Record<string, unknown>>;
}

const obj = (v: unknown): Record<string, unknown> => (v && typeof v === "object" && !Array.isArray(v) ? (v as Record<string, unknown>) : {});

let loaded: Promise<ExtraVars> | null = null;
let value: ExtraVars = { global: {}, script: {}, character: {} };
let saveTimer: ReturnType<typeof setTimeout> | null = null;

/** Reads them (once; later calls share the read). */
export function loadExtraVars(): Promise<void> {
  loaded ??= getMarinara()
    .storage.get()
    .then((stored) => {
      const raw = obj(stored.vars);
      value = { global: obj(raw.global), script: obj(raw.script) as ExtraVars["script"], character: obj(raw.character) as ExtraVars["character"] };
      return value;
    })
    .catch(() => value);
  return loaded.then(() => undefined);
}

function bucket(scope: ExtraScope, key: string): Record<string, unknown> {
  if (scope === "global") return value.global;
  const map = value[scope];
  return (map[key] ??= {});
}

/** The variables of a scope (`key`: the script's or the character's), starting from `initial` when there are none saved yet. */
export function readExtra(scope: ExtraScope, key: string, initial: Record<string, unknown> = {}): Record<string, unknown> {
  const own = scope === "global" ? value.global : value[scope][key];
  return structuredClone(own ?? initial);
}

/** Sets them (`replace`: they become exactly these; null deletes one). */
export function writeExtra(scope: ExtraScope, key: string, values: Record<string, unknown>, { replace = false, initial = {} as Record<string, unknown> } = {}): void {
  if (scope !== "global" && !value[scope][key]) value[scope][key] = structuredClone(initial);
  const target = bucket(scope, key);
  if (replace) for (const k of Object.keys(target)) delete target[k];
  for (const [k, v] of Object.entries(values ?? {})) {
    if (v === null || v === undefined) delete target[k];
    else target[k] = structuredClone(v);
  }
  save();
}

function save(): void {
  if (saveTimer) return;
  saveTimer = setTimeout(() => {
    saveTimer = null;
    void getMarinara()
      .storage.patch({ vars: value })
      .catch((e: unknown) => console.warn("[Fornello] could not save variables:", e));
  }, 300);
}

/** Saves what is waiting and forgets the rest (Fornello stopped). */
export function stopExtraVars(): void {
  if (saveTimer) {
    clearTimeout(saveTimer);
    saveTimer = null;
    void getMarinara().storage.patch({ vars: value }).catch(() => undefined);
  }
  loaded = null;
  value = { global: {}, script: {}, character: {} };
}
