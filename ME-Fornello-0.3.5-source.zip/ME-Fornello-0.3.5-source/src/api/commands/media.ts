// Page commands for pictures (the chat's image connection) and voice (Marinara's voice settings).

import { cmd } from "../command";
import { generateImage, speech } from "../features";
import type { PageSession } from "../session";

/** Makes a picture; its address comes back (for <img src>). */
async function genImage(s: PageSession, prompt: unknown, options: { title?: string } = {}): Promise<string> {
  return (await generateImage(s.here(), String(prompt ?? ""), options.title)).url;
}

/** Reads text aloud; done when it has been read (or the page closed, or stopSpeaking()). */
async function speak(s: PageSession, text: unknown, options: { voice?: string } = {}): Promise<boolean> {
  const audio = new Audio(URL.createObjectURL(await speech(String(text ?? ""), options.voice)));
  speaking.get(s)?.pause();
  speaking.set(s, audio);
  return new Promise<boolean>((resolve) => {
    const finish = (played: boolean) => {
      URL.revokeObjectURL(audio.src);
      if (speaking.get(s) === audio) speaking.delete(s);
      resolve(played);
    };
    audio.onended = () => finish(true);
    audio.onerror = () => finish(false);
    audio.onpause = () => {
      if (!audio.ended) finish(false);
    };
    void audio.play().catch(() => finish(false));
  });
}

/** What each page is reading aloud now. */
const speaking = new WeakMap<PageSession, HTMLAudioElement>();

export function mediaCommands(s: PageSession) {
  // reading stops with the page
  s.onDispose(() => speaking.get(s)?.pause());
  return {
    genImage: cmd({ writes: true, paid: true }, (prompt: unknown, options?: { title?: string }) => genImage(s, prompt, options)),
    speak: cmd({ costs: true }, (text: unknown, options?: { voice?: string }) => speak(s, text, options)),
    stopSpeaking: cmd(() => {
      speaking.get(s)?.pause();
      return true;
    }),
  };
}
