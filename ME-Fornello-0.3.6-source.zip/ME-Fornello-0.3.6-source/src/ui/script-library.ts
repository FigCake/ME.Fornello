// The script library window: the person's own scripts, the chat's cards' and
// the chat's own, as lists of scripts and folders, with an editor (line
// numbers, syntax errors as you type, the script's log).

import { chatCharacters } from "../api/chat-store";
import { currentChatId } from "../host/current-chat";
import type { Settings } from "../settings";
import { t } from "../shared/i18n";
import { FORM_CSS, section, setting, toggle } from "../shared/form";
import { CONTROLS, THEME_TOKENS } from "../shared/theme";
import type { ChatScripts, LogLine, ScriptHost } from "../scripts/host";
import { chatTrustKey } from "../scripts/host";
import { type ListPlace, placeKey, readList, writeList } from "../scripts/lists";
import { type CardScripts, type GlobalScript, type LibraryItem, type ScriptFolder, folderIconText, isFolder, newScriptId, normalizeButtons } from "../scripts/model";
import { checkScript } from "../scripts/runtime";
import { type FoundScripts, exportJson, fileName, hasData, scriptsFromFile } from "../scripts/files";
import { showToast } from "./toast";
import { BACKDROP_CSS, el, pickFile } from "./dom";

const STYLE = `
${THEME_TOKENS}
:host { position: fixed; inset: 0; z-index: 2147482700; }
* { box-sizing: border-box; }
${CONTROLS}
${FORM_CSS}
${BACKDROP_CSS}
.win { width: min(1040px, 100%); height: min(860px, 100%); display: flex; flex-direction: column; overflow: hidden;
  font: 13px/1.45 var(--d-font); color: var(--d-text); background: var(--d-panel-solid); border: 1px solid var(--d-line); border-radius: var(--d-radius); box-shadow: var(--d-shadow); }
header { display: flex; align-items: center; gap: 8px; padding: 10px 14px; border-bottom: 1px solid var(--d-divider); }
header h2 { margin: 0; font-size: 15px; color: var(--d-title); flex: 1; }
.body { flex: 1; min-height: 0; display: grid; grid-template-columns: minmax(280px, 380px) minmax(0, 1fr); }
.body.single { grid-template-columns: minmax(0, 1fr); }
.lists { overflow: auto; padding: 8px 12px 16px; border-right: 1px solid var(--d-divider); }
.pane { overflow: auto; padding: 12px 16px 18px; display: flex; flex-direction: column; gap: 8px; min-width: 0; }
@media (max-width: 760px) {
  .body { grid-template-columns: minmax(0, 1fr); }
  .body.editing .lists { display: none; }
  .body:not(.editing) .pane { display: none; }
}
.note { color: var(--d-muted); font-size: 12px; }
.row { display: flex; gap: 6px; align-items: center; flex-wrap: wrap; }
.item { display: flex; align-items: center; gap: 6px; padding: 5px 6px; border: 1px solid var(--d-line); border-radius: var(--d-radius-sm); margin: 3px 0; background: var(--d-panel-solid); }
.item.sel { border-color: var(--d-btn-border-active); background: var(--d-hl-bg); }
.item.drop { outline: 2px dashed var(--d-btn-border-active); }
.item .name { flex: 1; min-width: 0; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; cursor: pointer; font-weight: 600; }
.folder > .item { background: var(--d-field); }
.folder > .item .name { font-weight: 700; }
.folder .inside { margin-left: 14px; padding-left: 6px; border-left: 2px solid var(--folder, var(--d-line)); }
.dot { width: 10px; height: 10px; border-radius: 50%; background: var(--folder, var(--d-line)); flex: none; }
.badge { font-size: 11px; padding: 1px 6px; border-radius: 999px; border: 1px solid var(--d-line); color: var(--d-muted); white-space: nowrap; }
.badge.run { color: #3fb97a; border-color: #3fb97a66; }
.badge.bad { color: var(--d-danger); border-color: var(--d-danger); }
button.mini { padding: 2px 7px; font-size: 12px; min-width: 0; }
.menu { display: flex; flex-wrap: wrap; gap: 4px; padding: 6px; margin: -2px 0 4px; border: 1px dashed var(--d-line); border-radius: var(--d-radius-sm); }
.menu .lab { width: 100%; font-size: 11px; color: var(--d-muted); }
.code-wrap { display: grid; grid-template-columns: auto minmax(0, 1fr); border: 1px solid var(--d-line); border-radius: var(--d-radius-sm); background: var(--d-field); min-height: 300px; overflow: hidden; }
.gutter { font: 12px/1.5 var(--d-mono); color: var(--d-muted); text-align: right; padding: 8px 6px 8px 8px; user-select: none; overflow: hidden; white-space: pre; border-right: 1px solid var(--d-divider); }
.gutter .bad { color: var(--d-danger); font-weight: 700; }
textarea.code { font: 12px/1.5 var(--d-mono); border: 0; border-radius: 0; background: transparent; resize: vertical; min-height: 300px; white-space: pre; overflow: auto; padding: 8px; tab-size: 2; }
textarea.small { min-height: 64px; resize: vertical; font: 12px/1.45 var(--d-mono); }
.err { color: var(--d-danger); white-space: pre-wrap; font-size: 12px; }
.ok { color: #3fb97a; font-size: 12px; }
.log { font: 11px/1.45 var(--d-mono); max-height: 220px; overflow: auto; border: 1px solid var(--d-line); border-radius: var(--d-radius-sm); padding: 6px 8px; background: var(--d-field); white-space: pre-wrap; }
.log .warn { color: #d9a43a; }
.log .error { color: var(--d-danger); }
.log time { color: var(--d-muted); margin-right: 6px; }
.sec-state { font-size: 12px; color: var(--d-muted); }
/* a list's heading and its buttons wrap on a narrow screen instead of running over each other */
.sec-h { flex-wrap: wrap; row-gap: 4px; }
.sec-h h3 { min-width: 0; overflow-wrap: anywhere; }
.sec-h button.mini { white-space: nowrap; }
`;

/** A list on screen: where it is kept, its items, and (for a card or chat) whether the person allowed it. */
interface Shown {
  place: ListPlace;
  title: string;
  items: LibraryItem[];
  card?: CardScripts;
  chat?: ChatScripts | null;
}

type Editing =
  | { kind: "script"; place: ListPlace; draft: GlobalScript; isNew: boolean; folderId: string | null }
  | { kind: "folder"; place: ListPlace; draft: ScriptFolder; isNew: boolean }
  | { kind: "import"; place: ListPlace; found: FoundScripts; picked: Set<number> };

/** The key a running script goes by (ScriptHost), from where it is kept. */
const runKey = (place: ListPlace, id: string): string => (place.kind === "global" ? `global:${id}` : place.kind === "card" ? `card:${place.characterId}:${id}` : `chat:${place.chatId}:${id}`);

const blankScript = (): GlobalScript => ({ id: newScriptId(), name: t("New script", "새 스크립트"), code: "", enabled: true, buttons: [], info: "", data: {} });
const blankFolder = (): ScriptFolder => ({ type: "folder", id: newScriptId(), name: t("New folder", "새 폴더"), enabled: true, icon: "📁", color: "#7c8cff", scripts: [] });

export class ScriptLibrary {
  private element: HTMLElement | null = null;
  private root: ShadowRoot | null = null;
  private shown: Shown[] = [];
  private editing: Editing | null = null;
  /** The row whose ⋯ menu is open (place key + item id). */
  private menuFor: string | null = null;
  private readonly closedFolders = new Set<string>();
  private problem: { message: string; line: number | null } | null = null;
  private checkTimer: ReturnType<typeof setTimeout> | null = null;
  private unwatch: (() => void) | null = null;
  private returnFocus: HTMLElement | null = null;
  /** A drag in progress: where it comes from. */
  private dragging: { place: string; id: string } | null = null;

  constructor(
    private readonly settings: Settings,
    private readonly host: ScriptHost,
  ) {}

  async open(): Promise<void> {
    if (!this.element) {
      this.element = document.createElement("div");
      this.element.id = "fornello-scripts";
      this.root = this.element.attachShadow({ mode: "open" });
      this.returnFocus = document.activeElement instanceof HTMLElement ? document.activeElement : null;
      document.addEventListener("keydown", this.onKey, true);
      document.body.append(this.element);
      this.unwatch = this.host.watch(() => this.redrawSoon());
    }
    this.render();
    await this.load();
  }

  close(): void {
    document.removeEventListener("keydown", this.onKey, true);
    this.unwatch?.();
    this.unwatch = null;
    const wasOpen = !!this.element;
    this.element?.remove();
    this.element = null;
    this.root = null;
    this.editing = null;
    if (wasOpen && this.returnFocus?.isConnected) this.returnFocus.focus();
  }

  /** Redraws when open (the language or the settings changed). */
  refresh(): void {
    if (this.root) void this.load();
  }

  private readonly onKey = (e: KeyboardEvent) => {
    if (e.key !== "Escape" || !this.element) return;
    e.stopPropagation();
    if (this.editing) {
      this.editing = null;
      this.render();
    } else this.close();
  };

  private redrawScheduled = false;
  private redrawSoon(): void {
    if (this.redrawScheduled || !this.root) return;
    this.redrawScheduled = true;
    requestAnimationFrame(() => {
      this.redrawScheduled = false;
      // a redraw while typing would lose the cursor: the log updates on the next one
      if (this.root && !this.root.activeElement?.matches("textarea, input")) this.render();
    });
  }

  /** Reads the lists: the person's own, the chat's characters', the chat's. */
  private async load(): Promise<void> {
    const chatId = currentChatId();
    const status = this.host.status();
    const shown: Shown[] = [{ place: { kind: "global" }, title: t("My scripts (every chat)", "내 스크립트 (모든 채팅)"), items: structuredClone(this.settings.current.scripts) }];
    if (chatId) {
      const cast = await chatCharacters(chatId).catch(() => []);
      for (const c of cast) {
        const place: ListPlace = { kind: "card", characterId: c.id, characterName: c.name };
        const items = await readList(this.settings, place).catch(() => [] as LibraryItem[]);
        shown.push({ place, title: t(`Card: ${c.name}`, `카드: ${c.name}`), items, card: status.cards.find((x) => x.characterId === c.id) });
      }
      const place: ListPlace = { kind: "chat", chatId };
      shown.push({ place, title: t("This chat", "이 채팅"), items: await readList(this.settings, place).catch(() => [] as LibraryItem[]), chat: status.chat });
    }
    this.shown = shown;
    this.render();
  }

  // ── drawing ──

  private render(): void {
    if (!this.root) return;
    const scroll = this.root.querySelector(".lists")?.scrollTop ?? 0;
    const style = document.createElement("style");
    style.textContent = STYLE;
    const head = el(
      "header",
      {},
      el("h2", {}, t("🔥 Script library", "🔥 스크립트 보관함")),
      el("button", { className: "ghost", "aria-label": t("Close", "닫기"), onclick: () => this.close() }, "✕"),
    );
    const lists = el("div", { className: "lists" }, ...this.shown.map((sh) => this.listSection(sh)));
    if (!this.shown.length) lists.append(el("div", { className: "note" }, t("Loading…", "불러오는 중…")));
    const pane = el("div", { className: "pane" }, this.editing ? this.editor(this.editing) : el("div", { className: "note" }, t("Pick a script to edit it, or make a new one.", "고칠 스크립트를 고르거나 새로 만드세요.")));
    const body = el("div", { className: `body${this.editing ? " editing" : ""}` }, lists, pane);
    const win = el("div", { className: "win", role: "dialog", "aria-modal": "true", "aria-label": t("Script library", "스크립트 보관함"), tabIndex: -1 }, head, body);
    const back = el("div", { className: "back", onclick: (e: Event) => e.target === back && this.close() }, win);
    this.root.replaceChildren(style, back);
    const newLists = this.root.querySelector(".lists");
    if (newLists) newLists.scrollTop = scroll;
    if (this.problem?.line) this.markLine();
  }

  private listSection(sh: Shown): HTMLElement {
    const key = placeKey(sh.place);
    const extra: (Node | string)[] = [
      el("button", { className: "mini", title: t("New script", "새 스크립트"), onclick: () => this.edit({ kind: "script", place: sh.place, draft: blankScript(), isNew: true, folderId: null }) }, t("+ Script", "+ 스크립트")),
      el("button", { className: "mini", title: t("New folder", "새 폴더"), onclick: () => this.edit({ kind: "folder", place: sh.place, draft: blankFolder(), isNew: true }) }, t("+ Folder", "+ 폴더")),
      el("button", { className: "mini", title: t("Import script files, zips, cards or .js", "스크립트 파일·zip·카드·.js 가져오기"), onclick: () => this.importFile(sh.place) }, t("Import", "가져오기")),
      el("button", { className: "mini", title: t("Export this list as a script file", "이 목록을 스크립트 파일로 내보내기"), onclick: () => this.exportItems(sh.items, sh.title) }, t("Export", "내보내기")),
    ];
    const kids: (Node | null)[] = [this.trustLine(sh)];
    if (!sh.items.length) kids.push(el("div", { className: "note", style: "padding:4px 0" }, t("No scripts.", "스크립트 없음.")));
    for (const item of sh.items) kids.push(isFolder(item) ? this.folderBlock(sh, item) : this.scriptRow(sh, item, null));
    // a drop on the list itself puts the dragged item at its end
    const box = section(sh.title, undefined, extra, ...kids.filter((k): k is Node => !!k));
    box.addEventListener("dragover", (e) => this.dragging?.place === key && e.preventDefault());
    box.addEventListener("drop", (e) => {
      if (this.dragging?.place !== key || (e.target as HTMLElement).closest(".item")) return;
      e.preventDefault();
      void this.moveTo(sh, this.dragging.id, null, null);
    });
    return box;
  }

  /** For a card's or chat's list: whether it runs, and the person's say. */
  private trustLine(sh: Shown): HTMLElement | null {
    const trusted = this.settings.current.trustedScripts;
    if (sh.place.kind === "card" && sh.card) {
      const card = sh.card;
      const answer = trusted[card.characterId];
      const allowed = answer === card.hash;
      return el(
        "div",
        { className: "row sec-state" },
        allowed
          ? t("Allowed: runs in this character's chats", "허락함: 이 캐릭터 채팅에서 실행")
          : answer === `no:${card.hash}`
            ? t("Not run", "실행 안 함")
            : this.host.status().notNow.has(`${card.characterId}:${card.hash}`)
              ? t("Not now (asked again after a reload)", "지금은 안 함 (새로고침하면 다시 물어봄)")
              : t("Not asked yet", "아직 안 물어봄"),
        el("button", { className: "mini", onclick: () => void this.host.answer(card, !allowed).then(() => this.load()) }, allowed ? t("Stop allowing", "허락 취소") : t("Allow", "허락")),
      );
    }
    if (sh.place.kind === "chat" && sh.chat) {
      const chat = sh.chat;
      const allowed = trusted[chatTrustKey(chat.chatId)] === chat.hash;
      return el(
        "div",
        { className: "row sec-state" },
        allowed ? t("Allowed: runs in this chat", "허락함: 이 채팅에서 실행") : t("Not allowed", "허락 안 함"),
        el("button", { className: "mini", onclick: () => void this.host.answerChat(chat, !allowed).then(() => this.load()) }, allowed ? t("Stop allowing", "허락 취소") : t("Allow", "허락")),
      );
    }
    return null;
  }

  private folderBlock(sh: Shown, folder: ScriptFolder): HTMLElement {
    const key = `${placeKey(sh.place)}/${folder.id}`;
    const closed = this.closedFolders.has(key);
    const head = el(
      "div",
      { className: "item", draggable: true },
      el("button", { className: "mini ghost", "aria-label": closed ? t("Open", "열기") : t("Close", "닫기"), onclick: () => (closed ? this.closedFolders.delete(key) : this.closedFolders.add(key), this.render()) }, closed ? "▸" : "▾"),
      el("span", { className: "dot" }),
      toggle(folder.enabled, (on) => void this.change(sh, (items) => items.map((i) => (isFolder(i) && i.id === folder.id ? { ...i, enabled: on } : i))), t(`Turn on ${folder.name}`, `${folder.name} 켜기`)),
      el("span", { className: "name", onclick: () => this.edit({ kind: "folder", place: sh.place, draft: structuredClone(folder), isNew: false }) }, `${folderIconText(folder.icon) ? `${folderIconText(folder.icon)} ` : ""}${folder.name}`),
      el("span", { className: "badge" }, String(folder.scripts.length)),
      el("button", { className: "mini", title: t("New script in this folder", "이 폴더에 새 스크립트"), onclick: () => this.edit({ kind: "script", place: sh.place, draft: blankScript(), isNew: true, folderId: folder.id }) }, "+"),
      el("button", { className: "mini", "aria-label": t("More", "더 보기"), onclick: () => this.toggleMenu(key) }, "⋯"),
    );
    this.dragRow(head, sh, folder.id, folder.id);
    const block = el("div", { className: "folder", style: `--folder:${folder.color || "var(--d-line)"}` }, head);
    if (this.menuFor === key) block.append(this.itemMenu(sh, folder.id, true));
    if (!closed) block.append(el("div", { className: "inside" }, ...folder.scripts.map((g) => this.scriptRow(sh, g, folder)), folder.scripts.length ? null : el("div", { className: "note" }, t("Empty", "비어 있음"))));
    return block;
  }

  private scriptRow(sh: Shown, g: GlobalScript, folder: ScriptFolder | null): HTMLElement {
    const s = this.settings.current;
    const run = runKey(sh.place, g.id);
    const running = this.host.status().running.has(run);
    const bad = this.host.logOf(run).some((l) => l.kind === "error");
    const key = `${placeKey(sh.place)}/${g.id}`;
    const selected = this.editing?.kind === "script" && placeKey(this.editing.place) === placeKey(sh.place) && this.editing.draft.id === g.id;
    const row = el(
      "div",
      { className: `item${selected ? " sel" : ""}`, draggable: true },
      toggle(s.scriptSwitch[run] ?? g.enabled, (on) => void this.settings.set({ scriptSwitch: { ...s.scriptSwitch, [run]: on } }).then(() => this.render()), t(`Turn on ${g.name}`, `${g.name} 켜기`)),
      el("span", { className: "name", role: "button", tabIndex: 0, onclick: () => this.edit({ kind: "script", place: sh.place, draft: structuredClone(g), isNew: false, folderId: folder?.id ?? null }) }, g.name),
      g.buttons.length ? el("span", { className: "badge", title: t("Buttons", "버튼") }, `▢ ${g.buttons.length}`) : null,
      running ? el("span", { className: "badge run" }, t("Running", "실행 중")) : null,
      bad ? el("span", { className: "badge bad" }, t("Error", "오류")) : null,
      el("button", { className: "mini", "aria-label": t("More", "더 보기"), onclick: () => this.toggleMenu(key) }, "⋯"),
    );
    this.dragRow(row, sh, g.id, folder ? folder.id : null);
    const out = el("div", {}, row);
    if (this.menuFor === key) out.append(this.itemMenu(sh, g.id, false));
    return out;
  }

  private toggleMenu(key: string): void {
    this.menuFor = this.menuFor === key ? null : key;
    this.render();
  }

  /** Up, down, into a folder, to another list (copy or move), delete. */
  private itemMenu(sh: Shown, id: string, folder: boolean): HTMLElement {
    const box = el("div", { className: "menu" });
    box.append(
      el("button", { className: "mini", onclick: () => void this.nudge(sh, id, -1) }, t("↑ Up", "↑ 위로")),
      el("button", { className: "mini", onclick: () => void this.nudge(sh, id, 1) }, t("↓ Down", "↓ 아래로")),
    );
    if (!folder) {
      const folders = sh.items.filter(isFolder);
      const inside = folders.find((f) => f.scripts.some((g) => g.id === id));
      if (inside) box.append(el("button", { className: "mini", onclick: () => void this.moveTo(sh, id, null, null) }, t("Out of the folder", "폴더 밖으로")));
      for (const f of folders) if (f !== inside) box.append(el("button", { className: "mini", onclick: () => void this.moveTo(sh, id, f.id, null) }, t(`Into ${f.name}`, `${f.name}에 넣기`)));
    }
    const others = this.shown.filter((x) => placeKey(x.place) !== placeKey(sh.place));
    if (others.length) {
      box.append(el("span", { className: "lab" }, t("To another list", "다른 목록으로")));
      for (const o of others) {
        box.append(
          el("button", { className: "mini", onclick: () => void this.copyTo(sh, id, o, false) }, t(`Copy → ${o.title}`, `복사 → ${o.title}`)),
          el("button", { className: "mini", onclick: () => void this.copyTo(sh, id, o, true) }, t(`Move → ${o.title}`, `옮기기 → ${o.title}`)),
        );
      }
    }
    const { item } = ScriptLibrary.take(sh.items, id);
    if (item) box.append(el("button", { className: "mini", onclick: () => this.exportItems([item], item.name) }, t("Export", "내보내기")));
    box.append(el("button", { className: "mini danger", onclick: () => void this.remove(sh, id) }, t("Delete", "지우기")));
    return box;
  }

  /** Drag within a list: drop on a script puts it before that one; on a folder, into the folder. */
  private dragRow(row: HTMLElement, sh: Shown, id: string, folderId: string | null): void {
    const key = placeKey(sh.place);
    row.addEventListener("dragstart", (e) => {
      this.dragging = { place: key, id };
      e.dataTransfer?.setData("text/plain", id);
    });
    row.addEventListener("dragend", () => (this.dragging = null));
    row.addEventListener("dragover", (e) => {
      if (this.dragging?.place !== key || this.dragging.id === id) return;
      e.preventDefault();
      row.classList.add("drop");
    });
    row.addEventListener("dragleave", () => row.classList.remove("drop"));
    row.addEventListener("drop", (e) => {
      if (this.dragging?.place !== key || this.dragging.id === id) return;
      e.preventDefault();
      e.stopPropagation();
      const dragged = this.dragging.id;
      this.dragging = null;
      // a folder's row takes a script into the folder; folders stay at the top level
      const isFolderRow = sh.items.some((i) => isFolder(i) && i.id === id);
      const draggedIsFolder = sh.items.some((i) => isFolder(i) && i.id === dragged);
      if (isFolderRow && !draggedIsFolder) void this.moveTo(sh, dragged, id, null);
      else void this.moveTo(sh, dragged, draggedIsFolder ? null : folderId, id);
    });
  }

  // ── changing a list ──

  /** Writes a list as `change` makes it, then reads the lists again. */
  private async change(sh: Shown, change: (items: LibraryItem[]) => LibraryItem[]): Promise<boolean> {
    try {
      await writeList(this.settings, sh.place, change(structuredClone(sh.items)));
      this.host.refresh();
      await this.load();
      return true;
    } catch (e) {
      showToast(t(`Not saved: ${e instanceof Error ? e.message : e}`, `저장 안 됨: ${e instanceof Error ? e.message : e}`), "error");
      return false;
    }
  }

  /** Takes an item (script or folder) out of a list; it comes back with the list without it. */
  private static take(items: LibraryItem[], id: string): { item: LibraryItem | null; rest: LibraryItem[] } {
    let item: LibraryItem | null = null;
    const rest = items.flatMap((i): LibraryItem[] => {
      if (i.id === id) {
        item = i;
        return [];
      }
      if (isFolder(i)) {
        const kept = i.scripts.filter((g) => {
          if (g.id === id) item = g;
          return g.id !== id;
        });
        return [{ ...i, scripts: kept }];
      }
      return [i];
    });
    return { item, rest };
  }

  /** Puts an item into a folder (or the top level), before `beforeId` or at the end. */
  private static put(items: LibraryItem[], item: LibraryItem, folderId: string | null, beforeId: string | null): LibraryItem[] {
    if (folderId && !isFolder(item)) {
      return items.map((i) => {
        if (!isFolder(i) || i.id !== folderId) return i;
        const at = beforeId ? i.scripts.findIndex((g) => g.id === beforeId) : -1;
        const scripts = [...i.scripts];
        scripts.splice(at < 0 ? scripts.length : at, 0, item);
        return { ...i, scripts };
      });
    }
    const out = [...items];
    const at = beforeId ? out.findIndex((i) => i.id === beforeId) : -1;
    out.splice(at < 0 ? out.length : at, 0, item);
    return out;
  }

  private moveTo(sh: Shown, id: string, folderId: string | null, beforeId: string | null): Promise<boolean> {
    return this.change(sh, (items) => {
      const { item, rest } = ScriptLibrary.take(items, id);
      return item ? ScriptLibrary.put(rest, item, folderId, beforeId) : items;
    });
  }

  /** One step up or down among its neighbours. */
  private nudge(sh: Shown, id: string, by: number): Promise<boolean> {
    return this.change(sh, (items) => {
      const swap = <T extends { id: string }>(list: T[]): T[] | null => {
        const i = list.findIndex((x) => x.id === id);
        const j = i + by;
        if (i < 0 || j < 0 || j >= list.length) return i < 0 ? null : list;
        const out = [...list];
        [out[i], out[j]] = [out[j], out[i]];
        return out;
      };
      const top = swap(items);
      if (top) return top;
      return items.map((i) => (isFolder(i) ? { ...i, scripts: swap(i.scripts) ?? i.scripts } : i));
    });
  }

  private async copyTo(from: Shown, id: string, to: Shown, move: boolean): Promise<void> {
    const { item } = ScriptLibrary.take(from.items, id);
    if (!item) return;
    // a copy is a script (or folder) of its own
    const fresh = (g: GlobalScript): GlobalScript => ({ ...structuredClone(g), id: newScriptId() });
    const copy: LibraryItem = isFolder(item) ? { ...structuredClone(item), id: newScriptId(), scripts: item.scripts.map(fresh) } : fresh(item);
    if (!(await this.change(to, (items) => [...items, copy]))) return;
    if (move) {
      const source = this.shown.find((x) => placeKey(x.place) === placeKey(from.place));
      if (source) await this.change(source, (items) => ScriptLibrary.take(items, id).rest);
    }
    this.menuFor = null;
    showToast(move ? t(`Moved to ${to.title}.`, `${to.title}(으)로 옮겼어요.`) : t(`Copied to ${to.title}.`, `${to.title}에 복사했어요.`), "success");
  }

  private async remove(sh: Shown, id: string): Promise<void> {
    const { item } = ScriptLibrary.take(sh.items, id);
    if (!item) return;
    const what = isFolder(item) ? t(`the folder "${item.name}" and its ${item.scripts.length} script(s)`, `"${item.name}" 폴더와 안의 스크립트 ${item.scripts.length}개`) : `"${item.name}"`;
    if (!window.confirm(t(`Delete ${what}?`, `${what}를 지울까요?`))) return;
    const open = this.editing && this.editing.kind !== "import" ? this.editing.draft.id : null;
    if (open && (open === id || (isFolder(item) && item.scripts.some((g) => g.id === open)))) this.editing = null;
    this.menuFor = null;
    await this.change(sh, (items) => ScriptLibrary.take(items, id).rest);
  }

  // ── the editor ──

  private edit(next: Editing): void {
    this.editing = next;
    this.menuFor = null;
    this.problem = next.kind === "script" ? checkScript(next.draft.code) : null;
    this.render();
  }

  private editor(e: Editing): HTMLElement {
    return e.kind === "folder" ? this.folderEditor(e) : e.kind === "import" ? this.importer(e) : this.scriptEditor(e);
  }

  private folderEditor(e: Extract<Editing, { kind: "folder" }>): HTMLElement {
    const d = e.draft;
    const name = el("input", { value: d.name, "aria-label": t("Folder name", "폴더 이름") });
    const icon = el("input", { value: d.icon, maxLength: 4, style: "width:64px", "aria-label": t("Icon", "아이콘") });
    const color = el("input", { type: "color", value: /^#[0-9a-f]{6}$/i.test(d.color) ? d.color : "#7c8cff", "aria-label": t("Colour", "색") });
    const save = () => {
      const next: ScriptFolder = { ...d, name: name.value.trim() || t("Folder", "폴더"), icon: icon.value.trim(), color: color.value };
      const sh = this.shown.find((x) => placeKey(x.place) === placeKey(e.place));
      if (!sh) return;
      void this.change(sh, (items) => (e.isNew ? [...items, next] : items.map((i) => (isFolder(i) && i.id === d.id ? { ...next, scripts: i.scripts } : i)))).then((ok) => {
        if (!ok) return;
        this.editing = null;
        this.render();
      });
    };
    return el(
      "div",
      { className: "col" },
      el("div", { className: "row" }, el("button", { className: "mini ghost", onclick: () => ((this.editing = null), this.render()) }, t("← Back", "← 목록")), el("b", {}, e.isNew ? t("New folder", "새 폴더") : t("Folder", "폴더"))),
      setting(t("Name", "이름"), name),
      setting(t("Icon", "아이콘"), icon),
      setting(t("Colour", "색"), color),
      el("div", { className: "row" }, el("button", { className: "primary", onclick: save }, t("Save", "저장")), el("button", { className: "ghost", onclick: () => ((this.editing = null), this.render()) }, t("Close", "닫기"))),
    );
  }

  private scriptEditor(e: Extract<Editing, { kind: "script" }>): HTMLElement {
    const d = e.draft;
    const run = runKey(e.place, d.id);
    const name = el("input", { value: d.name, "aria-label": t("Script name", "스크립트 이름") });
    const gutter = el("div", { className: "gutter", "aria-hidden": "true" });
    const code = el("textarea", {
      className: "code",
      spellcheck: false,
      value: d.code,
      "aria-label": t("Script code", "스크립트 코드"),
      placeholder: "onMsg((m) => { … });",
    });
    const numbers = () => {
      const count = code.value.split("\n").length;
      gutter.replaceChildren(...Array.from({ length: count }, (_, i) => el("div", { className: this.problem?.line === i + 1 ? "bad" : "" }, String(i + 1))));
      gutter.scrollTop = code.scrollTop;
    };
    const problem = el("div", { className: this.problem ? "err" : "ok" }, this.problemText());
    code.addEventListener("scroll", () => (gutter.scrollTop = code.scrollTop));
    code.addEventListener("input", () => {
      d.code = code.value;
      numbers();
      if (this.checkTimer) clearTimeout(this.checkTimer);
      this.checkTimer = setTimeout(() => {
        this.problem = checkScript(code.value);
        problem.className = this.problem ? "err" : "ok";
        problem.textContent = this.problemText();
        numbers();
      }, 350);
    });
    // Tab writes two spaces instead of leaving the box
    code.addEventListener("keydown", (ev) => {
      if (ev.key !== "Tab" || ev.shiftKey) return;
      ev.preventDefault();
      const at = code.selectionStart;
      code.setRangeText("  ", at, code.selectionEnd, "end");
      code.dispatchEvent(new Event("input"));
    });
    numbers();
    const buttons = el("textarea", { className: "small", spellcheck: false, value: d.buttons.map((b) => b.name).join("\n"), "aria-label": t("Buttons, one per line", "버튼 (한 줄에 하나)") });
    const info = el("textarea", { className: "small", value: d.info, "aria-label": t("Note", "설명") });
    const data = el("textarea", { className: "small", spellcheck: false, value: Object.keys(d.data).length ? JSON.stringify(d.data, null, 2) : "", "aria-label": t("Script variables (JSON)", "스크립트 변수 (JSON)"), placeholder: '{ "count": 0 }' });
    const read = (): GlobalScript | null => {
      let parsed: Record<string, unknown> = {};
      if (data.value.trim()) {
        try {
          const v = JSON.parse(data.value);
          if (!v || typeof v !== "object" || Array.isArray(v)) throw new Error("not an object");
          parsed = v;
        } catch {
          showToast(t("Script variables: not a JSON object.", "스크립트 변수: JSON 객체가 아님."), "warning");
          return null;
        }
      }
      return { ...d, name: name.value.trim() || t("Script", "스크립트"), code: code.value, info: info.value, data: parsed, buttons: normalizeButtons(buttons.value.split("\n").map((n) => ({ name: n, visible: true }))) };
    };
    const save = () => {
      const next = read();
      const sh = this.shown.find((x) => placeKey(x.place) === placeKey(e.place));
      if (!next || !sh) return;
      void this.change(sh, (items) => {
        if (!e.isNew) return items.map((i) => (isFolder(i) ? { ...i, scripts: i.scripts.map((g) => (g.id === next.id ? next : g)) } : i.id === next.id ? next : i));
        return ScriptLibrary.put(items, next, e.folderId, null);
      }).then((ok) => {
        if (!ok) return;
        this.editing = { ...e, draft: structuredClone(next), isNew: false };
        showToast(t(`Saved "${next.name}".`, `"${next.name}" 저장함.`), "success");
        this.render();
      });
    };
    const place = this.shown.find((x) => placeKey(x.place) === placeKey(e.place));
    const out = el(
      "div",
      { className: "col", style: "display:flex;flex-direction:column;gap:8px" },
      el(
        "div",
        { className: "row" },
        el("button", { className: "mini ghost", onclick: () => ((this.editing = null), this.render()) }, t("← Back", "← 목록")),
        el("b", {}, e.isNew ? t("New script", "새 스크립트") : d.name),
        place ? el("span", { className: "badge" }, place.title) : null,
      ),
      setting(t("Name", "이름"), name),
      el("div", { className: "code-wrap" }, gutter, code),
      problem,
      setting(t("Buttons", "버튼"), buttons, t('One a line; onButton("name", fn) hears a press', '한 줄에 하나. onButton("이름", fn)으로 받음'), { stack: true }),
      setting(t("Note", "설명"), info, t("What it does", "무엇을 하는지"), { stack: true }),
      setting(t("Script variables", "스크립트 변수"), data, t('Starting values of getVars("script"), as JSON', 'getVars("script")의 처음 값(JSON)'), { stack: true }),
      el("div", { className: "row" }, el("button", { className: "primary", onclick: save }, t("Save", "저장")), el("button", { className: "ghost", onclick: () => ((this.editing = null), this.render()) }, t("Close", "닫기"))),
    );
    if (!e.isNew) out.append(this.logBox(run));
    return out;
  }

  private problemText(): string {
    if (!this.problem) return t("No syntax errors.", "문법 오류 없음.");
    return this.problem.line ? t(`Line ${this.problem.line}: ${this.problem.message}`, `${this.problem.line}번째 줄: ${this.problem.message}`) : this.problem.message;
  }

  /** The gutter's mark on the line with the error, in view. */
  private markLine(): void {
    const bad = this.root?.querySelector<HTMLElement>(".gutter .bad");
    const code = this.root?.querySelector<HTMLTextAreaElement>("textarea.code");
    if (bad && code && bad.offsetTop > code.clientHeight) code.scrollTop = bad.offsetTop - code.clientHeight / 2;
  }

  /** What the script wrote and its errors, newest last, with Restart and Clear. */
  private logBox(run: string): HTMLElement {
    const lines: LogLine[] = this.host.logOf(run);
    const running = this.host.status().running.has(run);
    const box = el("div", { className: "log", role: "log" });
    if (!lines.length) box.append(el("span", { className: "note" }, running ? t("Nothing written yet.", "아직 기록 없음.") : t("Not running.", "실행 중 아님.")));
    for (const l of lines) {
      const time = new Date(l.at).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit", second: "2-digit" });
      box.append(el("div", { className: l.kind }, el("time", {}, time), l.text));
    }
    queueMicrotask(() => (box.scrollTop = box.scrollHeight));
    return el(
      "div",
      { className: "col", style: "display:flex;flex-direction:column;gap:6px;margin-top:6px" },
      el(
        "div",
        { className: "row" },
        el("b", {}, t("Log", "기록")),
        running ? el("span", { className: "badge run" }, t("Running", "실행 중")) : null,
        el("span", { style: "flex:1" }),
        running ? el("button", { className: "mini", onclick: () => this.host.restart(run) }, t("Restart", "다시 시작")) : null,
        el("button", { className: "mini ghost", onclick: () => this.host.clearLog(run) }, t("Clear", "지우기")),
      ),
      box,
    );
  }

  // ── files ──

  /** Saves items as a Tavern Helper script file. */
  private exportItems(items: LibraryItem[], name: string): void {
    if (!items.length) {
      showToast(t("Nothing to export.", "내보낼 것이 없음."), "warning");
      return;
    }
    // a script's variables may hold an API key or the like: they go into the file only if the person says so
    const withData = hasData(items) && window.confirm(t("Include the scripts' variables? They may hold keys.", "스크립트 변수도 넣을까요? 키 같은 민감한 정보가 있을 수 있어요."));
    const url = URL.createObjectURL(new Blob([exportJson(items, withData)], { type: "application/json" }));
    const a = el("a", { href: url, download: fileName(name) });
    document.body.append(a);
    a.click();
    a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 10_000);
  }

  /** Picks a file (a script file, a card PNG or JSON, a .js) and shows what is in it, to choose from. */
  private importFile(place: ListPlace): void {
    pickFile(async (file) => {
      let found: FoundScripts;
      try {
        found = await scriptsFromFile(file.name, new Uint8Array(await file.arrayBuffer()));
      } catch (e) {
        showToast(t(`Could not read that file: ${e instanceof Error ? e.message : e}`, `그 파일을 읽지 못했어요: ${e instanceof Error ? e.message : e}`), "error");
        return;
      }
      if (!found.items.length) {
        showToast(t("No script found in that file.", "그 파일에서 스크립트를 찾지 못했어요."), "warning");
        return;
      }
      this.edit({ kind: "import", place, found, picked: new Set(found.items.map((_, i) => i)) });
    }, ".json,.zip,.png,.js,.txt");
  }

  private importer(e: Extract<Editing, { kind: "import" }>): HTMLElement {
    const rows = e.found.items.map((item, i) =>
      el(
        "label",
        { className: "item", style: "cursor:pointer" },
        el("input", { type: "checkbox", checked: e.picked.has(i), onchange: (ev: Event) => ((ev.target as HTMLInputElement).checked ? e.picked.add(i) : e.picked.delete(i)) }),
        el("span", { className: "name" }, isFolder(item) ? `${folderIconText(item.icon) || "📁"} ${item.name}` : item.name),
        isFolder(item) ? el("span", { className: "badge" }, t(`${item.scripts.length} script(s)`, `스크립트 ${item.scripts.length}개`)) : null,
      ),
    );
    const target = el(
      "select",
      { "aria-label": t("Into", "넣을 곳") },
      ...this.shown.map((sh) => el("option", { value: placeKey(sh.place), selected: placeKey(sh.place) === placeKey(e.place) }, sh.title)),
    );
    const go = async () => {
      const sh = this.shown.find((x) => placeKey(x.place) === target.value);
      const items = e.found.items.filter((_, i) => e.picked.has(i));
      if (!sh || !items.length) return;
      if (await this.change(sh, (list) => [...list, ...items])) {
        showToast(t(`Imported ${items.length} into ${sh.title}.`, `${sh.title}에 ${items.length}개 가져옴.`), "success");
        this.editing = null;
        this.render();
      }
    };
    return el(
      "div",
      { className: "col", style: "display:flex;flex-direction:column;gap:8px" },
      el("div", { className: "row" }, el("button", { className: "mini ghost", onclick: () => ((this.editing = null), this.render()) }, t("← Back", "← 목록")), el("b", {}, t(`Import from ${e.found.from}`, `${e.found.from}에서 가져오기`))),
      el("div", { className: "note" }, t("Pick what to bring in (as copies).", "가져올 것을 고르세요(복사본으로).")),
      ...rows,
      setting(t("Into", "넣을 곳"), target),
      el("div", { className: "row" }, el("button", { className: "primary", onclick: () => void go() }, t("Import", "가져오기")), el("button", { className: "ghost", onclick: () => ((this.editing = null), this.render()) }, t("Cancel", "취소"))),
    );
  }
}
