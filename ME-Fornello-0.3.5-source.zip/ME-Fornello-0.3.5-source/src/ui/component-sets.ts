// Component files and sets in the settings window: the import picker, export, sets.

import type { FornelloSettings, Settings } from "../settings";
import { t } from "../shared/i18n";
import { type ComponentDef, type ComponentKind, type ComponentSet, newComponentId } from "../components/model";
import { type FoundComponents, bringIn, componentsFromFile, exportComponents } from "../components/files";
import { fileName } from "../scripts/files";
import { saveBlob } from "../shared/capture";
import { helpTip, setting } from "../shared/form";
import { showToast } from "./toast";
import { el } from "./dom";

/** What a file's components wait on: which of them come in, and whether as a set too. */
export interface Importing {
  found: FoundComponents;
  picked: Set<number>;
  asSet: boolean;
}

/** What this part needs from the settings window. */
export interface SetsHost {
  readonly settings: Settings;
  render(): void;
  save(patch: Partial<FornelloSettings>): Promise<boolean>;
  newComponent(code: string, kind: ComponentKind, fileName: string): void;
  closeEditor(): void;
}

export class ComponentSets {
  /** A file's components, waiting for the person to pick what comes in. */
  importing: Importing | null = null;
  /** The set being made or changed. */
  private editingSet: ComponentSet | null = null;

  constructor(private readonly host: SetsHost) {}

  /** Picks a file: one .jsx or .html goes into the editor, others into the picker. */
  importFile(): void {
    const input = document.createElement("input");
    input.type = "file";
    input.accept = ".json,.png,.jsx,.tsx,.js,.html,.htm,.txt";
    input.addEventListener("change", async () => {
      const file = input.files?.[0];
      if (!file) return;
      // one bare .jsx or .html: straight into the editor, to look at before saving
      if (/\.(jsx|tsx|js|txt|html?)$/i.test(file.name)) {
        this.host.newComponent(await file.text(), /\.html?$/i.test(file.name) ? "html" : "jsx", file.name);
        return;
      }
      const found = await componentsFromFile(file.name, new Uint8Array(await file.arrayBuffer())).catch(() => ({ items: [], name: file.name }));
      if (!found.items.length) {
        showToast(t("No component found in that file.", "그 파일에서 컴포넌트를 찾지 못했어요."), "warning");
        return;
      }
      this.host.closeEditor();
      this.editingSet = null;
      this.importing = { found, picked: new Set(found.items.map((_, i) => i)), asSet: found.items.length > 1 };
      this.host.render();
    });
    input.click();
  }
  exportFile(defs: ComponentDef[], name: string, setName = ""): void {
    saveBlob(new Blob([exportComponents(defs, setName)], { type: "application/json" }), fileName(name));
  }
  /** The picker for a file's components: which come in, and whether as a set too. */
  importer(imp: Importing): HTMLElement {
    const mine = this.host.settings.current.components;
    const rows = imp.found.items.map((d, i) =>
      el(
        "label",
        { className: "item", style: "cursor:pointer" },
        el("input", { type: "checkbox", checked: imp.picked.has(i), onchange: (e: Event) => ((e.target as HTMLInputElement).checked ? imp.picked.add(i) : imp.picked.delete(i)) }),
        el("span", { className: "name" }, d.label || d.name),
        el("span", { className: "badge" }, d.kind === "html" ? "HTML" : "JSX"),
        mine.some((c) => c.name === d.name) ? el("span", { className: "badge", title: t("Replaces the one of this name", "같은 이름의 것을 바꿈") }, t("Replaces", "바꿈")) : null,
      ),
    );
    const asSet = el("label", { className: "row", style: "cursor:pointer" }, el("input", { type: "checkbox", checked: imp.asSet, onchange: (e: Event) => (imp.asSet = (e.target as HTMLInputElement).checked) }), t(`Save them as the set "${imp.found.name}" too`, `"${imp.found.name}" 묶음으로도 저장`));
    return el(
      "div",
      { className: "col", style: "margin-top:10px" },
      el("div", { className: "field-h" }, t(`Import from ${imp.found.name}`, `${imp.found.name}에서 불러오기`)),
      el("div", { className: "list" }, ...rows),
      asSet,
      el(
        "div",
        { className: "row" },
        el("button", { className: "primary", onclick: () => void this.bringInPicked(imp) }, t("Import", "불러오기")),
        el("button", { className: "ghost", onclick: () => ((this.importing = null), this.host.render()) }, t("Cancel", "취소")),
      ),
    );
  }
  private async bringInPicked(imp: Importing): Promise<void> {
    const picked = imp.found.items.filter((_, i) => imp.picked.has(i));
    if (!picked.length) return;
    const { list, ids } = bringIn(this.host.settings.current.components, picked);
    // a set of the same name takes in what came (one set, not two)
    const sets = [...this.host.settings.current.componentSets];
    if (imp.asSet) {
      const at = sets.findIndex((x) => x.name === imp.found.name);
      if (at >= 0) sets[at] = { ...sets[at], componentIds: [...new Set([...sets[at].componentIds, ...ids])] };
      else sets.push({ id: newComponentId(), name: imp.found.name, componentIds: ids });
    }
    if (!(await this.host.save({ components: list, componentSets: sets }))) return;
    this.importing = null;
    showToast(t(`Imported ${picked.length} component(s).`, `컴포넌트 ${picked.length}개를 불러왔어요.`), "success");
    this.host.render();
  }
  /** The sets: a named group of components each, to export or to turn on in a chat together. */
  setsBlock(): HTMLElement | null {
    const s = this.host.settings.current;
    if (!s.components.length && !s.componentSets.length) return null;
    const byId = new Map(s.components.map((c) => [c.id, c]));
    const rows = s.componentSets.map((set) =>
      el(
        "div",
        { className: "item" },
        el("span", { className: "name", style: "cursor:default" }, set.name),
        el("span", { className: "badge", title: set.componentIds.map((id) => byId.get(id)?.label || byId.get(id)?.name).join(", ") }, t(`${set.componentIds.length} component(s)`, `컴포넌트 ${set.componentIds.length}개`)),
        el("button", { className: "mini", onclick: () => this.exportFile(set.componentIds.map((id) => byId.get(id)).filter((d): d is ComponentDef => !!d), set.name, set.name) }, t("Export", "내보내기")),
        el("button", { className: "mini", onclick: () => ((this.editingSet = structuredClone(set)), (this.importing = null), this.host.render()) }, t("Edit", "고치기")),
        el("button", { className: "mini ghost", "aria-label": t(`Delete ${set.name}`, `${set.name} 지우기`), onclick: () => void this.removeSet(set) }, "✕"),
      ),
    );
    return el(
      "div",
      {},
      el(
        "div",
        { className: "field-h", style: "margin-top:10px" },
        t("Sets", "묶음"),
        helpTip(
          t("Groups of components to export or switch together", "함께 내보내거나 켜고 끄는 컴포넌트 묶음"),
          t("Sets", "묶음"),
        ),
        el("span", { style: "flex:1" }),
        s.components.length ? el("button", { className: "mini", onclick: () => ((this.editingSet = { id: newComponentId(), name: "", componentIds: [] }), (this.importing = null), this.host.render()) }, t("+ Set", "+ 묶음")) : null,
      ),
      rows.length ? el("div", { className: "list" }, ...rows) : null,
      this.editingSet ? this.setEditor(this.editingSet) : null,
    );
  }
  private setEditor(set: ComponentSet): HTMLElement {
    const name = el("input", { value: set.name, placeholder: t("Set name", "묶음 이름"), "aria-label": t("Set name", "묶음 이름") });
    name.addEventListener("input", () => (set.name = name.value));
    const picks = this.host.settings.current.components.map((c) =>
      el(
        "label",
        { className: "item", style: "cursor:pointer" },
        el("input", { type: "checkbox", checked: set.componentIds.includes(c.id), onchange: (e: Event) => (set.componentIds = (e.target as HTMLInputElement).checked ? [...set.componentIds, c.id] : set.componentIds.filter((id) => id !== c.id)) }),
        el("span", { className: "name" }, c.label || c.name),
        el("span", { className: "badge" }, c.kind === "html" ? "HTML" : "JSX"),
      ),
    );
    return el(
      "div",
      { className: "col", style: "margin-top:6px" },
      setting(t("Set name", "묶음 이름"), name),
      el("div", { className: "list" }, ...picks),
      el(
        "div",
        { className: "row" },
        el("button", { className: "primary", onclick: () => void this.saveSet(set) }, t("Save", "저장")),
        el("button", { className: "ghost", onclick: () => ((this.editingSet = null), this.host.render()) }, t("Cancel", "취소")),
      ),
    );
  }
  private async saveSet(set: ComponentSet): Promise<void> {
    if (!set.name.trim()) {
      showToast(t("Give the set a name.", "묶음 이름을 적어 주세요."), "warning");
      return;
    }
    const sets = [...this.host.settings.current.componentSets];
    const at = sets.findIndex((x) => x.id === set.id);
    const next = { ...set, name: set.name.trim() };
    if (at >= 0) sets[at] = next;
    else sets.push(next);
    if (!(await this.host.save({ componentSets: sets }))) return;
    this.editingSet = null;
    this.host.render();
  }
  private async removeSet(set: ComponentSet): Promise<void> {
    if (!window.confirm(t(`Delete the set "${set.name}"? Its components stay.`, `"${set.name}" 묶음을 지울까요? 컴포넌트는 그대로 남아요.`))) return;
    if (await this.host.save({ componentSets: this.host.settings.current.componentSets.filter((x) => x.id !== set.id) })) this.host.render();
  }
}
