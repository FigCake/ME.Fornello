// Settings for SillyTavern cards' lorebook templates: the person's answers about running a card's
// templates (by their SHA-256; changed templates are asked again), and how long a reply may wait
// for them before it goes on (a template that calls the AI takes a while).

export interface TemplateSettings {
  code: Record<string, boolean>;
  /** seconds */
  wait: number;
}

export const TEMPLATE_WAIT = { min: 5, max: 60 };
export const DEFAULT_TEMPLATES: TemplateSettings = { code: {}, wait: TEMPLATE_WAIT.min };

export function normalizeTemplates(raw: unknown): TemplateSettings {
  const r = (raw && typeof raw === "object" ? raw : {}) as Record<string, unknown>;
  const wait = Number(r.wait);
  return {
    code: Object.fromEntries(Object.entries(r.code && typeof r.code === "object" && !Array.isArray(r.code) ? r.code : {}).filter((e): e is [string, boolean] => typeof e[1] === "boolean")),
    wait: Number.isFinite(wait) && r.wait !== null && r.wait !== "" ? Math.max(TEMPLATE_WAIT.min, Math.min(TEMPLATE_WAIT.max, Math.round(wait))) : TEMPLATE_WAIT.min,
  };
}
