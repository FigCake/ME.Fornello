// Marinara's regex scripts applied as Marinara shows a message, to find the
// pages a card's display regex makes of a reply. A character's scripts apply
// in its chats even when Marinara leaves them off, as in SillyTavern.

import { parseList } from "./api/parse";
import { api } from "./shared/api";

export interface RegexScript {
  id: string;
  name: string;
  order: number;
  enabled: boolean;
  findRegex: string;
  replaceString: string;
  trimStrings: string[];
  placement: string[];
  flags: string;
  display: boolean;
  /** Applied to what goes to the AI. */
  prompt: boolean;
  targetCharacterIds: string[];
  targetPromptPresetIds: string[];
  minDepth: number | null;
  maxDepth: number | null;
}
type Script = RegexScript;

function parse(row: Record<string, unknown>): Script {
  const applyMode = String(row.applyMode ?? (String(row.promptOnly) === "true" ? "prompt" : "display"));
  const num = (v: unknown) => (v === null || v === undefined || v === "" ? null : Number(v));
  return {
    id: String(row.id),
    name: String(row.name ?? ""),
    order: Number(row.order ?? 0),
    enabled: row.enabled === true || row.enabled === "true",
    findRegex: String(row.findRegex ?? ""),
    replaceString: String(row.replaceString ?? ""),
    trimStrings: parseList(row.trimStrings),
    placement: parseList(row.placement),
    flags: String(row.flags ?? ""),
    display: applyMode === "display" || applyMode === "both",
    prompt: applyMode === "prompt" || applyMode === "both",
    targetCharacterIds: parseList(row.targetCharacterIds),
    targetPromptPresetIds: parseList(row.targetPromptPresetIds),
    minDepth: num(row.minDepth),
    maxDepth: num(row.maxDepth),
  };
}

/**
 * $1, $<name> and {{match}} in a replacement, as SillyTavern fills them (trim
 * strings taken out). $& and $$ stay: page code uses them in its own `.replace`.
 */
function expand(template: string, args: unknown[], trim: string[]): string {
  const last = args[args.length - 1];
  const groups = typeof last === "object" && last !== null ? (last as Record<string, string | undefined>) : undefined;
  const count = args.length - (groups ? 3 : 2); // the match and its captures
  return template.replace(/\{\{match\}\}/gi, "$0").replace(/\$(\d+)|\$<([^>]+)>/g, (_, n: string | undefined, name: string | undefined) => {
    const value = n !== undefined ? (Number(n) < count ? args[Number(n)] : undefined) : groups?.[name!];
    if (typeof value !== "string" || !value) return "";
    let out = value;
    for (const t of trim) if (t) out = out.split(t).join("");
    return out;
  });
}

let cache: { at: number; scripts: Promise<Script[]> } | null = null;

/** The scripts are read again next time. */
export function forgetRegexScripts(): void {
  cache = null;
}

export function regexScripts(): Promise<Script[]> {
  if (!cache || Date.now() - cache.at > 30_000) {
    const scripts = api<unknown>("/regex-scripts")
      .then((rows) => (Array.isArray(rows) ? (rows as Record<string, unknown>[]).map(parse) : []))
      .catch(() => []);
    cache = { at: Date.now(), scripts };
  }
  return cache.scripts;
}

export interface RegexTarget {
  role: "user" | "char" | "narrator" | "system";
  /** 0 = the latest message. */
  depth: number;
  /** Characters of the chat (scripts tied to one of them apply). */
  chatCharacters: string[];
  names?: { user: string; char: string };
}

/** The message as the display regex scripts turn it; `pageSources` collects the parts of it that became pages. */
export function applyDisplayRegex(text: string, scripts: Script[], target: RegexTarget, pageSources?: string[]): string {
  return applyRegexScripts(text, scripts, { ...target, mode: "display" }, pageSources);
}

/** Text as the regex scripts for screen ("display") or for the AI ("prompt") turn it. */
export function applyRegexScripts(text: string, scripts: Script[], target: RegexTarget & { mode: "display" | "prompt"; presetId?: string | null }, pageSources?: string[]): string {
  const placement = target.role === "user" ? "user_input" : "ai_output";
  let result = text;
  for (const s of scripts) {
    if (!s.enabled || !(target.mode === "display" ? s.display : s.prompt) || !s.findRegex || !s.placement.includes(placement)) continue;
    if (s.targetCharacterIds.length && !s.targetCharacterIds.some((id) => target.chatCharacters.includes(id))) continue;
    // scripts for one prompt preset, when the preset is known (the chat on screen leaves this to Marinara)
    if (s.targetPromptPresetIds.length && target.presetId !== undefined && !(target.presetId && s.targetPromptPresetIds.includes(target.presetId))) continue;
    if (s.minDepth !== null && target.depth < s.minDepth) continue;
    if (s.maxDepth !== null && target.depth > s.maxDepth) continue;
    let re: RegExp;
    try {
      re = new RegExp(s.findRegex, s.flags);
    } catch {
      continue;
    }
    const names = target.names;
    const macros = (t: string) => (names ? t.replace(/\{\{user\}\}/gi, names.user).replace(/\{\{char\}\}/gi, names.char) : t);
    result = result.replace(re, (...args: unknown[]) => {
      const out = macros(expand(s.replaceString, args, s.trimStrings));
      // the part of the reply that became a page (the screen still shows it as text)
      const matched = String(args[0]);
      if (pageSources && out.includes("```") && text.includes(matched)) pageSources.push(matched);
      return out;
    });
  }
  return result;
}
