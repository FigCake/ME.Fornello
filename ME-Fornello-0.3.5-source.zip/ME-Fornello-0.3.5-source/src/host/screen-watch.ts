// One observer of Marinara's screen for all of Fornello; changes are handed
// out once per frame.

type Listener = () => void;

/** `fn`, run on the next frame: calls before then add up to one run. */
export function oncePerFrame(fn: () => void): () => void {
  let queued = false;
  return () => {
    if (queued) return;
    queued = true;
    requestAnimationFrame(() => {
      queued = false;
      fn();
    });
  };
}

const listeners = new Set<Listener>();
let observer: MutationObserver | null = null;

const notify = oncePerFrame(() => {
  for (const fn of [...listeners]) {
    try {
      fn();
    } catch (e) {
      console.warn("[Fornello]", e);
    }
  }
});

/** Elements added or removed anywhere; text changed only inside a message (a swipe may reuse its text nodes). */
function matters(records: MutationRecord[]): boolean {
  return records.some((r) => r.type === "childList" || !!r.target.parentElement?.closest("[data-message-id]"));
}

/** Calls `fn` (at most once a frame) after anything on the page changed; returns the way to stop. */
export function onScreenChange(fn: Listener): () => void {
  listeners.add(fn);
  if (!observer) {
    observer = new MutationObserver((records) => {
      if (matters(records)) notify();
    });
    observer.observe(document.body, { childList: true, subtree: true, characterData: true });
  }
  return () => {
    listeners.delete(fn);
    if (!listeners.size) {
      observer?.disconnect();
      observer = null;
    }
  };
}
