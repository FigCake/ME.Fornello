// The settings shown at the top of the character assets tab and the Status tab: how pictures show,
// Pesto, and the chat's cards' SillyTavern templates. Each change redraws the tab they are in.

import { listConnections } from "../api/marinara";
import { ASSET_WIDTH, type AssetDisplay, type ExpressionPlace, type RulePlace } from "../assets/display";
import { PER_REPLY } from "../assets/rule";
import type { TemplateEntry, TemplateService } from "../ejs/service";
import { TEMPLATE_WAIT } from "../ejs/settings";
import type { FornelloSettings, Settings } from "../settings";
import { section, setting, toggle } from "../shared/form";
import { t } from "../shared/i18n";
import { STORY_DEPTH, STORY_WRITERS, type StorySettings, type StoryWriter } from "../state/settings";
import { currentChatId } from "../host/current-chat";
import { el } from "./dom";
import { showToast } from "./toast";

const WRITER_LABELS: Record<StoryWriter, () => string> = {
  ai: () => t("This chat's connection", "현재 연결"),
  fill: () => t("This chat's connection + a helper model when missing", "현재 연결 + 누락 시 보조 모델"),
  helper: () => t("A helper model", "보조 모델"),
};

/** A toggle that can't be changed while `off` (Pesto itself off). */
function offWhen(off: boolean, label: HTMLLabelElement): HTMLLabelElement {
  const input = label.querySelector("input");
  if (input) input.disabled = off;
  return label;
}

export class SettingsParts {
  /** SillyTavern cards' lorebook templates (main.ts sets it). */
  templates: TemplateService | null = null;
  /** Draws the tab these parts are in again. */
  redraw: () => void = () => undefined;
  /** The open chat's cards' templates (null: not read yet). */
  private ejs: { chatId: string; entries: TemplateEntry[] } | null = null;
  private ejsReading = false;
  /** The saved connections, read once the helper model is turned on (null: not read yet). */
  private connections: { id: string; name: string }[] | null = null;
  private connectionsRead = false;
  private timer: ReturnType<typeof setTimeout> | null = null;

  constructor(private readonly settings: Settings) {}

  private renderSoon(): void {
    if (this.timer) clearTimeout(this.timer);
    this.timer = setTimeout(() => {
      this.timer = null;
      this.redraw();
    }, 0);
  }

  private render(): void {
    this.redraw();
  }

  private async save(patch: Partial<FornelloSettings>): Promise<boolean> {
    try {
      await this.settings.set(patch);
      return true;
    } catch (e) {
      showToast(t(`Could not save settings: ${e instanceof Error ? e.message : String(e)}`, `설정 저장 실패: ${e instanceof Error ? e.message : String(e)}`), "error");
      return false;
    }
  }

  /** Character assets in chat (the assets tab's top): tags, the expression sprite, pictures shown by words. */
  assetsSection(): HTMLElement {
    const a = this.settings.current.assets;
    // from what is saved now (the panel isn't redrawn between two changes), then redrawn for the enabled controls
    const set = (patch: Partial<AssetDisplay>) =>
      void this.save({ assets: { ...this.settings.current.assets, ...patch } }).then((ok) => ok && this.renderSoon());
    const expressions = el(
      "select",
      { "aria-label": t("Expression sprite", "표정 그림"), "data-key": "asset-expressions", onchange: (e: Event) => set({ expressions: (e.target as HTMLSelectElement).value as ExpressionPlace }) },
      el("option", { value: "off", selected: a.expressions === "off" }, t("Off", "끄기")),
      el("option", { value: "above", selected: a.expressions === "above" }, t("Above the reply", "답변 위")),
      el("option", { value: "below", selected: a.expressions === "below" }, t("Below the reply", "답변 아래")),
    );
    const width = el("input", {
      type: "number",
      className: "num",
      min: String(ASSET_WIDTH.min),
      max: String(ASSET_WIDTH.max),
      step: "20",
      value: String(a.width),
      "aria-label": t("Picture width", "그림 너비"),
      "data-key": "asset-width",
      onchange: (e: Event) => {
        const input = e.target as HTMLInputElement;
        const w = Math.max(ASSET_WIDTH.min, Math.min(ASSET_WIDTH.max, Math.round(Number(input.value)) || a.width));
        input.value = String(w);
        set({ width: w });
      },
    });
    const tell = el(
      "select",
      { "aria-label": t("Tell the AI the names", "AI에게 이름 알려 주기"), "data-key": "asset-tell", disabled: !a.tags, onchange: (e: Event) => set({ tell: (e.target as HTMLSelectElement).value as RulePlace }) },
      el("option", { value: "card", selected: a.tell === "card" }, t("In each card's lorebook", "카드 로어북에")),
      el("option", { value: "chat", selected: a.tell === "chat" }, t("In this chat's lorebook", "채팅 로어북에")),
      el("option", { value: "off", selected: a.tell === "off" }, t("Don't", "알려 주지 않기")),
    );
    const perReply = el("input", {
      type: "number",
      className: "num",
      min: String(PER_REPLY.min),
      max: String(PER_REPLY.max),
      value: String(a.perReply),
      disabled: !a.tags || a.tell === "off",
      "aria-label": t("Most pictures per reply", "답변당 최대 그림 수"),
      "data-key": "asset-per-reply",
      onchange: (e: Event) => {
        const input = e.target as HTMLInputElement;
        const n = Math.max(PER_REPLY.min, Math.min(PER_REPLY.max, Math.round(Number(input.value)) || a.perReply));
        input.value = String(n);
        set({ perReply: n });
      },
    });
    return section(
      t("Character assets", "캐릭터 에셋"),
      t("Pictures of the chat's characters (their Gallery and sprites) in replies", "채팅 캐릭터의 그림(갤러리·스프라이트)을 답변에 보여 줘요"),
      [],
      setting(
        t("Picture tags", "그림 태그"),
        toggle(a.tags, (v) => set({ tags: v }), t("Picture tags", "그림 태그"), "asset-tags"),
        t(
          "[img:name] or [img:person:name] in a reply becomes the picture, after its paragraph. Other cards' {{img::name}} and {{raw::name}} work too",
          "답변의 [img:이름]·[img:인물:이름]이 그 문단 뒤에 그림으로 나와요. 다른 카드의 {{img::이름}}·{{raw::이름}}도 돼요",
        ),
      ),
      setting(
        t("Tell the AI the names", "AI에게 이름 알려 주기"),
        tell,
        t(
          "An always-on lorebook entry named \"Credenza\" lists the picture names. In a card's lorebook it travels with the card (only cards with assets get one); an entry you edit is left as it is",
          "\"Credenza\" 로어북 항목(항상 켜짐)에 그림 이름을 적어요. 카드 로어북에 두면 카드와 함께 내보내져요(에셋이 있는 카드만). 직접 고친 항목은 그대로 둬요",
        ),
      ),
      setting(t("Most pictures per reply", "답변당 최대 그림 수"), perReply, t("What the AI is asked; it may put fewer", "AI에게 부탁하는 수예요. 더 적게 넣을 수도 있어요")),
      setting(
        t("Expression sprite", "표정 그림"),
        expressions,
        t("The expression Marinara's Expression agent chose for the reply (the agent must be on)", "마리나라 표정 에이전트가 고른 표정 (에이전트를 켜야 해요)"),
      ),
      setting(
        t("Pictures by words", "단어로 보이는 그림"),
        toggle(a.words, (v) => set({ words: v }), t("Pictures by words", "단어로 보이는 그림"), "asset-words"),
        t("An asset with words shows under a reply that uses one of them, without the AI knowing", "단어를 달아 둔 에셋은 답변에 그 단어가 나오면 아래에 보여요. AI는 몰라도 돼요"),
      ),
      setting(t("Picture width", "그림 너비"), width, t("The widest a picture shows; a click shows it full size", "그림의 최대 너비. 누르면 원래 크기로 보여요")),
    );
  }

  /** Pesto (the Status tab's top): values a card's schema keeps, worked out from the replies and shown to the AI. */
  storySection(): HTMLElement {
    const st = this.settings.current.story;
    const set = (patch: Partial<StorySettings>) => void this.save({ story: { ...this.settings.current.story, ...patch } }).then((ok) => ok && this.renderSoon());
    const depth = el("input", {
      type: "number",
      className: "num",
      min: String(STORY_DEPTH.min),
      max: String(STORY_DEPTH.max),
      value: String(st.depth),
      disabled: !st.on,
      "aria-label": t("Where the values go", "값을 넣을 위치"),
      "data-key": "story-depth",
      onchange: (e: Event) => {
        const input = e.target as HTMLInputElement;
        const n = Math.max(STORY_DEPTH.min, Math.min(STORY_DEPTH.max, Math.round(Number(input.value))));
        const value = Number.isFinite(n) ? n : st.depth;
        input.value = String(value);
        set({ depth: value });
      },
    });
    return section(
      t("Pesto", "Pesto"),
      t(
        "For cards that bring a schema (lorebook entries pesto:schema, pesto:start, pesto:rules): Fornello keeps the story's values, the AI only reports what changed",
        "스키마를 가진 카드용이에요(로어북 항목 pesto:schema, pesto:start, pesto:rules). 이야기의 값은 Fornello가 계산하고, AI는 바뀐 것만 알려요",
      ),
      [],
      setting(
        t("Pesto", "Pesto"),
        toggle(st.on, (v) => set({ on: v }), t("Pesto", "Pesto"), "story-on"),
        t(
          "Before each reply the values and how to report changes go into this chat's lorebook; the AI's change blocks are hidden by a Marinara regex script, \"Fornello: Pesto blocks\" (removed when this is turned off)",
          "답변마다 현재 값과 바꾸는 법을 채팅 로어북에 넣어요. AI가 쓴 변경 블록은 마리나라 정규식 \"Fornello: Pesto blocks\"로 숨겨요(끄면 지워져요)",
        ),
      ),
      setting(
        t("Where the values go", "값을 넣을 위치"),
        depth,
        t("How many messages from the end of the chat (0: after the last one)", "채팅 끝에서 몇 번째 메시지 앞인지 (0: 마지막 메시지 뒤)"),
      ),
      setting(
        t("SillyTavern variable cards too", "실리태번 변수 카드도 읽기"),
        offWhen(!st.on, toggle(st.others, (v) => set({ others: v }), t("SillyTavern variable cards too", "실리태번 변수 카드도 읽기"), "story-others")),
        t(
          "A card without pesto:schema that brings its starting values (\"[InitVar]\" lorebook entries, or <VariableInsert> tags in its first message): its values are read from them, and its own update tags count",
          "pesto:schema가 없어도 시작값을 가진 카드(로어북 \"[InitVar]\" 항목, 또는 첫 메시지의 <VariableInsert> 태그)면 그 값으로 읽고, 카드 방식의 변경 태그도 반영해요",
        ),
      ),
      setting(
        t("Recording changes", "변경 사항 기록"),
        el(
          "select",
          { "aria-label": t("Recording changes", "변경 사항 기록"), "data-key": "story-writer", disabled: !st.on, onchange: (e: Event) => set({ writer: (e.target as HTMLSelectElement).value as StoryWriter }) },
          ...STORY_WRITERS.map((w) => el("option", { value: w, selected: w === st.writer }, WRITER_LABELS[w]())),
        ),
        t(
          "The AI ends each reply with a change block. With a helper model, a reply that has none is read by that model, which writes the block (one more call each time); \"the helper model\" doesn't ask the AI for blocks at all, so replies stay all story",
          "AI가 답장 끝에 변경 블록을 써요. 보조 모델을 고르면 블록 없는 답장을 그 모델이 읽고 블록을 써요(그때마다 호출 한 번 더). \"보조 모델\"은 AI에게 블록을 아예 부탁하지 않아서 답장이 이야기만으로 채워져요",
        ),
      ),
      st.writer !== "ai" ? setting(t("Helper model", "보조 모델"), this.connectionPicker(st, set), t("A cheap, quick connection is enough", "싸고 빠른 연결이면 충분해요")) : null,
      setting(
        t("Use the values as chat variables", "값을 채팅 변수로 쓰기"),
        offWhen(!st.on, toggle(st.vars, (v) => set({ vars: v }), t("Use the values as chat variables", "값을 채팅 변수로 쓰기"), "story-vars")),
        t(
          "Before each reply the values become this chat's variables, named \"story_\" and their path (\"story_hp\"), so the card's prompts and lorebook entries can use {{getvar::story_hp}} and {{#if var:story_hp < 10}}…{{/if}}. The Pesto window shows each value's name",
          "답변마다 값을 이 채팅의 변수로 넣어요. 이름은 \"story_\"와 경로예요(\"story_hp\"). 그래서 카드의 프롬프트·로어북에서 {{getvar::story_hp}}, {{#if var:story_hp < 10}}…{{/if}}처럼 쓸 수 있어요. 값마다 변수 이름은 Pesto 창에서 볼 수 있어요",
        ),
      ),
      setting(
        t("Show the values in the tracker", "트래커에 값 보이기"),
        offWhen(!st.on, toggle(st.tracker, (v) => set({ tracker: v }), t("Show the values in the tracker", "트래커에 값 보이기"), "story-tracker")),
        t(
          "The values also go in the tracker's World panel, as custom fields named by their paths, on the last reply (the tracker's other fields stay as they are)",
          "값을 트래커의 월드 패널에도 경로 이름의 사용자 필드로 넣어요. 마지막 답장 기준이고, 트래커의 다른 필드는 그대로 둬요",
        ),
      ),
    );
  }

  /** The helper model's connection: the chat's own, or one of the saved ones. */
  private connectionPicker(st: StorySettings, set: (patch: Partial<StorySettings>) => void): HTMLElement {
    if (!this.connectionsRead) {
      this.connectionsRead = true;
      void listConnections()
        .then((list) => (this.connections = list))
        .catch((e) => {
          console.warn("[Fornello] connections", e);
          this.connections = [];
        })
        .finally(() => this.renderSoon());
    }
    const list = this.connections ?? [];
    // a connection that is gone stays shown, so the choice isn't changed without the person
    const missing = st.fillWith && this.connections && !list.some((c) => c.id === st.fillWith);
    return el(
      "select",
      { "aria-label": t("Helper model", "보조 모델"), "data-key": "story-fill-with", disabled: !st.on, onchange: (e: Event) => set({ fillWith: (e.target as HTMLSelectElement).value }) },
      el("option", { value: "", selected: !st.fillWith }, t("This chat's connection", "이 채팅의 연결")),
      ...list.map((c) => el("option", { value: c.id, selected: c.id === st.fillWith }, c.name)),
      missing ? el("option", { value: st.fillWith, selected: true }, t("(a connection that is gone)", "(없어진 연결)")) : null,
      !this.connections && st.fillWith ? el("option", { value: st.fillWith, selected: true }, t("Reading…", "읽는 중…")) : null,
    );
  }

  /** The open chat's cards' lorebook templates (the Status tab): converting them, putting them back, the wait. */
  templatesSection(): HTMLElement | null {
    const service = this.templates;
    const chatId = currentChatId();
    if (!service || !chatId) return null;
    if ((!this.ejs || this.ejs.chatId !== chatId) && !this.ejsReading) {
      this.ejsReading = true;
      void service
        .scan(chatId)
        .then((entries) => (this.ejs = { chatId, entries }))
        .catch((e) => {
          console.warn("[Fornello] templates", e);
          this.ejs = { chatId, entries: [] };
        })
        .finally(() => {
          this.ejsReading = false;
          this.renderSoon();
        });
    }
    const ejs = this.ejs;
    const entries = ejs?.chatId === chatId ? ejs.entries : null;
    if (entries && !entries.length) return null;
    const tpl = this.settings.current.templates;
    const reread = () => {
      this.ejs = null;
      this.renderSoon();
    };
    const convert = async () => {
      const run = (entries ?? []).filter((e) => e.mode === "run" && (!e.converted || !e.allowed));
      const allowRun =
        run.length > 0 &&
        window.confirm(
          t(
            `${run.length} of these templates are more than conditions: Fornello would run them (JavaScript, in a Worker cut off from the network, with the page commands' usual checks) before each reply of chats with this card. Run them? (Cancel converts only the conditions.)`,
            `이 중 ${run.length}개는 조건문 이상이라, 이 카드의 채팅에서 답장마다 Fornello가 실행해요(자바스크립트, 네트워크가 막힌 Worker, 페이지 명령은 평소 확인을 거쳐요). 실행할까요? (취소하면 조건문만 바꿔요.)`,
          ),
        );
      try {
        const done = await service.convert(chatId, allowRun);
        showToast(t(`Converted: ${done.macro} as Marinara's conditions, ${done.run} to run.`, `변환했어요: 마리나라 조건문 ${done.macro}개, 실행 ${done.run}개.`), "info");
      } catch (e) {
        showToast(e instanceof Error ? e.message : String(e), "error");
      }
      reread();
    };
    const restore = async () => {
      try {
        const n = await service.restore(chatId);
        showToast(t(`Put back: ${n} entries.`, `되돌렸어요: 항목 ${n}개.`), "info");
      } catch (e) {
        showToast(e instanceof Error ? e.message : String(e), "error");
      }
      reread();
    };
    const wait = el("input", {
      type: "number",
      className: "num",
      min: String(TEMPLATE_WAIT.min),
      max: String(TEMPLATE_WAIT.max),
      value: String(tpl.wait),
      "aria-label": t("Longest wait before a reply (seconds)", "답장 전 최대 대기(초)"),
      "data-key": "templates-wait",
      onchange: (e: Event) => {
        const input = e.target as HTMLInputElement;
        const n = Math.max(TEMPLATE_WAIT.min, Math.min(TEMPLATE_WAIT.max, Math.round(Number(input.value)) || TEMPLATE_WAIT.min));
        input.value = String(n);
        void this.save({ templates: { ...this.settings.current.templates, wait: n } });
      },
    });
    const mode = (e: TemplateEntry) => (e.mode === "macro" ? t("Marinara's conditions", "마리나라 조건문") : t("run by Fornello", "Fornello가 실행"));
    const list = (entries ?? []).map((e) =>
      el("li", {}, `${e.name || e.id}: ${mode(e)}${e.converted ? t(" · converted", " · 변환됨") : ""}${e.converted && e.mode === "run" && !e.allowed ? t(" · not allowed to run", " · 실행 허락 안 됨") : ""}${!e.converted && e.why ? ` (${e.why})` : ""}`),
    );
    return section(
      t("SillyTavern templates", "실리태번 템플릿"),
      t(
        "Lorebook entries of this chat's cards written with <% %> templates. Converting changes their text in place (their keys and place stay; the first text is kept to put back): conditions become Marinara's {{#if}}, the rest Fornello runs before each reply",
        "이 채팅 카드의 로어북 중 <% %> 템플릿으로 쓴 항목이에요. 변환하면 항목 글만 바뀌어요(키·위치는 그대로, 원래 글은 되돌릴 수 있게 보관). 조건문은 마리나라 {{#if}}로, 나머지는 답장마다 Fornello가 실행해요",
      ),
      [
        ...(entries?.some((e) => !e.converted || (e.mode === "run" && !e.allowed)) ? [el("button", { className: "mini", "data-key": "templates-convert", onclick: () => void convert() }, t("Convert", "변환"))] : []),
        ...(entries?.some((e) => e.converted) ? [el("button", { className: "mini", "data-key": "templates-restore", onclick: () => void restore() }, t("Put back", "되돌리기"))] : []),
      ],
      entries ? el("ul", { className: "note", style: "margin:0;padding-left:18px" }, ...list) : el("div", { className: "note" }, t("Reading…", "읽는 중…")),
      setting(t("Longest wait before a reply", "답장 전 최대 대기"), wait, t("Seconds a reply may wait for the templates (and Fornello's other work before it); a template that calls the AI needs more", "템플릿(과 답장 전 Fornello의 다른 일)을 기다리는 최대 초예요. AI를 부르는 템플릿은 더 필요해요")),
    );
  }
}
